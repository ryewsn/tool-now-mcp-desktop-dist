"""ServiceNow MCP Server - Modular debugging tools for ServiceNow"""

import tomllib
import pathlib

# Read version from pyproject.toml to preserve exact format (YYYY.MM.DD.XX with
# leading zeros). importlib.metadata normalises versions per PEP 440, stripping
# leading zeros, so we always read the authoritative source directly.
_toml = pathlib.Path(__file__).resolve().parent.parent / "pyproject.toml"
with open(_toml, "rb") as _f:
    __version__ = tomllib.load(_f)["project"]["version"]
