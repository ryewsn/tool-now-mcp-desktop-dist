from __future__ import annotations
import json
import tomllib
import urllib.request
from pathlib import Path

_VERSION_URL = "https://raw.githubusercontent.com/ryewsn/tool-now-mcp-desktop-dist/main/version.json"
SERVER_FILES_URL = "https://github.com/ryewsn/tool-now-mcp-desktop-dist/raw/main/server-files-latest.zip"
_TIMEOUT = 3


def _read_current_version() -> str:
    pyproject = Path(__file__).parents[2] / "pyproject.toml"
    with open(pyproject, "rb") as f:
        data = tomllib.load(f)
    return data["project"]["version"]


def _fetch_latest_version() -> str | None:
    try:
        req = urllib.request.Request(
            _VERSION_URL,
            headers={"User-Agent": "servicenow-mcp-update-check"},
        )
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            data = json.loads(resp.read())
        return data["version"]
    except Exception:
        return None


def _build_notice() -> str | None:
    try:
        current = _read_current_version()
        latest = _fetch_latest_version()
        if latest and latest != current:
            return (
                f"\n\n---\n⚠️  ServiceNow MCP update available: {latest}\n"
                'Say "update ServiceNow MCP" to install it.'
            )
    except Exception:
        pass
    return None


update_notice: str | None = _build_notice()
