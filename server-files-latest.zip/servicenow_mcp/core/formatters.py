"""Output Formatting Utilities"""

from typing import List, Dict, Any

def format_error(status_code: int, error_message: str) -> str:
    """Format error responses consistently."""
    return f"Error: {status_code} - {error_message}"
