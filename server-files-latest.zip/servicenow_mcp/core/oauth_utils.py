"""OAuth and OpenAPI Utilities

Utilities for parsing OpenAPI specifications and extracting OAuth configuration
for automated ServiceNow integration setup.

Supports OpenAPI/Swagger specs (JSON/YAML). For non-OpenAPI documentation,
Claude Desktop reads and extracts OAuth configuration before calling tools.
"""

import json
import requests
from typing import Dict, List, Any, Optional


class OpenAPIParseError(Exception):
    """Exception raised when OpenAPI spec parsing fails."""
    pass




def fetch_spec_from_url(url: str) -> str:
    """
    Fetch OpenAPI specification from a URL.

    Args:
        url: URL to the OpenAPI spec (JSON or YAML)

    Returns:
        OpenAPI spec content as string

    Raises:
        OpenAPIParseError: If URL is unreachable or returns error
    """
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        raise OpenAPIParseError(f"Failed to fetch OpenAPI spec from {url}: {e}")


def parse_openapi_spec(spec_content: str, spec_type: str = "url") -> Dict[str, Any]:
    """
    Parse OpenAPI specification and extract key information.

    Args:
        spec_content: OpenAPI spec content (URL, JSON string, or file path)
        spec_type: Type of spec_content - "url", "content", or "filepath"

    Returns:
        Dictionary containing:
        - name: API name from info.title
        - base_url: Base URL from servers
        - token_url: OAuth token endpoint
        - auth_url: OAuth authorization endpoint (if present)
        - scopes: Dictionary of available OAuth scopes
        - grant_type: Detected OAuth grant type
        - description: API description

    Raises:
        OpenAPIParseError: If spec is invalid or required info missing
    """
    # Step 1: Get spec content
    if spec_type == "url":
        spec_content = fetch_spec_from_url(spec_content)
    elif spec_type == "filepath":
        # TODO: Implement ServiceNow attachment retrieval
        raise OpenAPIParseError("File path spec retrieval not yet implemented")

    # Step 2: Parse JSON or YAML
    try:
        spec_data = json.loads(spec_content)
    except json.JSONDecodeError:
        # Try YAML parsing
        try:
            import yaml
            spec_data = yaml.safe_load(spec_content)
        except ImportError:
            raise OpenAPIParseError(
                "Spec appears to be YAML but pyyaml not installed. "
                "Install with: pip install pyyaml"
            )
        except yaml.YAMLError as e:
            raise OpenAPIParseError(f"Invalid JSON/YAML format: {e}")

    # Step 3: Extract basic info
    if not isinstance(spec_data, dict):
        raise OpenAPIParseError("Invalid OpenAPI spec: root must be an object")

    result = {
        "name": spec_data.get("info", {}).get("title", "Unnamed API"),
        "description": spec_data.get("info", {}).get("description", ""),
        "version": spec_data.get("info", {}).get("version", ""),
        "base_url": None,
        "token_url": None,
        "auth_url": None,
        "scopes": {},
        "grant_type": None
    }

    # Step 4: Extract base URL from servers
    servers = spec_data.get("servers", [])
    if servers and len(servers) > 0:
        result["base_url"] = servers[0].get("url", "")

    # Step 5: Extract OAuth configuration from security schemes
    security_schemes = spec_data.get("components", {}).get("securitySchemes", {})

    for scheme_name, scheme in security_schemes.items():
        if scheme.get("type") == "oauth2":
            # Extract OAuth flows
            flows = scheme.get("flows", {})

            # Check for different grant types
            if "clientCredentials" in flows:
                flow = flows["clientCredentials"]
                result["token_url"] = flow.get("tokenUrl")
                result["scopes"] = flow.get("scopes", {})
                result["grant_type"] = "client_credentials"

            elif "authorizationCode" in flows:
                flow = flows["authorizationCode"]
                result["token_url"] = flow.get("tokenUrl")
                result["auth_url"] = flow.get("authorizationUrl")
                result["scopes"] = flow.get("scopes", {})
                result["grant_type"] = "authorization_code"

            elif "password" in flows:
                flow = flows["password"]
                result["token_url"] = flow.get("tokenUrl")
                result["scopes"] = flow.get("scopes", {})
                result["grant_type"] = "password"

            elif "implicit" in flows:
                flow = flows["implicit"]
                result["auth_url"] = flow.get("authorizationUrl")
                result["scopes"] = flow.get("scopes", {})
                result["grant_type"] = "implicit"

            # Found OAuth config, stop looking
            if result["grant_type"]:
                break

    return result


def detect_oauth_grant_type(security_scheme: Dict[str, Any]) -> Optional[str]:
    """
    Detect OAuth grant type from security scheme.

    Args:
        security_scheme: Security scheme definition from OpenAPI spec

    Returns:
        Grant type string or None if not OAuth
    """
    if security_scheme.get("type") != "oauth2":
        return None

    flows = security_scheme.get("flows", {})

    if "clientCredentials" in flows:
        return "client_credentials"
    elif "authorizationCode" in flows:
        return "authorization_code"
    elif "password" in flows:
        return "password"
    elif "implicit" in flows:
        return "implicit"

    return None


def extract_endpoints(spec_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract API endpoints from OpenAPI paths.

    Args:
        spec_data: Parsed OpenAPI specification

    Returns:
        List of endpoint dictionaries with path, method, summary, etc.
    """
    endpoints = []
    paths = spec_data.get("paths", {})

    for path, path_item in paths.items():
        for method in ["get", "post", "put", "patch", "delete", "options", "head"]:
            if method in path_item:
                operation = path_item[method]
                endpoints.append({
                    "path": path,
                    "method": method.upper(),
                    "summary": operation.get("summary", ""),
                    "description": operation.get("description", ""),
                    "operation_id": operation.get("operationId", "")
                })

    return endpoints


def format_scopes_for_servicenow(scopes: Dict[str, str]) -> str:
    """
    Format OAuth scopes dictionary as space-separated string.

    Args:
        scopes: Dictionary of scope name -> description

    Returns:
        Space-separated scope names
    """
    return " ".join(scopes.keys())
