"""Anonymous usage telemetry — fire-and-forget tool call metrics.

Emits one event per tool call to an internal ServiceNow Scripted REST API.
Disable by setting SNMCP_TELEMETRY=false in .env.
Failures are silently swallowed — telemetry must never degrade the tool experience.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Sequence

import httpx
from mcp.types import TextContent

from servicenow_mcp import __version__
from servicenow_mcp.config.settings import get_config

logger = logging.getLogger(__name__)

_ENDPOINT_CONFIG_URL = "https://raw.githubusercontent.com/ryewsn/tool-now-mcp-desktop-dist/main/telemetry-config.json"
# Safety net if the dynamic lookup fails. Must point at a live instance running the
# self-aware relay ingest script (see Phase 3 of the design doc) — never zyew2,
# which is a known short-lived instance. A stale-but-relay-capable target still
# forwards correctly, so this doesn't need to be refreshed on every switch.
_FALLBACK_ENDPOINT = "https://ayew3.service-now.com/api/snc/ingest/event?api_key=4b6ae1d9c1938c0b1a0f7d60d7ac39cf"
_ENV_ENDPOINT = os.getenv("SNMCP_TELEMETRY_ENDPOINT")
_resolved_endpoint: str | None = None
ENABLED = os.getenv("SNMCP_TELEMETRY", "true").lower() != "false"
_raw_install_id = os.getenv("SNMCP_INSTALL_ID", "unknown")
# Normalize to 5 lowercase alphanumeric chars. Strips dashes from legacy UUID-format
# IDs (e.g. "529e7a54-cda4-...") so they fit within PA's breakdown ELEMENT column.
INSTALL_ID = (
    "".join(c for c in _raw_install_id.lower() if c.isalnum())[:5]
    if _raw_install_id != "unknown"
    else "unknown"
)
CLIENT = os.getenv("SNMCP_CLIENT", "unknown")

if INSTALL_ID == "unknown":
    logger.warning(
        "SNMCP_INSTALL_ID not set — run 'python3 configure.py' to generate one"
    )


def _is_error(result: Sequence) -> bool:
    """Return True if the tool result is an error response."""
    for block in result:
        if isinstance(block, TextContent) and block.text.startswith("Error"):
            return True
    return False


def _resolve_instance_alias(instance: str | None) -> str:
    if instance:
        return instance
    try:
        return get_config().default_instance or "default"
    except Exception:
        return "default"


async def _get_endpoint() -> str:
    """Resolve the current telemetry endpoint: env override > cached fetch > dist-repo
    JSON lookup > baked-in fallback. The network fetch happens at most once per process."""
    global _resolved_endpoint
    if _ENV_ENDPOINT:
        return _ENV_ENDPOINT
    if _resolved_endpoint is not None:
        return _resolved_endpoint
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            response = await client.get(_ENDPOINT_CONFIG_URL)
            response.raise_for_status()
            _resolved_endpoint = response.json()["endpoint"]
    except Exception:
        logger.debug("Telemetry endpoint lookup failed, using fallback")
        _resolved_endpoint = _FALLBACK_ENDPOINT
    return _resolved_endpoint


async def emit_event(
    tool: str,
    result: Sequence,
    arguments: dict[str, Any],
    duration_ms: int,
) -> None:
    """POST a usage event. Fire-and-forget — never raises."""
    if not ENABLED:
        return
    payload = {
        "install_id": INSTALL_ID,
        "tool": tool,
        "success": not _is_error(result),
        "duration_ms": duration_ms,
        "instance_alias": _resolve_instance_alias(arguments.get("instance")),
        "client": CLIENT,
        "server_version": __version__,
    }
    try:
        endpoint = await _get_endpoint()
        async with httpx.AsyncClient(timeout=5.0) as client:
            await client.post(endpoint, json=payload)
    except Exception:
        logger.debug("Telemetry emit failed for tool %s", tool)
