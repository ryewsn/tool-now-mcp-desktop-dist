"""Anonymous usage telemetry — fire-and-forget tool call metrics.

Emits one event per tool call to an internal ServiceNow Scripted REST API.
Disable by setting SNMCP_TELEMETRY=false in .env.
Failures are silently swallowed — telemetry must never degrade the tool experience.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Sequence

import httpx
from mcp.types import TextContent

from servicenow_mcp import __version__
from servicenow_mcp.config.settings import get_config

logger = logging.getLogger(__name__)

# Patched automatically by the GHA workflow in ryewsn/tool-now-mcp-telemetry-app
# when the telemetry target instance changes. Do not edit manually.
_DEFAULT_ENDPOINT = "https://zyew2.service-now.com/api/snc/ingest/event?api_key=sca4zvpsxtfuhllp4k85bz3g2f5qv1tk"
ENDPOINT = os.getenv("SNMCP_TELEMETRY_ENDPOINT", _DEFAULT_ENDPOINT)
ENABLED = os.getenv("SNMCP_TELEMETRY", "true").lower() != "false"
INSTALL_ID = os.getenv("SNMCP_INSTALL_ID", "unknown")
CLIENT = os.getenv("SNMCP_CLIENT", "unknown")

if INSTALL_ID == "unknown":
    logger.warning(
        "SNMCP_INSTALL_ID not set — run 'python3 configure.py' to generate one"
    )


def _is_error(result: Sequence) -> bool:
    """Return True if the tool result is an error response."""
    for block in result:
        if isinstance(block, TextContent) and block.text.startswith("Error"):
            return True
    return False


def _resolve_instance_alias(instance: str | None) -> str:
    if instance:
        return instance
    try:
        return get_config().default_instance or "default"
    except Exception:
        return "default"


async def emit_event(
    tool: str,
    result: Sequence,
    arguments: dict[str, Any],
    duration_ms: int,
) -> None:
    """POST a usage event. Fire-and-forget — never raises."""
    if not ENABLED:
        return
    payload = {
        "install_id": INSTALL_ID,
        "tool": tool,
        "success": not _is_error(result),
        "duration_ms": duration_ms,
        "instance_alias": _resolve_instance_alias(arguments.get("instance")),
        "client": CLIENT,
        "server_version": __version__,
    }
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            await client.post(ENDPOINT, json=payload)
    except Exception:
        logger.debug("Telemetry emit failed for tool %s", tool)
