"""Read back which scope an oauth_entity (or sys_alias) row landed in, and remove a stray.

REST only (no Script Runner): works on installs that have OAuth and no Script Runner.
Response bodies are never copied into messages.
"""
import re
from typing import Any, Dict, NamedTuple, Optional

from .rest_verify import delete_with_readback
from .script_runner import GLOBAL_SCOPE_SYS_ID

_SYS_ID_RE = re.compile(r"[0-9a-f]{32}")


class Landing(NamedTuple):
    """kind: 'global', 'other' (a 32-hex sys_id that is not Global) or 'unknown'
    (blank, display name, odd shape, any read failure)."""
    kind: str
    scope: str
    client_id: str
    message: str


def _unknown(message: str, scope: str = "", client_id: str = "") -> Landing:
    return Landing("unknown", scope, client_id, message)


def _value(field: Any) -> str:
    field = field.get("value") if isinstance(field, dict) else field
    return field if isinstance(field, str) else ""


def read_landing(
    session: Any,
    base_url: str,
    table: str,
    sys_id: str,
    *,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 30,
) -> Landing:
    """One GET of sys_scope and client_id for the record. Never raises."""
    kw: Dict[str, Any] = {"timeout": timeout}
    if headers is not None:
        kw["headers"] = headers
    try:
        resp = session.get(
            f"{base_url.rstrip('/')}/api/now/table/{table}",
            params={
                "sysparm_query": f"sys_id={sys_id}",
                "sysparm_fields": "sys_id,sys_scope,client_id",
                "sysparm_display_value": "false",
                "sysparm_limit": 1,
            },
            **kw,
        )
    except Exception as e:  # never echo bodies or secrets
        return _unknown(f"the scope read-back failed ({type(e).__name__})")
    try:
        if resp.status_code != 200:
            return _unknown(f"the scope read-back returned HTTP {resp.status_code}")
        rows = resp.json().get("result")
        if not isinstance(rows, list) or not rows or not isinstance(rows[0], dict):
            return _unknown("the scope read-back did not return the record")
        row = rows[0]
        if _value(row.get("sys_id")) != sys_id:
            return _unknown("the scope read-back returned a different record")
        scope = _value(row.get("sys_scope"))
        client_id = _value(row.get("client_id"))
    except Exception as e:
        return _unknown(f"the scope read-back could not be read ({type(e).__name__})")
    if scope == GLOBAL_SCOPE_SYS_ID:
        return Landing("global", scope, client_id, "landed in the Global scope")
    if _SYS_ID_RE.fullmatch(scope):
        return Landing("other", scope, client_id, f"landed in scope {scope}, not Global")
    return _unknown("the read-back did not show a scope this check can compare with Global",
                    scope=scope, client_id=client_id)


def remove_stray(
    session: Any,
    base_url: str,
    table: str,
    sys_id: str,
    scope: str,
    *,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 30,
) -> str:
    """Delete a record that landed in the wrong scope, confirmed by read-back."""
    res = delete_with_readback(session, base_url, table, sys_id, headers=headers, timeout=timeout)
    if res["outcome"] == "deleted":
        return (f"The stray {table} record {sys_id} (scope {scope}) was removed "
                f"(confirmed by read-back).")
    return (f"The stray {table} record {sys_id} (scope {scope}) could not be removed "
            f"({res['message']}); delete it manually.")
