"""Inbound OAuth Application Creation (Framework-Independent)

Standalone function for creating inbound OAuth applications in ServiceNow.
Uses requests.Session directly — no dependency on MCP framework, ServiceNowClient,
or the config system. Designed for reuse by both MCP tools and CLI scripts.
"""

import re
import secrets
import string

import requests
from .entity_landing import read_landing, remove_stray
from .rest_verify import delete_with_readback
from .script_runner import GLOBAL_SCOPE_SYS_ID
from typing import Any, Dict, List, NamedTuple, Optional, Tuple

CLIENT_CREDENTIALS_PROPERTY = "glide.oauth.inbound.client.credential.grant_type.enabled"
_PROP_TIMEOUT = 30
_SYS_ID_RE = re.compile(r"^[0-9a-f]{32}$")


class _BadBody(Exception):
    pass


class _HttpError(Exception):
    def __init__(self, status: int):
        super().__init__(status)
        self.status = status


class PropertyResult(NamedTuple):
    """Outcome of ensure_client_credentials_property.

    ok: the Global row is confirmed true.
    wrong_scope: True ONLY when an insert this call made read back in a named non-Global
        scope (it was then deleted). The one outcome callers must refuse on.
    stop: a failure the old (pre-helper) bootstrap code also treated as fatal: the first read
        not 200, the insert not 201, the update not 200, or a request that raised.
    Every other not-ok outcome is "could not confirm": callers warn and continue.
    """
    ok: bool
    message: str
    wrong_scope: bool = False
    stop: bool = False
    error_kind: str = ""  # "ssl" | "timeout" | "connection" when a request raised that way (message-only)


def property_row_scope(row: Dict[str, Any]) -> Optional[str]:
    """sys_scope of a sys_properties row: a reference dict {"value", "link"} or a plain string."""
    scope = row.get("sys_scope")
    scope = scope.get("value") if isinstance(scope, dict) else scope
    return scope or None


def _scope_kind(row: Dict[str, Any]) -> str:
    """'global', 'other' (a named scope: a sys_id) or 'unknown' (blank, a display value, anything else)."""
    scope = property_row_scope(row)
    if scope == GLOBAL_SCOPE_SYS_ID:
        return "global"
    if isinstance(scope, str) and _SYS_ID_RE.match(scope):
        return "other"
    return "unknown"


def _error_kind(exc: BaseException) -> str:
    if isinstance(exc, requests.exceptions.SSLError):
        return "ssl"
    if isinstance(exc, (requests.exceptions.ConnectTimeout, requests.exceptions.ReadTimeout)):
        return "timeout"
    if isinstance(exc, requests.exceptions.ConnectionError):
        return "connection"
    return ""


def friendly_network_error(kind: str) -> str:
    """The user-facing text for the network failures create_inbound_oauth_app always reported."""
    return {
        "ssl": ("SSL error connecting to the instance. "
                "If you are on a corporate network, your proxy may be intercepting HTTPS."),
        "timeout": "Request timed out. The instance may be under load. Retry.",
        "connection": ("Cannot reach the instance. "
                       "Check the URL and ensure you are connected to your VPN if required."),
    }.get(kind, "")


def _manual_hint(action: str) -> str:
    return f"Please manually {action}: {CLIENT_CREDENTIALS_PROPERTY} = true (in the Global scope)"


def ensure_client_credentials_property(
    session: Any,
    base_url: str,
    *,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = _PROP_TIMEOUT,
) -> PropertyResult:
    """Make sure the Global sys_properties row for client_credentials is true.

    REST only (GET, POST, PUT and the verified delete), so it works on installs with no
    Script Runner. The one write path behind setup_inbound_oauth and the bootstrap setup.

    sys_properties has a sys_scope column and a REST insert lands in the session's current
    application scope, so the status code is never trusted:
      - looks the property up by name (limit 5) and acts only on the row whose scope is
        Global; rows in another scope are reported, never changed;
      - inserts a Global row when none exists, or sets the Global row's value by sys_id;
      - GETs the row back after any write and requires value=true and scope Global;
      - an insert that read back in a NAMED non-Global scope is deleted (read back) and
        refused (wrong_scope=True) with the fix: select Global as the current application,
        then retry.
    Anything it cannot confirm (a blank or display-value scope, a failed read-back, no
    row, another value) is reported as ok=False with wrong_scope=False and nothing is deleted.

    `session` is anything with requests-style get/post/put/delete. Never raises; never
    echoes response bodies.
    """
    base = base_url.rstrip("/")
    url = f"{base}/api/now/table/sys_properties"
    read_kw: Dict[str, Any] = {"timeout": timeout}
    if headers is not None:
        read_kw["headers"] = headers
    write_headers = dict(headers or {"Accept": "application/json"})
    write_headers.setdefault("Content-Type", "application/json")
    write_kw: Dict[str, Any] = {"timeout": timeout, "headers": write_headers}

    def _fail(what: str, detail: str, hint: Optional[str] = None, *, stop: bool = False,
              kind: str = "") -> PropertyResult:
        return PropertyResult(False, f"⚠️  {what}: {detail}" + (f"\n{hint}" if hint else ""), False, stop, kind)

    def _read(query: str, limit: int) -> List[Dict[str, Any]]:
        resp = session.get(
            url,
            params={
                "sysparm_query": query,
                "sysparm_fields": "sys_id,value,sys_scope",
                "sysparm_limit": limit,
                "sysparm_display_value": "false",
            },
            **read_kw,
        )
        if resp.status_code != 200:
            raise _HttpError(resp.status_code)
        body = resp.json()
        if not isinstance(body, dict):
            raise _BadBody()
        return body.get("result", [])

    def _verify(sys_id: str) -> Tuple[str, str]:
        """GET the row back. ('ok', '') | ('other', scope) | ('unverified', why). Never raises."""
        try:
            rows = _read(f"sys_id={sys_id}", 1)
        except _HttpError as e:
            return "unverified", f"the read-back returned HTTP {e.status}"
        except Exception as e:
            return "unverified", f"the read-back failed ({type(e).__name__})"
        if not rows:
            return "unverified", "the read-back found no such record"
        kind = _scope_kind(rows[0])
        if kind == "other":
            return "other", property_row_scope(rows[0]) or ""
        if kind == "unknown":
            return "unverified", "the read-back did not show a scope this check can compare with Global"
        if rows[0].get("value") != "true":
            return "unverified", f"the read-back shows value={rows[0].get('value')!r}, not 'true'"
        return "ok", ""

    def _unverified(what: str, why: str, action: str) -> PropertyResult:
        return _fail(f"System property {what} was accepted but could not be verified", why,
                     _manual_hint(action))

    try:
        rows = _read(f"name={CLIENT_CREDENTIALS_PROPERTY}", 5)
        if not isinstance(rows, list) or not all(isinstance(r, dict) for r in rows):
            raise _BadBody()
    except _HttpError as e:
        return _fail("Could not read the system property", f"HTTP {e.status}", stop=True)
    except _BadBody:
        # Not a list of rows: cannot tell what exists, so make no write and let the caller warn.
        return _fail("Could not confirm the system property",
                     "the response was not a list of rows; no change was made", _manual_hint("check"))
    except Exception as e:  # network errors etc.; never echo bodies or secrets
        return _fail("Could not check the system property", type(e).__name__, stop=True,
                     kind=_error_kind(e))

    global_rows = [r for r in rows if _scope_kind(r) == "global"]
    unknown_rows = [r for r in rows if _scope_kind(r) == "unknown"]
    notes = [
        f"Note: property row {r.get('sys_id')} in scope '{property_row_scope(r) or 'unreadable'}' was "
        f"left untouched; only the Global row counts. Review it manually."
        for r in rows if _scope_kind(r) != "global"
    ]
    tail = ("\n" + "\n".join(notes)) if notes else ""

    try:
        if global_rows:
            row = global_rows[0]
            if row.get("value") == "true":
                return PropertyResult(True, f"✓ System property already enabled{tail}")
            put = session.put(f"{url}/{row['sys_id']}", json={"value": "true"}, **write_kw)
            if put.status_code != 200:
                return _fail("Could not enable system property (admin role may be required)",
                             f"HTTP {put.status_code}", _manual_hint("set"), stop=True)
            state, why = _verify(row["sys_id"])
            if state == "ok":
                return PropertyResult(True, f"✓ System property enabled ({CLIENT_CREDENTIALS_PROPERTY} = true){tail}")
            if state == "other":
                why = f"the read-back shows scope '{why}', not Global"
            return _unverified("update", why, "set")

        if unknown_rows:
            # A row exists whose scope cannot be compared with Global: inserting another could
            # duplicate the real Global row, so never insert.
            only = unknown_rows[0] if len(rows) == 1 else None
            if only is not None and only.get("value") != "true":
                # The old code set a lone row's value by sys_id whatever its scope: keep that.
                put = session.put(f"{url}/{only['sys_id']}", json={"value": "true"}, **write_kw)
                if put.status_code != 200:
                    return _fail("Could not enable system property (admin role may be required)",
                                 f"HTTP {put.status_code}", _manual_hint("set"), stop=True)
                try:
                    back = _read(f"sys_id={only['sys_id']}", 1)
                except Exception as e:
                    return _unverified("update", f"the read-back failed ({type(e).__name__})", "set")
                if back and back[0].get("value") == "true":
                    return PropertyResult(True, f"✓ System property enabled ({CLIENT_CREDENTIALS_PROPERTY} = true); "
                                                f"its scope could not be read to confirm it is Global{tail}")
                return _unverified("update", "the read-back did not show value 'true'", "set")
            described = "; ".join(
                f"{r.get('sys_id')} (value '{r.get('value')}')" for r in unknown_rows)
            return _fail("Could not confirm the system property",
                         f"row(s) {described} have a scope this check cannot read; no change was made",
                         _manual_hint("check"))

        post = session.post(
            url,
            json={
                "name": CLIENT_CREDENTIALS_PROPERTY,
                "value": "true",
                "type": "boolean",
                "description": "Enable client credentials grant type for inbound OAuth",
            },
            **write_kw,
        )
        if post.status_code != 201:
            return _fail("Could not create system property (admin role may be required)",
                         f"HTTP {post.status_code}", _manual_hint("create"),
                         stop=not rows)  # old code stopped only when no row existed; it never inserted otherwise
        try:
            new_id = post.json().get("result", {}).get("sys_id")
        except Exception:
            new_id = None
        if not new_id:
            return _unverified("insert", "the response carried no sys_id; check the property in Global", "create")
        state, why = _verify(new_id)
        if state == "ok":
            return PropertyResult(True, f"✓ System property created and enabled ({CLIENT_CREDENTIALS_PROPERTY} = true){tail}")
        if state == "other":
            gone = delete_with_readback(session, base, "sys_properties", new_id,
                                        headers=headers, timeout=timeout)
            cleanup = ("The stray row was deleted (confirmed by read-back)." if gone["outcome"] == "deleted"
                       else f"The stray row {new_id} could not be removed ({gone['message']}); delete it manually.")
            message = (
                f"⚠️  The system property was created in application scope '{why}', not Global, so it has "
                f"no effect. The session's current application scope was not Global. {cleanup}\n"
                f"Fix: select Global in the application picker (the apps.current_app preference), then retry."
            )
            if rows:
                # An older install whose property row lives in a named scope used to carry on
                # (it was told "already enabled" or got a PUT). Our own stray is gone; warn only.
                return PropertyResult(False, message, False, False)
            return PropertyResult(False, message, True, False)
        return _unverified("insert", why, "create")
    except Exception as e:  # a write request that raised; never echo bodies or secrets
        return _fail("Could not update the system property", type(e).__name__, stop=True,
                     kind=_error_kind(e))


def _generate_client_secret(length: int = 32) -> str:
    """
    Generate a secure random alphanumeric string.

    Args:
        length: Length of the secret (default: 32)

    Returns:
        Random alphanumeric string
    """
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


def _own_service_account_ids(session: Any, base_url: str, username: str,
                             hostname: Optional[str]) -> Optional[set]:
    """sys_ids of the service account(s) this installer would have created for `username` on this
    host (read-only REST GET), or None when the lookup could not be completed."""
    from .service_account import _compute_new_username
    try:
        if hostname is None:
            import socket
            try:
                hostname = socket.gethostname() or ""
            except OSError:
                hostname = ""
        names = {_compute_new_username(username, hostname), f"{username}.claude_assisted",
                 f"{username[:28]}.claude_assisted"}
        resp = session.get(
            f"{base_url}/api/now/table/sys_user",
            params={
                "sysparm_query": "user_nameIN" + ",".join(sorted(names)),
                "sysparm_fields": "sys_id,user_name",
                "sysparm_limit": 5,
            },
            headers={"Accept": "application/json"},
        )
        if resp.status_code != 200:
            return None
        rows = resp.json().get("result", [])
        if not isinstance(rows, list):
            return None
        return {r["sys_id"] for r in rows if isinstance(r, dict) and r.get("sys_id")}
    except Exception:
        return None


def create_inbound_oauth_app(
    session: requests.Session,
    instance_url: str,
    app_name: str,
    username: str,
    progress_callback=None,
    hostname: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Create an inbound OAuth application in ServiceNow.

    This function performs the following steps:
    1. Validates the user exists and is active
    2. Checks/enables client_credentials grant type system property
    3. Deletes stale oauth_entity records this installer created (same name, client_credentials
       grant, and an OAuth Application User that is the setup user or this installer's
       service account for this host), each confirmed gone by a read-back; same-name apps
       that do not match are reported and left in place
    4. Generates a secure random client secret
    5. Creates an oauth_entity record with type=client
    6. Returns the auto-generated client_id and client_secret

    Args:
        session: Authenticated requests.Session (basic auth or bearer token already configured)
        instance_url: ServiceNow instance URL (e.g., "https://dev12345.service-now.com")
        app_name: Name for the OAuth application
        username: ServiceNow username for the OAuth Application User
        progress_callback: Optional callable(str) invoked before each major HTTP operation for progress reporting
        hostname: Host name used to derive the installer's service-account name (default: this machine's)

    Returns:
        Dict with keys:
        - success: bool
        - client_id: str (when success)
        - client_secret: str (when success)
        - app_sys_id: str (when success)
        - messages: list[str] (status messages from each step)
        - error: str (when not success)
    """
    messages: List[str] = []
    base_url = instance_url.rstrip("/")
    headers = {"Accept": "application/json", "Content-Type": "application/json"}

    try:
        # Step 1: Validate user exists and is active
        if progress_callback:
            progress_callback(f"Validating user '{username}'...")
        user_resp = session.get(
            f"{base_url}/api/now/table/sys_user",
            params={
                "sysparm_query": f"user_name={username}^active=true",
                "sysparm_fields": "sys_id,user_name,name,active",
                "sysparm_limit": 1,
            },
            headers={"Accept": "application/json"},
        )

        if user_resp.status_code == 401:
            return {
                "success": False,
                "messages": messages,
                "error": "Authentication failed (401). Check credentials.",
            }

        if user_resp.status_code != 200:
            return {
                "success": False,
                "messages": messages,
                "error": f"Failed to validate user (HTTP {user_resp.status_code}): {user_resp.text}",
            }

        user_results = user_resp.json().get("result", [])
        if not user_results:
            return {
                "success": False,
                "messages": messages,
                "error": f"User '{username}' not found or inactive.",
            }

        user_record = user_results[0]
        user_sys_id = user_record["sys_id"]
        messages.append(f"User '{username}' validated (sys_id: {user_sys_id})")

        # Step 2: Check/enable the client_credentials grant type property. One shared helper:
        # REST only, acts on the Global row, reads it back. Stops (no app, no secret) only for the
        # failures the old code stopped on (read/insert/update HTTP failures, a raised request)
        # and for an insert that landed in a named non-Global scope. A result it merely could not
        # confirm is a warning and setup continues, as before.
        prop = ensure_client_credentials_property(
            session, base_url, headers={"Accept": "application/json"})
        if prop.stop or prop.wrong_scope:
            return {
                "success": False,
                "messages": messages,
                "error": friendly_network_error(prop.error_kind) or prop.message,
            }
        if prop.ok:
            messages.append(prop.message.replace("✓ ", "", 1))
        else:
            messages.append(f"Warning: {prop.message.replace('⚠️  ', '', 1)}")

        # Step 3: Clean up stale OAuth apps THIS installer created (idempotent re-runs)
        # This handles the case where a user re-runs setup after deleting
        # the Claude Desktop config entry or losing their .env credentials.
        # The client_secret is never recoverable after initial creation, so
        # stale records are useless and should be replaced.
        #
        # A name match alone is not proof: the name is plain "Now MCP for Claude" when the
        # hostname is empty, so another machine's live app can share it. Only an app that
        # looks exactly like what step 5 creates (same OAuth Application User, client_credentials
        # grant) is deleted; every other same-name app is reported and left in place.
        stale_resp = session.get(
            f"{base_url}/api/now/table/oauth_entity",
            params={
                "sysparm_query": f"name={app_name}^type=client",
                "sysparm_fields": "sys_id,name,user,default_grant_type",
            },
            headers={"Accept": "application/json"},
        )

        if stale_resp.status_code == 200:
            stale_records = stale_resp.json().get("result", [])

            def _user_of(rec):
                u = rec.get("user")
                return u.get("value") if isinstance(u, dict) else u

            # The default install re-binds the app to the attributed service account, so a stale
            # app of this installer may belong to it rather than to the setup user. Look that
            # account up (read-only) only when some stale app needs it.
            owners = {user_sys_id}
            if any(_user_of(r) != user_sys_id for r in stale_records):
                sa_ids = _own_service_account_ids(session, base_url, username, hostname)
                if sa_ids is None:
                    messages.append(
                        "Warning: could not look up this installer's service account; stale apps bound "
                        "to it cannot be recognised and are left in place."
                    )
                else:
                    owners |= sa_ids

            for record in stale_records:
                rec_user = _user_of(record)
                if rec_user not in owners or record.get("default_grant_type") != "client_credentials":
                    messages.append(
                        f"Warning: skipped existing OAuth app '{record.get('name')}' ({record['sys_id']}) with the same name: "
                        f"it is not identified as created by this installer (different OAuth Application User or grant type). "
                        f"It was left in place."
                    )
                    continue
                outcome = delete_with_readback(
                    session, base_url, "oauth_entity", record["sys_id"],
                    headers={"Accept": "application/json"},
                    timeout=30,
                )
                if outcome["outcome"] == "deleted":
                    messages.append(f"Removed stale OAuth app '{record['name']}' ({record['sys_id']})")
                else:
                    messages.append(
                        f"Warning: could not delete stale OAuth app {record['sys_id']}: {outcome['message']}"
                        + (f" (HTTP {outcome['status_code']})" if outcome.get("status_code") else "")
                    )

        # Step 4: Generate client secret
        client_secret = _generate_client_secret()

        # Step 5: Create oauth_entity record
        if progress_callback:
            progress_callback("Creating OAuth application...")
        oauth_data = {
            "name": app_name,
            "client_secret": client_secret,
            "type": "client",
            "default_grant_type": "client_credentials",
            "access_token_lifespan": 1800,
            "refresh_token_lifespan": 0,
            "user": user_sys_id,
        }

        create_resp = session.post(
            f"{base_url}/api/now/table/oauth_entity",
            json=oauth_data,
            headers=headers,
        )

        if create_resp.status_code == 403:
            body = create_resp.text
            messages.append(f"403 response body: {body}")
            return {
                "success": False,
                "messages": messages,
                "error": (
                    "Your account does not have admin rights to create OAuth applications. "
                    "Ask your ServiceNow administrator for help."
                ),
            }
        if create_resp.status_code == 503:
            return {
                "success": False,
                "messages": messages,
                "error": "ServiceNow instance is temporarily unavailable. Try again later.",
            }
        if create_resp.status_code != 201:
            return {
                "success": False,
                "messages": messages,
                "error": f"Failed to create OAuth application (HTTP {create_resp.status_code}): {create_resp.text}",
            }

        app_record = create_resp.json().get("result", {})
        app_sys_id = app_record.get("sys_id", "")
        client_id = app_record.get("client_id", "")

        if not client_id:
            return {
                "success": False,
                "messages": messages,
                "error": f"OAuth application created (sys_id: {app_sys_id}) but client_id was not generated by ServiceNow.",
            }

        # Read back which scope the insert landed in (REST only: no Script Runner exists yet at
        # bootstrap). Only a CONFIRMED landing in a named non-Global scope is removed and
        # refused; anything that cannot be confirmed warns and keeps the old success.
        landing = read_landing(session, base_url, "oauth_entity", app_sys_id,
                               headers={"Accept": "application/json"})
        if landing.kind == "other":
            cleanup = remove_stray(session, base_url, "oauth_entity", app_sys_id, landing.scope,
                                   headers={"Accept": "application/json"})
            messages.append(cleanup)
            return {
                "success": False,
                "messages": messages,
                "error": (
                    f"The OAuth application was created in scope {landing.scope}, not Global. "
                    f"Select Global in the Application Picker (the apps.current_app preference), "
                    f"then retry."
                ),
            }
        if landing.kind == "unknown":
            messages.append(
                f"Warning: could not confirm the OAuth application landed in the Global scope "
                f"({landing.message}); check it in the Application Picker."
            )

        messages.append(f"OAuth application '{app_name}' created successfully")

        # Step 6: Return results
        return {
            "success": True,
            "client_id": client_id,
            "client_secret": client_secret,
            "app_sys_id": app_sys_id,
            "messages": messages,
        }

    except requests.exceptions.SSLError:
        return {
            "success": False,
            "messages": messages,
            "error": (
                "SSL error connecting to the instance. "
                "If you are on a corporate network, your proxy may be intercepting HTTPS."
            ),
        }
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ReadTimeout):
        return {
            "success": False,
            "messages": messages,
            "error": "Request timed out. The instance may be under load. Retry.",
        }
    except requests.exceptions.ConnectionError:
        return {
            "success": False,
            "messages": messages,
            "error": (
                "Cannot reach the instance. "
                "Check the URL and ensure you are connected to your VPN if required."
            ),
        }
    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "messages": messages,
            "error": f"Network error: {e}",
        }
