"""Inbound OAuth Application Creation (Framework-Independent)

Standalone function for creating inbound OAuth applications in ServiceNow.
Uses requests.Session directly — no dependency on MCP framework, ServiceNowClient,
or the config system. Designed for reuse by both MCP tools and CLI scripts.
"""

import secrets
import string

import requests
from typing import Any, Dict, List


def _generate_client_secret(length: int = 32) -> str:
    """
    Generate a secure random alphanumeric string.

    Args:
        length: Length of the secret (default: 32)

    Returns:
        Random alphanumeric string
    """
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


def create_inbound_oauth_app(
    session: requests.Session,
    instance_url: str,
    app_name: str,
    username: str,
) -> Dict[str, Any]:
    """
    Create an inbound OAuth application in ServiceNow.

    This function performs the following steps:
    1. Validates the user exists and is active
    2. Checks/enables client_credentials grant type system property
    3. Deletes any stale oauth_entity records with the same name (idempotent re-runs)
    4. Generates a secure random client secret
    5. Creates an oauth_entity record with type=client
    6. Returns the auto-generated client_id and client_secret

    Args:
        session: Authenticated requests.Session (basic auth or bearer token already configured)
        instance_url: ServiceNow instance URL (e.g., "https://dev12345.service-now.com")
        app_name: Name for the OAuth application
        username: ServiceNow username for the OAuth Application User

    Returns:
        Dict with keys:
        - success: bool
        - client_id: str (when success)
        - client_secret: str (when success)
        - app_sys_id: str (when success)
        - messages: list[str] (status messages from each step)
        - error: str (when not success)
    """
    messages: List[str] = []
    base_url = instance_url.rstrip("/")
    headers = {"Accept": "application/json", "Content-Type": "application/json"}

    try:
        # Step 1: Validate user exists and is active
        user_resp = session.get(
            f"{base_url}/api/now/table/sys_user",
            params={
                "sysparm_query": f"user_name={username}^active=true",
                "sysparm_fields": "sys_id,user_name,name,active",
                "sysparm_limit": 1,
            },
            headers={"Accept": "application/json"},
        )

        if user_resp.status_code == 401:
            return {
                "success": False,
                "messages": messages,
                "error": "Authentication failed (401). Check credentials.",
            }

        if user_resp.status_code != 200:
            return {
                "success": False,
                "messages": messages,
                "error": f"Failed to validate user (HTTP {user_resp.status_code}): {user_resp.text}",
            }

        user_results = user_resp.json().get("result", [])
        if not user_results:
            return {
                "success": False,
                "messages": messages,
                "error": f"User '{username}' not found or inactive.",
            }

        user_record = user_results[0]
        user_sys_id = user_record["sys_id"]
        messages.append(f"User '{username}' validated (sys_id: {user_sys_id})")

        # Step 2: Check/enable client_credentials grant type system property
        prop_name = "glide.oauth.inbound.client.credential.grant_type.enabled"
        prop_resp = session.get(
            f"{base_url}/api/now/table/sys_properties",
            params={
                "sysparm_query": f"name={prop_name}",
                "sysparm_fields": "sys_id,name,value",
                "sysparm_limit": 1,
            },
            headers={"Accept": "application/json"},
        )

        if prop_resp.status_code != 200:
            return {
                "success": False,
                "messages": messages,
                "error": f"Failed to check system property (HTTP {prop_resp.status_code}): {prop_resp.text}",
            }

        prop_results = prop_resp.json().get("result", [])

        if not prop_results:
            # Property missing — create it
            create_prop_resp = session.post(
                f"{base_url}/api/now/table/sys_properties",
                json={
                    "name": prop_name,
                    "value": "true",
                    "type": "boolean",
                    "description": "Enable client credentials grant type for inbound OAuth",
                },
                headers=headers,
            )
            if create_prop_resp.status_code == 201:
                messages.append("System property created and enabled")
            else:
                return {
                    "success": False,
                    "messages": messages,
                    "error": f"Failed to create system property (HTTP {create_prop_resp.status_code}): {create_prop_resp.text}",
                }
        else:
            prop = prop_results[0]
            if prop.get("value") == "true":
                messages.append("System property already enabled")
            else:
                # Property exists but disabled — enable it
                put_resp = session.put(
                    f"{base_url}/api/now/table/sys_properties/{prop['sys_id']}",
                    json={"value": "true"},
                    headers=headers,
                )
                if put_resp.status_code == 200:
                    messages.append("System property enabled")
                else:
                    return {
                        "success": False,
                        "messages": messages,
                        "error": f"Failed to enable system property (HTTP {put_resp.status_code}): {put_resp.text}",
                    }

        # Step 3: Clean up any stale OAuth apps with the same name
        # This handles the case where a user re-runs setup after deleting
        # the Claude Desktop config entry or losing their .env credentials.
        # The client_secret is never recoverable after initial creation, so
        # stale records are useless and should be replaced.
        stale_resp = session.get(
            f"{base_url}/api/now/table/oauth_entity",
            params={
                "sysparm_query": f"name={app_name}^type=client",
                "sysparm_fields": "sys_id,name",
            },
            headers={"Accept": "application/json"},
        )

        if stale_resp.status_code == 200:
            stale_records = stale_resp.json().get("result", [])
            for record in stale_records:
                del_resp = session.delete(
                    f"{base_url}/api/now/table/oauth_entity/{record['sys_id']}",
                    headers={"Accept": "application/json"},
                )
                if del_resp.status_code == 204:
                    messages.append(f"Removed stale OAuth app '{record['name']}' ({record['sys_id']})")
                else:
                    messages.append(f"Warning: could not delete stale OAuth app {record['sys_id']} (HTTP {del_resp.status_code})")

        # Step 4: Generate client secret
        client_secret = _generate_client_secret()

        # Step 5: Create oauth_entity record
        oauth_data = {
            "name": app_name,
            "client_secret": client_secret,
            "type": "client",
            "default_grant_type": "client_credentials",
            "access_token_lifespan": 1800,
            "refresh_token_lifespan": 0,
            "user": user_sys_id,
        }

        create_resp = session.post(
            f"{base_url}/api/now/table/oauth_entity",
            json=oauth_data,
            headers=headers,
        )

        if create_resp.status_code == 403:
            body = create_resp.text
            messages.append(f"403 response body: {body}")
            return {
                "success": False,
                "messages": messages,
                "error": (
                    "Your account does not have admin rights to create OAuth applications. "
                    "Ask your ServiceNow administrator for help."
                ),
            }
        if create_resp.status_code == 503:
            return {
                "success": False,
                "messages": messages,
                "error": "ServiceNow instance is temporarily unavailable. Try again later.",
            }
        if create_resp.status_code != 201:
            return {
                "success": False,
                "messages": messages,
                "error": f"Failed to create OAuth application (HTTP {create_resp.status_code}): {create_resp.text}",
            }

        app_record = create_resp.json().get("result", {})
        app_sys_id = app_record.get("sys_id", "")
        client_id = app_record.get("client_id", "")

        if not client_id:
            return {
                "success": False,
                "messages": messages,
                "error": f"OAuth application created (sys_id: {app_sys_id}) but client_id was not generated by ServiceNow.",
            }

        messages.append(f"OAuth application '{app_name}' created successfully")

        # Step 6: Return results
        return {
            "success": True,
            "client_id": client_id,
            "client_secret": client_secret,
            "app_sys_id": app_sys_id,
            "messages": messages,
        }

    except requests.exceptions.SSLError:
        return {
            "success": False,
            "messages": messages,
            "error": (
                "SSL error connecting to the instance. "
                "If you are on a corporate network, your proxy may be intercepting HTTPS."
            ),
        }
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ReadTimeout):
        return {
            "success": False,
            "messages": messages,
            "error": "Request timed out. The instance may be under load. Retry.",
        }
    except requests.exceptions.ConnectionError:
        return {
            "success": False,
            "messages": messages,
            "error": (
                "Cannot reach the instance. "
                "Check the URL and ensure you are connected to your VPN if required."
            ),
        }
    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "messages": messages,
            "error": f"Network error: {e}",
        }
