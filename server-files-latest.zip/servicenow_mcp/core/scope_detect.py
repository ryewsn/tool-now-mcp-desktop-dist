"""Post-run change detection for execute_script (audit F6).

execute_script runs free-form GlideScript, so nothing states where its writes land. This
module is best effort: take a marker (server time and acting user) before the run, then ask
sys_update_xml what that user changed since. Limits, all deliberate and documented in the tool:
it cannot separate two concurrent runs by the same user, it sees only update-tracked tables,
and sys_audit was not tested.

Rows are matched on sys_updated_on, never sys_created_on: an update overwrites the existing
row, so a created-on filter would miss a re-run that changed an artifact already captured.
"""

import re
from typing import Any, Dict, List, Optional

import requests

from .query_builder import QueryBuilder
from .scope_lookup import resolve_scope, scope_value

_SCRIPT_RUNNER_PATH = "/api/now/foundry_script_runner/execute"
_MARKER = "run_marker:"
_TIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$")
_SYS_ID_RE = re.compile(r"^[0-9a-f]{32}$")
_USER_RE = re.compile(r"^[A-Za-z0-9_.@+\-]+$")
_DETECT_LIMIT = 100


class DetectionError(Exception):
    """Detection could not run or could not be trusted; the script itself is unaffected."""


def take_run_marker(client) -> Dict[str, str]:
    """Read server time and the acting user with one one-line Script Runner call.

    Uses the same runner execute_script already needs (no new dependency; it is only called
    for runs that could write). Only the `run_marker:` output line is trusted. Returns
    {"time": "YYYY-MM-DD HH:MM:SS" (UTC), "user_name", "user_sys_id"}; raises DetectionError.
    """
    if not client._prepare_request():
        raise DetectionError("not authenticated to the instance")

    script = (
        f"gs.info('{_MARKER}' + new GlideDateTime().getValue() + '|' + "
        f"gs.getUserName() + '|' + gs.getUserID());"
    )
    url = f"{client.config.instance}{_SCRIPT_RUNNER_PATH}"
    try:
        response = client.session.post(url, json={"script": script})
    except requests.exceptions.RequestException as e:
        raise DetectionError(f"marker request failed: {e}")

    if response.status_code not in (200, 201):
        raise DetectionError(f"marker request returned HTTP {response.status_code}")
    try:
        output = response.json().get("result", {}).get("output", []) or []
    except ValueError:
        raise DetectionError("marker response was not JSON")

    for line in output:
        if isinstance(line, str) and line.startswith(_MARKER):
            parts = line[len(_MARKER):].split("|")
            if len(parts) != 3:
                break
            time, user_name, user_sys_id = (p.strip() for p in parts)
            if (_TIME_RE.match(time) and _USER_RE.match(user_name)
                    and _SYS_ID_RE.match(user_sys_id)):
                return {"time": time, "user_name": user_name, "user_sys_id": user_sys_id}
            break
    raise DetectionError("marker line missing or malformed in runner output")


def _display(ref: Any) -> str:
    if isinstance(ref, dict):
        return str(ref.get("display_value") or ref.get("value") or "")
    return str(ref or "")


def resolve_expected(client, expected_scope: Optional[str]) -> Dict[str, Any]:
    """Resolve expected_scope (never raises). Returns {"sys_id": str|None, "error": str|None}."""
    if not expected_scope:
        return {"sys_id": None, "error": None}
    try:
        resolved = resolve_scope(client, expected_scope)
    except Exception as e:
        return {"sys_id": None, "error": f"expected_scope could not be resolved: {e}"}
    if not resolved.get("success"):
        return {"sys_id": None,
                "error": f"expected_scope could not be resolved: {resolved.get('error', '')}"}
    return {"sys_id": resolved["sys_id"], "error": None}


def detect_changes(client, marker: Dict[str, str], expected_scope: Optional[str],
                   resolved: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """List sys_update_xml rows by the marker's user updated at or after the marker time.

    Returns {"changes": [{name, target_name, application, action}], "outside_expected": [...],
    "truncated": bool (the row limit was reached)}.
    `resolved` (from resolve_expected, taken before the run) skips the lookup. If expected_scope
    cannot be resolved the changes are still listed and the problem is returned as
    "scope_error" (outside_expected is then empty). Marker user names outside _USER_RE make the
    marker fail, which disables detection for that run. With expected_scope (a scope id, scope sys_id or "global"), a change whose application is
    not that scope goes in outside_expected too. Raises DetectionError on a failed query.
    """
    if resolved is None:
        resolved = resolve_expected(client, expected_scope)
    expected_sys_id = resolved["sys_id"]
    scope_error = resolved["error"]

    builder = QueryBuilder()
    # [VERIFIED: live read, ayew3, 2026-11-20] The Table API compares this raw datetime literal
    # in UTC (stored value), not the acting user's timezone: a row stored 17:01:56 UTC (displayed
    # 09:01:56) matched `>=17:01:56` and not `>=17:01:57`. Same zone as the marker's
    # GlideDateTime().getValue().
    builder.add_custom(f"sys_updated_on>={marker['time']}")
    builder.add_equals("sys_updated_by", marker["user_name"])
    query = builder.add_order_by("sys_updated_on", "DESC")

    response = client.query_table(
        table_name="sys_update_xml",
        query=query,
        fields=["name", "target_name", "action", "application", "sys_updated_on"],
        limit=_DETECT_LIMIT,
        display_value="all",
    )
    if not response.get("success"):
        raise DetectionError(f"sys_update_xml query failed: {response.get('error', '')}")

    changes: List[Dict[str, str]] = []
    outside: List[Dict[str, str]] = []
    for row in response.get("result") or []:
        change = {
            "name": _display(row.get("name")),
            "target_name": _display(row.get("target_name")),
            "application": _display(row.get("application")) or "(none)",
            "action": _display(row.get("action")),
        }
        changes.append(change)
        if expected_sys_id is not None and scope_value(row.get("application")) != expected_sys_id:
            outside.append(change)

    return {"changes": changes, "outside_expected": outside,
            "truncated": len(changes) >= _DETECT_LIMIT, "scope_error": scope_error}
