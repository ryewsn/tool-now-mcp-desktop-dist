# servicenow_mcp/core/oauth_identity.py
"""Shared helper deciding and applying which user an OAuth application runs as.

Two identities are possible: the dedicated service account created for the
integration, or the human who ran the setup ("human"). Binding sets the OAuth
application user to the service account and reads it back, so the result
always reflects what is actually stored. The helper never raises on HTTP
failures; it returns a readable reason instead, so a failed bind is never
silent.
"""
from typing import Optional

import requests

SERVICE_ACCOUNT = "service_account"
HUMAN = "human"
_VALID = (SERVICE_ACCOUNT, HUMAN)
_HEADERS = {"Accept": "application/json", "Content-Type": "application/json"}
_TIMEOUT = 30


def resolve_oauth_identity(oauth_identity: Optional[str],
                           create_service_account: Optional[bool]) -> str:
    """Return "service_account" or "human".

    An explicit ``oauth_identity`` wins. Otherwise ``create_service_account``
    False means "human"; None or True means "service_account".
    Raises ValueError for an ``oauth_identity`` that is not one of the two.
    """
    if oauth_identity is not None:
        if oauth_identity not in _VALID:
            raise ValueError(
                f"Invalid oauth_identity {oauth_identity!r}; "
                f"must be 'service_account' or 'human'.")
        return oauth_identity
    if create_service_account is False:
        return HUMAN
    return SERVICE_ACCOUNT


def _fallback(reason: str, verified: bool = True) -> dict:
    return {"identity": HUMAN, "bound": False, "verified": verified, "reason": reason}


def _unverified(detail: str) -> dict:
    """Outcome unknown after a PATCH was attempted: the update may have applied."""
    return _fallback(
        f"{detail} The update may have applied; check the OAuth application's "
        f"user (oauth_entity.user).", verified=False)


def _bind_blocker(sa_result: Optional[dict]) -> Optional[str]:
    """Return the first reason the account must not be bound, or None."""
    if not sa_result or not sa_result.get("success"):
        return "the service account was not created"
    if not sa_result.get("sys_id"):
        return "the service account has no sys_id"
    if sa_result.get("roles_skipped"):
        return "the requesting user's roles were not copied to the service account"
    if not sa_result.get("roles_compared"):
        return "the service account's roles could not be compared with the requesting user's"
    missing = sa_result.get("roles_missing")
    if missing is None:
        return "the service account's roles could not be compared with the requesting user's"
    if missing:
        return ("the service account is missing roles the requesting user has: "
                + ", ".join(missing))
    if not (sa_result.get("account_role_count") or 0) > 0:
        return "the service account holds no roles"
    return None


def _user_value(payload: dict) -> Optional[str]:
    user = (payload.get("result") or {}).get("user")
    if isinstance(user, dict):
        return user.get("value")
    return user


def bind_oauth_identity(session: requests.Session, instance_url: str,
                        oauth_entity_sys_id: str, identity: str,
                        sa_result: Optional[dict]) -> dict:
    """Apply the chosen identity to an OAuth application and verify it.

    Returns ``{"identity", "bound", "verified", "reason"}``. ``identity`` is the
    identity in effect as far as it could be confirmed. ``verified`` is True when
    the final state was confirmed (by a read-back, or because nothing was
    attempted) and False only when a PATCH was attempted and its outcome could
    not be confirmed; then ``identity`` stays "human" conservatively but the
    application user may in fact already be the service account. For ``identity="human"`` nothing is changed and
    ``bound`` is True (the result matches what was requested). For
    ``"service_account"``, ``bound`` is True only when the OAuth application
    user reads back as the service account; if the account is unsuitable or
    the update fails, ``identity`` is "human" and ``bound`` is False, with a
    plain-English ``reason``. Never raises on HTTP errors or exceptions.
    """
    if identity == HUMAN:
        return {"identity": HUMAN, "bound": True, "verified": True,
                "reason": "bound to the requesting user by request"}

    blocker = _bind_blocker(sa_result)
    if blocker:
        return _fallback(f"Kept the requesting user as the OAuth application user: {blocker}.")

    sa_sys_id = sa_result["sys_id"]
    url = f"{instance_url.rstrip('/')}/api/now/table/oauth_entity/{oauth_entity_sys_id}"
    try:
        resp = session.patch(url, json={"user": sa_sys_id},
                             headers=_HEADERS, timeout=_TIMEOUT)
    except requests.RequestException as exc:
        return _unverified(f"Could not confirm the OAuth application user update ({exc}).")
    if resp.status_code != 200:
        return _fallback(
            f"Could not update the OAuth application user (HTTP {resp.status_code}).")
    try:
        check = session.get(url, params={"sysparm_fields": "user"},
                            headers=_HEADERS, timeout=_TIMEOUT)
        if check.status_code != 200:
            return _unverified(
                f"The OAuth application user could not be verified after the update "
                f"(HTTP {check.status_code}).")
        actual = _user_value(check.json())
    except (requests.RequestException, ValueError) as exc:
        return _unverified(
            f"The OAuth application user could not be verified after the update ({exc}).")

    if actual != sa_sys_id:
        return _fallback(
            "The OAuth application user did not change to the service account "
            "after the update; it is still the requesting user.")

    reason = "OAuth application user set to the service account"
    elevated = sa_result.get("roles_elevated_skipped") or []
    if elevated:
        reason += f" ({len(elevated)} elevated roles not replicated)"
    return {"identity": SERVICE_ACCOUNT, "bound": True, "verified": True, "reason": reason}
