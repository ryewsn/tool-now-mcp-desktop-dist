"""Attributed Service Account Creation

Creates a dedicated sys_user for MCP operations so API calls are identifiable
in ServiceNow audit logs as AI-assisted rather than attributed to the setup user.

Standalone function — no dependency on MCP framework, ServiceNowClient, or config
system. Designed for reuse by both MCP tools and installer.
"""

import secrets
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from typing import Any, Dict


def _compute_new_username(setup_username: str, hostname: str) -> str:
    """Return '{setup_username}.claude.{hostname[:N]}' where N = max(4, 32 - len(setup_username)).

    setup_username is capped at 28 chars to ensure total user_name stays ≤ 40 chars
    (ServiceNow sys_user.user_name field limit).

    If hostname is empty after all resolution attempts, falls back to
    '{setup_username}.claude_assisted' to avoid a trailing-dot account name.
    """
    capped = setup_username[:28]
    if not hostname:
        return f"{capped}.claude_assisted"
    n = max(4, 32 - len(capped))
    return f"{capped}.claude.{hostname[:n]}"


_TABLE = "/api/now/table"
_GET_HEADERS = {"Accept": "application/json"}
_PAGE_SIZE = 500
_LOOKUP_CHUNK = 100


def _ref_value(ref):
    """Return the sys_id of a reference field value ({'value': id} or plain string)."""
    return ref.get("value") if isinstance(ref, dict) else ref


def _fetch_role_meta(session, base_url, role_sys_ids):
    """Resolve role name and elevated flag from sys_user_role, batched.

    Returns {role_sys_id: {"name": str, "elevated": bool}}, or None if any lookup
    returns a non-200 response.
    """
    ids = sorted(role_sys_ids)
    meta = {}
    for i in range(0, len(ids), _LOOKUP_CHUNK):
        chunk = ids[i:i + _LOOKUP_CHUNK]
        resp = session.get(
            f"{base_url}{_TABLE}/sys_user_role",
            params={
                "sysparm_query": "sys_idIN" + ",".join(chunk),
                "sysparm_fields": "sys_id,name,elevated_privilege",
                "sysparm_limit": len(chunk),
            },
            headers=_GET_HEADERS,
        )
        if resp.status_code != 200:
            return None
        for row in resp.json().get("result", []):
            meta[row["sys_id"]] = {
                "name": row.get("name") or row["sys_id"],
                "elevated": str(row.get("elevated_privilege")).lower() == "true",
            }
    return meta


def _fetch_effective_role_ids(session, base_url, user_sys_id):
    """Active sys_user_has_role rows for a user, all 'inherited' values, paginated.

    Returns the set of role sys_ids, or None if any page returns non-200.
    """
    role_ids = set()
    offset = 0
    while True:
        resp = session.get(
            f"{base_url}{_TABLE}/sys_user_has_role",
            params={
                "sysparm_query": f"user={user_sys_id}^state=active",
                "sysparm_fields": "role",
                "sysparm_limit": _PAGE_SIZE,
                "sysparm_offset": offset,
            },
            headers=_GET_HEADERS,
        )
        if resp.status_code != 200:
            return None
        rows = resp.json().get("result", [])
        role_ids.update(rid for r in rows if (rid := _ref_value(r.get("role"))))
        if len(rows) < _PAGE_SIZE:
            return role_ids
        offset += _PAGE_SIZE


def _copy_direct_roles(session, base_url, headers, setup_user_sys_id, account_sys_id, messages):
    """Copy the setup user's direct, active, non-elevated role grants to the account.

    Roles with sys_user_role.elevated_privilege set are never posted, and roles the
    account already holds by any path are skipped to avoid duplicate rows.

    Returns {"assigned", "failed", "skipped" (403 on read), "ok" (grants were read and
    classified), "elevated" (names of direct elevated roles not copied)}.
    """
    out = {"assigned": 0, "failed": 0, "skipped": False, "ok": False, "elevated": []}
    roles_resp = session.get(
        f"{base_url}{_TABLE}/sys_user_has_role",
        params={
            "sysparm_query": f"user={setup_user_sys_id}^state=active^inherited=false",
            "sysparm_fields": "role",
            "sysparm_limit": _PAGE_SIZE,
        },
        headers=_GET_HEADERS,
    )
    if roles_resp.status_code == 403:
        out["skipped"] = True
        messages.append("Warning: user_admin role required to replicate roles — assign roles manually.")
        return out
    if roles_resp.status_code != 200:
        messages.append(f"Warning: could not retrieve roles (HTTP {roles_resp.status_code})")
        return out

    role_ids = {
        rid for r in roles_resp.json().get("result", [])
        if (rid := _ref_value(r.get("role")))
    }
    if not role_ids:
        out["ok"] = True
        return out

    meta = _fetch_role_meta(session, base_url, role_ids)
    held = _fetch_effective_role_ids(session, base_url, account_sys_id)
    if meta is None or held is None:
        messages.append("Warning: could not classify roles to copy — no roles were copied.")
        return out

    def is_elevated(rid):
        return meta.get(rid, {}).get("elevated", False)

    out["elevated"] = sorted(meta[r]["name"] for r in role_ids if is_elevated(r))
    to_copy = sorted(r for r in role_ids if r not in held and not is_elevated(r))

    def _assign_role(role_sys_id):
        resp = session.post(
            f"{base_url}{_TABLE}/sys_user_has_role",
            json={"user": account_sys_id, "role": role_sys_id},
            headers=headers,
        )
        return role_sys_id, resp.status_code

    with ThreadPoolExecutor(max_workers=min(max(len(to_copy), 1), 10)) as executor:
        futures = {executor.submit(_assign_role, rid): rid for rid in to_copy}
        for future in as_completed(futures):
            role_sys_id, status_code = future.result()
            if status_code in (200, 201):
                out["assigned"] += 1
            else:
                out["failed"] += 1
                messages.append(f"Warning: could not assign role {role_sys_id} (HTTP {status_code})")
    out["ok"] = True
    return out


def _read_group_ids(session, base_url, query):
    """Return (status_code, set of group sys_ids) for a sys_user_grmember query."""
    resp = session.get(
        f"{base_url}{_TABLE}/sys_user_grmember",
        params={"sysparm_query": query, "sysparm_fields": "group", "sysparm_limit": _PAGE_SIZE},
        headers=_GET_HEADERS,
    )
    if resp.status_code != 200:
        return resp.status_code, set()
    return 200, {
        gid for r in resp.json().get("result", []) if (gid := _ref_value(r.get("group")))
    }


def _add_group_memberships(session, base_url, headers, setup_user_sys_id, account_sys_id, messages):
    """Add the account to each active group the setup user is directly a member of.

    Only sys_user_grmember rows filtered by user are read (never by group); parent
    groups are not walked. Groups the account already belongs to are skipped.

    Returns (added, failed, lookup_ok): lookup_ok is True when memberships were read,
    False on a non-403 read failure, None on 403 (user_admin role required).
    """
    status, groups = _read_group_ids(
        session, base_url, f"user={setup_user_sys_id}^group.active=true"
    )
    existing = set()
    if status == 200:
        status, existing = _read_group_ids(session, base_url, f"user={account_sys_id}")
    if status == 403:
        messages.append("Warning: user_admin role required to replicate group membership — add groups manually.")
        return 0, 0, None
    if status != 200:
        messages.append(f"Warning: could not retrieve group membership (HTTP {status})")
        return 0, 0, False

    added = failed = 0
    for group_id in sorted(groups - existing):
        resp = session.post(
            f"{base_url}{_TABLE}/sys_user_grmember",
            json={"user": account_sys_id, "group": group_id},
            headers=headers,
        )
        if resp.status_code in (200, 201):
            added += 1
        else:
            failed += 1
            messages.append(f"Warning: could not add to group {group_id} (HTTP {resp.status_code})")
    return added, failed, True


def _compare_effective_roles(session, base_url, setup_user_sys_id, account_sys_id) -> Dict[str, Any]:
    """Compare effective roles (direct and inherited, state=active) of both users.

    Returns {"compared": bool, "missing": [names], "elevated_skipped": [names],
    "account_role_count": int}. 'missing' lists non-elevated roles the setup user
    holds and the account does not hold by any path; 'elevated_skipped' lists elevated
    roles (sys_user_role.elevated_privilege) the setup user holds and the account lacks;
    'account_role_count' is the account's number of non-elevated roles. Any failure
    returns compared=False with empty results rather than raising.
    """
    failed = {"compared": False, "missing": [], "elevated_skipped": [], "account_role_count": 0}
    try:
        human = _fetch_effective_role_ids(session, base_url, setup_user_sys_id)
        account = _fetch_effective_role_ids(session, base_url, account_sys_id)
        if human is None or account is None:
            return failed
        meta = _fetch_role_meta(session, base_url, human | account)
        if meta is None:
            return failed

        def name(rid):
            return meta.get(rid, {}).get("name", rid)

        def elevated(rid):
            return meta.get(rid, {}).get("elevated", False)

        lacking = human - account
        return {
            "compared": True,
            "missing": sorted(name(r) for r in lacking if not elevated(r)),
            "elevated_skipped": sorted(name(r) for r in lacking if elevated(r)),
            "account_role_count": sum(1 for r in account if not elevated(r)),
        }
    except Exception:
        return failed


def create_attributed_service_account(
    session: requests.Session,
    instance_url: str,
    setup_username: str,
    setup_user_sys_id: str,
    setup_user_display_name: str,
    hostname: str = "",
    progress_callback=None,
) -> Dict[str, Any]:
    """
    Create a dedicated sys_user for MCP API calls attributed to the setup user.

    The account is named '{setup_username}.claude.{hostname[:N]}' where
    setup_username is capped at 28 chars and N = max(4, 32 - len(capped_username)),
    keeping total user_name ≤ 40 chars (ServiceNow field limit).
    If hostname is empty, socket.gethostname() is used as a fallback.

    Migration: if '{setup_username}.claude_assisted' exists but the new-style name
    does not, the existing account's user_name is updated to the new-style name.
    Migration failure falls back to creating a fresh new-style account.

    The account is created without an email address. Existing accounts are not
    modified for email.

    If the new-style account already exists, roles and group membership are re-synced
    but the password is NOT rotated.

    Args:
        session: Authenticated requests.Session (basic auth or bearer token configured)
        instance_url: ServiceNow instance URL (e.g., "https://dev123.service-now.com")
        setup_username: Login name of the human admin running setup (e.g., "rafael")
        setup_user_sys_id: sys_id of the setup user's sys_user record
        setup_user_display_name: Full display name (e.g., "Rafael Yew")
        hostname: Machine hostname for account name scoping. Falls back to
            socket.gethostname() if empty.
        progress_callback: Optional callable(message: str). Called with progress
            messages during account setup.

    Returns:
        Dict with keys:
        - success: bool
        - user_name: str — the attributed account's login name (when success)
        - password: str — generated password (when success; empty string if account pre-existed)
        - messages: list[str] — status messages
        - roles_assigned: int — direct roles copied (when success). Roles with
          sys_user_role.elevated_privilege set, and roles the account already holds, are not copied.
        - roles_skipped: bool — True if reading roles or group membership returned 403
        - roles_failed: int — number of role assignments that failed (when success)
        - groups_added: int — sys_user_grmember rows created for the account. The setup
          user's direct active groups are added; parent groups are not walked and groups
          the account already belongs to are skipped.
        - groups_failed: int — group membership inserts that failed
        - roles_compared: bool — True when effective roles of both users were read back
        - roles_missing: list[str] — names of non-elevated roles the setup user holds
          (any path) and the account does not; empty unless roles_compared
        - roles_elevated_skipped: list[str] — names of elevated roles the setup user holds
          and the account lacks (informational; elevated roles are never copied)
        - account_role_count: int — non-elevated effective roles the account holds after
          setup; 0 when roles_compared is False
        - error: str — error message (when not success)
    """
    if not hostname:
        try:
            hostname = socket.gethostname() or ""
        except OSError:
            hostname = ""

    base_url = instance_url.rstrip("/")
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    messages = []

    try:
        new_username = _compute_new_username(setup_username, hostname)
        old_username = f"{setup_username}.claude_assisted"

        # Parse display name: split on last space
        parts = setup_user_display_name.rsplit(" ", 1)
        if len(parts) == 2:
            first_name, last_name = parts
            attributed_last_name = f"{last_name} (Claude assisted)"
        else:
            first_name = setup_user_display_name
            attributed_last_name = "(Claude assisted)"

        if progress_callback:
            progress_callback("Setting up service account...")
        # --- Check if new-style account already exists ---
        check_new = session.get(
            f"{base_url}/api/now/table/sys_user",
            params={
                "sysparm_query": f"user_name={new_username}",
                "sysparm_fields": "sys_id",
                "sysparm_limit": 1,
            },
            headers={"Accept": "application/json"},
        )

        if check_new.status_code != 200:
            return {
                "success": False,
                "messages": messages,
                "error": f"Failed to check for existing attributed user (HTTP {check_new.status_code})",
            }

        existing_new_sys_id = None
        results = check_new.json().get("result", [])
        if results:
            existing_new_sys_id = results[0]["sys_id"]

        # --- If new-style exists: re-sync roles, no password rotation ---
        if existing_new_sys_id:
            messages.append(f"Found existing attributed user '{new_username}' — re-syncing roles.")
            attributed_sys_id = existing_new_sys_id
            password = ""
        else:
            # --- Check for old-style account (migration candidate) ---
            check_old = session.get(
                f"{base_url}/api/now/table/sys_user",
                params={
                    "sysparm_query": f"user_name={old_username}",
                    "sysparm_fields": "sys_id",
                    "sysparm_limit": 1,
                },
                headers={"Accept": "application/json"},
            )

            old_sys_id = None
            if check_old.status_code == 200:
                old_results = check_old.json().get("result", [])
                if old_results:
                    old_sys_id = old_results[0]["sys_id"]

            password = secrets.token_urlsafe(32)
            attributed_sys_id = None

            if old_sys_id:
                # --- Migrate: rename user_name, update password ---
                migrate_resp = session.patch(
                    f"{base_url}/api/now/table/sys_user/{old_sys_id}",
                    json={"user_name": new_username, "user_password": password},
                    headers=headers,
                )
                if migrate_resp.status_code == 200:
                    attributed_sys_id = old_sys_id
                    messages.append(
                        f"Migrated '{old_username}' → '{new_username}'."
                    )
                else:
                    messages.append(
                        f"Warning: migration of '{old_username}' failed "
                        f"(HTTP {migrate_resp.status_code}) — creating new account instead. "
                        f"Old account left in place."
                    )

            if attributed_sys_id is None:
                # --- Fresh create ---
                create_resp = session.post(
                    f"{base_url}/api/now/table/sys_user",
                    json={
                        "user_name": new_username,
                        "first_name": first_name,
                        "last_name": attributed_last_name,
                        "active": True,
                        "notification": 1,
                        "web_service_access_only": True,
                        "password_needs_reset": False,
                        "user_password": password,
                    },
                    headers=headers,
                )
                if create_resp.status_code != 201:
                    return {
                        "success": False,
                        "messages": messages,
                        "error": f"Failed to create attributed user (HTTP {create_resp.status_code}): {create_resp.text}",
                    }
                attributed_sys_id = create_resp.json().get("result", {}).get("sys_id")
                messages.append(f"Created attributed user '{new_username}'")

        # --- Copy the setup user's direct (non-elevated) role grants ---
        grants = _copy_direct_roles(
            session, base_url, headers, setup_user_sys_id, attributed_sys_id, messages
        )

        # --- Add the account to the setup user's direct, active groups ---
        groups_added, groups_failed, groups_ok = _add_group_memberships(
            session, base_url, headers, setup_user_sys_id, attributed_sys_id, messages
        )
        roles_skipped = grants["skipped"] or groups_ok is None

        # --- Read back effective roles of both users ---
        comparison = {"compared": False, "missing": [], "elevated_skipped": [],
                      "account_role_count": 0}
        if grants["ok"] and groups_ok:
            comparison = _compare_effective_roles(
                session, base_url, setup_user_sys_id, attributed_sys_id
            )
            if not comparison["compared"]:
                messages.append("Warning: could not read back effective roles for comparison.")
        elevated_skipped = (
            comparison["elevated_skipped"] if comparison["compared"] else grants["elevated"]
        )

        return {
            "success": True,
            "user_name": new_username,
            "password": password,
            "sys_id": attributed_sys_id,
            "messages": messages,
            "roles_assigned": grants["assigned"],
            "roles_failed": grants["failed"],
            "roles_skipped": roles_skipped,
            "groups_added": groups_added,
            "groups_failed": groups_failed,
            "roles_compared": comparison["compared"],
            "roles_missing": comparison["missing"],
            "roles_elevated_skipped": elevated_skipped,
            "account_role_count": comparison["account_role_count"],
        }

    except requests.exceptions.SSLError:
        return {
            "success": False,
            "messages": messages,
            "error": (
                "SSL error connecting to the instance. "
                "If you are on a corporate network, your proxy may be intercepting HTTPS."
            ),
        }
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ReadTimeout):
        return {
            "success": False,
            "messages": messages,
            "error": "Request timed out. The instance may be under load. Retry.",
        }
    except requests.exceptions.ConnectionError:
        return {
            "success": False,
            "messages": messages,
            "error": (
                "Cannot reach the instance. "
                "Check the URL and ensure you are connected to your VPN if required."
            ),
        }
    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "messages": messages,
            "error": f"Network error: {e}",
        }
    except (ValueError, KeyError) as e:
        # json.JSONDecodeError and requests' JSON errors subclass ValueError;
        # KeyError covers rows missing an expected field (e.g. sys_id).
        return {
            "success": False,
            "messages": messages,
            "error": f"Unexpected response from the instance ({type(e).__name__}: {e}).",
        }
