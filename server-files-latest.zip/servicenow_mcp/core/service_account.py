"""Attributed Service Account Creation

Creates a dedicated sys_user for MCP operations so API calls are identifiable
in ServiceNow audit logs as AI-assisted rather than attributed to the setup user.

Standalone function — no dependency on MCP framework, ServiceNowClient, or config
system. Designed for reuse by both MCP tools and installer.
"""

import secrets
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from typing import Any, Dict


def _compute_new_username(setup_username: str, hostname: str) -> str:
    """Return '{setup_username}.claude.{hostname[:N]}' where N = max(4, 32 - len(setup_username)).

    setup_username is capped at 28 chars to ensure total user_name stays ≤ 40 chars
    (ServiceNow sys_user.user_name field limit).

    If hostname is empty after all resolution attempts, falls back to
    '{setup_username}.claude_assisted' to avoid a trailing-dot account name.
    """
    capped = setup_username[:28]
    if not hostname:
        return f"{capped}.claude_assisted"
    n = max(4, 32 - len(capped))
    return f"{capped}.claude.{hostname[:n]}"


def create_attributed_service_account(
    session: requests.Session,
    instance_url: str,
    setup_username: str,
    setup_user_sys_id: str,
    setup_user_display_name: str,
    setup_user_email: str,
    hostname: str = "",
    progress_callback=None,
) -> Dict[str, Any]:
    """
    Create a dedicated sys_user for MCP API calls attributed to the setup user.

    The account is named '{setup_username}.claude.{hostname[:N]}' where
    setup_username is capped at 28 chars and N = max(4, 32 - len(capped_username)),
    keeping total user_name ≤ 40 chars (ServiceNow field limit).
    If hostname is empty, socket.gethostname() is used as a fallback.

    Migration: if '{setup_username}.claude_assisted' exists but the new-style name
    does not, the existing account's user_name is updated to the new-style name.
    Migration failure falls back to creating a fresh new-style account.

    If the new-style account already exists, roles are re-synced but the password
    is NOT rotated.

    Args:
        session: Authenticated requests.Session (basic auth or bearer token configured)
        instance_url: ServiceNow instance URL (e.g., "https://dev123.service-now.com")
        setup_username: Login name of the human admin running setup (e.g., "rafael")
        setup_user_sys_id: sys_id of the setup user's sys_user record
        setup_user_display_name: Full display name (e.g., "Rafael Yew")
        setup_user_email: Email address to copy to the attributed account
        hostname: Machine hostname for account name scoping. Falls back to
            socket.gethostname() if empty.
        progress_callback: Optional callable(message: str). Called with progress
            messages during account setup.

    Returns:
        Dict with keys:
        - success: bool
        - user_name: str — the attributed account's login name (when success)
        - password: str — generated password (when success; empty string if account pre-existed)
        - messages: list[str] — status messages
        - roles_assigned: int — number of roles replicated (when success)
        - roles_skipped: bool — True if user_admin role was absent (when success)
        - roles_failed: int — number of role assignments that failed (when success)
        - error: str — error message (when not success)
    """
    if not hostname:
        try:
            hostname = socket.gethostname() or ""
        except OSError:
            hostname = ""

    base_url = instance_url.rstrip("/")
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    messages = []

    try:
        new_username = _compute_new_username(setup_username, hostname)
        old_username = f"{setup_username}.claude_assisted"

        # Parse display name: split on last space
        parts = setup_user_display_name.rsplit(" ", 1)
        if len(parts) == 2:
            first_name, last_name = parts
            attributed_last_name = f"{last_name} (Claude assisted)"
        else:
            first_name = setup_user_display_name
            attributed_last_name = "(Claude assisted)"

        if progress_callback:
            progress_callback("Setting up service account...")
        # --- Check if new-style account already exists ---
        check_new = session.get(
            f"{base_url}/api/now/table/sys_user",
            params={
                "sysparm_query": f"user_name={new_username}",
                "sysparm_fields": "sys_id",
                "sysparm_limit": 1,
            },
            headers={"Accept": "application/json"},
        )

        if check_new.status_code != 200:
            return {
                "success": False,
                "messages": messages,
                "error": f"Failed to check for existing attributed user (HTTP {check_new.status_code})",
            }

        existing_new_sys_id = None
        results = check_new.json().get("result", [])
        if results:
            existing_new_sys_id = results[0]["sys_id"]

        # --- If new-style exists: re-sync roles, no password rotation ---
        if existing_new_sys_id:
            messages.append(f"Found existing attributed user '{new_username}' — re-syncing roles.")
            attributed_sys_id = existing_new_sys_id
            password = ""
        else:
            # --- Check for old-style account (migration candidate) ---
            check_old = session.get(
                f"{base_url}/api/now/table/sys_user",
                params={
                    "sysparm_query": f"user_name={old_username}",
                    "sysparm_fields": "sys_id",
                    "sysparm_limit": 1,
                },
                headers={"Accept": "application/json"},
            )

            old_sys_id = None
            if check_old.status_code == 200:
                old_results = check_old.json().get("result", [])
                if old_results:
                    old_sys_id = old_results[0]["sys_id"]

            password = secrets.token_urlsafe(32)
            attributed_sys_id = None

            if old_sys_id:
                # --- Migrate: rename user_name, update password ---
                migrate_resp = session.patch(
                    f"{base_url}/api/now/table/sys_user/{old_sys_id}",
                    json={"user_name": new_username, "user_password": password},
                    headers=headers,
                )
                if migrate_resp.status_code == 200:
                    attributed_sys_id = old_sys_id
                    messages.append(
                        f"Migrated '{old_username}' → '{new_username}'."
                    )
                else:
                    messages.append(
                        f"Warning: migration of '{old_username}' failed "
                        f"(HTTP {migrate_resp.status_code}) — creating new account instead. "
                        f"Old account left in place."
                    )

            if attributed_sys_id is None:
                # --- Fresh create ---
                create_resp = session.post(
                    f"{base_url}/api/now/table/sys_user",
                    json={
                        "user_name": new_username,
                        "first_name": first_name,
                        "last_name": attributed_last_name,
                        "email": setup_user_email,
                        "active": True,
                        "web_service_access_only": True,
                        "password_needs_reset": False,
                        "user_password": password,
                    },
                    headers=headers,
                )
                if create_resp.status_code != 201:
                    return {
                        "success": False,
                        "messages": messages,
                        "error": f"Failed to create attributed user (HTTP {create_resp.status_code}): {create_resp.text}",
                    }
                attributed_sys_id = create_resp.json().get("result", {}).get("sys_id")
                messages.append(f"Created attributed user '{new_username}'")

        # --- Replicate setup user's active roles ---
        roles_resp = session.get(
            f"{base_url}/api/now/table/sys_user_has_role",
            params={
                "sysparm_query": f"user={setup_user_sys_id}^state=active^inherited=false",
                "sysparm_fields": "role",
                "sysparm_limit": 500,
            },
            headers={"Accept": "application/json"},
        )

        roles_assigned = 0
        roles_failed = 0
        roles_skipped = False

        if roles_resp.status_code == 403:
            roles_skipped = True
            messages.append("Warning: user_admin role required to replicate roles — assign roles manually.")
        elif roles_resp.status_code == 200:
            role_sys_ids = [
                role_ref.get("value") if isinstance(role_ref := r.get("role", {}), dict) else role_ref
                for r in roles_resp.json().get("result", [])
                if r.get("role")
            ]
            role_sys_ids = [r for r in role_sys_ids if r]

            def _assign_role(role_sys_id):
                resp = session.post(
                    f"{base_url}/api/now/table/sys_user_has_role",
                    json={"user": attributed_sys_id, "role": role_sys_id},
                    headers=headers,
                )
                return role_sys_id, resp.status_code

            with ThreadPoolExecutor(max_workers=min(max(len(role_sys_ids), 1), 10)) as executor:
                futures = {executor.submit(_assign_role, rid): rid for rid in role_sys_ids}
                for future in as_completed(futures):
                    role_sys_id, status_code = future.result()
                    if status_code in (200, 201):
                        roles_assigned += 1
                    else:
                        roles_failed += 1
                        messages.append(f"Warning: could not assign role {role_sys_id} (HTTP {status_code})")
        else:
            messages.append(f"Warning: could not retrieve roles (HTTP {roles_resp.status_code})")

        return {
            "success": True,
            "user_name": new_username,
            "password": password,
            "sys_id": attributed_sys_id,
            "messages": messages,
            "roles_assigned": roles_assigned,
            "roles_failed": roles_failed,
            "roles_skipped": roles_skipped,
        }

    except requests.exceptions.SSLError:
        return {
            "success": False,
            "messages": messages,
            "error": (
                "SSL error connecting to the instance. "
                "If you are on a corporate network, your proxy may be intercepting HTTPS."
            ),
        }
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ReadTimeout):
        return {
            "success": False,
            "messages": messages,
            "error": "Request timed out. The instance may be under load. Retry.",
        }
    except requests.exceptions.ConnectionError:
        return {
            "success": False,
            "messages": messages,
            "error": (
                "Cannot reach the instance. "
                "Check the URL and ensure you are connected to your VPN if required."
            ),
        }
    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "messages": messages,
            "error": f"Network error: {e}",
        }
