import os
import subprocess


class SdkRunnerError(Exception):
    pass


def run_sdk_command(cmd: list, cwd: str, instance_config: dict, error_on_conflict: bool = False) -> dict:
    """Run a now-sdk subcommand in CI mode.

    Args:
        cmd: SDK subcommand and args, e.g. ["init", "--appName", "My App"]
        cwd: Working directory (SDK project root)
        instance_config: Dict with keys: url, auth_type ("oauth" or "basic"),
            and either (client_id, client_secret) for oauth or (username, password) for basic.
        error_on_conflict: When True and cmd[0] == "build", appends --errorOnConflict
            to fail loudly when both a .now.ts and metadata/ XML exist for the same record.
            Without this flag the XML version silently wins. Always pass True in production.

    Returns:
        {"success": bool, "stdout": str, "stderr": str, "returncode": int}

    Raises:
        SdkRunnerError: if binary paths are missing or subprocess exits non-zero.
    """
    node_bin = os.environ.get("NOW_NODE_BIN")
    sdk_bin = os.environ.get("NOW_SDK_BIN")
    if not node_bin or not sdk_bin:
        raise SdkRunnerError(
            "NOW_NODE_BIN and NOW_SDK_BIN must be set in .env. "
            "Re-run the installer to configure the SDK runtime."
        )

    effective_cmd = list(cmd)
    if error_on_conflict and effective_cmd and effective_cmd[0] == "build":
        effective_cmd.append("--errorOnConflict")

    ci_env = {**os.environ}
    ci_env["SN_SDK_NODE_ENV"] = "SN_SDK_CI_INSTALL"
    ci_env["SN_SDK_INSTANCE_URL"] = instance_config["url"]

    auth_type = instance_config.get("auth_type", "basic")
    ci_env["SN_SDK_AUTH_TYPE"] = auth_type
    if auth_type == "oauth":
        ci_env["SN_SDK_OAUTH_CLIENT_ID"] = instance_config["client_id"]
        ci_env["SN_SDK_OAUTH_CLIENT_SECRET"] = instance_config["client_secret"]
    else:
        ci_env["SN_SDK_USER"] = instance_config["username"]
        ci_env["SN_SDK_USER_PWD"] = instance_config["password"]

    try:
        result = subprocess.run(
            [node_bin, sdk_bin, *effective_cmd],
            cwd=cwd,
            capture_output=True,
            text=True,
            env=ci_env,
            timeout=120,
        )
    except subprocess.TimeoutExpired:
        raise SdkRunnerError(
            f"now-sdk {cmd[0] if cmd else '<no cmd>'} timed out after 120s. "
            "Check network connectivity to the instance."
        )

    if result.returncode != 0:
        raise SdkRunnerError(
            f"now-sdk {cmd[0] if cmd else '<no cmd>'} failed (exit {result.returncode}): {result.stderr.strip() or result.stdout.strip()}"
        )

    return {
        "success": True,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "returncode": result.returncode,
    }
