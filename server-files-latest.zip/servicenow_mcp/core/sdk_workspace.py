"""SDK workspace management for Fluent scope flow action authoring.

Manages per-scope SDK project directories at ~/.snmcp/sdk-projects/<scope>/
or SNMCP_SDK_WORKSPACE_DIR. Each workspace is a git repo with auto-commit
on every write, synced to a GitHub remote using credentials from discovery_credentials.
"""
import json
import os
import re
import subprocess
from pathlib import Path


class WorkspaceError(Exception):
    pass


def get_workspace_root() -> Path:
    """Return workspace root. Reads SNMCP_SDK_WORKSPACE_DIR or defaults to ~/.snmcp/sdk-projects/."""
    custom = os.environ.get("SNMCP_SDK_WORKSPACE_DIR", "").strip()
    if custom:
        return Path(custom)
    return Path.home() / ".snmcp" / "sdk-projects"


def get_workspace_path(scope_prefix: str) -> Path:
    return get_workspace_root() / scope_prefix


def workspace_exists(scope_prefix: str) -> bool:
    return get_workspace_path(scope_prefix).exists()


def init_workspace(scope_prefix: str, instance: str) -> Path:
    """Create workspace directory, scaffold files, git init, npm install.
    Idempotent — safe to call on an existing workspace.
    Returns the workspace Path.
    """
    workspace = get_workspace_path(scope_prefix)
    workspace.mkdir(parents=True, exist_ok=True)
    (workspace / "src" / "entities").mkdir(parents=True, exist_ok=True)

    _write_if_missing(workspace / ".gitignore", "node_modules/\ndist/\n")

    _write_if_missing(workspace / "package.json", json.dumps({
        "name": f"snmcp-{scope_prefix.replace('_', '-')}",
        "version": "1.0.0",
        "private": True,
        "dependencies": {"@servicenow/sdk": "latest"},
    }, indent=2) + "\n")

    _write_if_missing(workspace / "tsconfig.json", json.dumps({
        "extends": "./node_modules/@servicenow/sdk/tsconfig.base.json",
        "include": ["src/**/*"],
    }, indent=2) + "\n")

    if not (workspace / "snmcp.json").exists():
        _write_manifest(workspace, {
            "scope": scope_prefix,
            "instance": instance,
            "github_repo": None,
            "entities": {},
        })

    if not (workspace / ".git").exists():
        # Try -b main (Git >= 2.28); fall back to init + rename branch for older Git
        result = subprocess.run(
            ["git", "init", "-b", "main"],
            cwd=workspace,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            # Older git — init with default branch then rename
            _run_git(workspace, ["init"])
            _run_git(workspace, ["checkout", "-b", "main"])
        _run_git(workspace, ["config", "user.email", "snmcp@servicenow.com"])
        _run_git(workspace, ["config", "user.name", "ServiceNow MCP"])
        _run_git(workspace, ["add", "-A"])
        _run_git(workspace, ["commit", "-m", "chore: initialize SDK workspace"])

    _npm_install(workspace)
    return workspace


def _write_if_missing(path: Path, content: str) -> None:
    if not path.exists():
        path.write_text(content, encoding="utf-8")


def _npm_install(workspace: Path) -> None:
    """Run npm install in the workspace using NOW_NODE_BIN if available."""
    node_bin = os.environ.get("NOW_NODE_BIN", "node")
    node_dir = str(Path(node_bin).parent) if node_bin != "node" else ""
    env = {**os.environ}
    if node_dir:
        env["PATH"] = node_dir + os.pathsep + env.get("PATH", "")
    result = subprocess.run(
        ["npm", "install", "--prefer-offline"],
        cwd=workspace,
        capture_output=True,
        text=True,
        env=env,
    )
    if result.returncode != 0:
        raise WorkspaceError(
            f"npm install failed:\n"
            f"stderr: {result.stderr.strip()}\n"
            f"stdout: {result.stdout.strip()}"
        )


def _run_git(cwd: Path, args: list) -> str:
    result = subprocess.run(
        ["git"] + args,
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise WorkspaceError(f"git {' '.join(args)} failed: {result.stderr.strip()}")
    return result.stdout.strip()


def git_commit(scope_prefix: str, message: str) -> None:
    """Stage all changes and commit. No-op if working tree is clean."""
    workspace = get_workspace_path(scope_prefix)
    # Check for uncommitted changes first to avoid staging stray files unnecessarily
    status = _run_git(workspace, ["status", "--porcelain"])
    if status:
        _run_git(workspace, ["add", "-A"])
        _run_git(workspace, ["commit", "-m", message])


def _write_manifest(workspace: Path, manifest: dict) -> None:
    (workspace / "snmcp.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def read_manifest(scope_prefix: str) -> dict:
    path = get_workspace_path(scope_prefix) / "snmcp.json"
    if not path.exists():
        raise WorkspaceError(
            f"No workspace found for scope '{scope_prefix}'. "
            "Run init_scope_workspace first."
        )
    return json.loads(path.read_text(encoding="utf-8"))


def write_manifest(scope_prefix: str, manifest: dict) -> None:
    workspace = get_workspace_path(scope_prefix)
    _write_manifest(workspace, manifest)


def update_manifest_entity(scope_prefix: str, filename: str, meta: dict) -> None:
    """Upsert an entity entry in the manifest keyed by filename.
If last_deployed is omitted from meta, the existing value is preserved;
callers that pass last_deployed=None explicitly will reset it."""
    manifest = read_manifest(scope_prefix)
    existing = manifest["entities"].get(filename, {})
    manifest["entities"][filename] = {**existing, **meta}
    write_manifest(scope_prefix, manifest)


def write_entity_file(scope_prefix: str, filename: str, content: str) -> Path:
    """Write TypeScript content to src/entities/<filename>."""
    path = get_workspace_path(scope_prefix) / "src" / "entities" / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# GitHub credential retrieval
# ---------------------------------------------------------------------------

def get_github_credentials(client) -> tuple:
    """Return (username, token) from discovery_credentials via Foundry Script Runner.

    Uses getDecryptedValue() server-side since the REST API does not expose
    credential passwords. Requires the Foundry Script Runner to be installed
    (setup_script_runner MCP tool).
    """
    from .query_builder import QueryBuilder

    cred_name_env = os.environ.get("SERVICENOW_GITHUB_CREDENTIAL", "").strip()
    qb = QueryBuilder()
    if cred_name_env:
        qb.add_equals("name", cred_name_env)
    else:
        qb.add_like("name", "github")
    qb.add_equals("type", "basic_auth")
    resp = client.query_table(
        "discovery_credentials",
        query=qb.build(),
        fields=["sys_id", "name"],
        limit=1,
    )
    if not resp["success"] or not resp.get("result"):
        raise WorkspaceError(
            "No GitHub credential found on this instance. "
            "Run create_github_credential first."
        )

    cred_sys_id = resp["result"][0]["sys_id"]
    if not re.fullmatch(r"[0-9a-f]{32}", cred_sys_id):
        raise WorkspaceError(f"Unexpected sys_id format from discovery_credentials: {cred_sys_id!r}")
    script = (
        f"var gr = new GlideRecord('discovery_credentials');"
        f"gr.get('{cred_sys_id}');"
        f"gs.info(JSON.stringify({{"
        f"username: gr.getValue('user_name'),"
        f"token: gr.getDecryptedValue('password')"
        f"}}));"
    )
    foundry_url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
    try:
        exec_resp = client.session.post(
            foundry_url,
            json={"script": script, "timeout_ms": 10000},
        )
    except Exception as exc:
        raise WorkspaceError(f"Failed to contact Foundry Script Runner: {exc}")

    if exec_resp.status_code not in (200, 201):
        raise WorkspaceError(
            "Foundry Script Runner not available. "
            "Install it with the setup_script_runner MCP tool, then retry."
        )

    try:
        body = exec_resp.json()
        output = body.get("result", {}).get("output", [])
        for line in (output if isinstance(output, list) else []):
            msg = line.get("message", "").strip() if isinstance(line, dict) else ""
            if msg:
                data = json.loads(msg)
                return data["username"], data["token"]
    except Exception:
        pass

    raise WorkspaceError(
        "Could not parse GitHub credentials from Foundry Script Runner response. "
        "Ensure the GitHub credential has a valid username and token."
    )


# ---------------------------------------------------------------------------
# GitHub API + remote setup
# ---------------------------------------------------------------------------

def get_github_owner_options(token: str) -> list:
    """Return list of possible GitHub repo owners: personal account + org memberships.

    Returns list of dicts: [{"login": str, "type": "user"|"org"}, ...]
    """
    import requests
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
    }
    owners = []
    try:
        user_resp = requests.get("https://api.github.com/user", headers=headers, timeout=10)
        if user_resp.status_code == 200:
            login = user_resp.json().get("login")
            if login:
                owners.append({"login": login, "type": "user"})
        orgs_resp = requests.get("https://api.github.com/user/orgs", headers=headers, timeout=10)
        if orgs_resp.status_code == 200:
            for org in orgs_resp.json():
                login = org.get("login") if isinstance(org, dict) else None
                if login:
                    owners.append({"login": login, "type": "org"})
    except Exception as exc:
        raise WorkspaceError(f"GitHub API request failed: {exc}")
    return owners


def create_github_repo(token: str, owner: str, repo_name: str, private: bool = True) -> str:
    """Create a GitHub repo under owner. Returns HTTPS clone URL."""
    import requests
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
        "Content-Type": "application/json",
    }
    data = {"name": repo_name, "private": private, "auto_init": False}
    # Try org endpoint first; fall back to user endpoint on 404
    resp = requests.post(
        f"https://api.github.com/orgs/{owner}/repos",
        headers=headers,
        json=data,
        timeout=15,
    )
    if resp.status_code == 404:
        resp = requests.post(
            "https://api.github.com/user/repos",
            headers=headers,
            json=data,
            timeout=15,
        )
    if resp.status_code not in (200, 201):
        try:
            error_msg = resp.json().get("message", resp.text[:200])
        except Exception:
            error_msg = resp.text[:200]
        raise WorkspaceError(
            f"Failed to create GitHub repo '{owner}/{repo_name}': {error_msg}"
        )
    return resp.json()["clone_url"]


def git_set_remote_and_push(
    scope_prefix: str, username: str, token: str, clone_url: str
) -> None:
    """Add origin remote and push initial commit. Token embedded in URL for auth.

    Precondition: the workspace must have at least one commit (i.e., init_workspace
    must have been called first). git branch -M main fails on zero-commit repos.

    Token is never included in error messages.
    """
    auth_url = clone_url.replace("https://", f"https://{username}:{token}@")
    workspace = get_workspace_path(scope_prefix)

    def _run_sensitive(args: list, redacted_label: str) -> None:
        """Run a git command with auth URL; redact credentials from any error message."""
        result = subprocess.run(
            ["git"] + args,
            cwd=workspace,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise WorkspaceError(
                f"git {redacted_label} failed (credentials redacted): "
                f"{result.stderr.strip() or '(no output)'}"
            )

    _run_sensitive(["remote", "add", "origin", auth_url], "remote add origin <url>")
    _run_git(workspace, ["branch", "-M", "main"])  # no credentials in this command
    _run_sensitive(["push", "-u", "origin", "main"], "push -u origin main")


def clone_workspace(github_repo: str, workspace_path: Path, username: str, token: str) -> None:
    """Clone a workspace repo to workspace_path for machine-B recovery."""
    auth_url = github_repo.replace("https://", f"https://{username}:{token}@")
    workspace_path.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ["git", "clone", auth_url, str(workspace_path)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise WorkspaceError(f"git clone failed: {result.stderr.strip()}")


def write_env_workspace_dir(workspace_root: Path) -> None:
    """Write SNMCP_SDK_WORKSPACE_DIR to .env if not already set."""
    env_path = Path(".env")
    lines = env_path.read_text(encoding="utf-8").splitlines() if env_path.exists() else []
    if not any(line.startswith("SNMCP_SDK_WORKSPACE_DIR=") for line in lines):
        lines.append(f"SNMCP_SDK_WORKSPACE_DIR={workspace_root}")
        env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
