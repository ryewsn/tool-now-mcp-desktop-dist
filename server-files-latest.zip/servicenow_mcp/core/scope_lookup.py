"""Exact application-scope lookup and the sys_scope column probe.

Scope validation used to list the first 100 active scopes and search that list, which hid
every valid scope past the 100th (audit Finding 13; one instance had 2389). These helpers
look a scope up by exact value instead.
"""

import re
from typing import Any, Dict, Tuple

import requests

_SCRIPT_RUNNER_PATH = "/api/now/foundry_script_runner/execute"
_TABLE_NAME_RE = re.compile(r"^[a-zA-Z0-9_.]+$")
_MARKER = "has_scope:"
_SYS_ID_RE = re.compile(r"^[A-Za-z0-9_-]+$")

# (instance alias, table) -> bool
_scope_column_cache: Dict[Tuple[str, str], bool] = {}


def scope_value(ref: Any) -> str:
    """Return a reference field's value whether the API gave {"value": ..} or a bare string."""
    if isinstance(ref, dict):
        return str(ref.get("value", ""))
    return str(ref or "")


def resolve_scope(client, scope: str) -> Dict[str, Any]:
    """Resolve a scope id, scope sys_id or "global" with one exact query on sys_scope.

    Returns {"success": True, "sys_id", "scope", "name"} or {"success": False, "error"}.

    "global" is looked up by sys_id: on a real instance (ayew3, 2026-11-18) many ordinary
    apps carry the scope value "global", so `scope=global` is not unique, while the real
    Global row has sys_id "global".
    """
    if not scope or not str(scope).strip():
        return {"success": False, "error": "scope is required."}
    scope = str(scope).strip()

    if scope == "global":
        query = "sys_id=global"
    else:
        query = f"scope={scope}^ORsys_id={scope}"

    response = client.query_table(
        "sys_scope", query, fields=["sys_id", "scope", "name"], limit=2
    )
    if not response.get("success"):
        return {
            "success": False,
            "error": f"Failed to look up scope '{scope}': {response.get('error', '')}",
        }

    rows = response.get("result") or []
    if not rows:
        return {
            "success": False,
            "error": (
                f"Application scope '{scope}' was not found in sys_scope. Retry with "
                f"scope='global', or a scope id from get_table_schema / query_table on "
                f"sys_scope (field `scope`, e.g. x_myco_myapp)."
            ),
        }
    if len(rows) > 1:
        return {
            "success": False,
            "error": (
                f"More than one sys_scope record matches '{scope}'. Retry with the scope's "
                f"sys_id (query_table on sys_scope shows it)."
            ),
        }

    row = rows[0]
    return {
        "success": True,
        "sys_id": scope_value(row.get("sys_id")),
        "scope": scope_value(row.get("scope")),
        "name": scope_value(row.get("name")),
    }


def table_has_scope_column(client, table: str) -> Dict[str, Any]:
    """Ask the instance whether `table` has a sys_scope column (cached per instance and table).

    Returns {"success": True, "has_scope": bool} or {"success": False, "error"}. Uses one
    Script Runner call; only the marker line in result.output is trusted.
    """
    if not table or not _TABLE_NAME_RE.match(table):
        return {"success": False, "error": f"Invalid table name: {table!r}"}

    key = (client.config.alias, table)
    if key in _scope_column_cache:
        return {"success": True, "has_scope": _scope_column_cache[key]}

    if not client._prepare_request():
        return {"success": False, "error": "Not authenticated to the instance."}

    script = (
        f"var gr = new GlideRecord('{table}');\n"
        f"gs.info('{_MARKER}' + gr.isValidField('sys_scope'));"
    )
    url = f"{client.config.instance}{_SCRIPT_RUNNER_PATH}"
    try:
        response = client.session.post(url, json={"script": script})
    except requests.exceptions.RequestException as e:
        return {"success": False, "error": str(e)}

    if response.status_code == 400 and "does not represent any resource" in response.text:
        return {
            "success": False,
            "error": "Script Runner not installed — use setup_script_runner to install it",
        }
    if response.status_code not in (200, 201):
        return {
            "success": False,
            "error": f"HTTP {response.status_code}: {response.text[:500]}",
        }

    output = (response.json().get("result") or {}).get("output") or []
    for line in output:
        if isinstance(line, str) and line.startswith(_MARKER):
            has_scope = line[len(_MARKER):].strip().lower() == "true"
            _scope_column_cache[key] = has_scope
            return {"success": True, "has_scope": has_scope}

    return {
        "success": False,
        "error": f"Could not determine whether '{table}' has a sys_scope column "
                 f"(no marker in script output).",
    }


def clear_scope_column_cache() -> None:
    """Empty the sys_scope column cache (tests, and reset_client)."""
    _scope_column_cache.clear()


def parent_agent_scope(client, agent_sys_id: str) -> Dict[str, Any]:
    """Read an AI Agent's sys_scope, the scope its child records (tool links, team
    memberships) must be created in.

    Returns {"success": True, "scope": <scope sys_id>} or {"success": False, "error"}. A
    failed or empty read is an error: callers refuse and write nothing, they never fall back
    to the session's ambient scope.
    """
    agent_sys_id = str(agent_sys_id or "").strip()
    if not _SYS_ID_RE.match(agent_sys_id):
        return {
            "success": False,
            "error": (
                f"Could not read the scope of agent '{agent_sys_id}': not a valid sys_id. "
                f"Nothing was written."
            ),
        }
    response = client.query_table(
        "sn_aia_agent", f"sys_id={agent_sys_id}", fields=["sys_id", "sys_scope"], limit=1
    )
    if not response.get("success"):
        return {
            "success": False,
            "error": (
                f"Could not read the scope of agent {agent_sys_id}: "
                f"{response.get('error', 'query failed')}. Nothing was written."
            ),
        }
    rows = response.get("result") or []
    if not rows:
        return {
            "success": False,
            "error": f"Could not read the scope of agent {agent_sys_id}: agent not found. "
                     f"Nothing was written.",
        }
    scope = scope_value(rows[0].get("sys_scope"))
    if not scope:
        return {
            "success": False,
            "error": (
                f"Could not read the scope of agent {agent_sys_id}: the record has no "
                f"sys_scope value. Nothing was written."
            ),
        }
    return {"success": True, "scope": scope}


def landed_scope_text(result: Dict[str, Any], has_scope_column: bool = True) -> str:
    """Describe the scope a scoped write reported, e.g. 'x_snc_demo (Demo)'.

    A missing scope on a table that has a sys_scope column means the stored scope could not
    be looked up ("scope unknown"); `has_scope_column=False` is for tables without the column.
    """
    scope = (result or {}).get("scope")
    if not scope:
        return "scope unknown" if has_scope_column else "(table has no scope column)"
    name = (result or {}).get("scope_name")
    return f"{scope} ({name})" if name else str(scope)
