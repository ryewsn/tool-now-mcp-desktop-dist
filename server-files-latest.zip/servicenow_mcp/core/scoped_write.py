"""Scope-aware writes with read-back verification.

A write that targets an application scope is only reported as successful after the stored
record is read back and checked. Messages are built from that read-back, never from the
request or a script marker.

Rules (see docs/superpowers/specs/2026-11-18-scope-integrity-design.md section 9a):
- Update and delete by `sys_id` need no scope.
- A non-unique identifier (`match`) needs a scope and must resolve to exactly one record.
- Inserts require a scope (placement) on a table that has a sys_scope column.
- Updates never change a record's scope. `_move_scope` is an internal layer function only.
"""

import json
import re
from typing import Any, Dict, List, Optional

import requests

from .query_builder import QueryBuilder
from .scope_lookup import resolve_scope, scope_value, table_has_scope_column

_SCRIPT_RUNNER_PATH = "/api/now/foundry_script_runner/execute"
_RUNNER_MISSING = "Script Runner not installed — use setup_script_runner to install it"
_SYS_ID_MARKER_RE = re.compile(r"^[0-9a-fA-F]{32}$")
_SYS_ID_ARG_RE = re.compile(r"^[A-Za-z0-9_-]+$")
_MAX_CANDIDATES = 10


def _fail(error: str, status_code: int = 200) -> Dict[str, Any]:
    return {"success": False, "status_code": status_code, "error": error, "result": {}}


def _post_script(client, script: str) -> Dict[str, Any]:
    """Run a server-side script through the Script Runner.

    Returns {"success": True, "output": [lines]} or {"success": False, "status_code", "error"}.
    """
    if not client._prepare_request():
        return {"success": False, "status_code": 401, "error": "Not authenticated to the instance."}

    url = f"{client.config.instance}{_SCRIPT_RUNNER_PATH}"
    try:
        response = client.session.post(url, json={"script": script})
    except requests.exceptions.RequestException as e:
        return {"success": False, "status_code": 0, "error": str(e)}

    if response.status_code == 400 and "does not represent any resource" in response.text:
        return {"success": False, "status_code": 400, "error": _RUNNER_MISSING}
    if response.status_code not in (200, 201):
        return {
            "success": False,
            "status_code": response.status_code,
            "error": response.text[:500],
        }

    try:
        body = response.json()
    except ValueError:
        return {
            "success": False,
            "status_code": response.status_code,
            "error": "Script Runner returned a response that is not valid JSON.",
        }
    result = body.get("result") if isinstance(body, dict) else None
    if result is None:
        result = {}
    if not isinstance(result, dict):
        return {
            "success": False,
            "status_code": response.status_code,
            "error": "Script Runner returned an unexpected response (result is not an object).",
        }

    if result.get("error"):
        return {
            "success": False,
            "status_code": 200,
            "error": f"Script execution error: {result['error']}",
        }
    output = [line for line in (result.get("output") or []) if isinstance(line, str)]
    return {"success": True, "output": output}


def _setter_lines(data: Dict[str, Any]) -> str:
    return "\n".join(
        f"gr.setValue({json.dumps(field)}, {json.dumps(value)});"
        for field, value in (data or {}).items()
    )


def _insert_script(table: str, data: Dict[str, Any]) -> str:
    parts = [f"var gr = new GlideRecord({json.dumps(table)});", "gr.initialize();"]
    setters = _setter_lines(data)
    if setters:
        parts.append(setters)
    parts.extend([
        "var sysId = gr.insert();",
        "if (sysId) { gs.info('sys_id:' + sysId); }",
        "else { gs.info('insert_failed'); }",
    ])
    return "\n".join(parts)


def _update_script(table: str, sys_id: str, data: Dict[str, Any]) -> str:
    parts = [
        f"var gr = new GlideRecord({json.dumps(table)});",
        f"if (!gr.get({json.dumps(sys_id)})) {{ gs.info('record_not_found'); }}",
        "else {",
    ]
    setters = _setter_lines(data)
    if setters:
        parts.append(setters)
    parts.extend([
        "var ok = gr.update();",
        "if (ok) { gs.info('updated:' + ok); } else { gs.info('update_failed'); }",
        "}",
    ])
    return "\n".join(parts)


def _delete_script(table: str, sys_id: str) -> str:
    return "\n".join([
        f"var gr = new GlideRecord({json.dumps(table)});",
        f"if (!gr.get({json.dumps(sys_id)})) {{ gs.info('record_not_found'); }}",
        "else {",
        "var ok = gr.deleteRecord();",
        "if (ok) { gs.info('deleted:true'); } else { gs.info('delete_failed'); }",
        "}",
    ])


def _norm(value: Any) -> str:
    """Normalise a field value for comparing a submitted value with a read-back value."""
    if isinstance(value, dict):
        value = value.get("value", "")
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return ""
    return str(value)


def _any_line(output: List[str], marker: str) -> bool:
    return any(marker in line for line in output)


def _describe_scope(client, scope_sys_id: str) -> Dict[str, Optional[str]]:
    """Look a stored scope up for display; fall back to the bare sys_id."""
    if not scope_sys_id:
        return {"sys_id": "", "scope": None, "name": None}
    looked_up = resolve_scope(client, scope_sys_id)
    if looked_up.get("success"):
        return {"sys_id": scope_sys_id, "scope": looked_up["scope"], "name": looked_up["name"]}
    return {"sys_id": scope_sys_id, "scope": None, "name": None}


def _scope_label(desc: Dict[str, Optional[str]]) -> str:
    if desc["scope"]:
        return f"{desc['scope']} ({desc['name']}, sys_id {desc['sys_id']})"
    return f"sys_id '{desc['sys_id'] or '(none)'}'"


def _resolve_target(
    client,
    table: str,
    *,
    sys_id: str,
    match: Optional[Dict[str, Any]],
    scope: Optional[str],
    param_name: str,
    has_scope: bool,
) -> Dict[str, Any]:
    """Find the one record to write to.

    Returns {"success": True, "sys_id", "stored_scope"} (stored_scope is a sys_id or None for
    a table without a scope column) or a _fail dict.
    """
    resolved_stated = None
    if scope and str(scope).strip() and has_scope:
        resolved_stated = resolve_scope(client, scope)
        if not resolved_stated["success"]:
            return _fail(resolved_stated["error"], 0)

    fields = ["sys_id", "sys_scope"] if has_scope else ["sys_id"]

    if sys_id:
        if not _SYS_ID_ARG_RE.match(str(sys_id)):
            return _fail(f"Invalid sys_id: {sys_id!r}", 0)
        response = client.query_table(table, f"sys_id={sys_id}", fields=fields, limit=1)
        if not response.get("success"):
            return _fail(
                f"Failed to look up {table} record {sys_id}: {response.get('error', '')}",
                response.get("status_code", 0),
            )
        rows = response.get("result") or []
        if not rows:
            return _fail(f"Record not found: {sys_id} in {table}.")
        stored = scope_value(rows[0].get("sys_scope")) if has_scope else None
        if resolved_stated and stored != resolved_stated["sys_id"]:
            desc = _describe_scope(client, stored)
            return _fail(
                f"Record {sys_id} in {table} is stored in scope {_scope_label(desc)}, which "
                f"differs from the stated `{param_name}='{scope}'`. Updates never change a "
                f"record's scope. Retry with `{param_name}` set to the stored scope, or omit "
                f"`{param_name}` when addressing the record by sys_id.",
                0,
            )
        return {"success": True, "sys_id": sys_id, "stored_scope": stored}

    if not match:
        return _fail("Give either `sys_id` or `match` (field filters) to identify the record.", 0)

    builder = QueryBuilder()
    for field, value in match.items():
        text = _norm(value)
        if not text.strip():
            return _fail(
                f"match value for '{field}' is empty, so it cannot narrow the lookup (an empty "
                f"filter is silently dropped and could select an unrelated record). Give a "
                f"value, or use `sys_id` instead.",
                0,
            )
        if "^" in text or "\n" in text or "^" in str(field):
            return _fail(
                f"match value for '{field}' contains a character ('^' or a newline) that "
                f"cannot be used in a lookup. Use `sys_id` instead.",
                0,
            )
        builder.add_equals(field, text)

    if has_scope:
        if not scope or not str(scope).strip():
            return _fail(
                f"`{table}` has a scope column, and a lookup by `match` is not unique without "
                f"one. Retry with `{param_name}='<scope id>'`, or `{param_name}='global'` if "
                f"Global is intended; or address the record by `sys_id`.",
                0,
            )
        builder.add_equals("sys_scope", resolved_stated["sys_id"])

    fields = fields + (["name"] if "name" not in fields else [])
    response = client.query_table(table, builder.build(), fields=fields, limit=_MAX_CANDIDATES)
    if not response.get("success"):
        return _fail(
            f"Failed to look up {table} by match: {response.get('error', '')}",
            response.get("status_code", 0),
        )
    rows = response.get("result") or []
    where = f" in scope {resolved_stated['scope']}" if resolved_stated else ""
    if not rows:
        return _fail(f"No record in {table} matches {json.dumps(match)}{where}.")
    if len(rows) > 1:
        lines = []
        for row in rows:
            row_scope = scope_value(row.get("sys_scope")) if has_scope else ""
            shown = resolved_stated["scope"] if resolved_stated else (row_scope or "n/a")
            lines.append(
                f"  sys_id={scope_value(row.get('sys_id'))}  "
                f"name={_norm(row.get('name')) or '(none)'}  scope={shown}"
            )
        return _fail(
            f"{len(rows)} records in {table} match {json.dumps(match)}{where}; refusing to "
            f"write to any of them. Candidates:\n" + "\n".join(lines) +
            "\nRetry with `sys_id` set to the one you mean."
        )
    row = rows[0]
    stored = scope_value(row.get("sys_scope")) if has_scope else None
    return {"success": True, "sys_id": scope_value(row.get("sys_id")), "stored_scope": stored}


def scoped_insert(
    client,
    table: str,
    data: Dict[str, Any],
    scope: Optional[str],
    param_name: str = "scope",
) -> Dict[str, Any]:
    """Insert a record through GlideRecord and verify it by reading it back.

    scope accepts a scope id (x_...), a scope sys_id or "global". On a table that has a
    sys_scope column it is required; on a table without one it is ignored. `param_name` is the
    caller's own name for the parameter, used in the retry text of a refusal.

    Returns {"success", "status_code", "result": {"sys_id", "scope", "scope_name"}, "error"?}.
    """
    probe = table_has_scope_column(client, table)
    if not probe["success"]:
        return _fail(probe["error"], 0)
    has_scope = probe["has_scope"]

    resolved = None
    if has_scope:
        if not scope or not str(scope).strip():
            return _fail(
                f"`{table}` has a scope column and no `{param_name}` was given. Retry with "
                f"`{param_name}='<scope id>'`, or `{param_name}='global'` if Global is intended.",
                0,
            )
        resolved = resolve_scope(client, scope)
        if not resolved["success"]:
            return _fail(resolved["error"], 0)
        data = {**(data or {}), "sys_scope": resolved["sys_id"]}

    run = _post_script(client, _insert_script(table, data))
    if not run["success"]:
        return _fail(run["error"], run.get("status_code", 0))
    output = run["output"]

    if _any_line(output, "insert_failed"):
        return _fail(f"GlideRecord insert failed on {table}")

    new_sys_id = ""
    for line in output:
        if line.startswith("sys_id:"):
            new_sys_id = line.split(":", 1)[1].strip()
            break
    if not new_sys_id:
        return _fail(f"GlideRecord insert on {table} returned no sys_id.")
    if not _SYS_ID_MARKER_RE.match(new_sys_id):
        return _fail(
            f"GlideRecord insert on {table} returned a malformed sys_id ({new_sys_id[:40]!r}); "
            f"not reading it back."
        )

    fields = ["sys_id", "sys_scope"] if has_scope else ["sys_id"]
    readback = client.query_table(table, f"sys_id={new_sys_id}", fields=fields, limit=1)
    if not readback.get("success"):
        return _fail(
            f"Insert on {table} reported sys_id {new_sys_id} but the read-back failed: "
            f"{readback.get('error', '')}",
            readback.get("status_code", 0),
        )
    rows = readback.get("result") or []
    if not rows:
        return _fail(
            f"Insert on {table} reported sys_id {new_sys_id} but no such record exists on read-back."
        )

    if not has_scope:
        return {
            "success": True,
            "status_code": 201,
            "result": {"sys_id": new_sys_id, "scope": None, "scope_name": None},
        }

    landed = scope_value(rows[0].get("sys_scope"))
    if landed != resolved["sys_id"]:
        return _fail(
            f"Record {new_sys_id} was created in {table} but landed in scope sys_id "
            f"'{landed or '(none)'}', not the requested scope. It is a stray record; "
            f"delete it or move it before retrying."
        )

    return {
        "success": True,
        "status_code": 201,
        "result": {
            "sys_id": new_sys_id,
            "scope": resolved["scope"],
            "scope_name": resolved["name"],
        },
    }


def scoped_update(
    client,
    table: str,
    data: Dict[str, Any],
    *,
    sys_id: str = "",
    match: Optional[Dict[str, Any]] = None,
    scope: Optional[str] = None,
    param_name: str = "scope",
) -> Dict[str, Any]:
    """Update one record through GlideRecord and verify it by reading it back.

    Identify the record by `sys_id` (no scope needed) or by `match` field filters (a scope is
    required on a table with a sys_scope column, and exactly one record must match). The
    record's scope is never changed. Success is decided by the read-back: the submitted
    fields hold the submitted values and `sys_scope` is unchanged.

    Returns {"success", "status_code", "result": {"sys_id", "scope", "scope_name"}, "error"?}.
    """
    if not data:
        return _fail("No fields to update were given.", 0)
    if "sys_scope" in data:
        return _fail(
            "`sys_scope` cannot be part of an update: moving a record to another scope is not "
            "available through this tool. Create the record in the right scope instead.",
            0,
        )

    probe = table_has_scope_column(client, table)
    if not probe["success"]:
        return _fail(probe["error"], 0)
    has_scope = probe["has_scope"]

    target = _resolve_target(
        client, table, sys_id=sys_id, match=match, scope=scope,
        param_name=param_name, has_scope=has_scope,
    )
    if not target["success"]:
        return target
    record_id = target["sys_id"]
    stored_before = target["stored_scope"]

    run = _post_script(client, _update_script(table, record_id, data))
    if not run["success"]:
        return _fail(run["error"], run.get("status_code", 0))
    output = run["output"]
    if _any_line(output, "record_not_found"):
        return _fail(f"Record not found: {record_id} in {table}.")
    if _any_line(output, "update_failed"):
        return _fail(
            f"GlideRecord update on {table} {record_id} returned null; nothing was written."
        )

    fields = ["sys_id"] + (["sys_scope"] if has_scope else []) + [
        f for f in data if f not in ("sys_id", "sys_scope")
    ]
    readback = client.query_table(table, f"sys_id={record_id}", fields=fields, limit=1)
    if not readback.get("success"):
        return _fail(
            f"Update on {table} {record_id} ran but the read-back failed: "
            f"{readback.get('error', '')}",
            readback.get("status_code", 0),
        )
    rows = readback.get("result") or []
    if not rows:
        return _fail(f"Record {record_id} no longer exists in {table} on read-back.")
    row = rows[0]

    mismatches = []
    for field, wanted in data.items():
        stored_value = _norm(row.get(field)) if field in row else "(field not returned)"
        if stored_value != _norm(wanted):
            mismatches.append(
                f"{field}: submitted {_norm(wanted)!r}, stored {stored_value!r}"
            )
    if mismatches:
        return _fail(
            f"The update ran on {table} {record_id}, but the read-back differs for: "
            + "; ".join(mismatches)
            + ". The record may be partly changed — check it with get_record before retrying."
        )

    stored_after = None
    if has_scope:
        stored_after = scope_value(row.get("sys_scope"))
        if stored_after != stored_before:
            return _fail(
                f"Record {record_id} in {table} changed scope during the update: was "
                f"'{stored_before or '(none)'}', now '{stored_after or '(none)'}'."
            )

    desc = _describe_scope(client, stored_after) if has_scope else {"scope": None, "name": None}
    return {
        "success": True,
        "status_code": 200,
        "result": {"sys_id": record_id, "scope": desc["scope"], "scope_name": desc["name"]},
    }


def scoped_delete(
    client,
    table: str,
    *,
    sys_id: str = "",
    match: Optional[Dict[str, Any]] = None,
    scope: Optional[str] = None,
    param_name: str = "scope",
) -> Dict[str, Any]:
    """Delete one record through GlideRecord and verify by reading back that it is gone.

    Target resolution is the same as scoped_update.
    Returns {"success", "status_code", "result": {"sys_id", "scope", "scope_name"}, "error"?}.
    """
    probe = table_has_scope_column(client, table)
    if not probe["success"]:
        return _fail(probe["error"], 0)
    has_scope = probe["has_scope"]

    target = _resolve_target(
        client, table, sys_id=sys_id, match=match, scope=scope,
        param_name=param_name, has_scope=has_scope,
    )
    if not target["success"]:
        return target
    record_id = target["sys_id"]
    desc = _describe_scope(client, target["stored_scope"]) if has_scope else {
        "scope": None, "name": None,
    }

    run = _post_script(client, _delete_script(table, record_id))
    if not run["success"]:
        return _fail(run["error"], run.get("status_code", 0))
    output = run["output"]
    if _any_line(output, "record_not_found"):
        return _fail(f"Record not found: {record_id} in {table}.")
    if _any_line(output, "delete_failed"):
        return _fail(f"GlideRecord delete on {table} {record_id} failed; record not deleted.")

    readback = client.query_table(table, f"sys_id={record_id}", fields=["sys_id"], limit=1)
    if not readback.get("success"):
        return _fail(
            f"Delete on {table} {record_id} ran but the read-back failed: "
            f"{readback.get('error', '')}",
            readback.get("status_code", 0),
        )
    if readback.get("result"):
        return _fail(
            f"Delete on {table} reported success but record {record_id} still exists on "
            f"read-back."
        )

    return {
        "success": True,
        "status_code": 200,
        "result": {"sys_id": record_id, "scope": desc["scope"], "scope_name": desc["name"]},
    }


def _move_scope(client, table: str, sys_id: str, new_scope: str) -> Dict[str, Any]:
    """Internal layer function (no MCP tool): move an existing record to another scope.

    Sets sys_scope through GlideRecord and verifies by read-back. Platform behavior for
    moving existing records through the API was inconclusive in earlier spikes, so success is
    only ever reported from the read-back.
    """
    if not _SYS_ID_ARG_RE.match(str(sys_id or "")):
        return _fail(f"Invalid sys_id: {sys_id!r}", 0)
    resolved = resolve_scope(client, new_scope)
    if not resolved["success"]:
        return _fail(resolved["error"], 0)

    script = "\n".join([
        f"var gr = new GlideRecord({json.dumps(table)});",
        f"if (!gr.get({json.dumps(sys_id)})) {{ gs.info('record_not_found'); }}",
        "else {",
        _setter_lines({"sys_scope": resolved["sys_id"]}),
        "var ok = gr.update();",
        "if (ok) { gs.info('moved:' + ok); } else { gs.info('move_failed'); }",
        "}",
    ])
    run = _post_script(client, script)
    if not run["success"]:
        return _fail(run["error"], run.get("status_code", 0))
    if _any_line(run["output"], "record_not_found"):
        return _fail(f"Record not found: {sys_id} in {table}.")

    readback = client.query_table(table, f"sys_id={sys_id}", fields=["sys_id", "sys_scope"], limit=1)
    rows = (readback.get("result") or []) if readback.get("success") else []
    if not rows:
        return _fail(f"Could not read {table} {sys_id} back after the move.")
    landed = scope_value(rows[0].get("sys_scope"))
    if landed != resolved["sys_id"]:
        return _fail(
            f"Record {sys_id} in {table} is in scope sys_id '{landed or '(none)'}' after the "
            f"move, not '{resolved['scope']}'; the move did not take effect."
        )
    return {
        "success": True,
        "status_code": 200,
        "result": {"sys_id": sys_id, "scope": resolved["scope"], "scope_name": resolved["name"]},
    }
