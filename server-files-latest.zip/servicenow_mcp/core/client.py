"""ServiceNow API Client"""

import json
import requests
import time
from typing import Dict, List, Any, Optional
from ..config.settings import get_config, InstanceConfig

class ServiceNowClient:
    """Client for ServiceNow Table API operations with OAuth and Basic Auth support."""

    def __init__(self, instance_config: InstanceConfig):
        self.config = instance_config
        self.session = requests.Session()
        self.session.headers.update({"Accept": "application/json"})

        # OAuth token management
        self._access_token: Optional[str] = None
        self._token_expiry: float = 0  # Unix timestamp
        self._last_oauth_error: Optional[dict] = None  # {"message": str, "suggestion": str | None}

        # Configure authentication
        if self.config.uses_oauth:
            # OAuth: Get token on first request (lazy loading)
            pass
        elif self.config.uses_basic_auth:
            # Basic Auth: Set up session auth
            self.session.auth = (self.config.username, self.config.password)
        else:
            raise ValueError(
                f"Instance '{self.config.alias}' has no valid authentication configured"
            )

    def _get_oauth_token(self) -> Optional[str]:
        """
        Get OAuth access token. Fetches new token if expired or missing.

        Returns:
            Access token string, or None if token acquisition fails
        """
        # Check if we have a valid cached token
        if self._access_token and time.time() < self._token_expiry:
            return self._access_token

        # Get new token
        token_url = f"{self.config.instance}/oauth_token.do"

        try:
            response = requests.post(
                token_url,
                auth=(self.config.client_id, self.config.client_secret),
                data={"grant_type": "client_credentials"},
                headers={"Accept": "application/json"},
                timeout=10
            )

            if response.status_code == 200:
                token_data = response.json()
                self._access_token = token_data.get("access_token")

                # Calculate expiry time (default to 30 minutes if not specified)
                expires_in = token_data.get("expires_in", 1800)
                # Refresh 60 seconds before actual expiry to avoid edge cases
                self._token_expiry = time.time() + expires_in - 60
                self._last_oauth_error = None  # Clear previous error on success

                return self._access_token
            else:
                self._last_oauth_error = self._classify_oauth_error(
                    response.status_code, response.text
                )
                return None

        except Exception:
            self._last_oauth_error = self._classify_oauth_error(0, "")
            return None

    @staticmethod
    def _classify_oauth_error(status_code: int, body: str) -> dict:
        """
        Classify an OAuth token failure into a user-friendly message and optional suggestion.

        Args:
            status_code: HTTP status code (0 for connection errors/timeouts)
            body: Response body text

        Returns:
            Dict with 'message' (str) and 'suggestion' (str or None)
        """
        if status_code == 0:
            return {
                "message": "Could not reach the instance",
                "suggestion": (
                    "Try logging into your instance from a browser — "
                    "it may be hibernating or temporarily unavailable"
                )
            }

        if status_code == 404:
            return {
                "message": "OAuth endpoint not found (HTTP 404)",
                "suggestion": "Verify the instance URL in your .env is correct"
            }

        if status_code == 401:
            if "invalid_client" in body:
                return {
                    "message": "OAuth application not recognised by ServiceNow (HTTP 401 invalid_client)",
                    "suggestion": (
                        "The OAuth application registered for this instance may have been deleted "
                        "from ServiceNow. Use setup_inbound_oauth to recreate it, then update the "
                        "credentials with add_instance or update the .env file directly."
                    )
                }
            if "unauthorized_client" in body:
                return {
                    "message": "OAuth app does not have client_credentials grant enabled (HTTP 401)",
                    "suggestion": (
                        "In ServiceNow, open the OAuth app in System OAuth > Application Registry "
                        "and enable Allow Grant Types: Client Credentials"
                    )
                }
            return {
                "message": "OAuth authentication rejected (HTTP 401)",
                "suggestion": None
            }

        if status_code == 400:
            if "unsupported_grant_type" in body:
                return {
                    "message": "client_credentials grant type not supported on this OAuth app (HTTP 400)",
                    "suggestion": None
                }
            return {
                "message": f"Invalid OAuth request (HTTP 400): {body[:200]}",
                "suggestion": None
            }

        if status_code in (503, 504):
            return {
                "message": f"Instance returned service unavailable (HTTP {status_code})",
                "suggestion": (
                    "Try logging into your instance from a browser — it may be hibernating"
                )
            }

        body_excerpt = body[:200] if body else "(no response body)"
        return {
            "message": f"Token request failed (HTTP {status_code}): {body_excerpt}",
            "suggestion": None
        }

    def _auth_failure_response(self, empty_result=None) -> dict:
        """
        Build a standard 401 error response using the last classified OAuth error.

        Args:
            empty_result: Value for the 'result' key ([] for list endpoints, {} for single records).
                          Omitted from response if None.

        Returns:
            Dict with 'success', 'status_code', 'error', and optionally 'result'
        """
        error_info = self._last_oauth_error or {}
        message = error_info.get("message", "OAuth token acquisition failed. Check client_id and client_secret.")
        suggestion = error_info.get("suggestion")

        error_text = message
        if suggestion:
            error_text += f"\n\nSuggested fix: {suggestion}"

        response: dict = {
            "success": False,
            "status_code": 401,
            "error": error_text
        }
        if empty_result is not None:
            response["result"] = empty_result
        return response

    def _prepare_request(self) -> bool:
        """
        Prepare authentication for the next request.

        Returns:
            True if authentication is ready, False if OAuth token acquisition failed
        """
        if self.config.uses_oauth:
            # Get OAuth token and set Bearer header
            token = self._get_oauth_token()
            if token:
                self.session.headers.update({"Authorization": f"Bearer {token}"})
                return True
            else:
                # Token acquisition failed
                return False
        else:
            # Basic auth is already configured in session.auth
            return True

    def _detect_query_warnings(
        self,
        results: List[Dict[str, Any]],
        fields: Optional[List[str]],
        limit: int
    ) -> List[Dict[str, str]]:
        """
        Detect common query issues from response data.

        Analyzes query results for patterns that indicate silent failures —
        ServiceNow returns 200 OK but the data is wrong or incomplete.

        Args:
            results: List of record dicts returned by the API
            fields: List of fields that were requested (None if all fields)
            limit: The limit parameter used in the query

        Returns:
            List of warning dicts, each with 'pattern' and 'detail' keys.
            Empty list if no issues detected.
        """
        warnings: List[Dict[str, str]] = []

        if not results:
            return warnings

        # Pattern 1: Missing fields — requested fields not present in any response record
        if fields:
            response_keys: set = set()
            for record in results:
                response_keys.update(record.keys())
            missing = [f for f in fields if f not in response_keys]
            if missing:
                warnings.append({
                    "pattern": "missing_fields",
                    "detail": f"Fields {missing} were requested but not present in any response record"
                })

        # Pattern 2: Dot-notation all null — reference traversal fields empty across all results
        if fields:
            dot_fields = [f for f in fields if "." in f]
            if dot_fields:
                all_empty = all(
                    not record.get(f) for record in results for f in dot_fields
                )
                if all_empty:
                    warnings.append({
                        "pattern": "dot_notation_all_null",
                        "detail": (
                            f"Dot-notation fields {dot_fields} are empty across all "
                            f"{len(results)} results — reference may be invalid"
                        )
                    })

        # Pattern 3: Truncated results — result count equals limit
        if len(results) == limit:
            warnings.append({
                "pattern": "truncated_results",
                "detail": (
                    f"Result count ({len(results)}) equals limit ({limit}) — "
                    f"there may be more records. Increase limit or narrow filters."
                )
            })

        return warnings

    def _detect_write_warnings(
        self,
        data: Dict[str, Any],
        result: Dict[str, Any]
    ) -> List[Dict[str, str]]:
        """
        Detect common write issues from response data.

        Compares submitted payload fields against the response record.
        ServiceNow silently ignores unknown field names — they won't appear
        in the response even though the API returns 201/200.

        Args:
            data: The payload dict that was sent to ServiceNow
            result: The single record dict returned by the API

        Returns:
            List of warning dicts, each with 'pattern' and 'detail' keys.
            Empty list if no issues detected.
        """
        warnings: List[Dict[str, str]] = []

        if not result or not data:
            return warnings

        # Pattern: Write fields ignored — payload fields not present in response record
        response_keys = set(result.keys())
        ignored = [f for f in data.keys() if f not in response_keys]
        if ignored:
            warnings.append({
                "pattern": "write_fields_ignored",
                "detail": (
                    f"Fields {ignored} were sent but not present in response "
                    f"— ServiceNow may have silently ignored them"
                )
            })

        return warnings

    def query_table(
        self,
        table_name: str,
        query: str = "",
        fields: Optional[List[str]] = None,
        limit: int = 20,
        display_value: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Query a ServiceNow table.

        Args:
            table_name: Name of the table to query
            query: Encoded query string
            fields: List of fields to return (None = all fields)
            limit: Maximum number of records to return
            display_value: Controls display values for reference fields.
                "true" = display values only, "false" = sys_ids only, "all" = both.

        Returns:
            Dict with 'success', 'status_code', 'result', optionally 'warnings' and 'error'
        """
        # Prepare authentication (OAuth token or basic auth)
        if not self._prepare_request():
            return self._auth_failure_response(empty_result=[])

        url = f"{self.config.instance}/api/now/table/{table_name}"

        params = {
            "sysparm_query": query,
            "sysparm_limit": limit
        }

        if fields:
            params["sysparm_fields"] = ",".join(fields)

        if display_value is not None:
            params["sysparm_display_value"] = display_value

        try:
            response = self.session.get(url, params=params)

            if response.status_code == 200:
                results = response.json().get("result", [])
                warnings = self._detect_query_warnings(results, fields, limit)
                response_dict: Dict[str, Any] = {
                    "success": True,
                    "status_code": 200,
                    "result": results
                }
                if warnings:
                    response_dict["warnings"] = warnings
                return response_dict
            else:
                return {
                    "success": False,
                    "status_code": response.status_code,
                    "error": response.text,
                    "result": []
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "status_code": 0,
                "error": str(e),
                "result": []
            }

    def get_record(
        self,
        table_name: str,
        sys_id: str,
        fields: Optional[List[str]] = None,
        display_value: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get a single record by sys_id."""
        # Prepare authentication
        if not self._prepare_request():
            return self._auth_failure_response(empty_result={})

        url = f"{self.config.instance}/api/now/table/{table_name}/{sys_id}"

        params = {}
        if fields:
            params["sysparm_fields"] = ",".join(fields)

        if display_value is not None:
            params["sysparm_display_value"] = display_value

        try:
            response = self.session.get(url, params=params)

            if response.status_code == 200:
                return {
                    "success": True,
                    "status_code": 200,
                    "result": response.json().get("result", {})
                }
            else:
                return {
                    "success": False,
                    "status_code": response.status_code,
                    "error": response.text,
                    "result": {}
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "status_code": 0,
                "error": str(e),
                "result": {}
            }

    def create_record(
        self,
        table_name: str,
        data: Dict[str, Any],
        scope: str = ""
    ) -> Dict[str, Any]:
        """
        Create a new record in ServiceNow.

        Args:
            table_name: Target table
            data: Field values for the new record
            scope: Application scope (e.g., 'global', 'x_123_myapp'). Empty = current scope.

        Returns:
            Dict with 'success', 'status_code', 'result', and optionally 'error'
        """
        # Prepare authentication
        if not self._prepare_request():
            return self._auth_failure_response(empty_result={})

        url = f"{self.config.instance}/api/now/table/{table_name}"

        # Add scope parameter if specified
        params = {}
        if scope:
            params["sysparm_scope"] = scope

        try:
            response = self.session.post(
                url,
                json=data,
                params=params if params else None,
                headers={"Content-Type": "application/json", "Accept": "application/json"}
            )

            if response.status_code == 201:
                result = response.json().get("result", {})
                warnings = self._detect_write_warnings(data, result)
                response_dict: Dict[str, Any] = {
                    "success": True,
                    "status_code": 201,
                    "result": result
                }
                if warnings:
                    response_dict["warnings"] = warnings
                return response_dict
            else:
                return {
                    "success": False,
                    "status_code": response.status_code,
                    "error": response.text,
                    "result": {}
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "status_code": 0,
                "error": str(e),
                "result": {}
            }

    def update_record(
        self,
        table_name: str,
        sys_id: str,
        data: Dict[str, Any],
        scope: str = ""
    ) -> Dict[str, Any]:
        """
        Update an existing record in ServiceNow.

        Args:
            table_name: Target table
            sys_id: sys_id of the record to update
            data: Field values to update
            scope: Application scope (e.g., 'global', 'x_123_myapp'). Empty = current scope.

        Returns:
            Dict with 'success', 'status_code', 'result', and optionally 'error'
        """
        # Prepare authentication
        if not self._prepare_request():
            return self._auth_failure_response(empty_result={})

        url = f"{self.config.instance}/api/now/table/{table_name}/{sys_id}"

        # Add scope parameter if specified
        params = {}
        if scope:
            params["sysparm_scope"] = scope

        try:
            response = self.session.put(
                url,
                json=data,
                params=params if params else None,
                headers={"Content-Type": "application/json", "Accept": "application/json"}
            )

            if response.status_code == 200:
                result = response.json().get("result", {})
                warnings = self._detect_write_warnings(data, result)
                response_dict: Dict[str, Any] = {
                    "success": True,
                    "status_code": 200,
                    "result": result
                }
                if warnings:
                    response_dict["warnings"] = warnings
                return response_dict
            else:
                return {
                    "success": False,
                    "status_code": response.status_code,
                    "error": response.text,
                    "result": {}
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "status_code": 0,
                "error": str(e),
                "result": {}
            }

    def delete_record(
        self,
        table_name: str,
        sys_id: str
    ) -> Dict[str, Any]:
        """
        Delete a record from ServiceNow.

        Args:
            table_name: Target table
            sys_id: sys_id of the record to delete

        Returns:
            Dict with 'success', 'status_code', and optionally 'error'
        """
        # Prepare authentication
        if not self._prepare_request():
            return self._auth_failure_response()

        url = f"{self.config.instance}/api/now/table/{table_name}/{sys_id}"

        try:
            response = self.session.delete(url)

            if response.status_code == 204:
                return {
                    "success": True,
                    "status_code": 204
                }
            else:
                return {
                    "success": False,
                    "status_code": response.status_code,
                    "error": response.text
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "status_code": 0,
                "error": str(e)
            }

    def glide_write(
        self,
        table: str,
        operation: str,
        data: dict,
        sys_id: str = ""
    ) -> Dict[str, Any]:
        """
        Write to a sys_metadata subclass table via server-side GlideRecord.

        Use for tables extending sys_metadata (sn_aia_agent, sn_aia_tool,
        sn_aia_usecase, sn_aia_version) where the REST Table API silently
        drops read-only fields and bypasses business rules on insert.

        Args:
            table: ServiceNow table name
            operation: "insert", "update", or "delete"
            data: Field/value dict — used for insert and update, ignored for delete
            sys_id: Required for update and delete; empty for insert

        Returns:
            Dict with 'success', 'status_code', 'result', and optionally 'error'.
            On insert: result contains {"sys_id": "<new_sys_id>"}.
            On update/delete: result is {}.
        """
        if not self._prepare_request():
            return self._auth_failure_response(empty_result={})

        setter_lines = "\n".join(
            f"    gr.setValue({json.dumps(field)}, {json.dumps(value)});"
            for field, value in (data or {}).items()
        )

        if operation == "insert":
            parts = [f"var gr = new GlideRecord('{table}');", "gr.initialize();"]
            if setter_lines:
                parts.append(setter_lines)
            parts.extend([
                "var sysId = gr.insert();",
                "if (sysId) { gs.info('sys_id:' + sysId); }",
                "else { gs.info('insert_failed'); }"
            ])
            script = "\n".join(parts)
        elif operation == "update":
            parts = [
                f"var gr = new GlideRecord('{table}');",
                f"if (!gr.get({json.dumps(sys_id)})) {{",
                "    gs.info('record_not_found');",
                "} else {"
            ]
            if setter_lines:
                parts.append(setter_lines)
            parts.extend(["    gr.update();", "    gs.info('updated:true');", "}"])
            script = "\n".join(parts)
        elif operation == "delete":
            script = "\n".join([
                f"var gr = new GlideRecord('{table}');",
                f"if (!gr.get({json.dumps(sys_id)})) {{",
                "    gs.info('record_not_found');",
                "} else {",
                "    gr.deleteRecord();",
                "    gs.info('deleted:true');",
                "}"
            ])
        else:
            return {
                "success": False, "status_code": 0,
                "error": f"Unknown operation: {operation}", "result": {}
            }

        url = f"{self.config.instance}/api/now/foundry_script_runner/execute"
        try:
            response = self.session.post(url, json={"script": script})
        except requests.exceptions.RequestException as e:
            return {"success": False, "status_code": 0, "error": str(e), "result": {}}

        if response.status_code == 400 and "does not represent any resource" in response.text:
            return {
                "success": False, "status_code": 400,
                "error": "Script Runner not installed — use setup_script_runner to install it",
                "result": {}
            }

        if response.status_code not in (200, 201):
            return {
                "success": False, "status_code": response.status_code,
                "error": response.text[:500], "result": {}
            }

        result = response.json().get("result", {})
        output = result.get("output", [])
        error = result.get("error")

        if error and not any("record_not_found" in line for line in output):
            return {
                "success": False, "status_code": 200,
                "error": f"Script execution error: {error}", "result": {}
            }

        if any("record_not_found" in line for line in output):
            return {
                "success": False, "status_code": 200,
                "error": f"Record not found: {sys_id}", "result": {}
            }

        if any("insert_failed" in line for line in output):
            return {
                "success": False, "status_code": 200,
                "error": f"GlideRecord insert failed on {table}", "result": {}
            }

        if operation == "insert":
            new_sys_id = ""
            for line in output:
                if line.startswith("sys_id:"):
                    new_sys_id = line.split(":", 1)[1]
                    break
            return {"success": True, "status_code": 201, "result": {"sys_id": new_sys_id}}

        return {"success": True, "status_code": 200, "result": {}}

    def query_stats(
        self,
        table_name: str,
        query: str = "",
        aggregate: str = "COUNT",
        aggregate_field: str = "",
        group_by: str = "",
        display_value: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Query the ServiceNow Aggregate (Stats) API.

        Args:
            table_name: Name of the table to aggregate
            query: Encoded query string to filter records
            aggregate: Operation — COUNT, SUM, AVG, MIN, MAX
            aggregate_field: Field to aggregate on (required for SUM/AVG/MIN/MAX)
            group_by: Comma-separated field(s) to group by
            display_value: Controls display values for group_by fields

        Returns:
            Dict with 'success', 'status_code', 'result', optionally 'error'
        """
        if not self._prepare_request():
            return self._auth_failure_response(empty_result={})

        url = f"{self.config.instance}/api/now/stats/{table_name}"

        params = {}
        if query:
            params["sysparm_query"] = query
        if group_by:
            params["sysparm_group_by"] = group_by
        if display_value is not None:
            params["sysparm_display_value"] = display_value

        # Map aggregate type to the corresponding API parameter
        agg = aggregate.upper()
        if agg == "COUNT":
            params["sysparm_count"] = "true"
        elif agg in ("SUM", "AVG", "MIN", "MAX"):
            param_key = f"sysparm_{agg.lower()}_fields"
            params[param_key] = aggregate_field
        else:
            return {
                "success": False,
                "status_code": 0,
                "error": f"Invalid aggregate type: {aggregate}. Must be COUNT, SUM, AVG, MIN, or MAX.",
                "result": {}
            }

        try:
            response = self.session.get(url, params=params)

            if response.status_code == 200:
                return {
                    "success": True,
                    "status_code": 200,
                    "result": response.json().get("result", {})
                }
            else:
                return {
                    "success": False,
                    "status_code": response.status_code,
                    "error": response.text,
                    "result": {}
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "status_code": 0,
                "error": str(e),
                "result": {}
            }

    def get_xmlstats(self, include: str = "instance") -> Dict[str, Any]:
        """
        Fetch instance stats from xmlstats.do.

        Args:
            include: Comma-separated sections to include (e.g., "instance", "instance,servlet,jvm")

        Returns:
            Dict with 'success', 'status_code', 'result' (raw XML text), optionally 'error'
        """
        if not self._prepare_request():
            return self._auth_failure_response(empty_result="")

        url = f"{self.config.instance}/xmlstats.do"
        params = {"include": include}

        try:
            response = self.session.get(url, params=params)

            if response.status_code == 200:
                return {
                    "success": True,
                    "status_code": 200,
                    "result": response.text
                }
            else:
                return {
                    "success": False,
                    "status_code": response.status_code,
                    "error": response.text[:500],
                    "result": ""
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "status_code": 0,
                "error": str(e),
                "result": ""
            }

    def get_application_scopes(self) -> Dict[str, Any]:
        """
        Get list of application scopes available in the instance.

        Returns:
            Dict with 'success', 'status_code', 'result' (list of scope records)
        """
        return self.query_table(
            table_name="sys_scope",
            query="active=true^ORDERBYname",
            fields=["scope", "name", "version"],
            limit=100
        )

# Client instances (one per ServiceNow instance)
_clients: Dict[str, ServiceNowClient] = {}

def get_client(instance: Optional[str] = None) -> ServiceNowClient:
    """
    Get a client instance for the specified ServiceNow instance.

    Args:
        instance: Instance alias (e.g., "prod", "dev"). If None, returns default instance client.

    Returns:
        ServiceNowClient configured for the requested instance

    Raises:
        ValueError: If the instance alias doesn't exist
    """
    config = get_config()
    instance_config = config.get_instance(instance)
    alias = instance_config.alias

    # Create client if it doesn't exist
    if alias not in _clients:
        _clients[alias] = ServiceNowClient(instance_config)

    return _clients[alias]

def require_instance_confirmation(instance: Optional[str], operation: str) -> Optional[str]:
    """
    Check if instance confirmation is needed for the operation.

    When multiple instances are configured and no instance is specified,
    returns an error message asking the user to confirm which instance to use.

    Args:
        instance: Instance alias provided by user (None if not specified)
        operation: Description of the operation (e.g., "create OAuth integration", "query logs")

    Returns:
        Error message if confirmation needed, None if okay to proceed
    """
    config = get_config()

    # If only one instance configured, no confirmation needed
    if not config.has_multiple_instances():
        return None

    # If instance explicitly specified, no confirmation needed
    if instance is not None:
        return None

    # Multiple instances configured but no instance specified
    instances_list = config.format_instance_list()
    return (
        f"⚠️  Multiple ServiceNow instances are configured. Please specify which instance to use for this operation.\n\n"
        f"Available instances:\n{instances_list}\n\n"
        f"To {operation}, specify the instance parameter:\n"
        f"Example: instance='prod' or instance='dev'\n\n"
        f"If no instance is specified, the default instance ('{config.default_instance}') will be used."
    )

def require_scope_confirmation(scope: Optional[str], client: 'ServiceNowClient', operation: str) -> Optional[str]:
    """
    Check if scope confirmation is needed for the operation.

    Behavior depends on authentication type:
    - Basic Auth: Warns user to check UI scope picker (sysparm_scope doesn't work)
    - OAuth: Requires explicit scope parameter (sysparm_scope works correctly)

    Args:
        scope: Application scope provided by user (None if not specified)
        client: ServiceNowClient instance to query available scopes
        operation: Description of the operation (e.g., "create OAuth application")

    Returns:
        Error message if confirmation needed, None if okay to proceed
    """
    # Check authentication type
    using_basic_auth = client.config.uses_basic_auth
    using_oauth = client.config.uses_oauth

    if scope is None:
        if using_basic_auth:
            # Basic Auth: scope parameter is ignored by ServiceNow API — the actual scope
            # is determined by the user's active UI session and cannot be overridden.
            # Don't block; if the session is in the wrong scope the write will 403 and
            # the caller will surface actionable guidance.
            return None

        # OAuth: Require explicit scope parameter (sysparm_scope works correctly with OAuth)
        scopes_response = client.get_application_scopes()
        available_scopes = []

        if scopes_response["success"] and scopes_response["result"]:
            available_scopes = scopes_response["result"][:10]

        scope_list = "\n".join(f"  • {s.get('scope')} - {s.get('name')}" for s in available_scopes)
        if len(scopes_response.get("result", [])) > 10:
            scope_list += f"\n  ... and {len(scopes_response['result']) - 10} more"

        return (
            f"⚠️  Application scope must be explicitly specified.\n\n"
            f"To {operation}, you must specify which application scope to use.\n"
            f"This prevents accidental creation in the wrong scope.\n\n"
            f"Available scopes (use scope ID, not name):\n"
            f"  • global - Global scope (most common)\n"
            f"{scope_list}\n\n"
            f"Example: scope='global' or scope='x_123_myapp'\n\n"
            f"💡 Tip: Use 'global' for OAuth apps that should be available across all scopes."
        )

    return None


def reset_clients():
    """Clear cached clients so next call creates fresh ones.

    Call this after reload_config() when instance credentials change,
    so clients are re-created with updated authentication.
    """
    global _clients
    _clients = {}
