# servicenow_mcp/core/lifecycle.py
from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

import requests as _requests

from servicenow_mcp.core.update_check import SERVER_FILES_URL as _SERVER_FILES_URL

# Lazy-compatible import: installer.installer is not packaged with the MCP server,
# so we try to import at module level but fall back to None. The function that uses
# this will do a fresh import at call time if the module-level import failed.
# Having `remove_client_configs` in the module namespace allows tests to patch it.
try:
    from installer.installer import remove_client_configs
except ImportError:
    remove_client_configs = None  # type: ignore[assignment]

_GIT_TIMEOUT = 60
_DOWNLOAD_TIMEOUT = 30
_PIP_TIMEOUT = 120
_PACKAGES = ["mcp", "requests", "python-dotenv", "keyring"]

# ---------------------------------------------------------------------------
# Config patch/unpatch
# ---------------------------------------------------------------------------

def unpatch_client_configs() -> None:
    """Remove the servicenow entry from all Claude client configs.

    Leaves all other mcpServers entries intact. No-op if entry is absent.
    """
    # Use the module-level `remove_client_configs` name (imported at top or None).
    # If it's None (MCP server process where installer is not on the path), fall back
    # to a lazy import. This function is only called from configure.py and
    # installer/uninstaller.py, both of which run with the installer present.
    fn = remove_client_configs
    if fn is None:
        from installer.installer import remove_client_configs as fn  # type: ignore[no-redef]
    fn(remove_desktop=True, remove_code=True)


# ---------------------------------------------------------------------------
# Claude Desktop process management
# ---------------------------------------------------------------------------

def close_claude_desktop() -> None:
    """Terminate Claude Desktop if it is running.

    Windows only — macOS file handles are reference-counted so open
    processes do not block directory removal. No-op on other platforms.
    Waits up to 5 seconds after termination for the process to exit.
    """
    if platform.system() != "Windows":
        return

    result = subprocess.run(
        ["tasklist", "/FI", "IMAGENAME eq Claude.exe"],
        capture_output=True, text=True,
    )
    if "Claude.exe" not in result.stdout:
        return

    subprocess.run(["taskkill", "/IM", "Claude.exe", "/F"], capture_output=True)

    for _ in range(10):
        time.sleep(0.5)
        check = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq Claude.exe"],
            capture_output=True, text=True,
        )
        if "Claude.exe" not in check.stdout:
            return


# ---------------------------------------------------------------------------
# OAuth cleanup
# ---------------------------------------------------------------------------

def _parse_env_instances(env_vars: dict) -> list[dict]:
    """Return a list of instance credential dicts for all configured instances."""
    instances_str = env_vars.get("SERVICENOW_INSTANCES", "")
    if not instances_str:
        url = env_vars.get("SERVICENOW_INSTANCE", "")
        client_id = env_vars.get("SERVICENOW_CLIENT_ID", "")
        client_secret = env_vars.get("SERVICENOW_CLIENT_SECRET", "")
        username = env_vars.get("SERVICENOW_USERNAME", "")
        password = env_vars.get("SERVICENOW_PASSWORD", "")
        sa_sys_id = env_vars.get("SERVICENOW_SA_SYS_ID", "")
        if url and (client_id or username):
            return [{
                "name": "default", "url": url,
                "client_id": client_id, "client_secret": client_secret,
                "username": username, "password": password,
                "sa_sys_id": sa_sys_id,
            }]
        return []

    results = []
    for name in [n.strip() for n in instances_str.split(",") if n.strip()]:
        key = name.replace("-", "_").upper()
        url = env_vars.get(f"SERVICENOW_INSTANCE_{key}", "")
        client_id = env_vars.get(f"SERVICENOW_CLIENT_ID_{key}", "")
        client_secret = env_vars.get(f"SERVICENOW_CLIENT_SECRET_{key}", "")
        username = env_vars.get(f"SERVICENOW_USERNAME_{key}", "")
        password = env_vars.get(f"SERVICENOW_PASSWORD_{key}", "")
        sa_sys_id = env_vars.get(f"SERVICENOW_SA_SYS_ID_{key}", "")
        if url and (client_id or username):
            results.append({
                "name": name, "url": url,
                "client_id": client_id, "client_secret": client_secret,
                "username": username, "password": password,
                "sa_sys_id": sa_sys_id,
            })
    return results


def _delete_oauth_for_instance(
    url: str, client_id: str, client_secret: str, label: str,
    username: str = "", password: str = "",
) -> dict:
    """Authenticate to one instance and delete its oauth_entity by client_id. Never raises."""
    try:
        if username and password:
            auth_kwargs = {"auth": (username, password)}
            headers = {"Accept": "application/json"}
        else:
            try:
                token_resp = _requests.post(
                    f"{url}/oauth_token.do",
                    data={
                        "grant_type": "client_credentials",
                        "client_id": client_id,
                        "client_secret": client_secret,
                    },
                    timeout=15,
                )
                token_resp.raise_for_status()
                access_token = token_resp.json()["access_token"]
            except Exception as e:
                return {
                    "success": False,
                    "message": f"[{label}] OAuth record not deleted — authentication failed: {e}. Remove it manually from ServiceNow if needed.",
                }
            auth_kwargs = {}
            headers = {"Authorization": f"Bearer {access_token}"}

        try:
            search_resp = _requests.get(
                f"{url}/api/now/table/oauth_entity",
                headers=headers,
                params={
                    "sysparm_query": f"client_id={client_id}",
                    "sysparm_fields": "sys_id,name",
                    "sysparm_limit": 5,
                },
                timeout=15,
                **auth_kwargs,
            )
            search_resp.raise_for_status()
            records = search_resp.json().get("result", [])
        except Exception as e:
            return {
                "success": False,
                "message": f"[{label}] OAuth record not deleted — search failed: {e}. Remove it manually from ServiceNow if needed.",
            }

        if not records:
            return {"success": True, "message": f"[{label}] OAuth record already removed (not found in ServiceNow)."}

        sys_id = records[0]["sys_id"]
        record_name = records[0].get("name", sys_id)

        try:
            del_resp = _requests.delete(
                f"{url}/api/now/table/oauth_entity/{sys_id}",
                headers=headers,
                timeout=15,
                **auth_kwargs,
            )
            del_resp.raise_for_status()
        except Exception as e:
            return {
                "success": False,
                "message": f"[{label}] OAuth record not deleted — delete request failed: {e}. Remove '{record_name}' manually from ServiceNow.",
            }

        suffix = f" Warning: found {len(records)} records with this client_id — check ServiceNow for duplicates." if len(records) > 1 else ""
        return {"success": True, "message": f"[{label}] Deleted OAuth app '{record_name}' from ServiceNow.{suffix}"}

    except Exception as e:
        return {
            "success": False,
            "message": f"[{label}] Unexpected error during OAuth cleanup: {e}. Remove it manually from ServiceNow if needed.",
        }


def delete_oauth_app(install_dir: str) -> dict:
    """Delete ServiceNow OAuth apps paired with this installation.

    Handles both single-instance and multi-instance .env formats. Never raises.

    Returns:
        dict with 'success' (bool) and 'message' (str).
    """
    env_path = os.path.join(install_dir, ".env")
    if not os.path.isfile(env_path):
        return {
            "success": False,
            "message": "OAuth record not deleted — .env not found. Remove it manually from ServiceNow if needed.",
        }

    env_vars = {}
    try:
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and "=" in line and not line.startswith("#"):
                    key, _, value = line.partition("=")
                    env_vars[key.strip()] = value.strip()
    except IOError as e:
        return {
            "success": False,
            "message": f"OAuth record not deleted — could not read .env: {e}. Remove it manually from ServiceNow if needed.",
        }

    instances = _parse_env_instances(env_vars)
    if not instances:
        return {
            "success": False,
            "message": "OAuth record not deleted — credentials missing from .env. Remove it manually from ServiceNow if needed.",
        }

    results = [
        _delete_oauth_for_instance(
            inst["url"], inst["client_id"], inst["client_secret"], inst["name"],
            username=inst.get("username", ""), password=inst.get("password", ""),
        )
        for inst in instances
    ]

    all_ok = all(r["success"] for r in results)
    combined_message = "\n".join(r["message"] for r in results)
    return {"success": all_ok, "message": combined_message}


# ---------------------------------------------------------------------------
# Service account cleanup
# ---------------------------------------------------------------------------

def _is_attributed_username(username: str) -> bool:
    """Return True if username matches the installer-created naming conventions."""
    return ".claude." in username or username.endswith(".claude_assisted")


def _delete_sa_for_instance(
    url: str,
    username: str,
    password: str,
    client_id: str,
    client_secret: str,
    sa_sys_id: str,
    label: str,
) -> dict:
    """Delete the attributed sys_user for one instance. Never raises."""
    try:
        # Prefer basic auth; fall back to OAuth token
        if username and password:
            auth_kwargs = {"auth": (username, password)}
            headers = {"Accept": "application/json"}
        else:
            try:
                token_resp = _requests.post(
                    f"{url}/oauth_token.do",
                    data={
                        "grant_type": "client_credentials",
                        "client_id": client_id,
                        "client_secret": client_secret,
                    },
                    timeout=15,
                )
                token_resp.raise_for_status()
                access_token = token_resp.json()["access_token"]
            except Exception as e:
                return {
                    "success": False,
                    "message": f"[{label}] Service account not deleted — authentication failed: {e}. Remove it manually from ServiceNow if needed.",
                }
            auth_kwargs = {}
            headers = {"Authorization": f"Bearer {access_token}", "Accept": "application/json"}

        if sa_sys_id:
            # Direct delete by sys_id
            try:
                del_resp = _requests.delete(
                    f"{url}/api/now/table/sys_user/{sa_sys_id}",
                    headers=headers,
                    timeout=15,
                    **auth_kwargs,
                )
                del_resp.raise_for_status()
            except Exception as e:
                return {
                    "success": False,
                    "message": f"[{label}] Service account not deleted — delete request failed: {e}. Remove it manually from ServiceNow if needed.",
                }
            return {"success": True, "message": f"[{label}] Deleted attributed service account (sys_id: {sa_sys_id})."}

        # Fallback: lookup by username
        if not username:
            return {"success": True, "message": f"[{label}] No sa_sys_id and no username — skipping service account cleanup."}

        if not _is_attributed_username(username):
            return {
                "success": True,
                "message": f"[{label}] Skipping service account deletion — '{username}' does not match installer naming pattern.",
            }

        try:
            search_resp = _requests.get(
                f"{url}/api/now/table/sys_user",
                headers=headers,
                params={
                    "sysparm_query": f"user_name={username}",
                    "sysparm_fields": "sys_id",
                    "sysparm_limit": 1,
                },
                timeout=15,
                **auth_kwargs,
            )
            search_resp.raise_for_status()
            records = search_resp.json().get("result", [])
        except Exception as e:
            return {
                "success": False,
                "message": f"[{label}] Service account not deleted — lookup failed: {e}. Remove '{username}' manually from ServiceNow if needed.",
            }

        if not records:
            return {"success": True, "message": f"[{label}] Service account already removed ('{username}' not found)."}

        found_sys_id = records[0]["sys_id"]
        try:
            del_resp = _requests.delete(
                f"{url}/api/now/table/sys_user/{found_sys_id}",
                headers=headers,
                timeout=15,
                **auth_kwargs,
            )
            del_resp.raise_for_status()
        except Exception as e:
            return {
                "success": False,
                "message": f"[{label}] Service account not deleted — delete request failed: {e}. Remove '{username}' manually from ServiceNow if needed.",
            }
        return {"success": True, "message": f"[{label}] Deleted attributed service account '{username}'."}

    except Exception as e:
        return {
            "success": False,
            "message": f"[{label}] Unexpected error during service account cleanup: {e}. Remove it manually from ServiceNow if needed.",
        }


def delete_service_account(install_dir: str) -> dict:
    """Delete attributed service accounts for all instances paired with this installation.

    Handles both single-instance and multi-instance .env formats. Never raises.

    Returns:
        dict with 'success' (bool) and 'message' (str).
    """
    env_path = os.path.join(install_dir, ".env")
    if not os.path.isfile(env_path):
        return {
            "success": False,
            "message": "Service account not deleted — .env not found. Remove it manually from ServiceNow if needed.",
        }

    env_vars = {}
    try:
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and "=" in line and not line.startswith("#"):
                    key, _, value = line.partition("=")
                    env_vars[key.strip()] = value.strip()
    except IOError as e:
        return {
            "success": False,
            "message": f"Service account not deleted — could not read .env: {e}. Remove it manually from ServiceNow if needed.",
        }

    instances = _parse_env_instances(env_vars)
    if not instances:
        return {
            "success": False,
            "message": "Service account not deleted — credentials missing from .env. Remove it manually from ServiceNow if needed.",
        }

    results = [
        _delete_sa_for_instance(
            inst["url"], inst["username"], inst["password"],
            inst["client_id"], inst["client_secret"],
            inst["sa_sys_id"], inst["name"],
        )
        for inst in instances
    ]

    all_ok = all(r["success"] for r in results)
    combined_message = "\n".join(r["message"] for r in results)
    return {"success": all_ok, "message": combined_message}


# ---------------------------------------------------------------------------
# .env cleanup
# ---------------------------------------------------------------------------

def delete_env(env_path: str) -> None:
    """Remove the .env file if it exists. No-op if absent."""
    if os.path.exists(env_path):
        os.remove(env_path)


# ---------------------------------------------------------------------------
# File fetching
# ---------------------------------------------------------------------------

def fetch_server_files(server_dir) -> str:
    """Fetch the latest server files via git pull (git installs) or zip download (installer installs).

    Returns "ok" on success, or an error string on failure.
    """
    from pathlib import Path
    server_dir = Path(server_dir)

    if (server_dir / ".git").exists():
        return _fetch_via_git(server_dir)
    return _fetch_via_zip(server_dir)


def _fetch_via_git(server_dir) -> str:
    result = subprocess.run(
        ["git", "-C", str(server_dir), "pull"],
        capture_output=True, text=True, timeout=_GIT_TIMEOUT,
    )
    if result.returncode != 0:
        stderr = result.stderr.strip()
        if "local changes" in stderr or "conflict" in stderr.lower():
            return (
                "Update failed — local changes detected. "
                "Run `git stash` in the install directory then retry."
            )
        return f"Update failed: {stderr}"
    return "ok"


def _fetch_via_zip(server_dir) -> str:
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
            tmp_path = tmp.name
        try:
            req = urllib.request.Request(
                _SERVER_FILES_URL,
                headers={"User-Agent": "servicenow-mcp-installer"},
            )
            with urllib.request.urlopen(req, timeout=_DOWNLOAD_TIMEOUT) as resp:
                with open(tmp_path, "wb") as f:
                    f.write(resp.read())
        except Exception as exc:
            return (
                f"Could not reach the update server. "
                f"Check your connection and try again. ({exc})"
            )
        mcp_dir = server_dir / "servicenow_mcp"
        if mcp_dir.is_dir():
            shutil.rmtree(mcp_dir)
        with zipfile.ZipFile(tmp_path) as zf:
            for member in zf.namelist():
                if (
                    member in ("server.py", "pyproject.toml")
                    or member.startswith("servicenow_mcp/")
                ):
                    zf.extract(member, server_dir)
        return "ok"
    except PermissionError as exc:
        return (
            f"Permission denied updating files: {exc}. "
            "Re-run the installer from SharePoint as a fallback."
        )
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass


# ---------------------------------------------------------------------------
# pip install
# ---------------------------------------------------------------------------

def pip_install(python_exe: str = sys.executable) -> str:
    """Upgrade all MCP server packages. Returns "ok" or an error string."""
    result = subprocess.run(
        [python_exe, "-m", "pip", "install", "--upgrade"] + _PACKAGES,
        capture_output=True, text=True, timeout=_PIP_TIMEOUT,
    )
    if result.returncode != 0:
        return f"Files updated but pip upgrade failed: {result.stderr.strip()}"
    return "ok"


# ---------------------------------------------------------------------------
# Sequence wrappers
# ---------------------------------------------------------------------------

def run_shared_update_steps(server_dir, python_exe: str = sys.executable) -> str:
    """Canonical update sequence for configure.py.

    Steps: unpatch configs → close Claude Desktop → fetch files → pip install.
    Repatch is the caller's responsibility.

    Returns "ok" or the first error string encountered.
    """
    unpatch_client_configs()
    close_claude_desktop()

    status = fetch_server_files(server_dir)
    if status != "ok":
        return status

    return pip_install(python_exe)


def run_shared_uninstall_steps(install_dir: str) -> dict:
    """Canonical uninstall sequence for configure.py.

    Steps: unpatch configs → close Claude Desktop → delete OAuth apps → delete .env.

    Returns the oauth result dict (success bool + message).
    """
    unpatch_client_configs()
    close_claude_desktop()
    oauth_result = delete_oauth_app(install_dir)
    delete_env(os.path.join(install_dir, ".env"))
    return oauth_result
