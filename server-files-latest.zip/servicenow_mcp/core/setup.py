"""Shared OAuth setup utilities.

Framework-independent. Used by both configure.py (interactive CLI) and
installer/installer.py (GUI wizard). No MCP framework dependencies.
"""

import socket
import requests
from requests.adapters import HTTPAdapter

from servicenow_mcp.core.inbound_oauth import create_inbound_oauth_app
from servicenow_mcp.core.service_account import create_attributed_service_account
from servicenow_mcp.core.script_runner import install_script_runner_via_session


class _TimeoutAdapter(HTTPAdapter):
    """HTTPAdapter that enforces a default timeout on all requests."""

    def __init__(self, timeout=30, **kwargs):
        self._timeout = timeout
        super().__init__(**kwargs)

    def send(self, *args, **kwargs):
        kwargs.setdefault("timeout", self._timeout)
        return super().send(*args, **kwargs)


def create_instance_oauth(
    instance_url: str,
    username: str,
    password: str,
    app_name: str,
    create_service_account: bool = True,
    timeout: int = 30,
    progress_callback=None,
) -> dict:
    """Create an inbound OAuth app in ServiceNow using basic auth (one-time use).

    The password authenticates this call only and is never written to disk.

    Never raises. Never prints. Returns a structured result dict.

    Args:
        instance_url: Full ServiceNow URL, e.g. "https://dev123.service-now.com".
        username: ServiceNow username for authentication.
        password: ServiceNow password (used once, never stored).
        app_name: Display name for the OAuth application.
        create_service_account: If True, creates an AI-attributed service account
            and returns its credentials.
        timeout: HTTP request timeout in seconds.
        progress_callback: Optional callable(msg: str) invoked before each major HTTP
            operation. Used by callers to display live progress.

    Returns:
        On success: {success: True, client_id, client_secret, messages,
                     attributed_username?, attributed_password?}
        On failure: {success: False, messages, error}
    """
    try:
        session = requests.Session()
        session.auth = (username, password)
        session.mount("https://", _TimeoutAdapter(timeout=timeout))
        session.mount("http://", _TimeoutAdapter(timeout=timeout))

        result = create_inbound_oauth_app(
            session=session,
            instance_url=instance_url.rstrip("/"),
            app_name=app_name,
            username=username,
            progress_callback=progress_callback,
        )

        if not result["success"]:
            return {
                "success": False,
                "messages": result.get("messages", []),
                "error": result.get("error", "OAuth setup failed."),
            }

        creds: dict = {
            "success": True,
            "client_id": result["client_id"],
            "client_secret": result["client_secret"],
            "messages": list(result.get("messages", [])),
        }

        # Install Script Runner as part of bootstrap — required by many tools
        _sr_ok, _sr_msg = install_script_runner_via_session(session, instance_url, progress_callback=progress_callback)
        creds["messages"].append(f"Script Runner: {_sr_msg}")

        if not create_service_account:
            return creds

        user_resp = session.get(
            f"{instance_url.rstrip('/')}/api/now/table/sys_user",
            params={
                "sysparm_query": f"user_name={username}^active=true",
                "sysparm_fields": "sys_id,name,email",
                "sysparm_limit": 1,
            },
            headers={"Accept": "application/json"},
        )

        resp_data = user_resp.json()
        if user_resp.status_code != 200 or not resp_data.get("result"):
            creds["messages"].append("Could not fetch setup user profile for service account creation (non-fatal).")
            return creds

        user_record = resp_data["result"][0]
        try:
            _hostname = socket.gethostname() or ""
        except OSError:
            _hostname = ""

        sa_result = create_attributed_service_account(
            session=session,
            instance_url=instance_url.rstrip("/"),
            setup_username=username,
            setup_user_sys_id=user_record["sys_id"],
            setup_user_display_name=user_record.get("name", username),
            setup_user_email=user_record.get("email", ""),
            hostname=_hostname,
            progress_callback=progress_callback,
        )

        creds["messages"].extend(sa_result.get("messages", []))

        if sa_result["success"]:
            creds["attributed_username"] = sa_result["user_name"]
            creds["attributed_password"] = sa_result["password"]
        else:
            creds["messages"].append(
                f"Service account creation failed (non-fatal): {sa_result.get('error')}"
            )

        return creds

    except Exception as exc:
        return {
            "success": False,
            "messages": [],
            "error": str(exc),
        }
