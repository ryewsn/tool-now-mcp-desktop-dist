"""Shared OAuth setup utilities.

Framework-independent. Used by both configure.py (interactive CLI) and
installer/installer.py (GUI wizard). No MCP framework dependencies.
"""

import socket
import requests
from requests.adapters import HTTPAdapter

from servicenow_mcp.core.inbound_oauth import create_inbound_oauth_app
from servicenow_mcp.core.oauth_identity import bind_oauth_identity, resolve_oauth_identity
from servicenow_mcp.core.service_account import create_attributed_service_account
from servicenow_mcp.core.script_runner import install_script_runner_via_session


class _TimeoutAdapter(HTTPAdapter):
    """HTTPAdapter that enforces a default timeout on all requests."""

    def __init__(self, timeout=30, **kwargs):
        self._timeout = timeout
        super().__init__(**kwargs)

    def send(self, *args, **kwargs):
        kwargs.setdefault("timeout", self._timeout)
        return super().send(*args, **kwargs)


def create_instance_oauth(
    instance_url: str,
    username: str,
    password: str,
    app_name: str,
    create_service_account: bool = True,
    timeout: int = 30,
    progress_callback=None,
) -> dict:
    """Create an inbound OAuth app in ServiceNow using basic auth (one-time use).

    The password authenticates this call only and is never written to disk.

    Never raises. Never prints. Returns a structured result dict.

    Args:
        instance_url: Full ServiceNow URL, e.g. "https://dev123.service-now.com".
        username: ServiceNow username for authentication.
        password: ServiceNow password (used once, never stored).
        app_name: Display name for the OAuth application.
        create_service_account: If True, creates an AI-attributed service account
            and returns its credentials.
        timeout: HTTP request timeout in seconds.
        progress_callback: Optional callable(msg: str) invoked before each major HTTP
            operation. Used by callers to display live progress.

    Returns:
        On success: {success: True, client_id, client_secret, messages,
                     attributed_username?, attributed_password?}
        On failure: {success: False, messages, error}
    """
    try:
        session = requests.Session()
        session.auth = (username, password)
        session.mount("https://", _TimeoutAdapter(timeout=timeout))
        session.mount("http://", _TimeoutAdapter(timeout=timeout))

        result = create_inbound_oauth_app(
            session=session,
            instance_url=instance_url.rstrip("/"),
            app_name=app_name,
            username=username,
            progress_callback=progress_callback,
        )

        if not result["success"]:
            return {
                "success": False,
                "messages": result.get("messages", []),
                "error": result.get("error", "OAuth setup failed."),
            }

        creds: dict = {
            "success": True,
            "client_id": result["client_id"],
            "client_secret": result["client_secret"],
            "messages": list(result.get("messages", [])),
            "oauth_identity": "human",
        }

        # Install Script Runner as part of bootstrap — required by many tools
        _sr_ok, _sr_msg = install_script_runner_via_session(session, instance_url, progress_callback=progress_callback)
        creds["messages"].append(f"Script Runner: {_sr_msg}")

        if resolve_oauth_identity(None, create_service_account) == "human":
            creds["messages"].append(f"Running as: {username} (no service account requested)")
            creds["identity_report"] = {"identity": "human", "setup_username": username,
                                        "requested_service_account": False}
            return creds

        user_resp = session.get(
            f"{instance_url.rstrip('/')}/api/now/table/sys_user",
            params={
                "sysparm_query": f"user_name={username}^active=true",
                "sysparm_fields": "sys_id,name",
                "sysparm_limit": 1,
            },
            headers={"Accept": "application/json"},
        )

        resp_data = user_resp.json()
        if user_resp.status_code != 200 or not resp_data.get("result"):
            creds["messages"].append("Could not fetch setup user profile for service account creation (non-fatal).")
            creds["messages"].append(
                f"Running as: {username} — fell back: setup user profile unavailable")
            creds["identity_report"] = {"identity": "human", "setup_username": username,
                                        "requested_service_account": True,
                                        "reason": "setup user profile unavailable",
                                        "account_created": False}
            return creds

        user_record = resp_data["result"][0]
        display_name = user_record.get("name") or username
        try:
            _hostname = socket.gethostname() or ""
        except OSError:
            _hostname = ""

        sa_result = create_attributed_service_account(
            session=session,
            instance_url=instance_url.rstrip("/"),
            setup_username=username,
            setup_user_sys_id=user_record["sys_id"],
            setup_user_display_name=display_name,
            hostname=_hostname,
            progress_callback=progress_callback,
        )

        creds["messages"].extend(sa_result.get("messages", []))

        oauth_entity_sys_id = result.get("app_sys_id", "")
        if oauth_entity_sys_id:
            # Bind before reporting so messages reflect the identity actually in effect.
            bind_result = bind_oauth_identity(
                session, instance_url.rstrip("/"), oauth_entity_sys_id, "service_account", sa_result)
        else:
            bind_result = {"identity": "human", "bound": False,
                           "reason": f"OAuth application id unavailable; calls run as {display_name}"}
        creds["oauth_identity"] = bind_result["identity"]
        creds["identity_report"] = {
            "identity": bind_result["identity"],
            "setup_username": username,
            "setup_display_name": display_name,
            "requested_service_account": True,
            "reason": bind_result["reason"],
            "verified": bind_result.get("verified", True),
            "account_created": bool(sa_result["success"]),
            "account_name": sa_result.get("user_name") if sa_result["success"] else None,
            "account_sys_id": sa_result.get("sys_id") if sa_result["success"] else None,
            "roles_replicated": sa_result.get("roles_assigned", 0),
            "groups_added": sa_result.get("groups_added", 0),
            "roles_missing": list(sa_result.get("roles_missing") or []),
            "roles_elevated_skipped": list(sa_result.get("roles_elevated_skipped") or []),
        }

        if sa_result["success"]:
            # Only a verified bind may put the account in .env: on fallback OAuth runs as the
            # human, and an account named in .env would make source control act as the wrong user.
            if bind_result["identity"] == "service_account" and bind_result.get("verified", True):
                creds["attributed_username"] = sa_result["user_name"]
                creds["attributed_password"] = sa_result["password"]
            creds["sa_sys_id"] = sa_result["sys_id"]  # lets uninstall find the account by id
            creds["messages"].append(f"Groups added: {sa_result.get('groups_added', 0)}")
            missing = sa_result.get("roles_missing") or []
            if missing:
                creds["messages"].append(
                    f"Warning: roles the setup user has that the service account is missing: "
                    f"{', '.join(missing)}")
            elevated = sa_result.get("roles_elevated_skipped") or []
            if elevated:
                creds["messages"].append(f"Elevated roles not replicated: {', '.join(elevated)}")
        else:
            if sa_result.get("sys_id"):
                # A confirmed-mismatch create leaves a real row: record its id (never the
                # password) so uninstall can find it.
                creds["sa_sys_id"] = sa_result["sys_id"]
            creds["messages"].append(
                f"Service account creation failed (non-fatal): {sa_result.get('error')}"
            )

        if bind_result["identity"] == "service_account":
            creds["messages"].append(f"Running as: {sa_result['user_name']}")
        elif not bind_result.get("verified", True):
            creds["messages"].append(
                f"Running as: UNVERIFIED — the update may have applied; "
                f"check oauth_entity.user ({bind_result['reason']})")
        else:
            creds["messages"].append(f"Running as: {display_name} — fell back: {bind_result['reason']}")
            if sa_result["success"]:
                creds["messages"].append(
                    f"Note: the service account was created but the OAuth application is NOT using it; "
                    f"calls run as {display_name}.")

        return creds

    except Exception as exc:
        return {
            "success": False,
            "messages": [],
            "error": str(exc),
        }
