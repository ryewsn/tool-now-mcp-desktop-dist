"""Foundry Script Runner installation constants and helper.

Shared by core/setup.py (installer/configure bootstrap) and
tools/code/scripts.py (MCP tool). No MCP framework dependencies.
"""

import requests

SCRIPT_RUNNER_BASE_URI = "/api/now/foundry_script_runner"
SCRIPT_RUNNER_SERVICE_ID = "foundry_script_runner"
SCRIPT_RUNNER_OPERATION_SCRIPT = r"""(function process(request, response) {
    var body = request.body;
    var data = body ? body.data : null;
    if (!data) {
        try { data = JSON.parse(request.body + ''); } catch(e) { data = null; }
    }
    if (!data || !data.script) {
        response.setStatus(400);
        response.setBody({ success: false, error: 'Missing script in request body', output: [], returnValue: null, duration: 0 });
        return;
    }

    var userScript = data.script + '';
    var timeoutMs = parseInt(data.timeout_ms, 10) || 10000;

    var startTime = new GlideDateTime();
    var capturedOutput = [];
    var timedOut = false;
    var success = true;
    var errorMsg = null;
    var _realGs = gs;

    var _checkTimeout = function() {
        var elapsed = GlideDateTime.subtract(startTime, new GlideDateTime()).getNumericValue();
        if (elapsed > timeoutMs) {
            timedOut = true;
            throw new Error('Script timed out after ' + elapsed + 'ms (limit: ' + timeoutMs + 'ms)');
        }
    };

    var wrappedScript =
        'var __checkTimeout = _checkTimeout;\n' +
        'var gs = {\n' +
        '    info:        function(msg) { _checkTimeout(); capturedOutput.push(String(msg));           _realGs.info(msg); },\n' +
        '    warn:        function(msg) { _checkTimeout(); capturedOutput.push("[WARN] " + msg);       _realGs.warn(msg); },\n' +
        '    error:       function(msg) { _checkTimeout(); capturedOutput.push("[ERROR] " + msg);      _realGs.error(msg); },\n' +
        '    getProperty: function(key, def) { return _realGs.getProperty(key, def); },\n' +
        '    getUser:     function()         { return _realGs.getUser(); },\n' +
        '    getUserID:   function()         { return _realGs.getUserID(); },\n' +
        '    getUserName: function()         { return _realGs.getUserName(); },\n' +
        '    hasRole:     function(role)     { return _realGs.hasRole(role); },\n' +
        '    log:         function(msg, src) { _checkTimeout(); capturedOutput.push(String(msg));      _realGs.log(msg, src); },\n' +
        '    debug:       function(msg, src) { _checkTimeout(); capturedOutput.push("[DEBUG] " + msg); _realGs.debug(msg, src); },\n' +
        '    print:       function(msg)      { _checkTimeout(); capturedOutput.push(String(msg));      _realGs.print(msg); }\n' +
        '};\n' +
        userScript;

    try {
        eval(wrappedScript);
    } catch(e) {
        success = false;
        errorMsg = e.message || String(e);
    }

    var duration = GlideDateTime.subtract(startTime, new GlideDateTime()).getNumericValue();

    response.setStatus(200);
    response.setBody({
        success: success,
        output: capturedOutput,
        error: errorMsg,
        duration: duration,
        timed_out: timedOut
    });
})(request, response);"""


def install_script_runner_via_session(session: requests.Session, instance_url: str, progress_callback=None) -> tuple[bool, str]:
    """Install the Foundry Script Runner using a raw requests.Session.

    Used by the installer and configure.py bootstrap where no ServiceNowClient exists.
    Idempotent — safe to call if already installed.
    Returns (success, message).
    """
    if progress_callback:
        progress_callback("Installing Script Runner...")
    base = instance_url.rstrip("/")
    headers = {"Accept": "application/json", "Content-Type": "application/json"}

    existing = session.get(
        f"{base}/api/now/table/sys_ws_definition",
        params={
            "sysparm_query": f"service_id={SCRIPT_RUNNER_SERVICE_ID}^ORbase_uri={SCRIPT_RUNNER_BASE_URI}",
            "sysparm_fields": "sys_id,active",
            "sysparm_limit": 1,
        },
        headers=headers,
    )
    if existing.status_code == 200 and existing.json().get("result"):
        return True, "Foundry Script Runner already installed."

    defn = session.post(
        f"{base}/api/now/table/sys_ws_definition",
        json={
            "name": "Foundry Script Runner",
            "service_id": SCRIPT_RUNNER_SERVICE_ID,
            "base_uri": SCRIPT_RUNNER_BASE_URI,
            "namespace": "now",
            "short_description": "Executes scripts via eval() with gs.info capture. Deployed by Foundry MCP.",
            "active": "true",
            "consumes": "application/json,application/xml,text/xml",
            "produces": "application/json,application/xml,text/xml",
        },
        headers=headers,
    )
    if defn.status_code != 201:
        return False, f"Failed to create Script Runner API definition (HTTP {defn.status_code})."

    defn_sys_id = defn.json()["result"]["sys_id"]

    op = session.post(
        f"{base}/api/now/table/sys_ws_operation",
        json={
            "name": "Execute Script",
            "web_service_definition": defn_sys_id,
            "http_method": "POST",
            "relative_path": "/execute",
            "short_description": "Execute a script and capture gs.info output",
            "operation_script": SCRIPT_RUNNER_OPERATION_SCRIPT,
            "active": "true",
            "requires_authentication": "true",
            "requires_snc_internal_role": "true",
            "requires_acl_authorization": "false",
            "consumes": "application/json,application/xml,text/xml",
            "produces": "application/json,application/xml,text/xml",
        },
        headers=headers,
    )
    if op.status_code != 201:
        return False, f"Script Runner definition created but operation failed (HTTP {op.status_code})."

    return True, "Foundry Script Runner installed successfully."
