"""Foundry Script Runner installation constants and helper.

Shared by core/setup.py (installer/configure bootstrap) and
tools/code/scripts.py (MCP tool). No MCP framework dependencies.
"""

import requests

from .client import get_client, reset_client

# The real Global scope is the sys_scope row with sys_id "global" (see scope_lookup.py).
GLOBAL_SCOPE_SYS_ID = "global"
SCRIPT_RUNNER_BASE_URI = "/api/now/foundry_script_runner"
SCRIPT_RUNNER_SERVICE_ID = "foundry_script_runner"
SCRIPT_RUNNER_OPERATION_SCRIPT = r"""(function process(request, response) {
    var body = request.body;
    var data = body ? body.data : null;
    if (!data) {
        try { data = JSON.parse(request.body + ''); } catch(e) { data = null; }
    }
    if (!data || !data.script) {
        response.setStatus(400);
        response.setBody({ success: false, error: 'Missing script in request body', output: [], returnValue: null, duration: 0 });
        return;
    }

    var userScript = data.script + '';
    var timeoutMs = parseInt(data.timeout_ms, 10) || 10000;

    var startTime = new GlideDateTime();
    var capturedOutput = [];
    var timedOut = false;
    var success = true;
    var errorMsg = null;
    var _realGs = gs;

    var _checkTimeout = function() {
        var elapsed = GlideDateTime.subtract(startTime, new GlideDateTime()).getNumericValue();
        if (elapsed > timeoutMs) {
            timedOut = true;
            throw new Error('Script timed out after ' + elapsed + 'ms (limit: ' + timeoutMs + 'ms)');
        }
    };

    var wrappedScript =
        'var __checkTimeout = _checkTimeout;\n' +
        'var gs = {\n' +
        '    info:        function(msg) { _checkTimeout(); capturedOutput.push(String(msg));           _realGs.info(msg); },\n' +
        '    warn:        function(msg) { _checkTimeout(); capturedOutput.push("[WARN] " + msg);       _realGs.warn(msg); },\n' +
        '    error:       function(msg) { _checkTimeout(); capturedOutput.push("[ERROR] " + msg);      _realGs.error(msg); },\n' +
        '    getProperty: function(key, def) { return _realGs.getProperty(key, def); },\n' +
        '    getUser:     function()         { return _realGs.getUser(); },\n' +
        '    getUserID:   function()         { return _realGs.getUserID(); },\n' +
        '    getUserName: function()         { return _realGs.getUserName(); },\n' +
        '    hasRole:     function(role)     { return _realGs.hasRole(role); },\n' +
        '    log:         function(msg, src) { _checkTimeout(); capturedOutput.push(String(msg));      _realGs.log(msg, src); },\n' +
        '    debug:       function(msg, src) { _checkTimeout(); capturedOutput.push("[DEBUG] " + msg); _realGs.debug(msg, src); },\n' +
        '    print:       function(msg)      { _checkTimeout(); capturedOutput.push(String(msg));      _realGs.print(msg); }\n' +
        '};\n' +
        userScript;

    try {
        eval(wrappedScript);
    } catch(e) {
        success = false;
        errorMsg = e.message || String(e);
    }

    var duration = GlideDateTime.subtract(startTime, new GlideDateTime()).getNumericValue();

    response.setStatus(200);
    response.setBody({
        success: success,
        output: capturedOutput,
        error: errorMsg,
        duration: duration,
        timed_out: timedOut
    });
})(request, response);"""


def install_script_runner_via_session(session: requests.Session, instance_url: str, progress_callback=None) -> tuple[bool, str]:
    """Install the Foundry Script Runner using a raw requests.Session.

    Used by the installer and configure.py bootstrap where no ServiceNowClient exists.
    Idempotent — safe to call if already installed.
    Returns (success, message).
    """
    if progress_callback:
        progress_callback("Installing Script Runner...")
    base = instance_url.rstrip("/")
    headers = {"Accept": "application/json", "Content-Type": "application/json"}

    existing = session.get(
        f"{base}/api/now/table/sys_ws_definition",
        params={
            "sysparm_query": f"service_id={SCRIPT_RUNNER_SERVICE_ID}^ORbase_uri={SCRIPT_RUNNER_BASE_URI}",
            "sysparm_fields": "sys_id,active,sys_scope",
            "sysparm_limit": 1,
        },
        headers=headers,
    )
    try:
        existing_rows = existing.json().get("result") if existing.status_code == 200 else None
    except Exception:
        existing_rows = None
    if not isinstance(existing_rows, list):
        return False, (f"Could not check for an existing Script Runner (HTTP {existing.status_code}); retry.")
    if existing_rows:
        found_scope = _scope_value(existing_rows[0].get("sys_scope"))
        if found_scope and found_scope != GLOBAL_SCOPE_SYS_ID:
            # The runner works from here, so this is not an error, but it is not plain success either.
            return True, (
                f"Warning: Script Runner is installed but its definition is NOT in Global (scope {found_scope}). "
                f"It keeps working, but it was created in the wrong application. To fix it, delete the "
                f"sys_ws_definition record and its sys_ws_operation in the ServiceNow UI (Studio, or the list "
                f"view of sys_ws_definition / sys_ws_operation; no MCP tool deletes records), then run "
                f"setup_script_runner again."
            )
        suffix = f" (definition scope: {found_scope})" if found_scope else ""
        return True, "Foundry Script Runner already installed." + suffix

    defn = session.post(
        f"{base}/api/now/table/sys_ws_definition",
        json={
            "name": "Foundry Script Runner",
            "service_id": SCRIPT_RUNNER_SERVICE_ID,
            "base_uri": SCRIPT_RUNNER_BASE_URI,
            "namespace": "now",
            "short_description": "Executes scripts via eval() with gs.info capture. Deployed by Foundry MCP.",
            "active": "true",
            "consumes": "application/json,application/xml,text/xml",
            "produces": "application/json,application/xml,text/xml",
        },
        headers=headers,
    )
    if defn.status_code != 201:
        return False, f"Failed to create Script Runner API definition (HTTP {defn.status_code})."

    defn_sys_id = _created_sys_id(defn)
    if not defn_sys_id:
        return False, (
            "Script Runner definition was created (HTTP 201) but its sys_id could not be read; "
            "check sys_ws_definition / sys_ws_operation for it in Global, then retry setup_script_runner."
        )

    op = session.post(
        f"{base}/api/now/table/sys_ws_operation",
        json={
            "name": "Execute Script",
            "web_service_definition": defn_sys_id,
            "http_method": "POST",
            "relative_path": "/execute",
            "short_description": "Execute a script and capture gs.info output",
            "operation_script": SCRIPT_RUNNER_OPERATION_SCRIPT,
            "active": "true",
            "requires_authentication": "true",
            "requires_snc_internal_role": "true",
            "requires_acl_authorization": "false",
            "consumes": "application/json,application/xml,text/xml",
            "produces": "application/json,application/xml,text/xml",
        },
        headers=headers,
    )
    if op.status_code != 201:
        return False, f"Script Runner definition created but operation failed (HTTP {op.status_code})."

    # A REST create can land in the session's cached scope, so the success message
    # is built from a read-back of both records, never from the create responses.
    op_sys_id = _created_sys_id(op)
    if not op_sys_id:
        return False, (
            f"Script Runner operation was created (HTTP 201) but its sys_id could not be read "
            f"(definition sys_id: {defn_sys_id}); check sys_ws_definition / sys_ws_operation "
            f"for it in Global, then retry setup_script_runner."
        )
    stray = []
    for table, label, sys_id in (
        ("sys_ws_definition", "definition", defn_sys_id),
        ("sys_ws_operation", "operation", op_sys_id),
    ):
        scope = _read_scope(session, base, headers, table, sys_id)
        if scope is None:
            return False, (
                f"Script Runner records were created but their scope could not be verified "
                f"({label} {sys_id}). Check the {table} record's application, then retry setup_script_runner."
            )
        if scope != GLOBAL_SCOPE_SYS_ID:
            stray.append(f"{label} {sys_id} is in scope '{scope}'")
    if stray:
        return False, (
            "Script Runner was created outside Global: " + "; ".join(stray) + ". "
            "No MCP tool deletes records: delete them in the ServiceNow UI (Studio, or the list view of "
            "sys_ws_definition / sys_ws_operation), then retry setup_script_runner "
            "(it resets the client session itself, so the retry is not stuck on the stale scope)."
        )

    return True, "Foundry Script Runner installed successfully (definition and operation verified in Global)."


def _created_sys_id(resp):
    """sys_id from a create response body, or None if missing/malformed."""
    try:
        sys_id = resp.json()["result"]["sys_id"]
    except (ValueError, KeyError, TypeError, AttributeError):
        return None
    return sys_id or None


def _scope_value(raw) -> str:
    """sys_scope arrives as {'value': ..., 'link': ...} or a bare string."""
    if isinstance(raw, dict):
        return str(raw.get("value") or "")
    return str(raw or "")


def _read_scope(session, base, headers, table, sys_id):
    """Return the stored sys_scope sys_id of a record, or None if it cannot be read."""
    try:
        resp = session.get(
            f"{base}/api/now/table/{table}/{sys_id}",
            params={"sysparm_fields": "sys_id,sys_scope"},
            headers=headers,
        )
        if resp.status_code != 200:
            return None
        scope = _scope_value(resp.json().get("result", {}).get("sys_scope"))
    except Exception:
        return None
    return scope or None


def install_script_runner(client) -> tuple[bool, str]:
    """Install the Foundry Script Runner for an MCP client's instance.

    Thin wrapper over install_script_runner_via_session: one implementation of
    the install steps. REST only (the runner cannot install itself).

    The instance's cached client is reset first: its session may have cached a stale
    application scope, which would make a retry after a stray-scope install land in the
    same wrong scope again. Callers with a raw session use install_script_runner_via_session.
    """
    alias = client.config.alias
    reset_client(alias)
    client = get_client(alias)
    if not client._prepare_request():
        return False, "Authentication failed: could not prepare credentials to install the Script Runner."
    return install_script_runner_via_session(client.session, client.config.instance)
