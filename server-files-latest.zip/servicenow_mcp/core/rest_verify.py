"""REST delete with a GET read-back (no Script Runner).

A delete is "deleted" only after a GET by sys_id shows the record is gone. This module
is REST-only on purpose: the OAuth setup, rollback and uninstall paths run on installs
that have OAuth and no Script Runner, so they must not depend on it.

It takes anything with `get` and `delete` methods shaped like `requests`: a
`requests.Session`, a `ServiceNowClient.session` (call `client._prepare_request()` first
so the bearer token is current), or a thin wrapper around the module-level `requests`.
Response bodies are never copied into messages (they can echo credentials).
"""
import re
from typing import Any, Dict, Optional

_TABLE_RE = re.compile(r"^[a-z0-9_]+$")
_SYS_ID_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _result(outcome: str, status_code: Optional[int], message: str, **extra: Any) -> Dict[str, Any]:
    out = {"outcome": outcome, "status_code": status_code, "message": message}
    out.update(extra)
    return out


def delete_with_readback(
    session: Any,
    base_url: str,
    table: str,
    sys_id: str,
    *,
    headers: Optional[Dict[str, str]] = None,
    timeout: Optional[float] = None,
    request_kwargs: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Delete one record by sys_id, then GET it back.

    Returns {"outcome": "deleted" | "not_found" | "error", "status_code", "message"}:
      - any 2xx and the read-back is empty: "deleted".
      - 2xx and the record is still there: "error" (delete reported success but the
        record still exists).
      - 404: "not_found" ("not found or not visible to this user"); never "deleted".
      - 204 but the read-back could not run or failed: "error" with "unverified": True
        and "readback_status" (for example a 401 after deleting the OAuth app the session
        authenticates with: accepted, not verified).
      - any other status or a network error: "error", with the status.
    Never raises.
    """
    if not _TABLE_RE.match(table or "") or not _SYS_ID_RE.match(sys_id or ""):
        return _result("error", None, f"refusing to delete: invalid table or sys_id ({table!r}, {sys_id!r})")

    base = base_url.rstrip("/")
    kw: Dict[str, Any] = dict(request_kwargs or {})
    if headers is not None:
        kw["headers"] = headers
    if timeout is not None:
        kw["timeout"] = timeout

    try:
        del_resp = session.delete(f"{base}/api/now/table/{table}/{sys_id}", **kw)
    except Exception as e:  # network errors, never secrets
        return _result("error", None, f"delete request failed: {type(e).__name__}")

    status = del_resp.status_code
    if status == 404:
        return _result("not_found", 404, "not found or not visible to this user")
    if not (isinstance(status, int) and 200 <= status < 300):
        return _result("error", status, f"delete failed (HTTP {status})")

    try:
        get_resp = session.get(
            f"{base}/api/now/table/{table}",
            params={"sysparm_query": f"sys_id={sys_id}", "sysparm_fields": "sys_id", "sysparm_limit": 1},
            **kw,
        )
    except Exception as e:
        return _result(
            "error", status,
            f"delete accepted (HTTP {status}) but not verified: read-back failed ({type(e).__name__})",
            unverified=True, readback_status=None,
        )

    if get_resp.status_code != 200:
        return _result(
            "error", status,
            f"delete accepted (HTTP {status}) but not verified: read-back returned HTTP {get_resp.status_code}",
            unverified=True, readback_status=get_resp.status_code,
        )

    try:
        remaining = get_resp.json().get("result", [])
    except Exception:
        return _result(
            "error", status,
            f"delete accepted (HTTP {status}) but not verified: read-back was not valid JSON",
            unverified=True, readback_status=200,
        )

    if remaining and not isinstance(remaining, list):
        # A shape this check does not understand: cannot tell present from gone.
        return _result(
            "error", status,
            f"delete accepted (HTTP {status}) but not verified: the read-back had an unexpected shape",
            unverified=True, readback_status=200,
        )

    if remaining:
        return _result("error", status, "delete reported success but the record still exists")
    return _result("deleted", status, "deleted (confirmed gone by read-back)")
