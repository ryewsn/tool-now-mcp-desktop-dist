"""ServiceNow Query Builder"""

from typing import List

class QueryBuilder:
    """Builder for ServiceNow encoded queries."""

    def __init__(self):
        self.parts: List[str] = []

    def add_like(self, field: str, value: str) -> 'QueryBuilder':
        """Add LIKE condition (case-insensitive contains)."""
        if value:
            self.parts.append(f"{field}LIKE{value}")
        return self

    def add_equals(self, field: str, value: str) -> 'QueryBuilder':
        """Add equals condition."""
        if value:
            self.parts.append(f"{field}={value}")
        return self

    def add_relative_time(
        self,
        field: str,
        minutes_ago: int,
        operator: str = "RELATIVEGT"
    ) -> 'QueryBuilder':
        """Add relative time filter (e.g., last N minutes)."""
        if minutes_ago:
            self.parts.append(f"{field}{operator}@minute@ago@{minutes_ago}")
        return self

    def add_in(self, field: str, values: List[str]) -> 'QueryBuilder':
        """Add IN condition for multiple values."""
        if values:
            value_str = ",".join(values)
            self.parts.append(f"{field}IN{value_str}")
        return self

    def add_custom(self, condition: str) -> 'QueryBuilder':
        """Add a custom query condition."""
        if condition:
            self.parts.append(condition)
        return self

    def build(self) -> str:
        """Build the final encoded query string."""
        return "^".join(self.parts)

    def add_order_by(self, field: str, direction: str = "DESC") -> str:
        """Add ORDER BY to the query and return final string."""
        query = self.build()
        return f"{query}^ORDERBY{direction}{field}" if query else f"ORDERBY{direction}{field}"
