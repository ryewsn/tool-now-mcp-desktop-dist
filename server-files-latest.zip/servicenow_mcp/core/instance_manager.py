"""Instance management utilities for .env and Claude Desktop configuration.

Pure data functions — no interactive I/O (print/input). Used by both
MCP tools (conversational) and configure.py (terminal CLI).
"""

import glob
import json
import os
import platform
import re
import shutil
import socket
import sys


def extract_instance_name(value: str) -> str:
    """Extract instance name from a URL, hostname, or bare name.

    Examples:
        "acme" -> "acme"
        "acme.service-now.com" -> "acme"
        "https://acme.service-now.com" -> "acme"
        "https://acme.service-now.com/" -> "acme"
    """
    value = value.replace("https://", "").replace("http://", "").rstrip("/")
    if ".service-now.com" in value:
        value = value.split(".service-now.com")[0]
    return value.lower()


def instance_name_to_url(name: str) -> str:
    """Convert instance name to full URL."""
    return f"https://{name}.service-now.com"


def instance_name_to_env_key(name: str) -> str:
    """Convert instance name to a valid env var suffix.

    Replaces hyphens with underscores since env var names shouldn't
    contain hyphens.
    """
    return name.replace("-", "_").upper()


def parse_env_file(env_path: str) -> tuple:
    """Parse .env file and return (instances_dict, default_name, install_hostname).

    Handles both legacy single-instance format and multi-instance format.

    Args:
        env_path: Absolute path to the .env file

    Returns:
        Tuple of (instances dict, default instance name or None, install_hostname or "")
        Each instance dict has: url, username, password, client_id, client_secret
    """
    instances = {}
    default_instance = None
    install_hostname = ""

    if not os.path.exists(env_path):
        return instances, default_instance, install_hostname

    with open(env_path) as f:
        content = f.read()

    # Read install hostname (written by installer, shared across all instances)
    hostname_match = re.search(r"SERVICENOW_INSTALL_HOSTNAME=(.+)", content)
    if hostname_match:
        install_hostname = hostname_match.group(1).strip()

    # Detect legacy single-instance format (no SERVICENOW_INSTANCES key)
    if "SERVICENOW_INSTANCES" not in content:
        match_url = re.search(r"SERVICENOW_INSTANCE=(.+)", content)
        match_user = re.search(r"SERVICENOW_USERNAME=(.+)", content)
        match_pass = re.search(r"SERVICENOW_PASSWORD=(.+)", content)
        match_cid = re.search(r"SERVICENOW_CLIENT_ID=(.+)", content)
        match_csec = re.search(r"SERVICENOW_CLIENT_SECRET=(.+)", content)
        if match_url:
            url = match_url.group(1).strip()
            name = extract_instance_name(url)
            instances[name] = {
                "url": url,
                "username": match_user.group(1).strip() if match_user else "",
                "password": match_pass.group(1).strip() if match_pass else "",
                "client_id": match_cid.group(1).strip() if match_cid else "",
                "client_secret": match_csec.group(1).strip() if match_csec else "",
            }
            default_instance = name
        return instances, default_instance, install_hostname

    # Multi-instance format
    match_list = re.search(r"SERVICENOW_INSTANCES=(.+)", content)
    instance_names = []
    if match_list:
        instance_names = [n.strip() for n in match_list.group(1).split(",")]

    match_default = re.search(r"SERVICENOW_DEFAULT_INSTANCE=(.+)", content)
    if match_default:
        default_instance = match_default.group(1).strip()
    elif instance_names:
        default_instance = instance_names[0]

    for name in instance_names:
        key = instance_name_to_env_key(name)
        url_match = re.search(rf"SERVICENOW_INSTANCE_{key}=(.+)", content)
        user_match = re.search(rf"SERVICENOW_USERNAME_{key}=(.+)", content)
        pass_match = re.search(rf"SERVICENOW_PASSWORD_{key}=(.+)", content)
        cid_match = re.search(rf"SERVICENOW_CLIENT_ID_{key}=(.+)", content)
        csec_match = re.search(rf"SERVICENOW_CLIENT_SECRET_{key}=(.+)", content)
        if url_match:
            instances[name] = {
                "url": url_match.group(1).strip(),
                "username": user_match.group(1).strip() if user_match else "",
                "password": pass_match.group(1).strip() if pass_match else "",
                "client_id": cid_match.group(1).strip() if cid_match else "",
                "client_secret": csec_match.group(1).strip() if csec_match else "",
            }

    return instances, default_instance, install_hostname


def _read_preserved_env_metadata(env_path: str) -> dict:
    if not os.path.exists(env_path):
        return {}
    with open(env_path) as f:
        content = f.read()
    metadata = {}
    for key in (
        "SERVICENOW_MCP_CLIENTS",
        "SERVICENOW_MCP_CLAUDE_CODE_SCOPE",
    ):
        match = re.search(rf"{key}=(.+)", content)
        if match:
            metadata[key] = match.group(1).strip()
    return metadata


def write_env_file(env_path: str, instances: dict, default_instance: str, install_hostname: str = "") -> None:
    """Write instances to .env in multi-instance format.

    Args:
        env_path: Absolute path to the .env file
        instances: Dict of {name: {url, username, password, client_id, client_secret}}
        default_instance: Name of the default instance
        install_hostname: Machine hostname; if empty, socket.gethostname() is tried as
            fallback. Omitted from the file only if both the argument and socket call fail.
    """
    if not install_hostname:
        try:
            install_hostname = socket.gethostname() or ""
        except OSError:
            install_hostname = ""

    names = list(instances.keys())
    metadata = _read_preserved_env_metadata(env_path)

    with open(env_path, "w") as f:
        if install_hostname:
            f.write(f"SERVICENOW_INSTALL_HOSTNAME={install_hostname}\n")
        for key, value in metadata.items():
            f.write(f"{key}={value}\n")
        f.write(f"SERVICENOW_INSTANCES={','.join(names)}\n")
        f.write(f"SERVICENOW_DEFAULT_INSTANCE={default_instance}\n")

        for name in names:
            inst = instances[name]
            key = instance_name_to_env_key(name)
            f.write(f"\n# {name}\n")
            f.write(f"SERVICENOW_INSTANCE_{key}={inst['url']}\n")
            if inst.get("username"):
                f.write(f"SERVICENOW_USERNAME_{key}={inst['username']}\n")
                f.write(f"SERVICENOW_PASSWORD_{key}={inst['password']}\n")
            if inst.get("client_id"):
                f.write(f"SERVICENOW_CLIENT_ID_{key}={inst['client_id']}\n")
                f.write(f"SERVICENOW_CLIENT_SECRET_{key}={inst['client_secret']}\n")


def add_instance(
    env_path: str,
    name: str,
    data: dict,
    set_as_default: bool = False
) -> dict:
    """Add a new instance to the .env file.

    Args:
        env_path: Path to .env file
        name: Instance name (or URL — will be extracted)
        data: Dict with url, username, password, client_id, client_secret
        set_as_default: Whether to make this the default instance

    Returns:
        Dict with success, message, instances, default
    """
    if not name or not name.strip():
        return {"success": False, "message": "Instance name is required.",
                "instances": {}, "default": None}

    name = extract_instance_name(name.strip())

    # Auto-generate URL if not provided
    if not data.get("url"):
        data["url"] = instance_name_to_url(name)

    # Validate credentials
    has_basic = bool(data.get("username") and data.get("password"))
    has_oauth = bool(data.get("client_id") and data.get("client_secret"))

    if not has_basic and not has_oauth:
        missing = []
        if data.get("username") and not data.get("password"):
            missing.append("password")
        elif data.get("password") and not data.get("username"):
            missing.append("username")
        elif data.get("client_id") and not data.get("client_secret"):
            missing.append("client_secret")
        elif data.get("client_secret") and not data.get("client_id"):
            missing.append("client_id")
        else:
            missing.append("username/password or client_id/client_secret")
        return {"success": False,
                "message": f"Missing credentials: {', '.join(missing)}.",
                "instances": {}, "default": None}

    instances, default_instance, install_hostname = parse_env_file(env_path)

    if name in instances:
        return {"success": False,
                "message": f"Instance '{name}' already exists. Remove it first or choose a different name.",
                "instances": instances, "default": default_instance}

    instances[name] = {
        "url": data["url"],
        "username": data.get("username", ""),
        "password": data.get("password", ""),
        "client_id": data.get("client_id", ""),
        "client_secret": data.get("client_secret", ""),
    }

    # First instance or explicit request — set as default
    if not default_instance or set_as_default:
        default_instance = name

    write_env_file(env_path, instances, default_instance, install_hostname)

    auth_type = "OAuth" if has_oauth else "basic auth"
    return {
        "success": True,
        "message": f"Added '{name}' ({data['url']}, {auth_type}).",
        "instances": instances,
        "default": default_instance,
    }


def remove_instance(env_path: str, name: str) -> dict:
    """Remove an instance from the .env file.

    Args:
        env_path: Path to .env file
        name: Instance name to remove

    Returns:
        Dict with success, message, instances, default
    """
    instances, default_instance, install_hostname = parse_env_file(env_path)

    if name not in instances:
        available = ", ".join(instances.keys()) if instances else "none"
        return {"success": False,
                "message": f"Instance '{name}' not found. Available: {available}.",
                "instances": instances, "default": default_instance}

    del instances[name]

    if default_instance == name:
        default_instance = list(instances.keys())[0] if instances else None

    if instances:
        write_env_file(env_path, instances, default_instance, install_hostname)
    else:
        if os.path.exists(env_path):
            os.remove(env_path)

    return {
        "success": True,
        "message": f"Removed '{name}'.",
        "instances": instances,
        "default": default_instance,
    }


def set_default(env_path: str, name: str) -> dict:
    """Set the default instance.

    Args:
        env_path: Path to .env file
        name: Instance name to set as default

    Returns:
        Dict with success, message, default
    """
    instances, default_instance, install_hostname = parse_env_file(env_path)

    if name not in instances:
        available = ", ".join(instances.keys()) if instances else "none"
        return {"success": False,
                "message": f"Instance '{name}' not found. Available: {available}.",
                "default": default_instance}

    if default_instance == name:
        return {"success": True,
                "message": f"Instance '{name}' is already the default.",
                "default": default_instance}

    write_env_file(env_path, instances, name, install_hostname)

    return {
        "success": True,
        "message": f"Default instance set to '{name}'.",
        "default": name,
    }


def get_instances(env_path: str) -> dict:
    """Get all configured instances.

    Args:
        env_path: Path to .env file

    Returns:
        Dict with instances and default
    """
    instances, default_instance, install_hostname = parse_env_file(env_path)
    return {"instances": instances, "default": default_instance}


def get_claude_config_path() -> str | None:
    """Return the path to Claude Desktop's config file for this OS."""
    if platform.system() == "Darwin":
        return os.path.expanduser(
            "~/Library/Application Support/Claude/claude_desktop_config.json"
        )
    elif platform.system() == "Windows":
        appdata = os.environ.get("APPDATA", "")
        return os.path.join(appdata, "Claude", "claude_desktop_config.json")
    return None


def get_claude_config_paths() -> list:
    """Return a list of paths to Claude Desktop's config file for this OS.

    On Windows with MSIX installs, Claude Desktop reads from a virtualized
    path under LocalAppData\\Packages\\Claude_<hash>\\LocalCache\\Roaming\\Claude.
    When detected, both the MSIX path (primary) and the standard %APPDATA%
    path (fallback) are returned so the config is written to both locations.
    """
    if platform.system() == "Darwin":
        return [
            os.path.expanduser(
                "~/Library/Application Support/Claude/claude_desktop_config.json"
            )
        ]
    elif platform.system() == "Windows":
        paths = []
        local_appdata = os.environ.get("LOCALAPPDATA", "")
        if local_appdata:
            for msix_dir in glob.glob(os.path.join(local_appdata, "Packages", "Claude_*")):
                claude_dir = os.path.join(msix_dir, "LocalCache", "Roaming", "Claude")
                if os.path.isdir(claude_dir):
                    paths.append(os.path.join(claude_dir, "claude_desktop_config.json"))
                    break
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            paths.append(os.path.join(appdata, "Claude", "claude_desktop_config.json"))
        return paths
    return []


def patch_claude_desktop_config(python_path: str, server_path: str, cwd: str = None) -> bool:
    """Add/update the ServiceNow MCP server in Claude Desktop's config.

    Reads existing config (preserving other MCP servers), writes the
    servicenow entry with type='stdio'. On malformed JSON, copies to .bak
    and starts fresh. Writes to all paths returned by get_claude_config_paths().

    Args:
        python_path: Absolute path to the Python interpreter.
        server_path: Absolute path to server.py.
        cwd: Optional working directory to include in the config entry.
             Omitted from the entry when None (installer path).

    Returns:
        True if at least one config file was written, False if no config
        directories exist (Claude Desktop not installed or not yet opened).
    """
    entry: dict = {
        "type": "stdio",
        "command": python_path,
        "args": [server_path],
    }
    if cwd is not None:
        entry["cwd"] = cwd

    wrote_any = False

    for config_path in get_claude_config_paths():
        config_dir = os.path.dirname(config_path)
        if not os.path.exists(config_dir):
            continue

        config = {}
        if os.path.exists(config_path):
            try:
                with open(config_path) as f:
                    config = json.load(f)
            except (json.JSONDecodeError, IOError):
                bak_path = config_path + ".bak"
                try:
                    shutil.copy2(config_path, bak_path)
                except IOError:
                    pass
                config = {}

        config.setdefault("mcpServers", {})
        config["mcpServers"]["servicenow"] = entry

        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
            f.write("\n")

        wrote_any = True

    return wrote_any


def update_claude_desktop_config(project_dir: str) -> bool:
    """Add/update the ServiceNow MCP server in Claude Desktop's config.

    Reads the existing config (preserving other MCP servers),
    adds/updates the 'servicenow' entry, and writes it back.

    Args:
        project_dir: Absolute path to the project root (where server.py lives)

    Returns:
        True if config was updated, False if OS is unsupported or directory missing
    """
    config_path = get_claude_config_path()
    if not config_path:
        return False

    python_path = sys.executable
    server_path = os.path.join(project_dir, "server.py")

    config = {}
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                config = json.load(f)
        except (json.JSONDecodeError, IOError):
            config = {}
    else:
        config_dir = os.path.dirname(config_path)
        if not os.path.exists(config_dir):
            return False

    if "mcpServers" not in config:
        config["mcpServers"] = {}

    config["mcpServers"]["servicenow"] = {
        "command": python_path,
        "args": [server_path],
    }

    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)
        f.write("\n")

    return True
