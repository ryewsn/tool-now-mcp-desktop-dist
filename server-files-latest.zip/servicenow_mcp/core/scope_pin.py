"""Pin the acting user's apps.current_app, reset the session, make one call, restore.

The VCS endpoints (and any REST write that follows the session's ambient app scope) use the
scope cached in the client's session. This module sets the per-user apps.current_app
preference, builds a fresh session so the pin takes effect, runs one call, and puts the
preference back, reading it back to confirm. Moved out of tools/code/source_control.py so
other tools can use it; behavior and return shapes are unchanged.
"""

from typing import Callable, Optional

from .client import get_client, reset_client


def ensure_current_app(client, app_sys_id: str) -> dict:
    """
    Set the acting user's apps.current_app preference to app_sys_id and report what it was.

    The VCS endpoints follow the session-cached scope, and the commit endpoint rejects
    changedRecords unless the acting user's scope matches the target app (error 1008,
    seen in an earlier session; S2 saw a silent no-op instead). Resolves the acting user via
    client.config.username (set for both Basic Auth and OAuth instances in this project's
    .env convention).

    Never raises. Returns a state dict:
      {"ok": bool, "skipped": str|None, "error": str|None, "user": sys_id|None,
       "pref_sys_id": sys_id|None, "had_row": bool, "prior": str|None}
    ok=False means the preference could not be set; the caller must not make the VCS call.
    skipped is set (ok stays True) when no username is configured, so the scope could not
    be stated at all.
    """
    state = {"ok": True, "skipped": None, "error": None, "user": None,
             "pref_sys_id": None, "had_row": False, "prior": None}
    username = getattr(client.config, "username", None)
    if not username:
        state["skipped"] = "no username configured, so apps.current_app was not set"
        return state
    try:
        user_response = client.query_table("sys_user", query=f"user_name={username}", fields=["sys_id"], limit=1)
        if not user_response.get("success") or not user_response.get("result"):
            state.update(ok=False, error=f"could not resolve user '{username}'")
            return state
        user_sys_id = user_response["result"][0]["sys_id"]
        state["user"] = user_sys_id

        pref_response = client.query_table(
            "sys_user_preference",
            query=f"name=apps.current_app^user={user_sys_id}",
            fields=["sys_id", "value"],
            limit=1,
        )
        if not pref_response.get("success"):
            state.update(ok=False, error="could not read the apps.current_app preference")
            return state
        if pref_response.get("result"):
            pref = pref_response["result"][0]
            state.update(had_row=True, pref_sys_id=pref["sys_id"], prior=pref.get("value"))
            if pref.get("value") != app_sys_id:
                resp = client.update_record(
                    "sys_user_preference", pref["sys_id"], {"value": app_sys_id},
                    unscoped_ok="sys_user_preference has no sys_scope column (audit S6): "
                                "apps.current_app preference write")
                if not resp.get("success"):
                    state.update(ok=False, error=f"updating apps.current_app failed: {resp.get('error')}")
        else:
            resp = client.create_record("sys_user_preference", {
                "name": "apps.current_app",
                "value": app_sys_id,
                "user": user_sys_id,
            }, unscoped_ok="sys_user_preference has no sys_scope column (audit S6): "
                           "apps.current_app preference write")
            if not resp.get("success"):
                state.update(ok=False, error=f"creating apps.current_app failed: {resp.get('error')}")
            else:
                created = resp.get("result")
                state["created_sys_id"] = created.get("sys_id") if isinstance(created, dict) else None
    except Exception as exc:
        state.update(ok=False, error=str(exc))
    return state


def restore_current_app(client, app_sys_id: str, state: dict) -> str:
    """
    Put apps.current_app back to its prior value and read it back. Returns a message.

    No prior row: the row this call created (and only that sys_id) is deleted with the
    internal client.delete_record and read back as gone; if that fails the message says
    the row was left set to the app. A restore that does not read back is reported, never
    swallowed.
    """
    if state.get("skipped"):
        return f"Scope preference: {state['skipped']}."
    if not state.get("user"):
        return ""
    if not state.get("had_row"):
        created = state.get("created_sys_id")
        left = f"apps.current_app: no prior preference; left set to {app_sys_id}"
        if not created:
            return left + " (the sys_id of the row this call created was not returned, so it was not deleted)."
        try:
            resp = client.delete_record(
                "sys_user_preference", created,
                unscoped_ok="sys_user_preference has no sys_scope column (audit S6): "
                            "deleting the preference row this call created")
            if not resp.get("success"):
                return left + f" (deleting the row this call created failed: {resp.get('error')})."
            read = client.query_table(
                "sys_user_preference", query=f"sys_id={created}", fields=["sys_id"], limit=1)
            if not read.get("success"):
                return left + " (deleted, but the read-back to confirm it failed)."
            if read.get("result"):
                return left + " (the row this call created is still present after the delete)."
        except Exception as exc:
            return left + f" (deleting the row this call created raised: {exc})."
        return "apps.current_app: no prior preference; the row this call created was deleted (read back: gone)."
    prior = state.get("prior")
    try:
        if prior != app_sys_id:
            resp = client.update_record(
                "sys_user_preference", state["pref_sys_id"], {"value": prior or ""},
                unscoped_ok="sys_user_preference has no sys_scope column (audit S6): "
                            "restoring the prior apps.current_app value")
            if not resp.get("success"):
                return (f"apps.current_app NOT restored (update failed: {resp.get('error')}); "
                        f"it is still {app_sys_id}, was {prior}.")
        read = client.query_table(
            "sys_user_preference", query=f"name=apps.current_app^user={state['user']}",
            fields=["sys_id", "value"], limit=1)
        got = read["result"][0].get("value") if read.get("success") and read.get("result") else None
    except Exception as exc:
        return f"apps.current_app NOT restored (error: {exc}); it may still be {app_sys_id}, was {prior}."
    if (got or "") == (prior or ""):
        return f"apps.current_app restored to {prior or '(empty)'} (read back)."
    return f"apps.current_app NOT restored: read back {got}, expected {prior}."


def pinned_scope_call(client, app_sys_id: Optional[str], call: Callable,
                      verify: Optional[Callable] = None, *,
                      ensure: Optional[Callable] = None, restore: Optional[Callable] = None,
                      reset: Optional[Callable] = None, get: Optional[Callable] = None) -> dict:
    """
    Run one call so it cannot silently follow a stale session scope.

    Order: set apps.current_app (when app_sys_id is given) -> reset the client's session
    (reset_client on the alias of the client passed in) -> call(fresh_client) -> verify(fresh_client)
    where an authoritative read exists -> restore the prior preference and read it back (delete
    the row this call created when there was none) -> reset the alias again, so the next call
    builds a session that reflects the restored preference.

    call(client) returns a dict with a boolean "success". verify(client) returns (ok, detail) with ok True
    (confirmed), False (read back disproves it) or None (could not read). app_sys_id=None
    (import/migrate with no app yet) skips the preference and still resets the session.

    The keyword hooks (ensure, restore, reset, get) let a caller module pass its own
    module-level functions so its monkeypatches keep taking effect.

    Returns {"result": dict, "verified": True|False|None, "detail": str, "pref_note": str}.
    verified None means "triggered, not verified".
    """
    ensure = ensure or ensure_current_app
    restore = restore or restore_current_app
    reset = reset or reset_client
    get = get or get_client
    alias = client.config.alias
    state = None
    if app_sys_id:
        state = ensure(client, app_sys_id)
        if not state["ok"]:
            return {"result": {"success": False, "job_id": None,
                               "error": (f"Could not set apps.current_app to {app_sys_id} "
                                         f"({state['error']}). Nothing was sent to the VCS endpoint. "
                                         f"Check the user's access to sys_user_preference, then retry.")},
                    "verified": None, "detail": "", "pref_note": ""}
    fresh = None
    verified, detail = None, ""
    pref_note = ""
    try:
        reset(alias)
        fresh = get(alias)
        result = call(fresh)
        if result["success"] and verify is not None:
            verified, detail = verify(fresh)
    finally:
        # Always put the preference back, even if reset/get_client, the call or the verify
        # raised (the old client restores when no fresh one was built). Then reset the alias
        # again: `fresh` cached the APP scope on its first call, and restoring the row does not
        # change a session's cached scope, so the next unrelated call needs its own new session.
        try:
            if state:
                pref_note = restore(fresh or client, app_sys_id, state)
        finally:
            if state:
                reset(alias)
    return {"result": result, "verified": verified, "detail": detail, "pref_note": pref_note}
