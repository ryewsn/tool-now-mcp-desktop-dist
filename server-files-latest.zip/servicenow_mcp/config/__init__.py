"""Configuration management for ServiceNow connection"""
from .settings import get_config, ServiceNowConfig

__all__ = ["get_config", "ServiceNowConfig"]
