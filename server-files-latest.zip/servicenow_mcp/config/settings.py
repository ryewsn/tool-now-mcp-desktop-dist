"""ServiceNow MCP Configuration Management"""

import os
from typing import Optional, Dict
from dotenv import load_dotenv

class InstanceConfig:
    """Configuration for a single ServiceNow instance."""

    def __init__(
        self,
        alias: str,
        instance_url: str,
        username: Optional[str] = None,
        password: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        install_hostname: str = "",
        github_credential: Optional[str] = None,
    ):
        self.alias = alias
        self.instance = instance_url.rstrip('/')
        self.username = username
        self.password = password
        self.client_id = client_id
        self.client_secret = client_secret
        self.install_hostname = install_hostname
        self.github_credential = github_credential

    @property
    def uses_oauth(self) -> bool:
        """Check if this instance is configured for OAuth authentication."""
        return bool(self.client_id and self.client_secret)

    @property
    def uses_basic_auth(self) -> bool:
        """Check if this instance is configured for basic authentication."""
        return bool(self.username and self.password)

class ServiceNowConfig:
    """Configuration for ServiceNow instance connections (single or multi-instance)."""

    def __init__(self):
        load_dotenv()
        self.instances: Dict[str, InstanceConfig] = {}
        self.default_instance: Optional[str] = None
        self._load_config()

    def _load_config(self):
        """Load configuration - supports both single and multi-instance modes."""

        # Check for multi-instance configuration
        instances_str = os.getenv("SERVICENOW_INSTANCES")

        if instances_str:
            # Multi-instance mode
            instance_aliases = [alias.strip() for alias in instances_str.split(",")]

            for alias in instance_aliases:
                env_key = alias.upper().replace("-", "_")
                instance_url = os.getenv(f"SERVICENOW_INSTANCE_{env_key}")
                username = os.getenv(f"SERVICENOW_USERNAME_{env_key}")
                password = os.getenv(f"SERVICENOW_PASSWORD_{env_key}")
                client_id = os.getenv(f"SERVICENOW_CLIENT_ID_{env_key}")
                client_secret = os.getenv(f"SERVICENOW_CLIENT_SECRET_{env_key}")
                install_hostname = os.getenv(f"SERVICENOW_INSTALL_HOSTNAME_{env_key}") or os.getenv("SERVICENOW_INSTALL_HOSTNAME", "")
                github_credential = (
                    os.getenv(f"SERVICENOW_GITHUB_CREDENTIAL_{env_key}")
                    or os.getenv("SERVICENOW_GITHUB_CREDENTIAL")
                )

                if not instance_url:
                    raise ValueError(
                        f"Missing SERVICENOW_INSTANCE_{env_key} for instance '{alias}'"
                    )

                # Validate that we have either basic auth OR OAuth credentials
                has_basic_auth = bool(username and password)
                has_oauth = bool(client_id and client_secret)

                if not has_basic_auth and not has_oauth:
                    raise ValueError(
                        f"Missing authentication credentials for instance '{alias}'. "
                        f"Provide either:\n"
                        f"  - Basic Auth: SERVICENOW_USERNAME_{env_key} and SERVICENOW_PASSWORD_{env_key}\n"
                        f"  - OAuth: SERVICENOW_CLIENT_ID_{env_key} and SERVICENOW_CLIENT_SECRET_{env_key}"
                    )

                self.instances[alias] = InstanceConfig(
                    alias, instance_url, username, password, client_id, client_secret,
                    install_hostname=install_hostname,
                    github_credential=github_credential,
                )

            # Set default instance (explicit field or first in list for backwards compatibility)
            default_from_env = os.getenv("SERVICENOW_DEFAULT_INSTANCE")
            if default_from_env:
                if default_from_env not in instance_aliases:
                    raise ValueError(
                        f"SERVICENOW_DEFAULT_INSTANCE '{default_from_env}' is not in SERVICENOW_INSTANCES list. "
                        f"Available instances: {', '.join(instance_aliases)}"
                    )
                self.default_instance = default_from_env
            else:
                # Backwards compatibility: use first instance if no default specified
                self.default_instance = instance_aliases[0]

        else:
            # Single-instance mode (backwards compatible)
            instance_url = os.getenv("SERVICENOW_INSTANCE")
            username = os.getenv("SERVICENOW_USERNAME")
            password = os.getenv("SERVICENOW_PASSWORD")
            client_id = os.getenv("SERVICENOW_CLIENT_ID")
            client_secret = os.getenv("SERVICENOW_CLIENT_SECRET")
            install_hostname = os.getenv("SERVICENOW_INSTALL_HOSTNAME", "")
            github_credential = os.getenv("SERVICENOW_GITHUB_CREDENTIAL")

            if not instance_url:
                raise ValueError("Missing SERVICENOW_INSTANCE environment variable")

            # Validate that we have either basic auth OR OAuth credentials
            has_basic_auth = bool(username and password)
            has_oauth = bool(client_id and client_secret)

            if not has_basic_auth and not has_oauth:
                raise ValueError(
                    "Missing authentication credentials. Provide either:\n"
                    "  - Basic Auth: SERVICENOW_USERNAME and SERVICENOW_PASSWORD\n"
                    "  - OAuth: SERVICENOW_CLIENT_ID and SERVICENOW_CLIENT_SECRET\n\n"
                    "For multi-instance setup, use:\n"
                    "  SERVICENOW_INSTANCES=alias1,alias2\n"
                    "  SERVICENOW_INSTANCE_ALIAS1, SERVICENOW_USERNAME_ALIAS1, etc.\n"
                    "  or SERVICENOW_CLIENT_ID_ALIAS1, SERVICENOW_CLIENT_SECRET_ALIAS1, etc."
                )

            # Create default instance with alias "default"
            self.instances["default"] = InstanceConfig(
                "default", instance_url, username, password, client_id, client_secret,
                install_hostname=install_hostname,
                github_credential=github_credential,
            )
            self.default_instance = "default"

    def get_instance(self, alias: Optional[str] = None) -> InstanceConfig:
        """
        Get configuration for a specific instance.

        Args:
            alias: Instance alias (e.g., "prod", "dev"). If None, returns default instance.

        Returns:
            InstanceConfig for the requested instance

        Raises:
            ValueError: If the alias doesn't exist
        """
        if alias is None:
            alias = self.default_instance

        if alias not in self.instances:
            available = ", ".join(self.instances.keys())
            raise ValueError(
                f"Unknown instance alias '{alias}'. Available instances: {available}"
            )

        return self.instances[alias]

    def list_instances(self) -> list[str]:
        """Return list of configured instance aliases."""
        return list(self.instances.keys())

    def has_multiple_instances(self) -> bool:
        """Check if multiple instances are configured."""
        return len(self.instances) > 1

    def format_instance_list(self) -> str:
        """Format list of instances for user display."""
        lines = []
        for alias, config in self.instances.items():
            default_marker = " (default)" if alias == self.default_instance else ""
            lines.append(f"  - {alias}: {config.instance}{default_marker}")
        return "\n".join(lines)

# Singleton instance
_config: Optional[ServiceNowConfig] = None

def get_config() -> ServiceNowConfig:
    """Get the singleton configuration instance."""
    global _config
    if _config is None:
        _config = ServiceNowConfig()
    return _config


def reload_config():
    """Reset the config singleton so next call re-reads .env.

    Call this after modifying the .env file programmatically
    (e.g., via instance management tools) so subsequent tool calls
    see the updated configuration.
    """
    global _config
    _config = None
    load_dotenv(override=True)
