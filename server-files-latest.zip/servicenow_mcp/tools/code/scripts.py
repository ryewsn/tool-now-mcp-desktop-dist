"""Scripts and Code Retrieval Tools"""

import re

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

from ...core.script_runner import (
    SCRIPT_RUNNER_BASE_URI as _SCRIPT_RUNNER_BASE_URI,
    SCRIPT_RUNNER_SERVICE_ID as _SCRIPT_RUNNER_SERVICE_ID,
    SCRIPT_RUNNER_OPERATION_SCRIPT as _SCRIPT_RUNNER_OPERATION_SCRIPT,
)

_BLOCKED_PATTERNS = [
    ("deleteRecord", r"\bdeleteRecord\b"),
    ("deleteMultiple", r"\bdeleteMultiple\b"),
    ("GlideTableManager.drop", r"GlideTableManager\s*\.\s*drop\b"),
    ("GlideTableManager.delete", r"GlideTableManager\s*\.\s*delete\b"),
    ("gs.setProperty", r"\bgs\s*\.\s*setProperty\b"),
    ("GlideRecord.destroy", r"\bdestroy\s*\("),
]

_WRITE_PATTERNS = [
    r"\binsert\s*\(",
    r"\bupdate\s*\(",
    r"\bsetValue\s*\(",
]

def install_script_runner(client) -> tuple[bool, str]:
    """Install the Foundry Script Runner on the given client's instance.

    Idempotent — safe to call if already installed.
    Returns (success, message) where message is suitable for display.
    """
    existing = client.query_table(
        table_name="sys_ws_definition",
        query=f"service_id={_SCRIPT_RUNNER_SERVICE_ID}^ORbase_uri={_SCRIPT_RUNNER_BASE_URI}",
        fields=["sys_id", "name", "service_id", "active"],
        limit=1,
    )
    if not existing["success"]:
        return False, format_error(existing["status_code"], existing.get("error", ""))

    if existing["result"]:
        return True, "Foundry Script Runner already installed."

    defn_response = client.create_record(
        table_name="sys_ws_definition",
        data={
            "name": "Foundry Script Runner",
            "service_id": _SCRIPT_RUNNER_SERVICE_ID,
            "base_uri": _SCRIPT_RUNNER_BASE_URI,
            "namespace": "now",
            "short_description": "Executes scripts via eval() with gs.info capture. Deployed by Foundry MCP.",
            "active": "true",
            "consumes": "application/json,application/xml,text/xml",
            "produces": "application/json,application/xml,text/xml",
        },
    )
    if not defn_response["success"]:
        return False, "Failed to create Script Runner API definition: " + format_error(
            defn_response["status_code"], defn_response.get("error", "")
        )

    defn_sys_id = defn_response["result"]["sys_id"]

    op_response = client.create_record(
        table_name="sys_ws_operation",
        data={
            "name": "Execute Script",
            "web_service_definition": defn_sys_id,
            "http_method": "POST",
            "relative_path": "/execute",
            "short_description": "Execute a script and capture gs.info output",
            "operation_script": _SCRIPT_RUNNER_OPERATION_SCRIPT,
            "active": "true",
            "requires_authentication": "true",
            "requires_snc_internal_role": "true",
            "requires_acl_authorization": "false",
            "consumes": "application/json,application/xml,text/xml",
            "produces": "application/json,application/xml,text/xml",
        },
    )
    if not op_response["success"]:
        return False, "Script Runner API definition created but operation failed: " + format_error(
            op_response["status_code"], op_response.get("error", "")
        )

    return True, "Foundry Script Runner installed successfully."


def register_tools(mcp: FastMCP):
    """Register script and code-related tools with the MCP server."""

    @mcp.tool()
    def get_script_include(
        name: str = "",
        sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Fetch the source code for a Script Include (sys_script_include) by name or sys_id.

        Use when:
        - Syslog shows an error in a Script Include and you need to see the code
        - Reviewing code called by flows, Business Rules, or other scripts

        Key fields in results:
            active: Inactive scripts won't execute.
            api_name: Scoped API name used to call this (e.g., "global.MyUtils").
        """
        if not name and not sys_id:
            return "Please provide either a name or sys_id to look up the Script Include."

        # Build query
        builder = QueryBuilder()
        builder.add_equals("name", name)
        builder.add_equals("sys_id", sys_id)

        query = builder.build()

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_script_include",
            query=query,
            fields=["name", "api_name", "sys_id", "script", "active", "description", "sys_updated_on", "sys_updated_by"],
            limit=1
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return f"No Script Include found with name '{name}' or sys_id '{sys_id}'."

        # Format output
        entry = results[0]
        return (
            f"Script Include: {entry.get('name', 'N/A')}\n"
            f"API Name: {entry.get('api_name', 'N/A')}\n"
            f"Active: {entry.get('active', 'N/A')}\n"
            f"Description: {entry.get('description', 'N/A')}\n"
            f"Last updated: {entry.get('sys_updated_on', 'N/A')} by {entry.get('sys_updated_by', 'N/A')}\n"
            f"Sys ID: {entry.get('sys_id', 'N/A')}\n\n"
            f"--- CODE ---\n\n{entry.get('script', 'No script content found.')}"
        )

    @mcp.tool()
    def get_business_rule(
        name: str = "",
        sys_id: str = "",
        table: str = "",
        instance: str = None
    ) -> str:
        """
        Fetch the code and configuration for a Business Rule (sys_script) by name or sys_id.

        Use when:
        - Records are being modified unexpectedly and you suspect a Business Rule
        - Debugging "before" vs "after" rule timing issues

        Key fields in results:
            when: before/after/async/display — "before" rules can abort; "after" see final values.
            order: Execution priority; lower runs first.
            filter_condition: Encoded query for trigger conditions; empty means "always".
            action_insert/update/delete: Which operations trigger this rule.

        Args:
            table: Filter by the table the rule applies to (narrows results).
        """
        if not name and not sys_id:
            return "Please provide either a name or sys_id to look up the Business Rule."

        # Build query
        builder = QueryBuilder()
        builder.add_like("name", name)
        builder.add_equals("sys_id", sys_id)
        builder.add_equals("collection", table)

        query = builder.build()

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_script",
            query=query,
            fields=["name", "collection", "sys_id", "script", "active", "when", "filter_condition", "action_insert", "action_update", "action_delete", "action_query", "order", "sys_updated_on", "sys_updated_by"],
            limit=5
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return f"No Business Rule found matching your criteria."

        # Format output
        output = []
        for entry in results:
            triggers = []
            if entry.get('action_insert') == 'true':
                triggers.append('Insert')
            if entry.get('action_update') == 'true':
                triggers.append('Update')
            if entry.get('action_delete') == 'true':
                triggers.append('Delete')
            if entry.get('action_query') == 'true':
                triggers.append('Query')

            output.append(
                f"Business Rule: {entry.get('name', 'N/A')}\n"
                f"Table: {entry.get('collection', 'N/A')}\n"
                f"Active: {entry.get('active', 'N/A')}\n"
                f"When: {entry.get('when', 'N/A')} | Order: {entry.get('order', 'N/A')}\n"
                f"Triggers on: {', '.join(triggers) if triggers else 'N/A'}\n"
                f"Condition: {entry.get('filter_condition', 'None')}\n"
                f"Last updated: {entry.get('sys_updated_on', 'N/A')} by {entry.get('sys_updated_by', 'N/A')}\n"
                f"Sys ID: {entry.get('sys_id', 'N/A')}\n\n"
                f"--- CODE ---\n\n{entry.get('script', 'No script content found.')}"
            )

        return "\n\n===\n\n".join(output)

    @mcp.tool()
    def execute_script(
        script: str,
        allow_writes: bool = False,
        bypass_blocked_patterns: bool = False,
        timeout_ms: int = 10000,
        instance: str = None
    ) -> str:
        """
        Execute arbitrary GlideScript on a ServiceNow instance via the Foundry Script Runner.

        Requires the Foundry Script Runner Scripted REST API (setup_script_runner to install).
        Output captured from gs.info/warn/error/log/debug/print — all passthrough to syslog.
        Use gs.info() for general output.

        Timeout (default 10s) is checked on each gs.* call. For long-running loops, call
        __checkTimeout() explicitly to cooperate with the timeout limit.

        SAFETY:
        - Write operations (insert, update, setValue) blocked by default; set allow_writes=true.
        - Destructive patterns (deleteRecord, deleteMultiple, GlideTableManager.drop,
          gs.setProperty, destroy) always blocked unless bypass_blocked_patterns=true.
        - bypass_blocked_patterns=true removes all pattern-based safety checks.
        - Service account ACLs are the ultimate security boundary.

        Args:
            script: GlideScript to execute.
            allow_writes: Allow insert/update/setValue (default false).
            bypass_blocked_patterns: Skip blocked-pattern checks — removes safety guardrails
                (default false). Use only for scripts you fully understand.
            timeout_ms: Max execution time in ms (default 10000). Hard backstop is the
                ServiceNow platform transaction quota (~60s).
        """
        if not script or not script.strip():
            return "Please provide a script to execute."

        # Check blocked patterns (unless bypassed)
        if not bypass_blocked_patterns:
            for name, pattern in _BLOCKED_PATTERNS:
                if re.search(pattern, script):
                    return (
                        f"Script blocked: contains '{name}' which is a potentially destructive operation.\n"
                        f"Set bypass_blocked_patterns=true to override (use with caution)."
                    )

        # Check write patterns (unless allow_writes)
        if not allow_writes:
            for pattern in _WRITE_PATTERNS:
                if re.search(pattern, script):
                    return (
                        "Script appears to contain write operations (insert/update/setValue).\n"
                        "Set allow_writes=true to proceed."
                    )

        confirmation_error = require_instance_confirmation(instance, "execute script on ServiceNow")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        if not client._prepare_request():
            return "Authentication failed."

        url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
        response = client.session.post(url, json={"script": script, "timeout_ms": timeout_ms})

        if response.status_code == 400 and "does not represent any resource" in response.text:
            return (
                "Script execution requires the Foundry Script Runner to be installed on this instance.\n"
                "Use the setup_script_runner tool to install it."
            )

        if response.status_code not in (200, 201):
            return format_error(response.status_code, response.text[:500])

        result = response.json().get("result", {})
        output_lines = result.get("output", [])
        error = result.get("error")
        timed_out = result.get("timed_out", False)

        parts = []
        if output_lines:
            parts.append("\n".join(output_lines))
        if timed_out:
            parts.append(f"[TIMEOUT] {error}")
        elif error:
            parts.append(f"Error: {error}")

        if not parts:
            return "(Script executed successfully with no output)"
        return "\n".join(parts)

    @mcp.tool()
    def setup_script_runner(instance: str = None) -> str:
        """
        Install the Foundry Script Runner Scripted REST API — prerequisite for execute_script.

        Creates sys_ws_definition (/api/now/foundry_script_runner) and sys_ws_operation (POST /execute).
        Idempotent — safe to run if already installed. Returns status of each step.

        Supports: gs.info/warn/error/log/debug/print output capture, syslog passthrough,
        cooperative timeout (default 10s), full gs delegation (getProperty, getUser, hasRole).
        """
        confirmation_error = require_instance_confirmation(instance, "create Scripted REST API records")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        _success, message = install_script_runner(client)
        return message
