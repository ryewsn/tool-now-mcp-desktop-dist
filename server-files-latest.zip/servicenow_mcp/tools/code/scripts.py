"""Scripts and Code Retrieval Tools"""

import re

from mcp.server.mcpserver import MCPServer
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

from ...core.script_runner import install_script_runner  # noqa: F401 (single installer; patched here by tests)
from ...core.scope_detect import take_run_marker, detect_changes, resolve_expected

_BLOCKED_PATTERNS = [
    ("deleteRecord", r"\bdeleteRecord\b"),
    ("deleteMultiple", r"\bdeleteMultiple\b"),
    ("GlideTableManager.drop", r"GlideTableManager\s*\.\s*drop\b"),
    ("GlideTableManager.delete", r"GlideTableManager\s*\.\s*delete\b"),
    ("gs.setProperty", r"\bgs\s*\.\s*setProperty\b"),
    ("GlideRecord.destroy", r"\bdestroy\s*\("),
    ("prototype-assignment", r"\bprototype\.\w+\s*=(?!=)"),
]

_WRITE_PATTERNS = [
    r"\binsert\s*\(",
    r"\bupdate\s*\(",
    r"\bsetValue\s*\(",
]

def _detection_lines(client, marker, detection_error, expected_scope, resolved=None):
    """Lines appended to a writing run's output; never raises."""
    lines = []
    try:
        if marker is None:
            raise RuntimeError(detection_error or "no marker")
        detected = detect_changes(client, marker, expected_scope, resolved=resolved)
        changes = detected.get("changes", [])
        outside = detected.get("outside_expected", [])
        if changes:
            lines.append("Changes detected (update-tracked tables, best effort):")
            for c in changes:
                lines.append(f"  - {c['action']} {c['target_name'] or c['name']} "
                             f"[{c['name']}] application: {c['application']}")
            if detected.get("truncated"):
                lines.append("  (row limit reached; more changes may exist)")
        else:
            lines.append("No update-tracked changes detected (data tables are not tracked).")
        if detected.get("scope_error"):
            lines.append(f"Error: {detected['scope_error']}; changes could not be checked "
                         f"against it.")
        elif expected_scope:
            if outside:
                lines.append(f"Error: {len(outside)} change(s) landed outside expected_scope "
                             f"'{expected_scope}':")
                for c in outside:
                    lines.append(f"  - {c['target_name'] or c['name']} [{c['name']}] "
                                 f"in application: {c['application']}")
        else:
            lines.append("Run was UNGUARDED: no expected_scope given, so changes were not "
                         "checked against a scope.")
    except Exception as e:
        return [f"Scope detection failed ({e}); the script ran, its result is reported "
                f"separately."]
    return lines


def register_tools(mcp: MCPServer):
    """Register script and code-related tools with the MCP server."""

    @mcp.tool()
    def get_script_include(
        name: str = "",
        sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Fetch the source code for a Script Include (sys_script_include) by name or sys_id.

        Use when:
        - Syslog shows an error in a Script Include and you need to see the code
        - Reviewing code called by flows, Business Rules, or other scripts

        Key fields in results:
            active: Inactive scripts won't execute.
            api_name: Scoped API name used to call this (e.g., "global.MyUtils").
        """
        if not name and not sys_id:
            return "Please provide either a name or sys_id to look up the Script Include."

        # Build query
        builder = QueryBuilder()
        builder.add_equals("name", name)
        builder.add_equals("sys_id", sys_id)

        query = builder.build()

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_script_include",
            query=query,
            fields=["name", "api_name", "sys_id", "script", "active", "description", "sys_updated_on", "sys_updated_by"],
            limit=1
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return f"No Script Include found with name '{name}' or sys_id '{sys_id}'."

        # Format output
        entry = results[0]
        return (
            f"Script Include: {entry.get('name', 'N/A')}\n"
            f"API Name: {entry.get('api_name', 'N/A')}\n"
            f"Active: {entry.get('active', 'N/A')}\n"
            f"Description: {entry.get('description', 'N/A')}\n"
            f"Last updated: {entry.get('sys_updated_on', 'N/A')} by {entry.get('sys_updated_by', 'N/A')}\n"
            f"Sys ID: {entry.get('sys_id', 'N/A')}\n\n"
            f"--- CODE ---\n\n{entry.get('script', 'No script content found.')}"
        )

    @mcp.tool()
    def get_business_rule(
        name: str = "",
        sys_id: str = "",
        table: str = "",
        instance: str = None
    ) -> str:
        """
        Fetch the code and configuration for a Business Rule (sys_script) by name or sys_id.

        Use when:
        - Records are being modified unexpectedly and you suspect a Business Rule
        - Debugging "before" vs "after" rule timing issues

        Key fields in results:
            when: before/after/async/display — "before" rules can abort; "after" see final values.
            order: Execution priority; lower runs first.
            filter_condition: Encoded query for trigger conditions; empty means "always".
            action_insert/update/delete: Which operations trigger this rule.

        Args:
            table: Filter by the table the rule applies to (narrows results).
        """
        if not name and not sys_id:
            return "Please provide either a name or sys_id to look up the Business Rule."

        # Build query
        builder = QueryBuilder()
        builder.add_like("name", name)
        builder.add_equals("sys_id", sys_id)
        builder.add_equals("collection", table)

        query = builder.build()

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_script",
            query=query,
            fields=["name", "collection", "sys_id", "script", "active", "when", "filter_condition", "action_insert", "action_update", "action_delete", "action_query", "order", "sys_updated_on", "sys_updated_by"],
            limit=5
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return f"No Business Rule found matching your criteria."

        # Format output
        output = []
        for entry in results:
            triggers = []
            if entry.get('action_insert') == 'true':
                triggers.append('Insert')
            if entry.get('action_update') == 'true':
                triggers.append('Update')
            if entry.get('action_delete') == 'true':
                triggers.append('Delete')
            if entry.get('action_query') == 'true':
                triggers.append('Query')

            output.append(
                f"Business Rule: {entry.get('name', 'N/A')}\n"
                f"Table: {entry.get('collection', 'N/A')}\n"
                f"Active: {entry.get('active', 'N/A')}\n"
                f"When: {entry.get('when', 'N/A')} | Order: {entry.get('order', 'N/A')}\n"
                f"Triggers on: {', '.join(triggers) if triggers else 'N/A'}\n"
                f"Condition: {entry.get('filter_condition', 'None')}\n"
                f"Last updated: {entry.get('sys_updated_on', 'N/A')} by {entry.get('sys_updated_by', 'N/A')}\n"
                f"Sys ID: {entry.get('sys_id', 'N/A')}\n\n"
                f"--- CODE ---\n\n{entry.get('script', 'No script content found.')}"
            )

        return "\n\n===\n\n".join(output)

    @mcp.tool()
    def execute_script(
        script: str,
        allow_writes: bool = False,
        bypass_blocked_patterns: bool = False,
        timeout_ms: int = 10000,
        expected_scope: str = None,
        instance: str = None
    ) -> str:
        """
        Execute arbitrary GlideScript on a ServiceNow instance via the Foundry Script Runner.

        Requires the Foundry Script Runner Scripted REST API (setup_script_runner to install).
        Output captured from gs.info/warn/error/log/debug/print — all passthrough to syslog.
        Use gs.info() for general output.

        Timeout (default 10s) is checked on each gs.* call. For long-running loops, call
        __checkTimeout() explicitly to cooperate with the timeout limit.

        **Verify table names before use:**
        ServiceNow silently returns "invalid table name" for non-existent tables rather than
        an error — failed GlideRecord queries return no results and no indication of why.
        Before scripting against an unfamiliar table, call get_table_schema(table) to confirm
        it exists and get authoritative field names. Do not guess table or field names.

        SAFETY:
        - Write operations (insert, update, setValue) blocked by default; set allow_writes=true.
        - Destructive patterns (deleteRecord, deleteMultiple, GlideTableManager.drop,
          gs.setProperty, destroy) always blocked unless bypass_blocked_patterns=true.
        - Prototype reassignment (SomeClass.prototype.method =) always blocked unless
          bypass_blocked_patterns=true — prevents node-wide prototype poisoning.
        - bypass_blocked_patterns=true removes all pattern-based safety checks.
        - Service account ACLs are the ultimate security boundary.

        WHERE WRITES LAND (best effort): a script's writes follow the session's ambient
        application scope, which this tool does not set, so a record can land in the wrong
        scope with no error. For writes to a scoped application prefer the scope-safe tools
        (the `scope` parameter of create_record / update_record, or the dedicated tool for the
        artifact) over a hand-written GlideRecord insert. When a run could write (allow_writes
        or bypass_blocked_patterns is true) the tool reads server time and the acting user
        before the run, then lists the update-tracked changes (sys_update_xml, matched on
        sys_updated_on) that user made since, with their application. Give expected_scope (a
        scope id, scope sys_id or "global") and any change outside it is reported as an error;
        without it the run is labelled UNGUARDED. This never refuses or fails a run. Limits: it
        cannot separate two concurrent runs by the same user; it sees only tables captured by
        update tracking (a data table such as incident is invisible); sys_audit was not tested;
        a detection failure is reported but the script output is still returned; a user name
        outside the safe character set disables detection for that run. Read-only runs
        take no marker and add no lines.

        Args:
            script: GlideScript to execute.
            allow_writes: Allow insert/update/setValue (default false).
            bypass_blocked_patterns: Skip blocked-pattern checks — removes safety guardrails
                (default false). Use only for scripts you fully understand.
            timeout_ms: Max execution time in ms (default 10000). Hard backstop is the
                ServiceNow platform transaction quota (~60s).
            expected_scope: Scope id, scope sys_id or "global" the writes are meant to land in.
                Changes found in any other application are reported as errors. Optional; when
                omitted a writing run is labelled unguarded.
        """
        if not script or not script.strip():
            return "Please provide a script to execute."

        # Check blocked patterns (unless bypassed)
        if not bypass_blocked_patterns:
            for name, pattern in _BLOCKED_PATTERNS:
                if re.search(pattern, script):
                    return (
                        f"Script blocked: contains '{name}' which is a potentially destructive operation.\n"
                        f"Set bypass_blocked_patterns=true to override (use with caution)."
                    )

        # Check write patterns (unless allow_writes)
        if not allow_writes:
            for pattern in _WRITE_PATTERNS:
                if re.search(pattern, script):
                    return (
                        "Script appears to contain write operations (insert/update/setValue).\n"
                        "Set allow_writes=true to proceed."
                    )

        confirmation_error = require_instance_confirmation(instance, "execute script on ServiceNow")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        if not client._prepare_request():
            return "Authentication failed."

        # Detection only for runs that could write; a failure never fails the run.
        could_write = bool(allow_writes or bypass_blocked_patterns)
        marker = None
        detection_error = None
        resolved = None
        if could_write:
            resolved = resolve_expected(client, expected_scope)
            try:
                marker = take_run_marker(client)
            except Exception as e:
                detection_error = f"could not take the pre-run marker: {e}"

        url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
        response = client.session.post(url, json={"script": script, "timeout_ms": timeout_ms})

        if response.status_code == 400 and "does not represent any resource" in response.text:
            return (
                "Script execution requires the Foundry Script Runner to be installed on this instance.\n"
                "Use the setup_script_runner tool to install it."
            )

        if response.status_code not in (200, 201):
            return format_error(response.status_code, response.text[:500])

        result = response.json().get("result", {})
        output_lines = result.get("output", [])
        error = result.get("error")
        timed_out = result.get("timed_out", False)

        parts = []
        if output_lines:
            parts.append("\n".join(output_lines))
        if timed_out:
            parts.append(f"[TIMEOUT] {error}")
        elif error:
            parts.append(f"Error: {error}")

        if not parts:
            parts.append("(Script executed successfully with no output)")
        if could_write:
            parts.extend(_detection_lines(client, marker, detection_error, expected_scope, resolved))
        return "\n".join(parts)

    @mcp.tool()
    def setup_script_runner(instance: str = None) -> str:
        """
        Install the Foundry Script Runner Scripted REST API — prerequisite for execute_script and
        for tools that write through GlideRecord (e.g., create_custom_table, create_table_index).

        Creates sys_ws_definition (/api/now/foundry_script_runner) and sys_ws_operation (POST /execute).
        Idempotent — safe to run if already installed. After a fresh install the definition and the
        operation are read back and must both be in the Global scope; otherwise this reports an error
        naming the stray records instead of success.

        Supports: gs.info/warn/error/log/debug/print output capture, syslog passthrough,
        cooperative timeout (default 10s), full gs delegation (getProperty, getUser, hasRole).
        """
        confirmation_error = require_instance_confirmation(instance, "create Scripted REST API records")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        success, message = install_script_runner(client)
        return message if success else f"Error: {message}"
