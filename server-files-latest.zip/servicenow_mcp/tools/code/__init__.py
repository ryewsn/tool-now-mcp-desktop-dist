"""Scripts and code retrieval tools"""
from .scripts import register_tools as _register_scripts
from .source_control import register_tools as _register_source_control


def register_tools(mcp):
    _register_scripts(mcp)
    _register_source_control(mcp)


__all__ = ["register_tools"]
