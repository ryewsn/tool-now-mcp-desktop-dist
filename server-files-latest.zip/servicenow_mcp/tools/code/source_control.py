"""GitHub Source Control Tools"""

import json
import re
import time
from mcp.server.mcpserver import MCPServer
from ...core.client import get_client, reset_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

_DEFAULT_CREDENTIAL_NAME = "GitHub Token"
_NO_GITHUB_CREDENTIALS_MSG = "No GitHub credentials found on this instance."

# Verified against zyew2: source control lives under sn_devstudio VCS API.
_VCS_BASE = "/api/sn_devstudio/vcs"
_VCS_PROGRESS_TABLE = "sn_appclient_progress_log"


def _vcs_call(client, method: str, path: str, body: dict = None) -> dict:
    """
    POST or PUT to /api/sn_devstudio/vcs/{path}.

    Returns {"success": bool, "job_id": str | None, "error": str | None}
    """
    if not client._prepare_request():
        return {"success": False, "job_id": None, "error": "Authentication failed."}
    url = f"{client.config.instance}{_VCS_BASE}/{path.lstrip('/')}"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    try:
        fn = client.session.put if method.upper() == "PUT" else client.session.post
        resp = fn(url, json=body or {}, headers=headers)
    except Exception as exc:
        return {"success": False, "job_id": None, "error": str(exc)}
    if resp.status_code in (200, 202):
        try:
            data = resp.json() if resp.text.strip() else {}
        except Exception:
            data = {}
        if not isinstance(data, dict):
            data = {}
        job_id = data.get("transactionId") or data.get("progressId") or data.get("trackerId")
        return {"success": True, "job_id": job_id, "error": None}
    return {"success": False, "job_id": None,
            "error": format_error(resp.status_code, resp.text[:300])}


def _vcs_get_app(client, app_sys_id: str) -> dict:
    """GET /api/sn_devstudio/vcs/apps/{id}. Returns response body dict, or {} on failure."""
    if not client._prepare_request():
        return {}
    url = f"{client.config.instance}{_VCS_BASE}/apps/{app_sys_id}"
    try:
        resp = client.session.get(url, headers={"Accept": "application/json"})
        if resp.status_code == 200:
            data = resp.json()
            if not isinstance(data, dict):
                return {}
            # Unwrap ServiceNow result envelope if present
            if "result" in data and isinstance(data["result"], dict):
                return data["result"]
            return data
    except Exception:
        pass
    return {}


def _vcs_get_outgoing_changes(client, app_sys_id: str) -> list:
    """
    GET /api/sn_devstudio/vcs/apps/{id}/changes — list of pending local changes for an app.

    This is the "List Local Changes" endpoint (not under /repos/{repoId}/) — each entry
    is a dict with sysId, updateName, fileSysId, table, type, updatedBy, updatedOn,
    fileName, action, isDeleted, and an updateSet object. These are the exact objects the
    commit endpoint's changedRecords expects; pass them through as-is.

    Returns [] on failure or when there are no outgoing changes.
    """
    if not client._prepare_request():
        return []
    url = f"{client.config.instance}{_VCS_BASE}/apps/{app_sys_id}/changes"
    try:
        resp = client.session.get(url, headers={"Accept": "application/json"})
        if resp.status_code != 200:
            return []
        data = resp.json()
        if not isinstance(data, dict):
            return []
        result = data.get("result")
        if isinstance(result, list):
            return result
        return []
    except Exception:
        return []


def _ensure_current_app(client, app_sys_id: str) -> dict:
    """
    Set the acting user's apps.current_app preference to app_sys_id and report what it was.

    The VCS endpoints follow the session-cached scope, and the commit endpoint rejects
    changedRecords unless the acting user's scope matches the target app (error 1008,
    seen in an earlier session; S2 saw a silent no-op instead). Resolves the acting user via
    client.config.username (set for both Basic Auth and OAuth instances in this project's
    .env convention).

    Never raises. Returns a state dict:
      {"ok": bool, "skipped": str|None, "error": str|None, "user": sys_id|None,
       "pref_sys_id": sys_id|None, "had_row": bool, "prior": str|None}
    ok=False means the preference could not be set; the caller must not make the VCS call.
    skipped is set (ok stays True) when no username is configured, so the scope could not
    be stated at all.
    """
    state = {"ok": True, "skipped": None, "error": None, "user": None,
             "pref_sys_id": None, "had_row": False, "prior": None}
    username = getattr(client.config, "username", None)
    if not username:
        state["skipped"] = "no username configured, so apps.current_app was not set"
        return state
    try:
        user_response = client.query_table("sys_user", query=f"user_name={username}", fields=["sys_id"], limit=1)
        if not user_response.get("success") or not user_response.get("result"):
            state.update(ok=False, error=f"could not resolve user '{username}'")
            return state
        user_sys_id = user_response["result"][0]["sys_id"]
        state["user"] = user_sys_id

        pref_response = client.query_table(
            "sys_user_preference",
            query=f"name=apps.current_app^user={user_sys_id}",
            fields=["sys_id", "value"],
            limit=1,
        )
        if not pref_response.get("success"):
            state.update(ok=False, error="could not read the apps.current_app preference")
            return state
        if pref_response.get("result"):
            pref = pref_response["result"][0]
            state.update(had_row=True, pref_sys_id=pref["sys_id"], prior=pref.get("value"))
            if pref.get("value") != app_sys_id:
                resp = client.update_record(
                    "sys_user_preference", pref["sys_id"], {"value": app_sys_id},
                    unscoped_ok="sys_user_preference has no sys_scope column (audit S6): "
                                "apps.current_app preference write")
                if not resp.get("success"):
                    state.update(ok=False, error=f"updating apps.current_app failed: {resp.get('error')}")
        else:
            resp = client.create_record("sys_user_preference", {
                "name": "apps.current_app",
                "value": app_sys_id,
                "user": user_sys_id,
            }, unscoped_ok="sys_user_preference has no sys_scope column (audit S6): "
                           "apps.current_app preference write")
            if not resp.get("success"):
                state.update(ok=False, error=f"creating apps.current_app failed: {resp.get('error')}")
            else:
                created = resp.get("result")
                state["created_sys_id"] = created.get("sys_id") if isinstance(created, dict) else None
    except Exception as exc:
        state.update(ok=False, error=str(exc))
    return state


def _restore_current_app(client, app_sys_id: str, state: dict) -> str:
    """
    Put apps.current_app back to its prior value and read it back. Returns a message.

    No prior row: the row this call created (and only that sys_id) is deleted with the
    internal client.delete_record and read back as gone; if that fails the message says
    the row was left set to the app. A restore that does not read back is reported, never
    swallowed.
    """
    if state.get("skipped"):
        return f"Scope preference: {state['skipped']}."
    if not state.get("user"):
        return ""
    if not state.get("had_row"):
        created = state.get("created_sys_id")
        left = f"apps.current_app: no prior preference; left set to {app_sys_id}"
        if not created:
            return left + " (the sys_id of the row this call created was not returned, so it was not deleted)."
        try:
            resp = client.delete_record(
                "sys_user_preference", created,
                unscoped_ok="sys_user_preference has no sys_scope column (audit S6): "
                            "deleting the preference row this call created")
            if not resp.get("success"):
                return left + f" (deleting the row this call created failed: {resp.get('error')})."
            read = client.query_table(
                "sys_user_preference", query=f"sys_id={created}", fields=["sys_id"], limit=1)
            if not read.get("success"):
                return left + " (deleted, but the read-back to confirm it failed)."
            if read.get("result"):
                return left + " (the row this call created is still present after the delete)."
        except Exception as exc:
            return left + f" (deleting the row this call created raised: {exc})."
        return "apps.current_app: no prior preference; the row this call created was deleted (read back: gone)."
    prior = state.get("prior")
    try:
        if prior != app_sys_id:
            resp = client.update_record(
                "sys_user_preference", state["pref_sys_id"], {"value": prior or ""},
                unscoped_ok="sys_user_preference has no sys_scope column (audit S6): "
                            "restoring the prior apps.current_app value")
            if not resp.get("success"):
                return (f"apps.current_app NOT restored (update failed: {resp.get('error')}); "
                        f"it is still {app_sys_id}, was {prior}.")
        read = client.query_table(
            "sys_user_preference", query=f"name=apps.current_app^user={state['user']}",
            fields=["sys_id", "value"], limit=1)
        got = read["result"][0].get("value") if read.get("success") and read.get("result") else None
    except Exception as exc:
        return f"apps.current_app NOT restored (error: {exc}); it may still be {app_sys_id}, was {prior}."
    if (got or "") == (prior or ""):
        return f"apps.current_app restored to {prior or '(empty)'} (read back)."
    return f"apps.current_app NOT restored: read back {got}, expected {prior}."


# Verification polling. The platform can lag a few seconds; tests patch _poll_sleep.
_POLL_ATTEMPTS = 6
_POLL_INTERVAL = 3.0
_poll_sleep = time.sleep


def _branch_rows(client, app_sys_id: str, branch: str = None):
    """
    Read sys_repo_branch (name, object_id, is_current) for ONE app. Returns a list, or None on failure.

    Branch rows reference sys_repo_config, which references the app (sys_app); two apps can
    both have `main` current, so the read is filtered by dot-walk on that app. ORDERBYname
    keeps before/after reads comparable. limit=100 is unchanged (an app has few branches).
    """
    query = f"sys_repo_config.sys_app={app_sys_id}^" + (f"name={branch}" if branch else "is_current=true")
    query += "^ORDERBYname"
    resp = client.query_table("sys_repo_branch", query=query,
                              fields=["name", "object_id", "is_current"], limit=100)
    if not resp.get("success"):
        return None
    return resp.get("result") or []


def _is_true(value) -> bool:
    return str(value).lower() == "true"


def _current_heads(client, app_sys_id: str):
    """{branch name: object_id} for the app's is_current branch rows, or None if unreadable."""
    rows = _branch_rows(client, app_sys_id)
    if rows is None:
        return None
    return {r.get("name"): r.get("object_id") for r in rows if _is_true(r.get("is_current"))}


def _verify_head_changed(before, app_sys_id: str):
    """Build a verify callable: the current branch head (object_id) differs from `before`."""
    def verify(client):
        if before is None:
            return None, "could not read sys_repo_branch before the call"
        if not before:
            # No is_current row for this app (none exists, ACL-hidden or filter mismatch):
            # there is no baseline to compare, so this is "not verified", not "head unchanged".
            return None, "no current sys_repo_branch row found for this app"
        read_failed = True
        for attempt in range(_POLL_ATTEMPTS):
            if attempt:
                _poll_sleep(_POLL_INTERVAL)
            after = _current_heads(client, app_sys_id)
            if after is None:
                continue
            read_failed = False
            if after != before:
                moved = [f"{n}: {str(before.get(n))[:8]} -> {str(h)[:8]}"
                         for n, h in after.items() if before.get(n) != h]
                return True, "sys_repo_branch head moved (" + ", ".join(moved or ["branch changed"]) + ")"
        if read_failed:
            return None, "could not read sys_repo_branch after the call"
        return False, (f"sys_repo_branch head unchanged after {_POLL_ATTEMPTS} checks "
                       f"(current: {', '.join(f'{n}@{str(h)[:8]}' for n, h in before.items()) or 'none'})")
    return verify


def _verify_branch_current(branch: str, app_sys_id: str):
    """Build a verify callable: sys_repo_branch has `branch` with is_current=true."""
    def verify(client):
        read_failed = True
        for attempt in range(_POLL_ATTEMPTS):
            if attempt:
                _poll_sleep(_POLL_INTERVAL)
            rows = _branch_rows(client, app_sys_id, branch)
            if rows is None:
                continue
            read_failed = False
            if any(_is_true(r.get("is_current")) for r in rows):
                return True, f"sys_repo_branch shows '{branch}' is_current=true"
        if read_failed:
            return None, "could not read sys_repo_branch"
        return False, f"sys_repo_branch does not show '{branch}' as is_current=true after {_POLL_ATTEMPTS} checks"
    return verify


def _vcs_scoped_call(client, app_sys_id, call, verify=None) -> dict:
    """
    Run one VCS call so it cannot silently follow a stale session scope.

    Order: set apps.current_app (when app_sys_id is given) -> reset the client's session
    (reset_client on the alias of the client passed in) -> call(fresh_client) -> verify(fresh_client)
    where an authoritative read exists -> restore the prior preference and read it back (delete
    the row this call created when there was none) -> reset the alias again, so the next call
    builds a session that reflects the restored preference.

    call(client) returns the _vcs_call dict. verify(client) returns (ok, detail) with ok True
    (confirmed), False (read back disproves it) or None (could not read). app_sys_id=None
    (import/migrate with no app yet) skips the preference and still resets the session.

    Returns {"result": dict, "verified": True|False|None, "detail": str, "pref_note": str}.
    verified None means "triggered, not verified".
    """
    alias = client.config.alias
    state = None
    if app_sys_id:
        state = _ensure_current_app(client, app_sys_id)
        if not state["ok"]:
            return {"result": {"success": False, "job_id": None,
                               "error": (f"Could not set apps.current_app to {app_sys_id} "
                                         f"({state['error']}). Nothing was sent to the VCS endpoint. "
                                         f"Check the user's access to sys_user_preference, then retry.")},
                    "verified": None, "detail": "", "pref_note": ""}
    fresh = None
    verified, detail = None, ""
    pref_note = ""
    try:
        reset_client(alias)
        fresh = get_client(alias)
        result = call(fresh)
        if result["success"] and verify is not None:
            verified, detail = verify(fresh)
    finally:
        # Always put the preference back, even if reset/get_client, the call or the verify
        # raised (the old client restores when no fresh one was built). Then reset the alias
        # again: `fresh` cached the APP scope on its first call, and restoring the row does not
        # change a session's cached scope, so the next unrelated call needs its own new session.
        try:
            if state:
                pref_note = _restore_current_app(fresh or client, app_sys_id, state)
        finally:
            if state:
                reset_client(alias)
    return {"result": result, "verified": verified, "detail": detail, "pref_note": pref_note}


def _commit_outcome(verb: str, app_name: str, changes: list, outcome: dict) -> str:
    """Tool message for commit/push: confirmed only by the sys_repo_branch head read-back."""
    result = outcome["result"]
    if not result["success"]:
        return f"{verb} failed: {result['error']}" + _pref_tail(outcome)
    job_id = result["job_id"]
    head = f"{verb} sent for '{app_name}' ({len(changes)} outgoing change(s))."
    job = (f"\nJob: {job_id}\nUse get_source_control_operation_status to poll for completion."
           if job_id else "\nNo job ID returned.")
    if outcome["verified"] is False:
        wait = int((_POLL_ATTEMPTS - 1) * _POLL_INTERVAL)   # real sleep: no sleep before the first read
        return (f"{verb} NOT confirmed for '{app_name}': the branch head was not seen to move within "
                f"~{wait} s ({outcome['detail']}). The endpoint accepted the request, and the commit is "
                f"asynchronous, so it may still land. A stale session scope is one possible cause. "
                f"Re-read sys_repo_branch (or the remote head) before retrying: a retry may send a "
                f"second commit job." + job + _pref_tail(outcome))
    return head + job + "\n" + _scoped_summary(outcome)


def _pref_tail(outcome: dict) -> str:
    return ("\n" + outcome["pref_note"]) if outcome["pref_note"] else ""


def _scoped_summary(outcome: dict) -> str:
    """The verification and preference lines for a tool message, built from the read-back."""
    lines = []
    if outcome["verified"] is True:
        lines.append(f"Verified: {outcome['detail']}.")
    elif outcome["verified"] is None:
        why = f" ({outcome['detail']})" if outcome["detail"] else ""
        lines.append(f"Result: triggered, not verified{why}.")
    if outcome["pref_note"]:
        lines.append(outcome["pref_note"])
    return "\n".join(lines)


def _get_app_repo_url_via_script(client, app_sys_id: str) -> str:
    """
    Get the VCS repo URL for a specific app using the sn_vcs server-side API via execute_script.

    Fallback for when GET /api/sn_devstudio/vcs/apps/{id} returns non-200. Returns the
    repo URL string (trailing slashes stripped), or "" if the app has no source control
    connection or if the Foundry Script Runner is unavailable.
    """
    if not client._prepare_request():
        return ""
    safe_id = app_sys_id.replace("'", "\\'")
    script = (
        f"try {{"
        f"  var r = sn_vcs.AppSourceControl.getRepository('{safe_id}');"
        f"  gs.info(r ? (r.getRepositoryURL() || '').replace(/\\/+$/, '') : '');"
        f"}} catch(e) {{ gs.info(''); }}"
    )
    foundry_url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
    try:
        resp = client.session.post(foundry_url, json={"script": script, "timeout_ms": 15000})
    except Exception:
        return ""
    if resp.status_code not in (200, 201):
        return ""
    try:
        body = resp.json()
        result_block = body.get("result", {}) if isinstance(body, dict) else {}
        output = result_block.get("output", []) if isinstance(result_block, dict) else []
        for line in (output if isinstance(output, list) else []):
            if isinstance(line, dict) and "message" in line:
                return line["message"].strip()
    except Exception:
        pass
    return ""


def _vcs_repo_id(client, app_sys_id: str) -> str:
    """Return the VCS repoId for an app. Falls back to app_sys_id if unavailable."""
    return _vcs_get_app(client, app_sys_id).get("repoId") or app_sys_id


def _find_app_by_repo_url(client, repo_url: str) -> dict | None:
    """
    Find the sys_app record whose VCS repo URL matches repo_url exactly.

    Uses sn_vcs.AppSourceControl server-side API via execute_script — no fuzzy or name
    matching. Returns {"sys_id", "name", "scope"} dict, or None if not found.
    """
    if not client._prepare_request():
        return None

    safe_url = repo_url.replace("\\", "\\\\").replace("'", "\\'")
    script = (
        "var gr = new GlideRecord('sys_app');"
        "gr.setLimit(500); gr.query();"
        "var found = null;"
        "while (gr.next() && !found) {"
        "  try {"
        "    var repo = sn_vcs.AppSourceControl.getRepository(gr.getUniqueValue());"
        "    if (repo) {"
        f"      var u = (repo.getRepositoryURL() || '').replace(/\\/+$/, '');"
        f"      if (u == '{safe_url}'.replace(/\\/+$/, ''))"
        "        found = {sys_id: gr.getUniqueValue(), name: gr.getValue('name'), scope: gr.getValue('scope')};"
        "    }"
        "  } catch(e) {}"
        "}"
        "gs.info(found ? JSON.stringify(found) : 'null');"
    )
    foundry_url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
    try:
        resp = client.session.post(foundry_url, json={"script": script, "timeout_ms": 30000})
    except Exception:
        return None
    if resp.status_code not in (200, 201):
        return None
    try:
        body = resp.json()
        result_block = body.get("result", {}) if isinstance(body, dict) else {}
        output = result_block.get("output", []) if isinstance(result_block, dict) else []
        for line in (output if isinstance(output, list) else []):
            msg = line.get("message", "").strip() if isinstance(line, dict) else ""
            if msg and msg != "null":
                try:
                    parsed = json.loads(msg)
                    if isinstance(parsed, dict):
                        return parsed
                except Exception:
                    pass
    except Exception:
        pass
    return None


def _resolve_credential_sys_id(client, credential_name: str) -> tuple:
    """
    Resolve a credential name to its sys_id in discovery_credentials.

    The sn_devstudio VCS API passes the credential value directly to
    sn_vcs.AppSourceControl.setCredential(), which expects a sys_id —
    not a display name. Passing a name causes error code 1001 (auth failed).

    Returns (sys_id, None) on success, or (None, error_str) on failure.
    error_str includes a list of available credential names when the
    lookup itself succeeds but the name isn't found.
    """
    if re.match(r'^[0-9a-f]{32}$', credential_name, re.IGNORECASE):
        return credential_name, None  # already a sys_id

    qb = QueryBuilder()
    qb.add_equals("name", credential_name)
    resp = client.query_table("discovery_credentials", query=qb.build(),
                              fields=["sys_id", "name"], limit=1)
    if resp["success"] and resp["result"]:
        return resp["result"][0]["sys_id"], None

    # Not found — fetch available names to help the caller
    qb2 = QueryBuilder()
    qb2.add_order_by("name", "")
    avail = client.query_table("discovery_credentials", query=qb2.build(),
                               fields=["name"], limit=50)
    if avail["success"] and avail["result"]:
        names = ", ".join(f'"{r["name"]}"' for r in avail["result"])
        return None, (f"Credential '{credential_name}' not found. "
                      f"Available credentials: {names}")
    return None, f"Credential '{credential_name}' not found in discovery_credentials."


def _find_github_credentials(client) -> list:
    """Search discovery_credentials for Basic Auth records with 'github' in the name."""
    qb = QueryBuilder()
    qb.add_like("name", "github")
    qb.add_equals("type", "basic_auth")
    qb.add_order_by("name", "")
    resp = client.query_table(
        "discovery_credentials",
        query=qb.build(),
        fields=["sys_id", "name", "type"],
        limit=50,
    )
    if not resp["success"] or not resp["result"]:
        return []
    return resp["result"]


def _resolve_github_credential(client, credential, credential_name_hint=None):
    """
    Resolve the GitHub credential sys_id for a VCS operation.

    Returns (sys_id, message) where:
      (sys_id, None)   — success, proceed silently
      (sys_id, str)    — success, prepend str to the tool response
      (None, str)      — halt, return str as the tool response

    Resolution order:
      1. Explicit credential param (name or sys_id)
      2. client.config.github_credential (from SERVICENOW_GITHUB_CREDENTIAL env var)
      3. credential_name_hint exact match (used by migrate to try source credential on target)
      4. Discovery: LIKE 'github' search in discovery_credentials
    """
    # Step 1: explicit param
    if credential is not None:
        sys_id, error = _resolve_credential_sys_id(client, credential)
        return (sys_id, None) if sys_id else (None, error)

    # Step 2: env var stored on InstanceConfig
    env_cred = getattr(client.config, "github_credential", None)
    if env_cred:
        sys_id, error = _resolve_credential_sys_id(client, env_cred)
        if sys_id:
            return sys_id, f"Using credential '{env_cred}' (from .env)"
        return None, error

    # Step 3: hint match (migrate passes source app's credential name)
    if credential_name_hint:
        sys_id, _ = _resolve_credential_sys_id(client, credential_name_hint)
        if sys_id:
            return sys_id, None
        # not found on target — fall through to discovery

    # Step 4: discovery
    found = _find_github_credentials(client)
    if len(found) == 1:
        cred = found[0]
        return cred["sys_id"], f"Using credential '{cred['name']}' (auto-discovered)."

    if len(found) > 1:
        lines = ["Multiple GitHub credentials found on this instance:"]
        for i, cred in enumerate(found, 1):
            lines.append(f"  {i}. {cred['name']} ({cred.get('type', 'unknown')})")
        lines.append("")
        lines.append('Reply with the credential name or number to use, or "new" to create one.')
        lines.append("To skip this prompt in future sessions, add to your .env:")
        lines.append(f"  SERVICENOW_GITHUB_CREDENTIAL={found[0]['name']}")
        return None, "\n".join(lines)

    return None, (
        _NO_GITHUB_CREDENTIALS_MSG + "\n"
        "Use create_github_credential to set one up. You will need:\n"
        "  • name     — display name (e.g. \"GitHub Token\")\n"
        "  • username — GitHub username or org machine account\n"
        "  • token    — Personal Access Token with repo scope"
    )


def _resolve_app(client, identifier: str) -> dict:
    """
    Resolve an app identifier (sys_id, scope, or name) to a sys_app record.

    Resolution order:
    1. 32-char hex string → exact sys_id match
    2. Starts with x_ or matches scope pattern → exact scope match
    3. Fuzzy name match (LIKE)

    Returns:
        dict with app fields on success
        {"error": str} if not found or multiple matches found
    """
    is_sys_id = bool(re.match(r'^[0-9a-f]{32}$', identifier, re.IGNORECASE))

    if is_sys_id:
        qb = QueryBuilder()
        qb.add_equals("sys_id", identifier)
        resp = client.query_table("sys_app", query=qb.build(),
                                  fields=["sys_id", "name", "scope", "version"], limit=1)
    else:
        is_scope = bool(re.match(r'^[a-z][a-z0-9]*(_[a-z0-9]+){2,}$', identifier))
        if is_scope:
            qb = QueryBuilder()
            qb.add_equals("scope", identifier)
            resp = client.query_table("sys_app", query=qb.build(),
                                      fields=["sys_id", "name", "scope", "version"], limit=2)
        else:
            qb = QueryBuilder()
            qb.add_like("name", identifier)
            resp = client.query_table("sys_app", query=qb.build(),
                                      fields=["sys_id", "name", "scope", "version"], limit=5)

    if not resp["success"]:
        return {"error": format_error(resp["status_code"], resp.get("error", ""))}

    results = resp["result"]
    if not results:
        return {
            "error": (
                f"No app found matching '{identifier}'. "
                "App names may contain spaces (e.g. 'Note Taker') — use the app scope "
                "(x_snc_...) or sys_id for reliable matching."
            )
        }

    if len(results) > 1 and not is_sys_id:
        matches = [f"  • {r['name']} (scope: {r.get('scope', 'n/a')}, sys_id: {r['sys_id']})"
                   for r in results]
        return {
            "error": (
                f"Multiple apps match '{identifier}'. Please re-specify using scope or sys_id:\n"
                + "\n".join(matches)
            )
        }

    return results[0]


def register_tools(mcp: MCPServer):

    @mcp.tool()
    def get_app_source_control_info(app: str, instance: str = None) -> str:
        """
        Get source control status for a ServiceNow app — current branch, linked GitHub
        repo URL, credential name, and list of uncommitted files.

        Returns synchronously (no async job needed — read-only operation).

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App scope (e.g. x_snc_update_all), sys_id, or display name.
                 **Prefer scope — name matching uses SQL LIKE and silently fails for
                 multi-word names or names shared across apps. If name matching returns
                 "No app found", fall back to query_table(table="sys_app",
                 query="nameCONTAINS<keyword>", fields="sys_id,name,scope") to
                 discover the scope, then re-call with the scope.**
            instance: ServiceNow instance alias (e.g. "prod", "dev"). Uses default if omitted.
        """
        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        app_name = app_record.get("name", app)

        app_info = _vcs_get_app(client, app_sys_id)
        if not app_info:
            return f"App '{app_name}' has no source control connection configured in Studio."

        repo_url = (app_info.get("repositoryURL") or app_info.get("repoUrl")
                    or app_info.get("url") or "unknown")
        branch = app_info.get("currentBranch") or app_info.get("branch") or "unknown"
        credential = (app_info.get("credentialName") or app_info.get("credential")
                      or _DEFAULT_CREDENTIAL_NAME)

        lines = [
            f"App: {app_name} ({app_record.get('scope', 'n/a')})",
            f"Repo: {repo_url}",
            f"Branch: {branch}",
            f"Credential: {credential}",
        ]

        uncommitted_raw = app_info.get("uncommittedFiles") or app_info.get("files") or []
        if isinstance(uncommitted_raw, str):
            uncommitted = [f.strip() for f in uncommitted_raw.split(",") if f.strip()]
        else:
            uncommitted = list(uncommitted_raw)

        if uncommitted:
            lines.append(f"Uncommitted files ({len(uncommitted)}):")
            for f in uncommitted:
                lines.append(f"  • {f}")
        else:
            lines.append("Uncommitted files: none")

        return "\n".join(lines)

    @mcp.tool()
    def get_source_control_operation_status(job_sys_id: str, instance: str = None) -> str:
        """
        Poll the status of an async source control operation (push, pull, commit, import, etc.).

        Call this after any write source control tool returns a job ID. Poll every
        10–30 seconds until state is "complete" or "failed".

        Uses GET /api/sn_devstudio/vcs/transactions/{transactionId}.

        Args:
            job_sys_id: The transaction/job ID returned by the triggering tool
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        client = get_client(instance)

        if not client._prepare_request():
            return "Authentication failed."

        url = f"{client.config.instance}{_VCS_BASE}/transactions/{job_sys_id}"
        try:
            resp = client.session.get(url, headers={"Accept": "application/json"})
        except Exception as exc:
            return f"Request failed: {exc}"

        if resp.status_code == 404:
            return f"Job '{job_sys_id}' not found."
        if resp.status_code != 200:
            return format_error(resp.status_code, resp.text[:300])

        try:
            data = resp.json()
        except Exception:
            return f"Job '{job_sys_id}': status response could not be parsed."

        if not isinstance(data, dict):
            data = {}

        _STATE_LABELS = {"0": "pending", "1": "running", "2": "successful", "3": "failed", "4": "cancelled"}
        raw_state = data.get("state")
        state = _STATE_LABELS.get(str(raw_state), str(raw_state)) if raw_state is not None else "unknown"

        detail = data.get("detailMessage") or data.get("errorMessage") or data.get("error_message") or ""
        percent = data.get("percentComplete") or data.get("percent_complete") or ""

        parts = [f"Job: {job_sys_id}", f"State: {state}"]
        if percent and str(percent) != "0":
            parts.append(f"Progress: {str(percent).rstrip('%')}%")
        if detail:
            parts.append(f"Detail: {detail}")

        return "\n".join(parts)

    @mcp.tool()
    def commit_app_changes(app: str, message: str, instance: str = None) -> str:
        """
        Commit and push the current state of a ServiceNow app's source files to GitHub.

        The sn_devstudio VCS API combines commit and push into a single operation —
        calling this will commit all in-platform changes and push them to the linked
        GitHub repo in one step. The operation is async — use
        get_source_control_operation_status to poll for completion.

        Scope and verification: before the call the tool sets the acting user's
        apps.current_app to the app, resets this instance's client session (the VCS
        endpoint follows the session's cached scope; a stale session makes a commit
        silently do nothing), makes the call on the fresh session, then restores the
        preference and reads it back. The commit is reported as confirmed only when the
        current branch's head (sys_repo_branch.object_id) changed; an unchanged head
        after a short wait is reported as an error ("NOT confirmed"); the commit is
        asynchronous and may still land, so re-read sys_repo_branch (or the remote head)
        before retrying: a retry may send a second commit job. If the baseline head could
        not be read the result says "triggered, not verified". If the preference had no
        prior row, the row this call created is deleted and read back as gone (the message
        says so, or says it was left set to the app if that failed). The client session is
        reset again afterwards so the next call does not reuse the app-scoped session.

        Fetches the app's outgoing changes first and passes them explicitly as
        changedRecords — omitting this (as earlier versions of this tool did) makes the
        underlying VCS endpoint commit zero files while still reporting success. If there
        are no outgoing changes, returns immediately without calling the commit endpoint.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            message: Commit message
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "commit app changes")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        repo_id = _vcs_repo_id(client, app_sys_id)

        changes = _vcs_get_outgoing_changes(client, app_sys_id)
        if not changes:
            return f"Nothing to commit for '{app_record['name']}' — no outgoing changes."

        return _commit_outcome(
            "Commit", app_record["name"], changes,
            _vcs_scoped_call(
                client, app_sys_id,
                lambda c: _vcs_call(c, "POST", f"apps/{app_sys_id}/repos/{repo_id}/commits", {
                    "commitMessage": message,
                    "commitMode": "",
                    "changedRecords": changes
                }),
                verify=_verify_head_changed(_current_heads(client, app_sys_id), app_sys_id)))

    @mcp.tool()
    def pull_app_from_github(app: str, instance: str = None) -> str:
        """
        Pull the latest changes from GitHub into a ServiceNow app's source files.

        Fetches and merges commits from the remote branch. If conflicts occur, the
        operation will fail — resolve conflicts in Studio, then retry. The operation
        is async — use get_source_control_operation_status to poll for completion.

        The call is made on a fresh session with apps.current_app set to the app (restored
        and read back afterwards). The pull itself is "triggered, not verified": there is
        no authoritative read-back here, so check the job status.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "pull app from GitHub")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        repo_id = _vcs_repo_id(client, app_sys_id)

        outcome = _vcs_scoped_call(
            client, app_sys_id,
            lambda c: _vcs_call(c, "POST", f"apps/{app_sys_id}/repos/{repo_id}/apply", {
                "preserveLocalChanges": False
            }))
        result = outcome["result"]

        if not result["success"]:
            return f"Pull failed: {result['error']}" + _pref_tail(outcome)

        job_id = result["job_id"]
        if job_id:
            return (f"Pull triggered for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.\n"
                    + _scoped_summary(outcome))
        return (f"Pull triggered for '{app_record['name']}'. No job ID returned — check syslog if issues occur.\n"
                + _scoped_summary(outcome))

    @mcp.tool()
    def switch_app_branch(app: str, branch: str, create: bool = False, instance: str = None) -> str:
        """
        Switch a ServiceNow app to a different existing source control branch (this tool does not create branches).

        Uncommitted changes on the current branch may be lost — use stash_app_changes or
        commit_app_changes first if needed. The operation is async — use
        get_source_control_operation_status to poll for completion.

        The branch must already exist on the remote: the `create` parameter is NOT sent
        to the platform, and switching to a missing branch is a silent no-op on the
        instance. The switch is verified from sys_repo_branch (the named branch must show
        is_current=true), not from get_app_source_control_info, which can lag or report
        the wrong branch. If sys_repo_branch does not confirm it, the message says
        "NOT confirmed" and the fix is to create the branch on GitHub, then retry. The
        call runs on a fresh session with apps.current_app set to the app (restored and
        read back afterwards).

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            branch: Target branch name to switch to (e.g. "main", "feature/my-feature")
            create: Currently ignored: not sent to the platform. Create the branch on GitHub first.
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "switch app branch")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        repo_id = _vcs_repo_id(client, app_sys_id)

        outcome = _vcs_scoped_call(
            client, app_sys_id,
            lambda c: _vcs_call(c, "PUT", f"apps/{app_sys_id}/repos/{repo_id}/branches/switch", {
                "branchName": branch
            }),
            verify=_verify_branch_current(branch, app_sys_id))
        result = outcome["result"]

        if not result["success"]:
            return f"Branch switch failed: {result['error']}" + _pref_tail(outcome)

        job_id = result["job_id"]
        job = (f"\nJob: {job_id}\nUse get_source_control_operation_status to poll for completion."
               if job_id else "")
        if outcome["verified"] is False:
            return (f"Branch switch NOT confirmed for '{app_record['name']}' → '{branch}': {outcome['detail']}. "
                    f"A branch that does not exist on the remote is a silent no-op "
                    f"(this tool does not create branches). Create it on GitHub, then retry."
                    + job + _pref_tail(outcome))
        return (f"Branch switch sent for '{app_record['name']}' → '{branch}'." + job + "\n"
                + _scoped_summary(outcome))

    @mcp.tool()
    def push_app_to_github(app: str, instance: str = None) -> str:
        """
        Push committed changes for a ServiceNow app to its linked GitHub repository.

        Note: The sn_devstudio VCS API combines commit and push into a single operation.
        This tool commits any uncommitted changes with a generic message and pushes to
        GitHub. If you want to provide a specific commit message, use commit_app_changes
        instead (which also commits and pushes in one step).

        Scope and verification are the same as commit_app_changes: apps.current_app is
        set, the client session is reset, the call is made on the fresh session, and the
        push is confirmed only when the current branch head (sys_repo_branch.object_id)
        changed; an unchanged head is reported as an error ("NOT confirmed"), but the
        push is asynchronous and may still land, so re-read sys_repo_branch (or the
        remote head) before retrying: a retry may send a second job.

        Fetches the app's outgoing changes first and passes them explicitly as
        changedRecords — omitting this (as earlier versions of this tool did) makes the
        underlying VCS endpoint commit zero files while still reporting success. If there
        are no outgoing changes, returns immediately without calling the commit endpoint.

        The operation is async — use get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "push app to GitHub")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        repo_id = _vcs_repo_id(client, app_sys_id)

        changes = _vcs_get_outgoing_changes(client, app_sys_id)
        if not changes:
            return f"Nothing to push for '{app_record['name']}' — no outgoing changes."

        return _commit_outcome(
            "Push", app_record["name"], changes,
            _vcs_scoped_call(
                client, app_sys_id,
                lambda c: _vcs_call(c, "POST", f"apps/{app_sys_id}/repos/{repo_id}/commits", {
                    "commitMessage": "Push via ServiceNow MCP",
                    "commitMode": "",
                    "changedRecords": changes
                }),
                verify=_verify_head_changed(_current_heads(client, app_sys_id), app_sys_id)))

    @mcp.tool()
    def stash_app_changes(app: str, action: str = "stash", instance: str = None) -> str:
        """
        Stash or apply stashed changes for a ServiceNow app's source control working tree.

        Use "stash" to temporarily save uncommitted changes before switching branches.
        Use "apply" to restore previously stashed changes.

        The operation is async — use get_source_control_operation_status to poll for completion.
        Runs on a fresh session with apps.current_app set to the app (restored and read back
        afterwards). The stash itself is "triggered, not verified": no authoritative read-back.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            action: "stash" to save changes, "apply" to restore stashed changes (default: "stash")
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        if action not in ("stash", "apply"):
            return "Invalid action. Use 'stash' to save changes or 'apply' to restore stashed changes."

        confirmation_error = require_instance_confirmation(instance, f"{action} app changes")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        repo_id = _vcs_repo_id(client, app_sys_id)

        stash_path = "stash" if action == "stash" else "stash/apply"
        label = "Stash" if action == "stash" else "Stash apply"
        outcome = _vcs_scoped_call(
            client, app_sys_id,
            lambda c: _vcs_call(c, "POST", f"apps/{app_sys_id}/repos/{repo_id}/{stash_path}", {}))
        result = outcome["result"]

        if not result["success"]:
            return (f"Stash {action} failed: {result['error']}\n"
                    f"If this persists, use Studio directly to manage stashed changes."
                    + _pref_tail(outcome))

        job_id = result["job_id"]
        if job_id:
            return (f"{label} triggered for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.\n"
                    + _scoped_summary(outcome))
        return (f"{label} triggered for '{app_record['name']}'. Check syslog if issues occur.\n"
                + _scoped_summary(outcome))

    @mcp.tool()
    def import_app_from_github(
        repo_url: str,
        branch: str = "main",
        credential: str = None,
        instance: str = None
    ) -> str:
        """
        Import a ServiceNow app from a GitHub repository URL.

        Idempotent: if an app linked to this repo URL already exists on the instance,
        pulls the latest changes instead of re-importing. A fresh import installs the
        app from source control into the instance.

        The operation is async — use get_source_control_operation_status to poll for completion.
        The client session is reset before the call. The import/pull is "triggered, not
        verified" (no authoritative read-back); a fresh import has no app yet, so no scope
        preference is set for it.

        Args:
            repo_url: GitHub repository URL (e.g. https://github.com/org/repo)
            branch: Branch to import from (default: "main")
            credential: Name of the credential record to use (default: auto-discovered)
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "import app from GitHub")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        credential_sys_id, cred_message = _resolve_github_credential(client, credential)
        if credential_sys_id is None:
            return cred_message
        response_prefix = (cred_message + "\n") if cred_message else ""

        existing = _find_app_by_repo_url(client, repo_url)

        if existing:
            app_sys_id = existing["sys_id"]
            repo_id = _vcs_repo_id(client, app_sys_id)
            outcome = _vcs_scoped_call(
                client, app_sys_id,
                lambda c: _vcs_call(c, "POST", f"apps/{app_sys_id}/repos/{repo_id}/apply", {
                    "preserveLocalChanges": False
                }))
            result = outcome["result"]
            if not result["success"]:
                return (response_prefix + f"App already installed ('{existing['name']}') but pull failed: "
                        f"{result['error']}" + _pref_tail(outcome))
            job_id = result["job_id"]
            msg = (f"App '{existing['name']}' ({existing.get('scope', 'n/a')}) already exists on this instance.\n"
                   f"Pulling latest from {repo_url} (branch: {branch}) instead of re-importing.")
            if job_id:
                msg += f"\nJob: {job_id}\nUse get_source_control_operation_status to poll for completion."
            return response_prefix + msg + "\n" + _scoped_summary(outcome)

        # No app exists yet, so there is no scope to state: the session is still reset.
        outcome = _vcs_scoped_call(
            client, None,
            lambda c: _vcs_call(c, "POST", "apps", {
                "url": repo_url,
                "branch": branch,
                "credential": credential_sys_id
            }))
        result = outcome["result"]

        if not result["success"]:
            return response_prefix + f"Import failed: {result['error']}"

        job_id = result["job_id"]
        msg = f"Import triggered from {repo_url} (branch: {branch}, credential: {credential or 'discovered'})."
        if job_id:
            msg += f"\nJob: {job_id}\nUse get_source_control_operation_status to poll for completion."
        else:
            msg += ("\nNo job ID returned — the import likely completed synchronously. "
                    "Use get_app_source_control_info to verify the app is linked.")
        return response_prefix + msg + "\n" + _scoped_summary(outcome)

    @mcp.tool()
    def migrate_app_via_source_control(
        app: str,
        source_instance: str,
        target_instance: str,
        branch: str = None,
        credential: str = None
    ) -> str:
        """
        Migrate a ServiceNow app from one instance to another via its GitHub source control link.

        Phase 1 (always runs): Resolves the app on the source instance and checks for
        uncommitted changes. If no uncommitted changes exist, proceeds to Phase 2 automatically.
        If uncommitted changes are found, returns a prominent WARNING and two options:

          Option A — Migrate committed state: Pull from source control as-is to the target.
                     Uncommitted changes on source will NOT be included.
          Option B — Commit then migrate: Commit and push source instance changes first,
                     then import to target. All current changes will be migrated.

        To execute Option A: call import_app_from_github on the target instance using the
          repo URL shown in the warning output.
        To execute Option B: call commit_app_changes on the source instance first, wait for
          completion, then call import_app_from_github on the target instance.

        The target-instance import/pull resets the TARGET instance's client session and is
        "triggered, not verified" (no authoritative read-back); poll the job on the target.

        GitHub credential resolution for the target instance:
          1. credential param (if provided)
          2. SERVICENOW_GITHUB_CREDENTIAL_<TARGET> env var
          3. SERVICENOW_GITHUB_CREDENTIAL global env var
          4. Same credential name used by the app on the source instance (exact match on target)
          5. Discovery: search discovery_credentials for names containing 'github'
          6. Nothing found: prompts with pre-filled name and username from the source instance

        Args:
            app: App name, scope, or sys_id (looked up on source_instance)
            source_instance: Instance alias to migrate from (e.g. "dev")
            target_instance: Instance alias to migrate to (e.g. "prod")
            branch: Branch to migrate (defaults to current branch on source)
            credential: Credential name on target instance (default: auto-discovered)
        """
        confirmation_error = require_instance_confirmation(target_instance, "migrate app to target instance")
        if confirmation_error:
            return confirmation_error

        source_client = get_client(source_instance)
        target_client = get_client(target_instance)

        app_record = _resolve_app(source_client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        app_name = app_record.get("name", app)

        app_info = _vcs_get_app(source_client, app_sys_id)
        if not app_info:
            # VCS REST API failed — try server-side sn_vcs.AppSourceControl as fallback
            fallback_url = _get_app_repo_url_via_script(source_client, app_sys_id)
            if fallback_url:
                app_info = {"url": fallback_url}
            else:
                return (
                    f"App '{app_name}' has no source control connection configured on {source_instance}. "
                    f"Verify in Studio > Source Control that a repository is linked."
                )

        repo_url = (app_info.get("repositoryURL") or app_info.get("repoUrl")
                    or app_info.get("url") or "")
        if not repo_url:
            return f"App '{app_name}' has no repository URL configured on {source_instance}."

        current_branch = branch or app_info.get("currentBranch") or app_info.get("branch") or "main"
        source_credential_name = (app_info.get("credentialName") or app_info.get("credential") or None)
        if isinstance(source_credential_name, dict):
            source_credential_name = (source_credential_name.get("display_value")
                                      or source_credential_name.get("value") or None)

        uncommitted_raw = app_info.get("uncommittedFiles") or app_info.get("files") or []
        if isinstance(uncommitted_raw, str):
            uncommitted_files = [f.strip() for f in uncommitted_raw.split(",") if f.strip()]
        else:
            uncommitted_files = list(uncommitted_raw)

        if uncommitted_files:
            file_list = "\n".join(f"  • {f}" for f in uncommitted_files)
            cred_display = credential or source_credential_name or "GitHub Token"
            return (
                f"WARNING: Uncommitted changes found on {source_instance}\n"
                f"App: {app_name} ({app_record.get('scope', 'n/a')})\n"
                f"Repo: {repo_url}\n"
                f"Branch: {current_branch}\n\n"
                f"Uncommitted files ({len(uncommitted_files)}):\n{file_list}\n\n"
                f"Choose how to proceed:\n\n"
                f"Option A — Migrate committed state:\n"
                f"  Call import_app_from_github on '{target_instance}' with:\n"
                f"    repo_url=\"{repo_url}\", branch=\"{current_branch}\", "
                f"credential=\"{cred_display}\", instance=\"{target_instance}\"\n"
                f"  Uncommitted changes on {source_instance} will NOT be included.\n\n"
                f"Option B — Commit then migrate (includes all current changes):\n"
                f"  1. Call commit_app_changes: app=\"{app}\", message=\"...\", instance=\"{source_instance}\"\n"
                f"  2. Wait for the commit job to complete.\n"
                f"  3. Call import_app_from_github on '{target_instance}' with:\n"
                f"     repo_url=\"{repo_url}\", branch=\"{current_branch}\", "
                f"credential=\"{cred_display}\", instance=\"{target_instance}\""
            )

        # Resolve credential on target using source credential name as a hint
        credential_sys_id, cred_message = _resolve_github_credential(
            target_client, credential, credential_name_hint=source_credential_name
        )
        if credential_sys_id is None:
            # If nothing found and we have source credential info, build pre-filled prompt
            if source_credential_name and _NO_GITHUB_CREDENTIALS_MSG in (cred_message or ""):
                qb = QueryBuilder()
                qb.add_equals("name", source_credential_name)
                cred_resp = source_client.query_table(
                    "discovery_credentials", query=qb.build(),
                    fields=["user_name"], limit=1
                )
                source_username = ""
                if cred_resp.get("success") and cred_resp.get("result"):
                    source_username = cred_resp["result"][0].get("user_name", "")
                if source_username:
                    return (
                        f"Target instance '{target_instance}' has no GitHub credential.\n"
                        f"Found credential '{source_credential_name}' (username: '{source_username}') "
                        f"on {source_instance}.\n"
                        f"Provide the token to create a matching record on '{target_instance}':\n"
                        f"  create_github_credential(name=\"{source_credential_name}\", "
                        f"username=\"{source_username}\", token=\"...\", instance=\"{target_instance}\")"
                    )
            return cred_message

        response_prefix = (cred_message + "\n") if cred_message else ""

        existing = _find_app_by_repo_url(target_client, repo_url)

        if existing:
            target_app_id = existing["sys_id"]
            target_repo_id = _vcs_repo_id(target_client, target_app_id)
            # The wrapper resets target_client's own alias (the target instance), not the source's.
            outcome = _vcs_scoped_call(
                target_client, target_app_id,
                lambda c: _vcs_call(c, "POST",
                                    f"apps/{target_app_id}/repos/{target_repo_id}/apply",
                                    {"preserveLocalChanges": False}))
            prefix = (f"App '{app_name}' already exists on {target_instance}. "
                      f"Pulling latest from {repo_url}.\n")
        else:
            outcome = _vcs_scoped_call(
                target_client, None,
                lambda c: _vcs_call(c, "POST", "apps", {
                    "url": repo_url,
                    "branch": current_branch,
                    "credential": credential_sys_id
                }))
            prefix = f"Migrating '{app_name}' from {source_instance} → {target_instance}.\n"
        result = outcome["result"]

        if not result["success"]:
            return response_prefix + prefix + f"Failed: {result['error']}" + _pref_tail(outcome)

        job_id = result["job_id"]
        msg = response_prefix + prefix + f"Repo: {repo_url} (branch: {current_branch})"
        if job_id:
            msg += (f"\nJob: {job_id} (on {target_instance})\n"
                    f"Use get_source_control_operation_status to poll for completion "
                    f"(specify instance=\"{target_instance}\").")
        return msg + "\n" + _scoped_summary(outcome)

    @mcp.tool()
    def create_github_credential(
        name: str,
        username: str,
        token: str,
        instance: str = None,
    ) -> str:
        """
        Create a GitHub Basic Auth credential in ServiceNow's discovery_credentials table.

        Use this when import_app_from_github or migrate_app_via_source_control reports
        no GitHub credentials found on the instance. After creation, the credential
        is immediately available for source control operations.

        To skip the discovery prompt in future sessions, add to your .env after creation:
          SERVICENOW_GITHUB_CREDENTIAL=<name>          (all instances)
          SERVICENOW_GITHUB_CREDENTIAL_<INSTANCE>=<name>  (per-instance override)

        Args:
            name: Display name for the credential (e.g. "GitHub Token")
            username: GitHub username or org machine account
            token: GitHub Personal Access Token with repo scope
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "create GitHub credential")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        result = client.create_record("discovery_credentials", {
            "name": name,
            "type": "basic_auth",
            "user_name": username,
            "password": token,
        }, unscoped_ok="discovery_credentials has no sys_scope column (audit S6): "
                       "GitHub credential record")

        if not result["success"]:
            return format_error(result["status_code"], result.get("error", ""))

        record = result.get("result") or {}
        sys_id = record.get("sys_id", "unknown") if isinstance(record, dict) else "unknown"
        return (
            f"GitHub credential '{name}' created (sys_id: {sys_id}).\n"
            f"To use it by default, add to your .env:\n"
            f"  SERVICENOW_GITHUB_CREDENTIAL={name}"
        )
