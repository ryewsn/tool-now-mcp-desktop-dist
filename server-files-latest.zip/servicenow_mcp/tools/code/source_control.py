"""GitHub Source Control Tools"""

import json
import re
from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation  # used by tools added in subsequent tasks
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

_DEFAULT_CREDENTIAL_NAME = "GitHub Token"

# Table names — verified during Task 0 discovery.
# Update these constants if Task 0 finds different names.
_SC_OPERATION_LOG_TABLE = "sn_appclient_progress_log"  # verify in Task 0
# Update table name from Task 0 discovery
_SC_APP_CONFIG_TABLE = "sys_app"  # or the discovered related table name


# REST endpoint base path for sn_appclient source control operations.
# *** UPDATE FROM TASK 0 if the actual path differs ***
_SC_REST_BASE = "/api/sn_appclient/source_control"

# GlideScript template for execute_script fallback.
# *** UPDATE SCRIPT_INCLUDE AND METHOD NAMES FROM TASK 0 DISCOVERY ***
_SC_SCRIPT_TEMPLATE = """
var sc = new sn_appclient.{SCRIPT_INCLUDE}();
var result = sc.{METHOD}('{app_id}', {extra_args});
gs.info(JSON.stringify(result));
"""

# Map of operation name → (REST path suffix, GlideScript method name)
# *** UPDATE method names from Task 0 discovery ***
_SC_OPERATIONS = {
    "push":    ("push",    "push"),
    "pull":    ("pull",    "pull"),
    "commit":  ("commit",  "commitFiles"),
    "switch":  ("switch",  "switchBranch"),
    "stash":   ("stash",   "stashChanges"),
    "unstash": ("unstash", "applyStash"),
    "import":  ("import",  "importApp"),
}


def _trigger_sc_operation(client, operation: str, params: dict) -> dict:
    """
    Trigger a source control operation. REST-first, execute_script fallback.

    Returns dict: {"success": bool, "job_id": str | None, "error": str | None}
    """
    if operation not in _SC_OPERATIONS:
        return {"success": False, "job_id": None, "error": f"Unknown operation: {operation}"}

    rest_suffix, script_method = _SC_OPERATIONS[operation]

    if not client._prepare_request():
        return {"success": False, "job_id": None, "error": "Authentication failed."}

    # --- Attempt REST endpoint ---
    rest_url = f"{client.config.instance}{_SC_REST_BASE}/{rest_suffix}"
    rest_resp = None
    try:
        rest_resp = client.session.post(
            rest_url,
            json=params,
            headers={"Content-Type": "application/json", "Accept": "application/json"}
        )
        if rest_resp.status_code in (200, 201):
            data = rest_resp.json().get("result", {})
            job_id = data.get("job_id") or data.get("sys_id") or data.get("progressId")
            return {"success": True, "job_id": job_id, "error": None}
    except Exception:
        pass  # fall through to execute_script

    if rest_resp is not None and rest_resp.status_code not in (404, 405):
        return {"success": False, "job_id": None,
                "error": format_error(rest_resp.status_code, rest_resp.text[:300])}

    # --- Fallback: execute_script ---
    app_id = params.get("app_id", "")

    # Validate app_id to prevent GlideScript injection — allow only alphanumeric, underscore, hyphen
    if app_id and not re.match(r'^[0-9a-zA-Z_-]+$', app_id):
        return {"success": False, "job_id": None, "error": f"app_id contains invalid characters: {app_id!r}"}

    extra = params.get("extra_args", "{}")
    script = _SC_SCRIPT_TEMPLATE.format(
        SCRIPT_INCLUDE="SCUtil",   # *** update from Task 0 ***
        METHOD=script_method,
        app_id=app_id,
        extra_args=extra
    )

    foundry_url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
    try:
        script_resp = client.session.post(foundry_url, json={"script": script, "timeout_ms": 90000})
    except Exception as e:
        return {"success": False, "job_id": None, "error": str(e)}

    if script_resp.status_code == 400 and "does not represent any resource" in script_resp.text:
        return {"success": False, "job_id": None,
                "error": "Script execution requires the Foundry Script Runner. Use setup_script_runner to install it."}

    if script_resp.status_code not in (200, 201):
        return {"success": False, "job_id": None,
                "error": format_error(script_resp.status_code, script_resp.text[:300])}

    result = script_resp.json().get("result", {})
    output_lines = result.get("output", [])
    error = result.get("error")

    if error:
        return {"success": False, "job_id": None, "error": error}

    if result.get("timed_out"):
        return {"success": False, "job_id": None, "error": "Script execution timed out after 90s."}

    for line in output_lines:
        msg = line.get("message", "")
        try:
            parsed = json.loads(msg)
            job_id = parsed.get("job_id") or parsed.get("sys_id") or parsed.get("progressId")
            if job_id:
                return {"success": True, "job_id": job_id, "error": None}
        except Exception:
            continue

    return {"success": True, "job_id": None, "error": "Operation dispatched but no job_id returned — check progress in syslog."}


def _resolve_app(client, identifier: str) -> dict:
    """
    Resolve an app identifier (sys_id, scope, or name) to a sys_app record.

    Resolution order:
    1. 32-char hex string → exact sys_id match
    2. Starts with x_ or matches scope pattern → exact scope match
    3. Fuzzy name match (LIKE)

    Returns:
        dict with app fields on success
        {"error": str} if not found or multiple matches found
    """
    is_sys_id = bool(re.match(r'^[0-9a-f]{32}$', identifier, re.IGNORECASE))

    if is_sys_id:
        qb = QueryBuilder()
        qb.add_equals("sys_id", identifier)
        resp = client.query_table("sys_app", query=qb.build(),
                                  fields=["sys_id", "name", "scope", "version"], limit=1)
    else:
        is_scope = bool(re.match(r'^[a-z][a-z0-9]*(_[a-z0-9]+){2,}$', identifier))
        if is_scope:
            qb = QueryBuilder()
            qb.add_equals("scope", identifier)
            resp = client.query_table("sys_app", query=qb.build(),
                                      fields=["sys_id", "name", "scope", "version"], limit=2)
        else:
            qb = QueryBuilder()
            qb.add_like("name", identifier)
            resp = client.query_table("sys_app", query=qb.build(),
                                      fields=["sys_id", "name", "scope", "version"], limit=5)

    if not resp["success"]:
        return {"error": format_error(resp["status_code"], resp.get("error", ""))}

    results = resp["result"]
    if not results:
        return {"error": f"No app found matching '{identifier}'. Try scope (x_snc_...) or exact name."}

    if len(results) > 1 and not is_sys_id:
        matches = [f"  • {r['name']} (scope: {r.get('scope', 'n/a')}, sys_id: {r['sys_id']})"
                   for r in results]
        return {
            "error": (
                f"Multiple apps match '{identifier}'. Please re-specify using scope or sys_id:\n"
                + "\n".join(matches)
            )
        }

    return results[0]


def register_tools(mcp: FastMCP):

    @mcp.tool()
    def get_app_source_control_info(app: str, instance: str = None) -> str:
        """
        Get source control status for a ServiceNow app — current branch, linked GitHub
        repo URL, credential name, and list of uncommitted files.

        Returns synchronously (no async job needed — read-only operation).

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope (e.g. x_snc_myapp), or sys_id
            instance: ServiceNow instance alias (e.g. "prod", "dev"). Uses default if omitted.
        """
        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        app_name = app_record.get("name", app)

        # Query source control configuration for this app.
        # Field names confirmed in Task 0 — update _SC_APP_CONFIG_TABLE and field refs if needed.
        qb = QueryBuilder()
        qb.add_equals("app", app_sys_id)
        sc_resp = client.query_table(
            _SC_APP_CONFIG_TABLE,
            query=qb.build(),
            fields=["repo_url", "branch", "credential", "uncommitted_files"],
            limit=1,
            display_value="all"
        )

        if not sc_resp["success"]:
            return format_error(sc_resp["status_code"], sc_resp.get("error", ""))

        if not sc_resp["result"]:
            return f"App '{app_name}' has no source control connection configured in Studio."

        cfg = sc_resp["result"][0]
        repo_url_raw = cfg.get("repo_url", "unknown")
        repo_url = repo_url_raw.get("value", "unknown") if isinstance(repo_url_raw, dict) else (repo_url_raw or "unknown")
        branch_raw = cfg.get("branch", "unknown")
        branch = branch_raw.get("value", "unknown") if isinstance(branch_raw, dict) else (branch_raw or "unknown")
        credential_raw = cfg.get("credential", {}) or {}
        credential = credential_raw.get("display_value", _DEFAULT_CREDENTIAL_NAME) if isinstance(credential_raw, dict) else str(credential_raw)
        uncommitted_raw = cfg.get("uncommitted_files", "")
        if isinstance(uncommitted_raw, dict):
            uncommitted = uncommitted_raw.get("value", "")
        else:
            uncommitted = uncommitted_raw or ""

        lines = [
            f"App: {app_name} ({app_record.get('scope', 'n/a')})",
            f"Repo: {repo_url}",
            f"Branch: {branch}",
            f"Credential: {credential}",
        ]
        if uncommitted:
            file_list = uncommitted.split(",") if isinstance(uncommitted, str) else uncommitted
            lines.append(f"Uncommitted files ({len(file_list)}):")
            for f in file_list:
                lines.append(f"  • {f.strip()}")
        else:
            lines.append("Uncommitted files: none")

        return "\n".join(lines)

    @mcp.tool()
    def get_source_control_operation_status(job_sys_id: str, instance: str = None) -> str:
        """
        Poll the status of an async source control operation (push, pull, commit, import, etc.).

        Call this after any write source control tool returns a job sys_id. Poll every
        10–30 seconds until state is "complete" or "failed".

        Args:
            job_sys_id: The operation job sys_id returned by the triggering tool
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        client = get_client(instance)
        resp = client.get_record(_SC_OPERATION_LOG_TABLE, job_sys_id)

        if not resp["success"]:
            if resp["status_code"] == 404:
                return f"Job '{job_sys_id}' not found in {_SC_OPERATION_LOG_TABLE}."
            return format_error(resp["status_code"], resp.get("error", ""))

        record = resp["result"]
        # Field names confirmed from Task 0 — update if different
        state = record.get("state") or record.get("status") or "unknown"
        error_msg = record.get("error_message") or record.get("error") or ""
        percent = record.get("percent_complete") or record.get("progress") or ""

        parts = [f"Job: {job_sys_id}", f"State: {state}"]
        if percent:
            parts.append(f"Progress: {str(percent).rstrip('%')}%")
        if error_msg:
            parts.append(f"Error: {error_msg}")

        return "\n".join(parts)

    @mcp.tool()
    def commit_app_changes(app: str, message: str, instance: str = None) -> str:
        """
        Create a git commit of the current state of a ServiceNow app's source files.

        This captures all in-platform changes and creates a commit in the linked GitHub repo.
        The operation is async — use get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            message: Commit message
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "commit app changes")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        result = _trigger_sc_operation(client, "commit", {
            "app_id": app_record["sys_id"],
            "extra_args": f'"{message}"'
        })

        if not result["success"]:
            return f"Commit failed: {result['error']}"

        job_id = result["job_id"]
        if job_id:
            return (f"Commit triggered for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.")
        return f"Commit triggered for '{app_record['name']}'. No job ID returned — check syslog if issues occur."

    @mcp.tool()
    def pull_app_from_github(app: str, instance: str = None) -> str:
        """
        Pull the latest changes from GitHub into a ServiceNow app's source files.

        Fetches and merges commits from the remote branch. If conflicts occur, the
        operation will fail — resolve conflicts in Studio, then retry. The operation
        is async — use get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "pull app from GitHub")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        result = _trigger_sc_operation(client, "pull", {"app_id": app_record["sys_id"]})

        if not result["success"]:
            return f"Pull failed: {result['error']}"

        job_id = result["job_id"]
        if job_id:
            return (f"Pull triggered for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.")
        return f"Pull triggered for '{app_record['name']}'. No job ID returned — check syslog if issues occur."

    @mcp.tool()
    def switch_app_branch(app: str, branch: str, create: bool = False, instance: str = None) -> str:
        """
        Switch a ServiceNow app to a different source control branch, or create a new branch.

        Uncommitted changes on the current branch may be lost — use stash_app_changes or
        commit_app_changes first if needed. The operation is async — use
        get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            branch: Target branch name to switch to (e.g. "main", "feature/my-feature")
            create: Set to true to create the branch if it doesn't exist (default: false)
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "switch app branch")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        result = _trigger_sc_operation(client, "switch", {
            "app_id": app_record["sys_id"],
            "extra_args": f'"{branch}", {str(create).lower()}'
        })

        if not result["success"]:
            return f"Branch switch failed: {result['error']}"

        job_id = result["job_id"]
        action = "created and switched" if create else "switched"
        if job_id:
            return (f"Branch {action} to '{branch}' for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.")
        return f"Branch switch triggered for '{app_record['name']}' → '{branch}'. Check syslog if issues occur."

    @mcp.tool()
    def push_app_to_github(app: str, instance: str = None) -> str:
        """
        Push committed changes for a ServiceNow app to its linked GitHub repository.

        The app must have committed changes ready to push. Use commit_app_changes first
        if you have uncommitted changes. The operation is async — use
        get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "push app to GitHub")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        result = _trigger_sc_operation(client, "push", {"app_id": app_record["sys_id"]})

        if not result["success"]:
            return f"Push failed: {result['error']}"

        job_id = result["job_id"]
        if job_id:
            return (f"Push triggered for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.")
        return f"Push triggered for '{app_record['name']}'. No job ID returned."

    @mcp.tool()
    def stash_app_changes(app: str, action: str = "stash", instance: str = None) -> str:
        """
        Stash or apply stashed changes for a ServiceNow app's source control working tree.

        Use "stash" to temporarily save uncommitted changes before switching branches.
        Use "apply" to restore previously stashed changes.

        The operation is async — use get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            action: "stash" to save changes, "apply" to restore stashed changes (default: "stash")
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        if action not in ("stash", "apply"):
            return "Invalid action. Use 'stash' to save changes or 'apply' to restore stashed changes."

        confirmation_error = require_instance_confirmation(instance, f"{action} app changes")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        operation = "stash" if action == "stash" else "unstash"
        result = _trigger_sc_operation(client, operation, {"app_id": app_record["sys_id"]})

        if not result["success"]:
            return f"Stash {action} failed: {result['error']}"

        job_id = result["job_id"]
        verb = "stashed" if action == "stash" else "applied"
        if job_id:
            return (f"Changes {verb} for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.")
        return f"Stash {action} triggered for '{app_record['name']}'. Check syslog if issues occur."

    @mcp.tool()
    def import_app_from_github(
        repo_url: str,
        branch: str = "main",
        credential: str = None,
        instance: str = None
    ) -> str:
        """
        Import a ServiceNow app from a GitHub repository URL.

        Idempotent: if an app linked to this repo URL already exists on the instance,
        pulls the latest changes instead of re-importing. A fresh import installs the
        app from source control into the instance.

        The operation is async — use get_source_control_operation_status to poll for completion.

        Args:
            repo_url: GitHub repository URL (e.g. https://github.com/org/repo)
            branch: Branch to import from (default: "main")
            credential: Name of the sys_repo_credential record to use
                        (default: "GitHub Token")
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "import app from GitHub")
        if confirmation_error:
            return confirmation_error

        credential_name = credential or _DEFAULT_CREDENTIAL_NAME
        client = get_client(instance)

        # Idempotency check: look for an existing app linked to this repo URL.
        # Field name for repo URL on sys_app confirmed in Task 0 — update if needed.
        qb = QueryBuilder()
        qb.add_equals("source_control_url", repo_url)
        existing_resp = client.query_table(
            "sys_app",
            query=qb.build(),
            fields=["sys_id", "name", "scope"],
            limit=1
        )

        if existing_resp["success"] and existing_resp["result"]:
            existing = existing_resp["result"][0]
            # App already installed — pull latest instead
            result = _trigger_sc_operation(client, "pull", {"app_id": existing["sys_id"]})
            if not result["success"]:
                return f"App already installed ('{existing['name']}') but pull failed: {result['error']}"
            job_id = result["job_id"]
            msg = (f"App '{existing['name']}' ({existing.get('scope', 'n/a')}) already exists on this instance.\n"
                   f"Pulling latest from {repo_url} (branch: {branch}) instead of re-importing.")
            if job_id:
                msg += f"\nJob: {job_id}\nUse get_source_control_operation_status to poll for completion."
            return msg

        # Fresh import
        result = _trigger_sc_operation(client, "import", {
            "app_id": "",
            "extra_args": f'"{repo_url}", "{branch}", "{credential_name}"'
        })

        if not result["success"]:
            return f"Import failed: {result['error']}"

        job_id = result["job_id"]
        msg = f"Import triggered from {repo_url} (branch: {branch}, credential: {credential_name})."
        if job_id:
            msg += f"\nJob: {job_id}\nUse get_source_control_operation_status to poll for completion."
        return msg

    @mcp.tool()
    def migrate_app_via_source_control(
        app: str,
        source_instance: str,
        target_instance: str,
        branch: str = None,
        credential: str = None
    ) -> str:
        """
        Migrate a ServiceNow app from one instance to another via its GitHub source control link.

        Phase 1 (always runs): Resolves the app on the source instance and checks for
        uncommitted changes. If no uncommitted changes exist, proceeds to Phase 2 automatically.
        If uncommitted changes are found, returns a prominent WARNING and two options:

          Option A — Migrate committed state: Pull from source control as-is to the target.
                     Uncommitted changes on source will NOT be included.
          Option B — Push then migrate: Push source instance to GitHub first, then pull to target.
                     All current changes will be migrated.

        To execute Option A: call import_app_from_github on the target instance using the
          repo URL shown in the warning output.
        To execute Option B: call push_app_to_github on the source instance first, wait for
          completion, then call import_app_from_github on the target instance.

        Args:
            app: App name, scope, or sys_id (looked up on source_instance)
            source_instance: Instance alias to migrate from (e.g. "dev")
            target_instance: Instance alias to migrate to (e.g. "prod")
            branch: Branch to migrate (defaults to current branch on source)
            credential: Credential name on target instance (default: "GitHub Token")
        """
        confirmation_error = require_instance_confirmation(target_instance, "migrate app to target instance")
        if confirmation_error:
            return confirmation_error

        credential_name = credential or _DEFAULT_CREDENTIAL_NAME
        source_client = get_client(source_instance)

        # --- Phase 1: Pre-flight check ---
        app_record = _resolve_app(source_client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        app_name = app_record.get("name", app)

        # Get source control info from source instance
        qb = QueryBuilder()
        qb.add_equals("app", app_sys_id)
        sc_resp = source_client.query_table(
            _SC_APP_CONFIG_TABLE,
            query=qb.build(),
            fields=["repo_url", "branch", "credential", "uncommitted_files"],
            limit=1,
            display_value="all"
        )

        if not sc_resp["success"]:
            return format_error(sc_resp["status_code"], sc_resp.get("error", ""))

        if not sc_resp["result"]:
            return f"App '{app_name}' has no source control connection configured on {source_instance}."

        cfg = sc_resp["result"][0]
        repo_url = cfg["repo_url"] if isinstance(cfg.get("repo_url"), str) else (cfg.get("repo_url") or {}).get("value", "")
        current_branch = branch or (cfg["branch"] if isinstance(cfg.get("branch"), str) else (cfg.get("branch") or {}).get("value", "main"))
        uncommitted_raw = cfg["uncommitted_files"] if isinstance(cfg.get("uncommitted_files"), str) else (cfg.get("uncommitted_files") or {}).get("value", "")

        uncommitted_files = [f.strip() for f in uncommitted_raw.split(",") if f.strip()] if uncommitted_raw else []

        if uncommitted_files:
            # --- Phase 1 result: WARN and present options ---
            file_list = "\n".join(f"  • {f}" for f in uncommitted_files)
            return (
                f"WARNING: Uncommitted changes found on {source_instance}\n"
                f"App: {app_name} ({app_record.get('scope', 'n/a')})\n"
                f"Repo: {repo_url}\n"
                f"Branch: {current_branch}\n\n"
                f"Uncommitted files ({len(uncommitted_files)}):\n{file_list}\n\n"
                f"Choose how to proceed:\n\n"
                f"Option A — Migrate committed state:\n"
                f"  Call import_app_from_github on '{target_instance}' with:\n"
                f"    repo_url=\"{repo_url}\", branch=\"{current_branch}\", "
                f"credential=\"{credential_name}\", instance=\"{target_instance}\"\n"
                f"  Uncommitted changes on {source_instance} will NOT be included.\n\n"
                f"Option B — Push then migrate (includes all current changes):\n"
                f"  1. Call push_app_to_github: app=\"{app}\", instance=\"{source_instance}\"\n"
                f"  2. Wait for the push job to complete.\n"
                f"  3. Call import_app_from_github on '{target_instance}' with:\n"
                f"     repo_url=\"{repo_url}\", branch=\"{current_branch}\", "
                f"credential=\"{credential_name}\", instance=\"{target_instance}\""
            )

        # --- Phase 2: No uncommitted changes — proceed automatically ---
        target_client = get_client(target_instance)

        # Idempotency: check if app already exists on target
        qb2 = QueryBuilder()
        qb2.add_equals("source_control_url", repo_url)
        existing_resp = target_client.query_table(
            "sys_app", query=qb2.build(), fields=["sys_id", "name"], limit=1
        )

        if existing_resp["success"] and existing_resp["result"]:
            existing = existing_resp["result"][0]
            result = _trigger_sc_operation(target_client, "pull", {"app_id": existing["sys_id"]})
            prefix = (f"App '{app_name}' already exists on {target_instance}. "
                      f"Pulling latest from {repo_url}.\n")
        else:
            result = _trigger_sc_operation(target_client, "import", {
                "app_id": "",
                "extra_args": f'"{repo_url}", "{current_branch}", "{credential_name}"'
            })
            prefix = f"Migrating '{app_name}' from {source_instance} → {target_instance}.\n"

        if not result["success"]:
            return prefix + f"Failed: {result['error']}"

        job_id = result["job_id"]
        msg = prefix + f"Repo: {repo_url} (branch: {current_branch})"
        if job_id:
            msg += (f"\nJob: {job_id} (on {target_instance})\n"
                    f"Use get_source_control_operation_status to poll for completion "
                    f"(specify instance=\"{target_instance}\").")
        return msg
