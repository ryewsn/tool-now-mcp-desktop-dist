"""GitHub Source Control Tools"""

import json
import re
from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation  # used by tools added in subsequent tasks
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

_DEFAULT_CREDENTIAL_NAME = "GitHub Token"
_NO_GITHUB_CREDENTIALS_MSG = "No GitHub credentials found on this instance."

# Verified against zyew2: source control lives under sn_devstudio VCS API.
_VCS_BASE = "/api/sn_devstudio/vcs"
_VCS_PROGRESS_TABLE = "sn_appclient_progress_log"


def _vcs_call(client, method: str, path: str, body: dict = None) -> dict:
    """
    POST or PUT to /api/sn_devstudio/vcs/{path}.

    Returns {"success": bool, "job_id": str | None, "error": str | None}
    """
    if not client._prepare_request():
        return {"success": False, "job_id": None, "error": "Authentication failed."}
    url = f"{client.config.instance}{_VCS_BASE}/{path.lstrip('/')}"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    try:
        fn = client.session.put if method.upper() == "PUT" else client.session.post
        resp = fn(url, json=body or {}, headers=headers)
    except Exception as exc:
        return {"success": False, "job_id": None, "error": str(exc)}
    if resp.status_code in (200, 202):
        try:
            data = resp.json() if resp.text.strip() else {}
        except Exception:
            data = {}
        if not isinstance(data, dict):
            data = {}
        job_id = data.get("transactionId") or data.get("progressId") or data.get("trackerId")
        return {"success": True, "job_id": job_id, "error": None}
    return {"success": False, "job_id": None,
            "error": format_error(resp.status_code, resp.text[:300])}


def _vcs_get_app(client, app_sys_id: str) -> dict:
    """GET /api/sn_devstudio/vcs/apps/{id}. Returns response body dict, or {} on failure."""
    if not client._prepare_request():
        return {}
    url = f"{client.config.instance}{_VCS_BASE}/apps/{app_sys_id}"
    try:
        resp = client.session.get(url, headers={"Accept": "application/json"})
        if resp.status_code == 200:
            data = resp.json()
            if not isinstance(data, dict):
                return {}
            # Unwrap ServiceNow result envelope if present
            if "result" in data and isinstance(data["result"], dict):
                return data["result"]
            return data
    except Exception:
        pass
    return {}


def _get_app_repo_url_via_script(client, app_sys_id: str) -> str:
    """
    Get the VCS repo URL for a specific app using the sn_vcs server-side API via execute_script.

    Fallback for when GET /api/sn_devstudio/vcs/apps/{id} returns non-200. Returns the
    repo URL string (trailing slashes stripped), or "" if the app has no source control
    connection or if the Foundry Script Runner is unavailable.
    """
    if not client._prepare_request():
        return ""
    safe_id = app_sys_id.replace("'", "\\'")
    script = (
        f"try {{"
        f"  var r = sn_vcs.AppSourceControl.getRepository('{safe_id}');"
        f"  gs.info(r ? (r.getRepositoryURL() || '').replace(/\\/+$/, '') : '');"
        f"}} catch(e) {{ gs.info(''); }}"
    )
    foundry_url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
    try:
        resp = client.session.post(foundry_url, json={"script": script, "timeout_ms": 15000})
    except Exception:
        return ""
    if resp.status_code not in (200, 201):
        return ""
    try:
        body = resp.json()
        result_block = body.get("result", {}) if isinstance(body, dict) else {}
        output = result_block.get("output", []) if isinstance(result_block, dict) else []
        for line in (output if isinstance(output, list) else []):
            if isinstance(line, dict) and "message" in line:
                return line["message"].strip()
    except Exception:
        pass
    return ""


def _vcs_repo_id(client, app_sys_id: str) -> str:
    """Return the VCS repoId for an app. Falls back to app_sys_id if unavailable."""
    return _vcs_get_app(client, app_sys_id).get("repoId") or app_sys_id


def _find_app_by_repo_url(client, repo_url: str) -> dict | None:
    """
    Find the sys_app record whose VCS repo URL matches repo_url exactly.

    Uses sn_vcs.AppSourceControl server-side API via execute_script — no fuzzy or name
    matching. Returns {"sys_id", "name", "scope"} dict, or None if not found.
    """
    if not client._prepare_request():
        return None

    safe_url = repo_url.replace("\\", "\\\\").replace("'", "\\'")
    script = (
        "var gr = new GlideRecord('sys_app');"
        "gr.setLimit(500); gr.query();"
        "var found = null;"
        "while (gr.next() && !found) {"
        "  try {"
        "    var repo = sn_vcs.AppSourceControl.getRepository(gr.getUniqueValue());"
        "    if (repo) {"
        f"      var u = (repo.getRepositoryURL() || '').replace(/\\/+$/, '');"
        f"      if (u == '{safe_url}'.replace(/\\/+$/, ''))"
        "        found = {sys_id: gr.getUniqueValue(), name: gr.getValue('name'), scope: gr.getValue('scope')};"
        "    }"
        "  } catch(e) {}"
        "}"
        "gs.info(found ? JSON.stringify(found) : 'null');"
    )
    foundry_url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
    try:
        resp = client.session.post(foundry_url, json={"script": script, "timeout_ms": 30000})
    except Exception:
        return None
    if resp.status_code not in (200, 201):
        return None
    try:
        body = resp.json()
        result_block = body.get("result", {}) if isinstance(body, dict) else {}
        output = result_block.get("output", []) if isinstance(result_block, dict) else []
        for line in (output if isinstance(output, list) else []):
            msg = line.get("message", "").strip() if isinstance(line, dict) else ""
            if msg and msg != "null":
                try:
                    parsed = json.loads(msg)
                    if isinstance(parsed, dict):
                        return parsed
                except Exception:
                    pass
    except Exception:
        pass
    return None


def _resolve_credential_sys_id(client, credential_name: str) -> tuple:
    """
    Resolve a credential name to its sys_id in discovery_credentials.

    The sn_devstudio VCS API passes the credential value directly to
    sn_vcs.AppSourceControl.setCredential(), which expects a sys_id —
    not a display name. Passing a name causes error code 1001 (auth failed).

    Returns (sys_id, None) on success, or (None, error_str) on failure.
    error_str includes a list of available credential names when the
    lookup itself succeeds but the name isn't found.
    """
    if re.match(r'^[0-9a-f]{32}$', credential_name, re.IGNORECASE):
        return credential_name, None  # already a sys_id

    qb = QueryBuilder()
    qb.add_equals("name", credential_name)
    resp = client.query_table("discovery_credentials", query=qb.build(),
                              fields=["sys_id", "name"], limit=1)
    if resp["success"] and resp["result"]:
        return resp["result"][0]["sys_id"], None

    # Not found — fetch available names to help the caller
    qb2 = QueryBuilder()
    qb2.add_order_by("name", "")
    avail = client.query_table("discovery_credentials", query=qb2.build(),
                               fields=["name"], limit=50)
    if avail["success"] and avail["result"]:
        names = ", ".join(f'"{r["name"]}"' for r in avail["result"])
        return None, (f"Credential '{credential_name}' not found. "
                      f"Available credentials: {names}")
    return None, f"Credential '{credential_name}' not found in discovery_credentials."


def _find_github_credentials(client) -> list:
    """Search discovery_credentials for Basic Auth records with 'github' in the name."""
    qb = QueryBuilder()
    qb.add_like("name", "github")
    qb.add_equals("type", "basic_auth")
    qb.add_order_by("name", "")
    resp = client.query_table(
        "discovery_credentials",
        query=qb.build(),
        fields=["sys_id", "name", "type"],
        limit=50,
    )
    if not resp["success"] or not resp["result"]:
        return []
    return resp["result"]


def _resolve_github_credential(client, credential, credential_name_hint=None):
    """
    Resolve the GitHub credential sys_id for a VCS operation.

    Returns (sys_id, message) where:
      (sys_id, None)   — success, proceed silently
      (sys_id, str)    — success, prepend str to the tool response
      (None, str)      — halt, return str as the tool response

    Resolution order:
      1. Explicit credential param (name or sys_id)
      2. client.config.github_credential (from SERVICENOW_GITHUB_CREDENTIAL env var)
      3. credential_name_hint exact match (used by migrate to try source credential on target)
      4. Discovery: LIKE 'github' search in discovery_credentials
    """
    # Step 1: explicit param
    if credential is not None:
        sys_id, error = _resolve_credential_sys_id(client, credential)
        return (sys_id, None) if sys_id else (None, error)

    # Step 2: env var stored on InstanceConfig
    env_cred = getattr(client.config, "github_credential", None)
    if env_cred:
        sys_id, error = _resolve_credential_sys_id(client, env_cred)
        if sys_id:
            return sys_id, f"Using credential '{env_cred}' (from .env)"
        return None, error

    # Step 3: hint match (migrate passes source app's credential name)
    if credential_name_hint:
        sys_id, _ = _resolve_credential_sys_id(client, credential_name_hint)
        if sys_id:
            return sys_id, None
        # not found on target — fall through to discovery

    # Step 4: discovery
    found = _find_github_credentials(client)
    if len(found) == 1:
        cred = found[0]
        return cred["sys_id"], f"Using credential '{cred['name']}' (auto-discovered)."

    if len(found) > 1:
        lines = ["Multiple GitHub credentials found on this instance:"]
        for i, cred in enumerate(found, 1):
            lines.append(f"  {i}. {cred['name']} ({cred.get('type', 'unknown')})")
        lines.append("")
        lines.append('Reply with the credential name or number to use, or "new" to create one.')
        lines.append("To skip this prompt in future sessions, add to your .env:")
        lines.append(f"  SERVICENOW_GITHUB_CREDENTIAL={found[0]['name']}")
        return None, "\n".join(lines)

    return None, (
        _NO_GITHUB_CREDENTIALS_MSG + "\n"
        "Use create_github_credential to set one up. You will need:\n"
        "  • name     — display name (e.g. \"GitHub Token\")\n"
        "  • username — GitHub username or org machine account\n"
        "  • token    — Personal Access Token with repo scope"
    )


def _resolve_app(client, identifier: str) -> dict:
    """
    Resolve an app identifier (sys_id, scope, or name) to a sys_app record.

    Resolution order:
    1. 32-char hex string → exact sys_id match
    2. Starts with x_ or matches scope pattern → exact scope match
    3. Fuzzy name match (LIKE)

    Returns:
        dict with app fields on success
        {"error": str} if not found or multiple matches found
    """
    is_sys_id = bool(re.match(r'^[0-9a-f]{32}$', identifier, re.IGNORECASE))

    if is_sys_id:
        qb = QueryBuilder()
        qb.add_equals("sys_id", identifier)
        resp = client.query_table("sys_app", query=qb.build(),
                                  fields=["sys_id", "name", "scope", "version"], limit=1)
    else:
        is_scope = bool(re.match(r'^[a-z][a-z0-9]*(_[a-z0-9]+){2,}$', identifier))
        if is_scope:
            qb = QueryBuilder()
            qb.add_equals("scope", identifier)
            resp = client.query_table("sys_app", query=qb.build(),
                                      fields=["sys_id", "name", "scope", "version"], limit=2)
        else:
            qb = QueryBuilder()
            qb.add_like("name", identifier)
            resp = client.query_table("sys_app", query=qb.build(),
                                      fields=["sys_id", "name", "scope", "version"], limit=5)

    if not resp["success"]:
        return {"error": format_error(resp["status_code"], resp.get("error", ""))}

    results = resp["result"]
    if not results:
        return {
            "error": (
                f"No app found matching '{identifier}'. "
                "App names may contain spaces (e.g. 'Note Taker') — use the app scope "
                "(x_snc_...) or sys_id for reliable matching."
            )
        }

    if len(results) > 1 and not is_sys_id:
        matches = [f"  • {r['name']} (scope: {r.get('scope', 'n/a')}, sys_id: {r['sys_id']})"
                   for r in results]
        return {
            "error": (
                f"Multiple apps match '{identifier}'. Please re-specify using scope or sys_id:\n"
                + "\n".join(matches)
            )
        }

    return results[0]


def register_tools(mcp: FastMCP):

    @mcp.tool()
    def get_app_source_control_info(app: str, instance: str = None) -> str:
        """
        Get source control status for a ServiceNow app — current branch, linked GitHub
        repo URL, credential name, and list of uncommitted files.

        Returns synchronously (no async job needed — read-only operation).

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App scope (e.g. x_snc_update_all), sys_id, or display name.
                 **Prefer scope — name matching uses SQL LIKE and silently fails for
                 multi-word names or names shared across apps. If name matching returns
                 "No app found", fall back to query_table(table="sys_app",
                 query="nameCONTAINS<keyword>", fields="sys_id,name,scope") to
                 discover the scope, then re-call with the scope.**
            instance: ServiceNow instance alias (e.g. "prod", "dev"). Uses default if omitted.
        """
        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        app_name = app_record.get("name", app)

        app_info = _vcs_get_app(client, app_sys_id)
        if not app_info:
            return f"App '{app_name}' has no source control connection configured in Studio."

        repo_url = (app_info.get("repositoryURL") or app_info.get("repoUrl")
                    or app_info.get("url") or "unknown")
        branch = app_info.get("currentBranch") or app_info.get("branch") or "unknown"
        credential = (app_info.get("credentialName") or app_info.get("credential")
                      or _DEFAULT_CREDENTIAL_NAME)

        lines = [
            f"App: {app_name} ({app_record.get('scope', 'n/a')})",
            f"Repo: {repo_url}",
            f"Branch: {branch}",
            f"Credential: {credential}",
        ]

        uncommitted_raw = app_info.get("uncommittedFiles") or app_info.get("files") or []
        if isinstance(uncommitted_raw, str):
            uncommitted = [f.strip() for f in uncommitted_raw.split(",") if f.strip()]
        else:
            uncommitted = list(uncommitted_raw)

        if uncommitted:
            lines.append(f"Uncommitted files ({len(uncommitted)}):")
            for f in uncommitted:
                lines.append(f"  • {f}")
        else:
            lines.append("Uncommitted files: none")

        return "\n".join(lines)

    @mcp.tool()
    def get_source_control_operation_status(job_sys_id: str, instance: str = None) -> str:
        """
        Poll the status of an async source control operation (push, pull, commit, import, etc.).

        Call this after any write source control tool returns a job ID. Poll every
        10–30 seconds until state is "complete" or "failed".

        Uses GET /api/sn_devstudio/vcs/transactions/{transactionId}.

        Args:
            job_sys_id: The transaction/job ID returned by the triggering tool
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        client = get_client(instance)

        if not client._prepare_request():
            return "Authentication failed."

        url = f"{client.config.instance}{_VCS_BASE}/transactions/{job_sys_id}"
        try:
            resp = client.session.get(url, headers={"Accept": "application/json"})
        except Exception as exc:
            return f"Request failed: {exc}"

        if resp.status_code == 404:
            return f"Job '{job_sys_id}' not found."
        if resp.status_code != 200:
            return format_error(resp.status_code, resp.text[:300])

        try:
            data = resp.json()
        except Exception:
            return f"Job '{job_sys_id}': status response could not be parsed."

        if not isinstance(data, dict):
            data = {}

        _STATE_LABELS = {"0": "pending", "1": "running", "2": "successful", "3": "failed", "4": "cancelled"}
        raw_state = data.get("state")
        state = _STATE_LABELS.get(str(raw_state), str(raw_state)) if raw_state is not None else "unknown"

        detail = data.get("detailMessage") or data.get("errorMessage") or data.get("error_message") or ""
        percent = data.get("percentComplete") or data.get("percent_complete") or ""

        parts = [f"Job: {job_sys_id}", f"State: {state}"]
        if percent and str(percent) != "0":
            parts.append(f"Progress: {str(percent).rstrip('%')}%")
        if detail:
            parts.append(f"Detail: {detail}")

        return "\n".join(parts)

    @mcp.tool()
    def commit_app_changes(app: str, message: str, instance: str = None) -> str:
        """
        Commit and push the current state of a ServiceNow app's source files to GitHub.

        The sn_devstudio VCS API combines commit and push into a single operation —
        calling this will commit all in-platform changes and push them to the linked
        GitHub repo in one step. The operation is async — use
        get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            message: Commit message
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "commit app changes")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        repo_id = _vcs_repo_id(client, app_sys_id)

        result = _vcs_call(client, "POST", f"apps/{app_sys_id}/repos/{repo_id}/commits", {
            "commitMessage": message,
            "commitMode": ""
        })

        if not result["success"]:
            return f"Commit failed: {result['error']}"

        job_id = result["job_id"]
        if job_id:
            return (f"Commit triggered for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.")
        return f"Commit triggered for '{app_record['name']}'. No job ID returned — check syslog if issues occur."

    @mcp.tool()
    def pull_app_from_github(app: str, instance: str = None) -> str:
        """
        Pull the latest changes from GitHub into a ServiceNow app's source files.

        Fetches and merges commits from the remote branch. If conflicts occur, the
        operation will fail — resolve conflicts in Studio, then retry. The operation
        is async — use get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "pull app from GitHub")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        repo_id = _vcs_repo_id(client, app_sys_id)

        result = _vcs_call(client, "POST", f"apps/{app_sys_id}/repos/{repo_id}/apply", {
            "preserveLocalChanges": False
        })

        if not result["success"]:
            return f"Pull failed: {result['error']}"

        job_id = result["job_id"]
        if job_id:
            return (f"Pull triggered for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.")
        return f"Pull triggered for '{app_record['name']}'. No job ID returned — check syslog if issues occur."

    @mcp.tool()
    def switch_app_branch(app: str, branch: str, create: bool = False, instance: str = None) -> str:
        """
        Switch a ServiceNow app to a different source control branch, or create a new branch.

        Uncommitted changes on the current branch may be lost — use stash_app_changes or
        commit_app_changes first if needed. The operation is async — use
        get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            branch: Target branch name to switch to (e.g. "main", "feature/my-feature")
            create: Set to true to create the branch if it doesn't exist (default: false)
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "switch app branch")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        repo_id = _vcs_repo_id(client, app_sys_id)

        result = _vcs_call(client, "PUT", f"apps/{app_sys_id}/repos/{repo_id}/branches/switch", {
            "branchName": branch
        })

        if not result["success"]:
            return f"Branch switch failed: {result['error']}"

        job_id = result["job_id"]
        if job_id:
            return (f"Branch switched to '{branch}' for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.")
        return f"Branch switch triggered for '{app_record['name']}' → '{branch}'. Check syslog if issues occur."

    @mcp.tool()
    def push_app_to_github(app: str, instance: str = None) -> str:
        """
        Push committed changes for a ServiceNow app to its linked GitHub repository.

        Note: The sn_devstudio VCS API combines commit and push into a single operation.
        This tool commits any uncommitted changes with a generic message and pushes to
        GitHub. If you want to provide a specific commit message, use commit_app_changes
        instead (which also commits and pushes in one step).

        The operation is async — use get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "push app to GitHub")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        repo_id = _vcs_repo_id(client, app_sys_id)

        result = _vcs_call(client, "POST", f"apps/{app_sys_id}/repos/{repo_id}/commits", {
            "commitMessage": "Push via ServiceNow MCP",
            "commitMode": ""
        })

        if not result["success"]:
            return f"Push failed: {result['error']}"

        job_id = result["job_id"]
        if job_id:
            return (f"Push triggered for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.")
        return f"Push triggered for '{app_record['name']}'. No job ID returned."

    @mcp.tool()
    def stash_app_changes(app: str, action: str = "stash", instance: str = None) -> str:
        """
        Stash or apply stashed changes for a ServiceNow app's source control working tree.

        Use "stash" to temporarily save uncommitted changes before switching branches.
        Use "apply" to restore previously stashed changes.

        The operation is async — use get_source_control_operation_status to poll for completion.

        Identify the app by name (fuzzy), scope (x_snc_...), or sys_id.

        Args:
            app: App name, scope, or sys_id
            action: "stash" to save changes, "apply" to restore stashed changes (default: "stash")
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        if action not in ("stash", "apply"):
            return "Invalid action. Use 'stash' to save changes or 'apply' to restore stashed changes."

        confirmation_error = require_instance_confirmation(instance, f"{action} app changes")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        app_record = _resolve_app(client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        repo_id = _vcs_repo_id(client, app_sys_id)

        if action == "stash":
            result = _vcs_call(client, "POST", f"apps/{app_sys_id}/repos/{repo_id}/stash", {})
        else:
            result = _vcs_call(client, "POST", f"apps/{app_sys_id}/repos/{repo_id}/stash/apply", {})

        if not result["success"]:
            return (f"Stash {action} failed: {result['error']}\n"
                    f"If this persists, use Studio directly to manage stashed changes.")

        job_id = result["job_id"]
        verb = "stashed" if action == "stash" else "applied"
        if job_id:
            return (f"Changes {verb} for '{app_record['name']}'.\n"
                    f"Job: {job_id}\n"
                    f"Use get_source_control_operation_status to poll for completion.")
        return f"Stash {action} triggered for '{app_record['name']}'. Check syslog if issues occur."

    @mcp.tool()
    def import_app_from_github(
        repo_url: str,
        branch: str = "main",
        credential: str = None,
        instance: str = None
    ) -> str:
        """
        Import a ServiceNow app from a GitHub repository URL.

        Idempotent: if an app linked to this repo URL already exists on the instance,
        pulls the latest changes instead of re-importing. A fresh import installs the
        app from source control into the instance.

        The operation is async — use get_source_control_operation_status to poll for completion.

        Args:
            repo_url: GitHub repository URL (e.g. https://github.com/org/repo)
            branch: Branch to import from (default: "main")
            credential: Name of the credential record to use (default: auto-discovered)
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "import app from GitHub")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        credential_sys_id, cred_message = _resolve_github_credential(client, credential)
        if credential_sys_id is None:
            return cred_message
        response_prefix = (cred_message + "\n") if cred_message else ""

        existing = _find_app_by_repo_url(client, repo_url)

        if existing:
            app_sys_id = existing["sys_id"]
            repo_id = _vcs_repo_id(client, app_sys_id)
            result = _vcs_call(client, "POST", f"apps/{app_sys_id}/repos/{repo_id}/apply", {
                "preserveLocalChanges": False
            })
            if not result["success"]:
                return response_prefix + f"App already installed ('{existing['name']}') but pull failed: {result['error']}"
            job_id = result["job_id"]
            msg = (f"App '{existing['name']}' ({existing.get('scope', 'n/a')}) already exists on this instance.\n"
                   f"Pulling latest from {repo_url} (branch: {branch}) instead of re-importing.")
            if job_id:
                msg += f"\nJob: {job_id}\nUse get_source_control_operation_status to poll for completion."
            return response_prefix + msg

        result = _vcs_call(client, "POST", "apps", {
            "url": repo_url,
            "branch": branch,
            "credential": credential_sys_id
        })

        if not result["success"]:
            return response_prefix + f"Import failed: {result['error']}"

        job_id = result["job_id"]
        msg = f"Import triggered from {repo_url} (branch: {branch}, credential: {credential or 'discovered'})."
        if job_id:
            msg += f"\nJob: {job_id}\nUse get_source_control_operation_status to poll for completion."
        else:
            msg += ("\nNo job ID returned — the import likely completed synchronously. "
                    "Use get_app_source_control_info to verify the app is linked.")
        return response_prefix + msg

    @mcp.tool()
    def migrate_app_via_source_control(
        app: str,
        source_instance: str,
        target_instance: str,
        branch: str = None,
        credential: str = None
    ) -> str:
        """
        Migrate a ServiceNow app from one instance to another via its GitHub source control link.

        Phase 1 (always runs): Resolves the app on the source instance and checks for
        uncommitted changes. If no uncommitted changes exist, proceeds to Phase 2 automatically.
        If uncommitted changes are found, returns a prominent WARNING and two options:

          Option A — Migrate committed state: Pull from source control as-is to the target.
                     Uncommitted changes on source will NOT be included.
          Option B — Commit then migrate: Commit and push source instance changes first,
                     then import to target. All current changes will be migrated.

        To execute Option A: call import_app_from_github on the target instance using the
          repo URL shown in the warning output.
        To execute Option B: call commit_app_changes on the source instance first, wait for
          completion, then call import_app_from_github on the target instance.

        GitHub credential resolution for the target instance:
          1. credential param (if provided)
          2. SERVICENOW_GITHUB_CREDENTIAL_<TARGET> env var
          3. SERVICENOW_GITHUB_CREDENTIAL global env var
          4. Same credential name used by the app on the source instance (exact match on target)
          5. Discovery: search discovery_credentials for names containing 'github'
          6. Nothing found: prompts with pre-filled name and username from the source instance

        Args:
            app: App name, scope, or sys_id (looked up on source_instance)
            source_instance: Instance alias to migrate from (e.g. "dev")
            target_instance: Instance alias to migrate to (e.g. "prod")
            branch: Branch to migrate (defaults to current branch on source)
            credential: Credential name on target instance (default: auto-discovered)
        """
        confirmation_error = require_instance_confirmation(target_instance, "migrate app to target instance")
        if confirmation_error:
            return confirmation_error

        source_client = get_client(source_instance)
        target_client = get_client(target_instance)

        app_record = _resolve_app(source_client, app)
        if "error" in app_record:
            return app_record["error"]

        app_sys_id = app_record["sys_id"]
        app_name = app_record.get("name", app)

        app_info = _vcs_get_app(source_client, app_sys_id)
        if not app_info:
            # VCS REST API failed — try server-side sn_vcs.AppSourceControl as fallback
            fallback_url = _get_app_repo_url_via_script(source_client, app_sys_id)
            if fallback_url:
                app_info = {"url": fallback_url}
            else:
                return (
                    f"App '{app_name}' has no source control connection configured on {source_instance}. "
                    f"Verify in Studio > Source Control that a repository is linked."
                )

        repo_url = (app_info.get("repositoryURL") or app_info.get("repoUrl")
                    or app_info.get("url") or "")
        if not repo_url:
            return f"App '{app_name}' has no repository URL configured on {source_instance}."

        current_branch = branch or app_info.get("currentBranch") or app_info.get("branch") or "main"
        source_credential_name = (app_info.get("credentialName") or app_info.get("credential") or None)
        if isinstance(source_credential_name, dict):
            source_credential_name = (source_credential_name.get("display_value")
                                      or source_credential_name.get("value") or None)

        uncommitted_raw = app_info.get("uncommittedFiles") or app_info.get("files") or []
        if isinstance(uncommitted_raw, str):
            uncommitted_files = [f.strip() for f in uncommitted_raw.split(",") if f.strip()]
        else:
            uncommitted_files = list(uncommitted_raw)

        if uncommitted_files:
            file_list = "\n".join(f"  • {f}" for f in uncommitted_files)
            cred_display = credential or source_credential_name or "GitHub Token"
            return (
                f"WARNING: Uncommitted changes found on {source_instance}\n"
                f"App: {app_name} ({app_record.get('scope', 'n/a')})\n"
                f"Repo: {repo_url}\n"
                f"Branch: {current_branch}\n\n"
                f"Uncommitted files ({len(uncommitted_files)}):\n{file_list}\n\n"
                f"Choose how to proceed:\n\n"
                f"Option A — Migrate committed state:\n"
                f"  Call import_app_from_github on '{target_instance}' with:\n"
                f"    repo_url=\"{repo_url}\", branch=\"{current_branch}\", "
                f"credential=\"{cred_display}\", instance=\"{target_instance}\"\n"
                f"  Uncommitted changes on {source_instance} will NOT be included.\n\n"
                f"Option B — Commit then migrate (includes all current changes):\n"
                f"  1. Call commit_app_changes: app=\"{app}\", message=\"...\", instance=\"{source_instance}\"\n"
                f"  2. Wait for the commit job to complete.\n"
                f"  3. Call import_app_from_github on '{target_instance}' with:\n"
                f"     repo_url=\"{repo_url}\", branch=\"{current_branch}\", "
                f"credential=\"{cred_display}\", instance=\"{target_instance}\""
            )

        # Resolve credential on target using source credential name as a hint
        credential_sys_id, cred_message = _resolve_github_credential(
            target_client, credential, credential_name_hint=source_credential_name
        )
        if credential_sys_id is None:
            # If nothing found and we have source credential info, build pre-filled prompt
            if source_credential_name and _NO_GITHUB_CREDENTIALS_MSG in (cred_message or ""):
                qb = QueryBuilder()
                qb.add_equals("name", source_credential_name)
                cred_resp = source_client.query_table(
                    "discovery_credentials", query=qb.build(),
                    fields=["user_name"], limit=1
                )
                source_username = ""
                if cred_resp.get("success") and cred_resp.get("result"):
                    source_username = cred_resp["result"][0].get("user_name", "")
                if source_username:
                    return (
                        f"Target instance '{target_instance}' has no GitHub credential.\n"
                        f"Found credential '{source_credential_name}' (username: '{source_username}') "
                        f"on {source_instance}.\n"
                        f"Provide the token to create a matching record on '{target_instance}':\n"
                        f"  create_github_credential(name=\"{source_credential_name}\", "
                        f"username=\"{source_username}\", token=\"...\", instance=\"{target_instance}\")"
                    )
            return cred_message

        response_prefix = (cred_message + "\n") if cred_message else ""

        existing = _find_app_by_repo_url(target_client, repo_url)

        if existing:
            target_app_id = existing["sys_id"]
            target_repo_id = _vcs_repo_id(target_client, target_app_id)
            result = _vcs_call(target_client, "POST",
                               f"apps/{target_app_id}/repos/{target_repo_id}/apply",
                               {"preserveLocalChanges": False})
            prefix = (f"App '{app_name}' already exists on {target_instance}. "
                      f"Pulling latest from {repo_url}.\n")
        else:
            result = _vcs_call(target_client, "POST", "apps", {
                "url": repo_url,
                "branch": current_branch,
                "credential": credential_sys_id
            })
            prefix = f"Migrating '{app_name}' from {source_instance} → {target_instance}.\n"

        if not result["success"]:
            return response_prefix + prefix + f"Failed: {result['error']}"

        job_id = result["job_id"]
        msg = response_prefix + prefix + f"Repo: {repo_url} (branch: {current_branch})"
        if job_id:
            msg += (f"\nJob: {job_id} (on {target_instance})\n"
                    f"Use get_source_control_operation_status to poll for completion "
                    f"(specify instance=\"{target_instance}\").")
        return msg

    @mcp.tool()
    def create_github_credential(
        name: str,
        username: str,
        token: str,
        instance: str = None,
    ) -> str:
        """
        Create a GitHub Basic Auth credential in ServiceNow's discovery_credentials table.

        Use this when import_app_from_github or migrate_app_via_source_control reports
        no GitHub credentials found on the instance. After creation, the credential
        is immediately available for source control operations.

        To skip the discovery prompt in future sessions, add to your .env after creation:
          SERVICENOW_GITHUB_CREDENTIAL=<name>          (all instances)
          SERVICENOW_GITHUB_CREDENTIAL_<INSTANCE>=<name>  (per-instance override)

        Args:
            name: Display name for the credential (e.g. "GitHub Token")
            username: GitHub username or org machine account
            token: GitHub Personal Access Token with repo scope
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "create GitHub credential")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        result = client.create_record("discovery_credentials", {
            "name": name,
            "type": "basic_auth",
            "user_name": username,
            "password": token,
        })

        if not result["success"]:
            return format_error(result["status_code"], result.get("error", ""))

        record = result.get("result") or {}
        sys_id = record.get("sys_id", "unknown") if isinstance(record, dict) else "unknown"
        return (
            f"GitHub credential '{name}' created (sys_id: {sys_id}).\n"
            f"To use it by default, add to your .env:\n"
            f"  SERVICENOW_GITHUB_CREDENTIAL={name}"
        )
