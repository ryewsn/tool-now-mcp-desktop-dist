"""Events and Scheduled Jobs Tools"""

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

def register_tools(mcp: FastMCP):
    """Register event and scheduled job-related tools with the MCP server."""

    @mcp.tool()
    def query_events(
        event_name: str = "",
        state: str = "",
        table: str = "",
        limit: int = 500,
        minutes_ago: int = 15,
        min_age_minutes: int = 0,
        instance: str = None
    ) -> str:
        """
        Query the event queue (sysevent) for Business Rules that fire events and Script Actions that process them.

        Use when:
        - An event-driven process, notification, or Script Action isn't firing
        - Events appear stuck or unprocessed

        Args:
            state: "ready", "processed", "error", or "transferred"
            min_age_minutes: Exclude events newer than N minutes (0 = no filter). Use with state="ready" to find stuck events.

        Key fields:
            state: "ready"=waiting, "processed"=done, "error"=failed, "transferred"=moved to another node
            claimed_by: Processing node. Empty = unclaimed.
            parm1/parm2: parm1 is typically the record sys_id; parm2 carries additional context.
            queue: Event processing queue — use to identify queue-specific bottlenecks.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_like("name", event_name)
        builder.add_equals("state", state)
        builder.add_equals("table", table)
        builder.add_relative_time("sys_created_on", minutes_ago)
        if min_age_minutes > 0:
            builder.add_custom(f"sys_created_onRELATIVELT@minute@ago@{min_age_minutes}")

        query = builder.add_order_by("sys_created_on", "DESC")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sysevent",
            query=query,
            fields=["sys_created_on", "name", "table", "state", "parm1", "parm2",
                    "claimed_by", "process_on", "processing_duration", "processed",
                    "queue", "user_name"],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No events found matching your criteria."

        # Format output
        output = []
        for entry in results:
            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('name', 'N/A')} - {entry.get('state', 'N/A')}\n"
                f"Table: {entry.get('table', 'N/A')}\n"
                f"Parm1: {entry.get('parm1', 'N/A')} | Parm2: {entry.get('parm2', 'N/A')}\n"
                f"Claimed by: {entry.get('claimed_by', 'N/A')} | Process on: {entry.get('process_on', 'N/A')}\n"
                f"Queue: {entry.get('queue', 'N/A')} | Duration: {entry.get('processing_duration', 'N/A')}\n"
                f"Processed: {entry.get('processed', 'N/A')} | User: {entry.get('user_name', 'N/A')}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def query_scheduled_jobs(
        job_name: str = "",
        state: str = "",
        min_error_count: int = 0,
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        Query scheduled job execution records (sys_trigger) — run history, state, and errors.
        Use query_job_definitions to see what jobs are configured; use this to debug why a job didn't run or is failing.

        Use when:
        - A scheduled job didn't run, ran at the wrong time, or is running too frequently
        - Verifying a job's last execution time or error details

        Args:
            state: "0" (Ready), "1" (Running), "2" (Queued), "-1" (Error), "-2" (Permanent Error)
            min_error_count: Return only jobs with this many consecutive failures (0 = no filter; 1 = any error).

        Key fields:
            state: 0=Ready, 1=Running, 2=Queued, -1=Error, -2=Permanent Error
            error_count: Consecutive failures. Check last_error first when >0.
            priority: Lower number = higher priority.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_like("name", job_name)
        builder.add_equals("state", state)
        if min_error_count > 0:
            builder.add_custom(f"error_countGREATERTHANOREQUALTO{min_error_count}")

        # Special handling for ORDER BY
        query_str = builder.build()
        if query_str:
            query = f"{query_str}^ORDERBYDESCnext_action"
        else:
            query = "ORDERBYDESCnext_action"

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_trigger",
            query=query,
            fields=["name", "state", "next_action", "trigger_type", "job_context",
                    "system_id", "error_count", "last_error", "processing_duration",
                    "run_count", "claimed_by", "priority"],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No scheduled jobs found matching your criteria."

        # Format output
        state_map = {"0": "Ready", "1": "Running", "2": "Queued", "-1": "Error", "-2": "Permanent Error"}
        output = []
        for entry in results:
            state_display = state_map.get(entry.get('state', ''), entry.get('state', 'N/A'))
            error_count = entry.get('error_count', '0')
            last_error = entry.get('last_error', '')
            error_info = f"\nError count: {error_count} | Last error: {last_error}" if error_count and error_count != '0' else ""
            output.append(
                f"{entry.get('name', 'N/A')} - {state_display}\n"
                f"Trigger type: {entry.get('trigger_type', 'N/A')} | Priority: {entry.get('priority', 'N/A')}\n"
                f"Next run: {entry.get('next_action', 'N/A')}\n"
                f"Run count: {entry.get('run_count', 'N/A')} | Duration: {entry.get('processing_duration', 'N/A')}\n"
                f"Claimed by: {entry.get('claimed_by', 'N/A')}{error_info}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def query_job_definitions(
        name: str = "",
        active: str = "",
        scope: str = "",
        limit: int = 100,
        instance: str = None
    ) -> str:
        """
        List scheduled job definitions (sysauto_script) — what is configured to run, not what ran.
        Use query_scheduled_jobs to inspect execution history after finding candidates here.

        Use when:
        - Auditing active jobs across application scopes
        - Finding resource-consuming OOB jobs to disable on a PDI/dev instance

        Args:
            active: "true" or "false" (default returns all)
            scope: Partial match on application scope name (e.g. "Discovery", "CMDB")

        Key fields:
            run_type: daily, weekly, monthly, periodically, once, on_demand
            run_period: Repeat interval for periodically-scheduled jobs (e.g. "00:05:00").
        """
        builder = QueryBuilder()
        builder.add_like("name", name)
        builder.add_equals("active", active)
        builder.add_like("sys_scope.name", scope)
        query = builder.add_order_by("name", "")

        client = get_client(instance)
        response = client.query_table(
            table_name="sysauto_script",
            query=query,
            fields=["name", "active", "run_type", "sys_scope", "run_period",
                    "run_time", "sys_updated_on"],
            limit=limit,
            display_value="true"
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No job definitions found matching your criteria."

        output = []
        for entry in results:
            active_flag = "active" if entry.get("active") == "true" else "inactive"
            run_period = entry.get("run_period", "")
            run_time = entry.get("run_time", "")
            schedule_detail = f" | interval: {run_period}" if run_period else (f" | time: {run_time}" if run_time else "")
            output.append(
                f"{entry.get('name', 'N/A')} [{active_flag}]\n"
                f"  scope:    {entry.get('sys_scope', 'N/A')}\n"
                f"  run type: {entry.get('run_type', 'N/A')}{schedule_detail}\n"
                f"  updated:  {entry.get('sys_updated_on', 'N/A')}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). Use name/scope filters to narrow results."
        return result
