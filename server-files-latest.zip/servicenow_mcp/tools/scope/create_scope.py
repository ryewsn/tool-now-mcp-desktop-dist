import json
import os
from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.sdk_runner import run_sdk_command, SdkRunnerError  # noqa: F401


def _suggest_scope_prefix(client, project_name: str) -> tuple:
    """Query glide.appcreator.company.code for vendor prefix, derive scope suggestions."""
    qb = QueryBuilder()
    qb.add_equals("name", "glide.appcreator.company.code")
    resp = client.query_table("sys_properties", query=qb.build(), fields=["value"], limit=1)
    vendor = ""
    if resp["success"] and resp.get("result"):
        vendor = resp["result"][0].get("value", "").lower().replace("-", "_")

    safe_project = project_name.lower().replace(" ", "_").replace("-", "_")[:12]
    if vendor:
        xml_prefix = f"x_{vendor}_{safe_project}"
        fluent_prefix = f"x_{vendor}_{safe_project}_sdk"
    else:
        xml_prefix = f"x_snc_{safe_project}"
        fluent_prefix = f"x_snc_{safe_project}_sdk"

    return xml_prefix, fluent_prefix


def _create_xml_scope(client, name: str, scope_prefix: str) -> dict:
    """Create a sys_app record for an XML scope via GlideRecord insert."""
    resp = client.glide_write("sys_app", "insert", {
        "name": name,
        "scope": scope_prefix,
        "version": "1.0.0",
        "active": True,
    })
    if not resp["success"]:
        error = resp.get("error", "Unknown error")
        raise RuntimeError(f"Failed to create XML scope: {error}")
    return {
        "type": "xml",
        "name": name,
        "scope": scope_prefix,
        "sys_id": resp.get("result", {}).get("sys_id", ""),
    }


def _get_install_dir() -> str:
    """Return the MCP install directory (parent of the package root)."""
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))))


def _build_instance_config(client) -> dict:
    """Build SDK CI auth config from the client's credentials."""
    config = {"url": client.config.url}
    auth_type = getattr(client.config, "auth_type", "basic")
    config["auth_type"] = auth_type
    if auth_type == "oauth":
        config["client_id"] = client.config.client_id
        config["client_secret"] = client.config.client_secret
    else:
        config["username"] = getattr(client.config, "username", "")
        config["password"] = getattr(client.config, "password", "")
    return config


def _create_fluent_scope(client, name: str, scope_prefix: str, instance: str = None) -> dict:
    """Create a Fluent scope via now-sdk init + now-sdk deploy in CI mode."""
    install_dir = _get_install_dir()
    instance_alias = client.config.alias
    workspace = os.path.join(install_dir, "sdk-projects", instance_alias, scope_prefix)
    os.makedirs(workspace, exist_ok=True)

    instance_config = _build_instance_config(client)
    safe_name = name.replace('"', "'")

    run_sdk_command(
        ["init", "--appName", safe_name, "--scopeName", scope_prefix,
         "--packageName", scope_prefix, "--template", "base"],
        cwd=workspace,
        instance_config=instance_config,
    )

    config_path = os.path.join(workspace, "now.config.json")
    if not os.path.isfile(config_path):
        raise RuntimeError(
            f"now.config.json not found at {config_path} after now-sdk init. "
            "Check that NOW_SDK_BIN is valid and the init command succeeded."
        )

    with open(config_path, encoding="utf-8") as f:
        config = json.load(f)
    scope_id = config.get("scopeId", "")

    run_sdk_command(["deploy"], cwd=workspace, instance_config=instance_config)

    return {
        "type": "fluent",
        "name": name,
        "scope": scope_prefix,
        "sys_id": scope_id,
        "workspace": workspace,
    }


def register_tools(mcp: FastMCP) -> None:
    @mcp.tool()
    def create_scope(
        name: str,
        type: str,
        scope_prefix: str = None,
        fluent_prefix: str = None,
        instance: str = None,
    ) -> str:
        """Create a ServiceNow scoped application for the hybrid two-scope architecture.

        Use this to set up XML scopes, Fluent (SDK-managed) scopes, or both together.
        When creating both, cross-scope privileges are wired automatically.

        When scope_prefix is omitted, the tool suggests prefixes based on the instance's
        vendor code and returns them for confirmation — call again with the confirmed prefix.

        Args:
            name: Display name for the application (e.g. "ITOM Agent Tools").
            type: "xml" — XML/Studio-managed scope only.
                  "fluent" — SDK-managed Fluent scope only.
                  "both" — creates both and wires them together.
            scope_prefix: Application scope prefix (e.g. "x_acme_myapp"). Must start with "x_".
                          Omit to get prefix suggestions returned for confirmation.
            fluent_prefix: Fluent scope prefix when type="both" and you want it different
                           from scope_prefix + "_sdk".
            instance: Instance alias. Uses default if not specified.
        """
        confirmation_error = require_instance_confirmation(instance, "create scoped applications")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        if not scope_prefix:
            xml_sug, fluent_sug = _suggest_scope_prefix(client, project_name=name)
            return (
                f"Suggested scope prefixes for '{name}':\n"
                f"  XML scope:    {xml_sug}\n"
                f"  Fluent scope: {fluent_sug}\n\n"
                f"Call create_scope again with scope_prefix='<your choice>' to proceed."
            )

        if type == "xml":
            result = _create_xml_scope(client, name=name, scope_prefix=scope_prefix)
            return f"Created XML scope '{scope_prefix}' (sys_id: {result['sys_id']})."

        if type == "fluent":
            result = _create_fluent_scope(client, name=name, scope_prefix=scope_prefix, instance=instance)
            return (
                f"Created Fluent scope '{scope_prefix}' (sys_id: {result['sys_id']}).\n"
                f"SDK workspace: {result['workspace']}\n"
                f"Run wire_scopes(fluent_scope='{scope_prefix}') to establish baseline cross-scope privileges."
            )

        if type == "both":
            fp = fluent_prefix or scope_prefix + "_sdk"
            xml_result = _create_xml_scope(client, name=name, scope_prefix=scope_prefix)
            fluent_result = _create_fluent_scope(client, name=name + " SDK", scope_prefix=fp, instance=instance)
            from .wire_scopes import _wire_baseline_privileges
            wire_result = _wire_baseline_privileges(
                client,
                fluent_scope_id=fluent_result["sys_id"],
                xml_scope_id=xml_result["sys_id"],
            )
            return (
                f"Created hybrid scope pair:\n"
                f"  XML scope:    {scope_prefix} (sys_id: {xml_result['sys_id']})\n"
                f"  Fluent scope: {fp} (sys_id: {fluent_result['sys_id']})\n"
                f"  Workspace:    {fluent_result['workspace']}\n"
                f"  Wiring:       {wire_result['created']} privilege records created."
            )

        return f"Unknown type '{type}'. Use 'xml', 'fluent', or 'both'."
