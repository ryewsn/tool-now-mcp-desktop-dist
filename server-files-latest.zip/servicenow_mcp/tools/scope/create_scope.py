from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder


def _suggest_scope_prefix(client, project_name: str) -> tuple:
    """Query glide.appcreator.company.code for vendor prefix, derive scope suggestions."""
    qb = QueryBuilder()
    qb.add_equals("name", "glide.appcreator.company.code")
    resp = client.query_table("sys_properties", query=qb.build(), fields=["value"], limit=1)
    vendor = ""
    if resp["success"] and resp.get("result"):
        vendor = resp["result"][0].get("value", "").lower().replace("-", "_")

    safe_project = project_name.lower().replace(" ", "_").replace("-", "_")[:12]
    if vendor:
        xml_prefix = f"x_{vendor}_{safe_project}"
        fluent_prefix = f"x_{vendor}_{safe_project}_sdk"
    else:
        xml_prefix = f"x_snc_{safe_project}"
        fluent_prefix = f"x_snc_{safe_project}_sdk"

    return xml_prefix, fluent_prefix


def _create_xml_scope(client, name: str, scope_prefix: str) -> dict:
    """Create a sys_app record for an XML scope via GlideRecord insert."""
    resp = client.glide_write("sys_app", "insert", {
        "name": name,
        "scope": scope_prefix,
        "version": "1.0.0",
        "active": True,
    })
    if not resp["success"]:
        error = resp.get("error", "Unknown error")
        raise RuntimeError(f"Failed to create XML scope: {error}")
    return {
        "type": "xml",
        "name": name,
        "scope": scope_prefix,
        "sys_id": resp.get("result", {}).get("sys_id", ""),
    }


def register_tools(mcp: FastMCP) -> None:
    @mcp.tool()
    def create_scope(
        name: str,
        type: str,
        scope_prefix: str = None,
        fluent_prefix: str = None,
        instance: str = None,
    ) -> str:
        """Create a ServiceNow scoped application.

        Use for XML/Studio-managed scopes. For Fluent (SDK-managed) scopes,
        use the ServiceNow SDK directly via Claude Code.

        When scope_prefix is omitted, the tool suggests prefixes based on the instance's
        vendor code and returns them for confirmation — call again with the confirmed prefix.

        Args:
            name: Display name for the application (e.g. "ITOM Agent Tools").
            type: "xml" — XML/Studio-managed scope (only supported type).
            scope_prefix: Application scope prefix (e.g. "x_acme_myapp"). Must start with "x_".
                          Omit to get prefix suggestions returned for confirmation.
            fluent_prefix: Unused — retained for API compatibility. Will be removed.
            instance: Instance alias. Uses default if not specified.
        """
        confirmation_error = require_instance_confirmation(instance, "create scoped applications")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        if not scope_prefix:
            xml_sug, fluent_sug = _suggest_scope_prefix(client, project_name=name)
            return (
                f"Suggested scope prefixes for '{name}':\n"
                f"  XML scope:    {xml_sug}\n"
                f"  Fluent scope: {fluent_sug}\n\n"
                f"Call create_scope again with scope_prefix='<your choice>' to proceed."
            )

        if type == "xml":
            result = _create_xml_scope(client, name=name, scope_prefix=scope_prefix)
            return f"Created XML scope '{scope_prefix}' (sys_id: {result['sys_id']})."

        return f"Unknown type '{type}'. Only 'xml' is supported. For Fluent scopes, use the ServiceNow SDK directly."
