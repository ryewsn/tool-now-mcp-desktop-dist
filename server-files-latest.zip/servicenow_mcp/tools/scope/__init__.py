from mcp.server.fastmcp import FastMCP


def register_tools(mcp: FastMCP) -> None:
    """Register scope management tools."""
    from . import scope_status, create_scope, wire_scopes
    scope_status.register_tools(mcp)
    create_scope.register_tools(mcp)
    wire_scopes.register_tools(mcp)
