from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from .scope_status import BASELINE_PRIVILEGES, XML_BASELINE_PRIVILEGES


def _lookup_sn_aia_scope_id(client) -> str:
    """Look up the sys_id of the 'Now Assist AI Agents' scope by its stable scope prefix."""
    qb = QueryBuilder()
    qb.add_equals("scope", "sn_aia")
    resp = client.query_table("sys_scope", query=qb.build(), fields=["sys_id"], limit=1)
    if resp["success"] and resp.get("result"):
        return resp["result"][0]["sys_id"]
    return ""


def _privilege_exists(existing: list, requesting_scope_id: str, target_name: str, operation: str) -> bool:
    return any(
        p.get("target_name") == target_name
        and p.get("operation") == operation
        and p.get("sys_scope") == requesting_scope_id
        for p in existing
    )


def _wire_baseline_privileges(client, fluent_scope_id: str, xml_scope_id: str = None) -> dict:
    """Create baseline sys_scope_privilege records. Idempotent — skips existing."""
    aia_scope_id = _lookup_sn_aia_scope_id(client)
    global_scope_id = "global"

    # Fetch all existing privileges for the relevant scopes to check idempotency
    scope_ids = [fluent_scope_id]
    if xml_scope_id:
        scope_ids.append(xml_scope_id)
    qb = QueryBuilder()
    qb.add_custom(f"sys_scopeIN{','.join(scope_ids)}")
    existing_resp = client.query_table(
        "sys_scope_privilege", query=qb.build(),
        fields=["target_name", "operation", "sys_scope"], limit=200
    )
    existing = existing_resp.get("result", []) if existing_resp["success"] else []

    created = 0
    skipped = 0
    errors = []

    for priv in BASELINE_PRIVILEGES:
        target_scope = aia_scope_id if priv["target_type"] == "sys_db_object" else global_scope_id
        if _privilege_exists(existing, fluent_scope_id, priv["target_name"], priv["operation"]):
            skipped += 1
            continue
        resp = client.glide_write("sys_scope_privilege", "insert", {
            "sys_scope": fluent_scope_id,
            "target_scope": target_scope,
            "target_name": priv["target_name"],
            "target_type": priv["target_type"],
            "operation": priv["operation"],
            "status": "allowed",
        })
        if resp["success"]:
            created += 1
        else:
            errors.append(priv["target_name"])

    if xml_scope_id:
        for priv in XML_BASELINE_PRIVILEGES:
            if _privilege_exists(existing, xml_scope_id, priv["target_name"], priv["operation"]):
                skipped += 1
                continue
            resp = client.glide_write("sys_scope_privilege", "insert", {
                "sys_scope": xml_scope_id,
                "target_scope": aia_scope_id,
                "target_name": priv["target_name"],
                "target_type": priv["target_type"],
                "operation": priv["operation"],
                "status": "allowed",
            })
            if resp["success"]:
                created += 1
            else:
                errors.append(f"xml:{priv['target_name']}")

    return {"created": created, "skipped": skipped, "errors": errors}


def register_tools(mcp: FastMCP) -> None:
    @mcp.tool()
    def wire_scopes(
        fluent_scope: str,
        xml_scope: str = None,
        instance: str = None,
    ) -> str:
        """Create baseline cross-scope privileges for the hybrid two-scope architecture.

        Establishes the minimum privilege set a Fluent (SDK-managed) scope needs to:
        - Wire flow actions as AI agent tools (sn_aia_* tables)
        - Execute GlideRecord write operations from flow action scripts

        Idempotent — safe to run multiple times. Reports what was created vs already present.

        Domain-specific privileges (e.g. access to incident, em_alert, RAG APIs) are
        NOT created here — they are handled by the individual tools that need them.

        Args:
            fluent_scope: Scope prefix (e.g. "x_snc_myapp_sdk") or sys_id of the Fluent scope.
            xml_scope: Optional scope prefix or sys_id of the companion XML scope. When provided,
                       also grants the XML scope access to the AI agent tables.
            instance: Instance alias. Uses default if not specified.
        """
        confirmation_error = require_instance_confirmation(instance, "create cross-scope privileges")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        def _resolve_scope_id(scope_ref: str) -> str:
            if len(scope_ref) == 32 and all(c in "0123456789abcdef" for c in scope_ref):
                return scope_ref
            qb = QueryBuilder()
            qb.add_equals("scope", scope_ref)
            resp = client.query_table("sys_scope", query=qb.build(), fields=["sys_id"], limit=1)
            if resp["success"] and resp.get("result"):
                return resp["result"][0]["sys_id"]
            raise ValueError(f"Scope '{scope_ref}' not found on instance.")

        fluent_id = _resolve_scope_id(fluent_scope)
        xml_id = _resolve_scope_id(xml_scope) if xml_scope else None

        result = _wire_baseline_privileges(client, fluent_scope_id=fluent_id, xml_scope_id=xml_id)

        lines = [f"Cross-scope wiring complete for '{fluent_scope}':"]
        lines.append(f"  Created: {result['created']} privilege records")
        lines.append(f"  Skipped: {result['skipped']} (already existed)")
        if result["errors"]:
            lines.append(f"  Errors:  {', '.join(result['errors'])}")
        if xml_scope:
            lines.append(f"  XML scope '{xml_scope}' also granted AI agent table access.")
        return "\n".join(lines)
