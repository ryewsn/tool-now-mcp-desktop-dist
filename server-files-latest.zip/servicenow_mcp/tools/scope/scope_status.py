import os
from mcp.server.fastmcp import FastMCP
from ...core.client import get_client
from ...core.query_builder import QueryBuilder

BASELINE_PRIVILEGES = [
    {"requesting": "fluent", "target_name": "sn_aia_agent_tool_m2m", "target_type": "sys_db_object", "operation": "read"},
    {"requesting": "fluent", "target_name": "sn_aia_agent_tool_m2m", "target_type": "sys_db_object", "operation": "write"},
    {"requesting": "fluent", "target_name": "sn_aia_trigger_configuration", "target_type": "sys_db_object", "operation": "read"},
    {"requesting": "fluent", "target_name": "sn_aia_trigger_configuration", "target_type": "sys_db_object", "operation": "write"},
    {"requesting": "fluent", "target_name": "sn_aia_trigger_agent_usecase_m2m", "target_type": "sys_db_object", "operation": "read"},
    {"requesting": "fluent", "target_name": "sn_aia_trigger_agent_usecase_m2m", "target_type": "sys_db_object", "operation": "write"},
    {"requesting": "fluent", "target_name": "GlideRecord.insert", "target_type": "scriptable", "operation": "execute"},
    {"requesting": "fluent", "target_name": "GlideRecord.update", "target_type": "scriptable", "operation": "execute"},
    {"requesting": "fluent", "target_name": "GlideRecord.setValue", "target_type": "scriptable", "operation": "execute"},
    {"requesting": "fluent", "target_name": "GlideRecord.deleteRecord", "target_type": "scriptable", "operation": "execute"},
    {"requesting": "fluent", "target_name": "GlideRecord.deleteMultiple", "target_type": "scriptable", "operation": "execute"},
    {"requesting": "fluent", "target_name": "GlideRecord.setWorkflow", "target_type": "scriptable", "operation": "execute"},
]

XML_BASELINE_PRIVILEGES = [
    {"requesting": "xml", "target_name": "sn_aia_agent_tool_m2m", "target_type": "sys_db_object", "operation": "read"},
    {"requesting": "xml", "target_name": "sn_aia_agent_tool_m2m", "target_type": "sys_db_object", "operation": "write"},
    {"requesting": "xml", "target_name": "sn_aia_trigger_configuration", "target_type": "sys_db_object", "operation": "read"},
    {"requesting": "xml", "target_name": "sn_aia_trigger_configuration", "target_type": "sys_db_object", "operation": "write"},
    {"requesting": "xml", "target_name": "sn_aia_trigger_agent_usecase_m2m", "target_type": "sys_db_object", "operation": "read"},
    {"requesting": "xml", "target_name": "sn_aia_trigger_agent_usecase_m2m", "target_type": "sys_db_object", "operation": "write"},
]


def _detect_scope_type(scope_prefix: str, instance_alias: str, install_dir: str = None) -> str:
    # Detection is local-filesystem-only: returns "fluent" only when a now.config.json
    # exists in the local SDK workspace. Scopes created on another machine will appear as "xml".
    if install_dir is None:
        install_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    workspace = os.path.join(install_dir, "sdk-projects", instance_alias, scope_prefix, "now.config.json")
    return "fluent" if os.path.isfile(workspace) else "xml"


def _check_baseline_wiring(existing_privileges: list, scope_type: str = "fluent") -> tuple:
    baseline = BASELINE_PRIVILEGES if scope_type == "fluent" else XML_BASELINE_PRIVILEGES
    existing_keys = {(p["target_name"], p["operation"]) for p in existing_privileges}
    present = [p for p in baseline if (p["target_name"], p["operation"]) in existing_keys]
    missing = [p for p in baseline if (p["target_name"], p["operation"]) not in existing_keys]
    return present, missing


def _format_status_report(scopes: list, instance: str, wiring: dict) -> str:
    lines = [f"Scopes on {instance}:"]
    for s in scopes:
        type_label = s["type"].upper()
        workspace_note = f" [workspace: {s.get('workspace', '')}]" if s["type"] == "fluent" else ""
        lines.append(f"  {s['scope']:<30} ({s['name']})  — {type_label}{workspace_note}")

    fluent_scopes = [s for s in scopes if s["type"] == "fluent"]
    xml_scopes = [s for s in scopes if s["type"] == "xml"]
    if fluent_scopes and xml_scopes:
        lines.append(f"\nPairing detected: {xml_scopes[0]['scope']} ↔ {fluent_scopes[0]['scope']}")

    missing = wiring.get("missing", [])
    present = wiring.get("present", [])
    total = len(present) + len(missing)
    lines.append(f"\nBaseline wiring: {len(present)}/{total} records present")
    if missing:
        lines.append("  Missing: " + ", ".join(f"{m['target_name']} ({m['operation']})" for m in missing[:5]))
        if fluent_scopes:
            fs = fluent_scopes[0]["scope"]
            xs = xml_scopes[0]["scope"] if xml_scopes else ""
            xml_arg = f', xml_scope="{xs}"' if xs else ""
            lines.append(f'  → Run wire_scopes(fluent_scope="{fs}"{xml_arg}) to complete')

    return "\n".join(lines)


def register_tools(mcp: FastMCP) -> None:
    @mcp.tool()
    def scope_status(scope_prefix: str = None, instance: str = None) -> str:
        """Detect ServiceNow scopes on the instance and report their type (Fluent vs XML),
        pairing status, and baseline cross-scope wiring completeness.

        Use at the start of a build session to understand the current scope setup, or
        after create_scope to verify the scope was created successfully.

        Args:
            scope_prefix: Optional filter — returns only scopes whose prefix contains this string.
                          If omitted, returns all custom scopes (excludes OOB sn_* and global).
            instance: ServiceNow instance alias (e.g. "prod", "dev"). Uses default if not specified.
        """
        client = get_client(instance)
        install_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__)))))

        qb = QueryBuilder()
        qb.add_custom("sys_class_name=sys_app")
        if scope_prefix:
            qb.add_like("scope", scope_prefix)
        else:
            qb.add_custom("scopeSTARTSWITHx_")

        resp = client.query_table("sys_app", query=qb.build(),
                                  fields=["sys_id", "name", "scope", "version"], limit=50)
        if not resp["success"]:
            return f"Error querying scopes: {resp.get('error', '')}"

        instance_alias = client.config.alias
        scopes = []
        for r in resp.get("result", []):
            scope_type = _detect_scope_type(r["scope"], instance_alias, install_dir)
            entry = {"sys_id": r["sys_id"], "name": r["name"], "scope": r["scope"], "type": scope_type}
            if scope_type == "fluent":
                entry["workspace"] = os.path.join(install_dir, "sdk-projects", instance_alias, r["scope"])
            scopes.append(entry)

        if not scopes:
            return "No custom scopes found" + (f" matching '{scope_prefix}'" if scope_prefix else "") + "."

        fluent_scopes = [s for s in scopes if s["type"] == "fluent"]
        wiring = {"present": [], "missing": []}
        if fluent_scopes:
            fluent_sys_id = fluent_scopes[0]["sys_id"]
            qb2 = QueryBuilder()
            qb2.add_equals("sys_scope", fluent_sys_id)
            priv_resp = client.query_table("sys_scope_privilege",
                                           query=qb2.build(),
                                           fields=["target_name", "operation"], limit=100)
            if priv_resp["success"]:
                existing = priv_resp.get("result", [])
                present, missing = _check_baseline_wiring(existing)
                wiring = {"present": present, "missing": missing}

        return _format_status_report(scopes, instance_alias, wiring)
