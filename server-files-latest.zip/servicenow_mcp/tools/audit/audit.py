"""Audit and Change Tracking Tools"""

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

def register_tools(mcp: FastMCP):
    """Register audit-related tools with the MCP server."""

    @mcp.tool()
    def query_audit(
        table_name: str = "",
        document_id: str = "",
        field_name: str = "",
        user: str = "",
        limit: int = 500,
        minutes_ago: int = 15,
        instance: str = None
    ) -> str:
        """
        Query sys_audit for field-level record change history — who changed what, and when.
        Use get_table_schema("sys_audit") to discover valid field names and values.

        Look here when:
        - A record has unexpected values and you need to know what changed
        - Investigating who modified sensitive data
        - Debugging Business Rules or flows that update records unexpectedly
        - Users report "the system changed my data"

        Key fields in results:
            fieldname: Which field was changed.
            oldvalue/newvalue: Before/after values — core of any change investigation.
            user: Who or what made the change (user login, system, or workflow engine).
            tablename/documentkey: Which record; use documentkey as sys_id to fetch the record.
            reason: Why the change was made (if provided).

        Args:
            minutes_ago: Default 15. Use 0 to remove time filter — pair with other filters to avoid full-table scan.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_equals("tablename", table_name)
        builder.add_equals("documentkey", document_id)
        builder.add_equals("fieldname", field_name)
        builder.add_equals("user", user)
        builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "DESC")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_audit",
            query=query,
            fields=["sys_created_on", "tablename", "documentkey", "fieldname", "oldvalue", "newvalue", "user", "reason"],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No audit records found matching your criteria."

        # Format output
        output = []
        for entry in results:
            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('tablename', 'N/A')}.{entry.get('fieldname', 'N/A')}\n"
                f"Changed by: {entry.get('user', 'N/A')}\n"
                f"Old value: {entry.get('oldvalue', '(empty)')}\n"
                f"New value: {entry.get('newvalue', '(empty)')}\n"
                f"Record: {entry.get('documentkey', 'N/A')}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def query_update_xml(
        update_set: str = "",
        name: str = "",
        target_name: str = "",
        table: str = "",
        type: str = "",
        application: str = "",
        action: str = "",
        minutes_ago: int = 15,
        limit: int = 200,
        include_payload: bool = False,
        instance: str = None
    ) -> str:
        """
        Query sys_update_xml to trace configuration and code artifacts captured in update sets —
        one entry per artifact per capture, not per field. For field-level change history use
        query_audit instead. Use get_table_schema("sys_update_xml") to discover additional field names.

        Look here when:
        - Tracing what a specific update set contains or modified
        - Identifying which application owns a recently changed artifact
        - Debugging why a deployment changed an unexpected record
        - Investigating DELETE operations on configuration records

        Key fields in results:
            action: INSERT_OR_UPDATE or DELETE.
            type: Artifact type (e.g. "Script Include", "Business Rule", "Access Roles").
            update_set: Update set that captured this change (display name).
            application: Scoped application that owns the artifact.
            name: Internal artifact identifier (format: tablename_sysid).
            target_name: Human-readable name of the changed record.
            table: Target table of the artifact (e.g. "sys_security_acl_role").

        CRITICAL: Default time window is 15 minutes. Expand minutes_ago only if needed —
        sys_update_xml accumulates thousands of entries per hour on active instances.

        Args:
            type: Filter — exact, case-sensitive match (e.g. "Script Include", "Business Rule", "Access Roles")
            action: Filter — exact, case-sensitive match: "INSERT_OR_UPDATE" or "DELETE"
            minutes_ago: Default 15. Use 0 to remove time filter — pair with other filters to avoid full-table scan.
            include_payload: Default False — payload can be hundreds of KB.
        """
        fields = [
            "sys_updated_on", "action", "type", "update_set",
            "application", "name", "target_name", "table", "category",
        ]
        if include_payload:
            fields.append("payload")

        builder = QueryBuilder()
        builder.add_like("update_set.name", update_set)
        builder.add_like("name", name)
        builder.add_like("target_name", target_name)
        builder.add_like("table", table)
        builder.add_equals("type", type)
        builder.add_like("application.name", application)
        builder.add_equals("action", action)
        builder.add_relative_time("sys_updated_on", minutes_ago)

        query = builder.add_order_by("sys_updated_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_update_xml",
            query=query,
            fields=fields,
            limit=limit,
            display_value="true",
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No update XML records found matching your criteria."

        output = []
        for entry in results:
            lines = [
                f"[{entry.get('sys_updated_on')}] {entry.get('action', 'N/A')} | {entry.get('type', 'N/A')}",
                f"Update Set: {entry.get('update_set', 'N/A')} | App: {entry.get('application', 'N/A')} | Category: {entry.get('category', 'N/A')}",
                f"Name: {entry.get('name', 'N/A')}",
                f"Target: {entry.get('target_name', 'N/A')}",
            ]
            if entry.get('table'):
                lines.append(f"Table: {entry.get('table')}")
            if include_payload and entry.get('payload'):
                lines.append(f"Payload:\n{entry.get('payload')}")
            output.append("\n".join(lines))

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result
