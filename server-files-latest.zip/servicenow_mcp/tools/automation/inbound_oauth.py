"""Inbound OAuth Application Setup Tools

Automates creation of OAuth applications in ServiceNow for inbound authentication
(external clients authenticating to ServiceNow APIs).
"""

import socket
from pathlib import Path

from mcp.server.mcpserver import MCPServer
from ...core.client import get_client, require_instance_confirmation, require_scope_confirmation
from ...core.formatters import format_error
from ...core.inbound_oauth import _generate_client_secret
from ...core.instance_manager import instance_name_to_env_key
from ...core.oauth_identity import bind_oauth_identity, resolve_oauth_identity


def validate_user_exists(username: str, instance: str = None) -> tuple[bool, str, dict]:
    """
    Validate that a ServiceNow user exists and is active.

    Args:
        username: Username to validate
        instance: ServiceNow instance alias

    Returns:
        Tuple of (success: bool, message: str, user_record: dict)
    """
    client = get_client(instance)

    response = client.query_table(
        table_name="sys_user",
        query=f"user_name={username}^active=true",
        fields=["sys_id", "user_name", "name", "active"],
        limit=1
    )

    if not response["success"]:
        return False, format_error(response["status_code"], response.get("error", "")), {}

    if not response["result"]:
        return False, f"❌ User '{username}' not found or is inactive in ServiceNow", {}

    user = response["result"][0]
    return True, "", user


def check_client_credentials_enabled(instance: str = None) -> tuple[bool, str]:
    """
    Check if client_credentials grant type is enabled in ServiceNow.
    Automatically enables it if not already enabled.

    Args:
        instance: ServiceNow instance alias

    Returns:
        Tuple of (enabled: bool, message: str)
    """
    client = get_client(instance)

    response = client.query_table(
        table_name="sys_properties",
        query="name=glide.oauth.inbound.client.credential.grant_type.enabled",
        fields=["sys_id", "name", "value"],
        limit=1
    )

    if not response["success"]:
        return False, format_error(response["status_code"], response.get("error", ""))

    # Property doesn't exist - create it
    if not response["result"]:
        create_response = client.create_record(
            table_name="sys_properties",
            data={
                "name": "glide.oauth.inbound.client.credential.grant_type.enabled",
                "value": "true",
                "type": "boolean",
                "description": "Enable client credentials grant type for inbound OAuth"
            }
        )

        if not create_response["success"]:
            return False, (
                f"⚠️  Could not create system property (admin role may be required).\n"
                f"Please manually create: glide.oauth.inbound.client.credential.grant_type.enabled = true\n"
                f"Error: {create_response.get('error', 'Unknown error')}"
            )

        return True, "✓ System property created and enabled (glide.oauth.inbound.client.credential.grant_type.enabled = true)"

    # Property exists - check if enabled
    prop = response["result"][0]
    if prop.get("value") != "true":
        # Update to enable it
        update_response = client.update_record(
            table_name="sys_properties",
            sys_id=prop["sys_id"],
            data={"value": "true"}
        )

        if not update_response["success"]:
            return False, (
                f"⚠️  Could not enable system property (admin role may be required).\n"
                f"Please manually set: glide.oauth.inbound.client.credential.grant_type.enabled = true\n"
                f"Error: {update_response.get('error', 'Unknown error')}"
            )

        return True, "✓ System property enabled (glide.oauth.inbound.client.credential.grant_type.enabled = true)"

    return True, "✓ System property already enabled"


def store_credentials_in_keychain(instance: str, client_id: str, client_secret: str) -> tuple[bool, str]:
    """
    Store OAuth credentials in macOS Keychain.

    Args:
        instance: ServiceNow instance alias
        client_id: OAuth client ID
        client_secret: OAuth client secret

    Returns:
        Tuple of (success: bool, message: str)
    """
    try:
        import keyring

        service_name = "servicenow-mcp"
        keyring.set_password(service_name, f"{instance}-client-id", client_id)
        keyring.set_password(service_name, f"{instance}-client-secret", client_secret)

        return True, (
            "✓ Credentials stored in macOS Keychain\n\n"
            f"  Retrieve with:\n"
            f"    keyring get {service_name} {instance}-client-id\n"
            f"    keyring get {service_name} {instance}-client-secret"
        )
    except ImportError:
        return False, (
            "⚠️  keyring package not installed. Credentials not stored in keychain.\n"
            "  Install with: pip install keyring"
        )
    except Exception as e:
        return False, f"⚠️  Failed to store credentials in keychain: {str(e)}"


def update_env_file(
    instance_alias: str,
    client_id: str,
    client_secret: str,
    username: str = None,
    password: str = None,
    sa_sys_id: str = None,
) -> tuple[bool, str]:
    """
    Update .env file with OAuth credentials for the specified instance.

    Adds CLIENT_ID and CLIENT_SECRET variables while preserving Basic Auth as fallback.
    Optionally writes SERVICENOW_USERNAME_<ALIAS> and SERVICENOW_PASSWORD_<ALIAS> when
    username and password are both provided (e.g. for AI-attributed service accounts).

    Args:
        instance_alias: Instance alias (e.g., "zyew", "prod")
        client_id: OAuth client ID
        client_secret: OAuth client secret
        username: Optional service account username to write to .env
        password: Optional service account password to write to .env
        sa_sys_id: Optional service account sys_id, written as SERVICENOW_SA_SYS_ID_<ALIAS>
            (the key the installer writes and uninstall reads to find the account). It is not a
            credential, so it may be written even when the username/password are not.

    Returns:
        Tuple of (success: bool, message: str)
    """
    # Find .env file in project root
    env_path = Path(__file__).parent.parent.parent.parent / ".env"

    if not env_path.exists():
        return False, f"⚠️  .env file not found at: {env_path}"

    # Append SERVICENOW_INSTALL_HOSTNAME if not already present
    try:
        existing_content = env_path.read_text()
        if "SERVICENOW_INSTALL_HOSTNAME" not in existing_content:
            try:
                detected_hostname = socket.gethostname() or ""
            except OSError:
                detected_hostname = ""
            if detected_hostname:
                with open(env_path, "a") as _f:
                    _f.write(f"SERVICENOW_INSTALL_HOSTNAME={detected_hostname}\n")
    except OSError:
        pass  # hostname append is best-effort; continue with credential update

    try:
        # Read current .env content
        with open(env_path, 'r') as f:
            lines = f.readlines()

        # Find the instance section and add OAuth credentials
        # Same normalization as the installer, settings and uninstall (hyphens -> underscores).
        instance_upper = instance_name_to_env_key(instance_alias)
        legacy_upper = instance_alias.upper()
        if legacy_upper != instance_upper:
            # Earlier versions wrote un-normalized keys (e.g. SERVICENOW_CLIENT_ID_MY-DEV), which
            # nothing else reads. Rename them to the normalized key, dropping a legacy line when the
            # normalized key is already present, so no stale duplicate is left behind.
            migrated = []
            for line in lines:
                key = line.split("=", 1)[0].strip() if "=" in line else ""
                new_line = line
                for kind in ("CLIENT_ID", "CLIENT_SECRET", "USERNAME", "PASSWORD", "SA_SYS_ID"):
                    if key == f"SERVICENOW_{kind}_{legacy_upper}":
                        normalized = f"SERVICENOW_{kind}_{instance_upper}"
                        if any(l.strip().startswith(f"{normalized}=") for l in lines):
                            new_line = None
                        else:
                            new_line = f"{normalized}={line.split('=', 1)[1]}"
                        break
                if new_line is not None:
                    migrated.append(new_line)
            lines = migrated
        client_id_var = f"SERVICENOW_CLIENT_ID_{instance_upper}"
        client_secret_var = f"SERVICENOW_CLIENT_SECRET_{instance_upper}"
        username_var = f"SERVICENOW_USERNAME_{instance_upper}"
        password_var = f"SERVICENOW_PASSWORD_{instance_upper}"

        # Check if OAuth credentials already exist
        has_client_id = any(client_id_var in line for line in lines)
        has_client_secret = any(client_secret_var in line for line in lines)

        if has_client_id and has_client_secret:
            # Update existing OAuth credentials
            has_username = any(username_var in line for line in lines)
            has_password = any(password_var in line for line in lines)

            new_lines = []
            for line in lines:
                if client_id_var in line and line.strip().startswith(client_id_var):
                    new_lines.append(f"{client_id_var}={client_id}\n")
                elif client_secret_var in line and line.strip().startswith(client_secret_var):
                    new_lines.append(f"{client_secret_var}={client_secret}\n")
                elif username and has_username and username_var in line and line.strip().startswith(username_var):
                    new_lines.append(f"{username_var}={username}\n")
                elif password and has_password and password_var in line and line.strip().startswith(password_var):
                    new_lines.append(f"{password_var}={password}\n")
                else:
                    new_lines.append(line)

            # Append username/password if not already present in file
            if username and password and (not has_username or not has_password):
                new_lines.append(f"{username_var}={username}\n")
                new_lines.append(f"{password_var}={password}\n")

            lines = new_lines
            action = "updated"
        else:
            # Add new OAuth credentials after instance URL line
            instance_url_var = f"SERVICENOW_INSTANCE_{instance_upper}"
            new_lines = []
            oauth_added = False

            for i, line in enumerate(lines):
                new_lines.append(line)
                # Add OAuth credentials after instance URL line
                if instance_url_var in line and not oauth_added:
                    # Add OAuth section
                    new_lines.append(f"# OAuth Authentication (recommended - provides better scope control)\n")
                    new_lines.append(f"{client_id_var}={client_id}\n")
                    new_lines.append(f"{client_secret_var}={client_secret}\n")
                    if username and password:
                        new_lines.append(f"{username_var}={username}\n")
                        new_lines.append(f"{password_var}={password}\n")
                    new_lines.append(f"# Basic Auth (fallback - OAuth takes priority if both configured)\n")
                    oauth_added = True

            lines = new_lines
            action = "added"

        if sa_sys_id:
            sa_var = f"SERVICENOW_SA_SYS_ID_{instance_upper}"
            if any(line.strip().startswith(f"{sa_var}=") for line in lines):
                lines = [f"{sa_var}={sa_id}\n" if line.strip().startswith(f"{sa_var}=") else line
                         for line in lines for sa_id in [sa_sys_id]]
            else:
                if lines and not lines[-1].endswith("\n"):
                    lines[-1] += "\n"
                lines.append(f"{sa_var}={sa_sys_id}\n")

        # Write back to .env
        with open(env_path, 'w') as f:
            f.writelines(lines)

        return True, (
            f"✓ OAuth credentials {action} in .env file\n\n"
            f"  {client_id_var}={client_id}\n"
            f"  {client_secret_var}=********\n\n"
            f"  ⚠️  IMPORTANT: Restart Claude Desktop (Cmd+Q, then reopen) for changes to take effect."
        )

    except Exception as e:
        return False, f"⚠️  Failed to update .env file: {str(e)}"


def register_tools(mcp: MCPServer):
    """Register inbound OAuth application setup tools with the MCP server."""

    @mcp.tool()
    def setup_inbound_oauth(
        name: str,
        user: str,
        client_secret: str = "",
        scopes: str = "",
        refresh_token_lifespan: int = 0,
        access_token_lifespan: int = 7_776_000,  # 90 days
        store_in_keychain: bool = False,
        update_env: bool = False,
        scope: str = None,
        create_service_account: bool = None,
        oauth_identity: str = None,
        instance: str = None
    ) -> str:
        """
        Create an inbound OAuth application (oauth_entity) in ServiceNow so external clients can call ServiceNow APIs using client_credentials grant. Automatically enables glide.oauth.inbound.client.credential.grant_type.enabled (requires admin).

        **vs. Outbound OAuth — use setup_oauth_integration instead when:**
        - Inbound (this tool): external clients call ServiceNow. ServiceNow generates client_id/secret. Single oauth_entity record.
        - Outbound: ServiceNow calls external APIs. You provide credentials. 5-table chain.

        **Bootstrap workflow — setting up OAuth on a new instance:**
        1. The instance must already be registered with basic auth credentials. If it is not yet registered, call add_instance(auth_type="basic", username=..., password=...) first. Do NOT ask the user for a client_id or client_secret — those are the output of this tool, not inputs.
        2. Call this tool with update_env=True. It creates the OAuth app in ServiceNow, writes the new client_id/client_secret to .env, and automatically installs the Foundry Script Runner (required by many tools).
        3. After this tool succeeds, the instance is already switched to OAuth. Do not ask the user whether to make the switch — it is automatic when update_env=True. Tell the user to restart Claude Desktop (Cmd+Q, then reopen) to pick up the new credentials.

        **Auto-recovery — orphaned record from a failed previous setup:**
        If an oauth_entity with the same name exists in ServiceNow but no OAuth credentials are present in .env, the previous setup completed the ServiceNow half but never saved credentials. This tool automatically deletes the orphaned record and recreates it — no user intervention needed. Just call it again with the same arguments.

        **CRITICAL — ServiceNow field names for oauth_entity (wrong names silently ignored):**
        - type = "client"  (not oauth_entity_type)
        - default_grant_type = "client_credentials"  (not grant_type)
        - user = <sys_id>  (not oauth_application_user)

        **CRITICAL — Scope behavior:** oauth_entity ignores sysparm_scope regardless of auth method; record inherits caller's active application scope. To land in global scope, user must set Global in the Application Picker before calling this tool.

        When multiple instances are configured and the user has not named one, ask which instance to use before calling this tool. If the user has already named the instance, proceed without asking.

        Args:
            name: For MCP server use "Now MCP for Claude" (hostname appended automatically).
            user: ServiceNow username of the setup user. With oauth_identity='human' this user is the OAuth Application User; with 'service_account' the account is given this user's groups and direct roles.
            client_secret: Leave empty to auto-generate.
            scopes: Comma-separated API scopes (optional).
            refresh_token_lifespan: Seconds; 0 = no refresh tokens (default: 0).
            access_token_lifespan: Seconds (default: 7_776_000 = 90 days). The client
                auto-refreshes tokens using client_credentials before expiry, so a long
                lifespan is safe and reduces unnecessary re-authentication.
            store_in_keychain: Store credentials in macOS Keychain (default: False).
            update_env: Update .env with CLIENT_ID/SECRET. Set True when bootstrapping OAuth for an instance — switches the instance from basic auth to OAuth automatically (default: False).
            scope: "global" or scope ID (e.g., "x_123_myapp"). Ignored with Basic Auth.
            oauth_identity: Which user the OAuth application runs as: "service_account" (default) or "human".
                - "service_account": creates a dedicated <username>.claude.<hostname> sys_user (created without an
                  email address), adds it to the setup user's groups so it holds what those groups grant, copies the
                  setup user's directly granted roles, and sets it as the OAuth application user. Elevated roles that
                  were granted directly to the setup user cannot be copied and are reported in the output. If the
                  account cannot be created or verified, or does not hold the setup user's roles, the application stays bound to the setup user and the output
                  says so.
                - "human": no service account is created; the OAuth application runs as the `user` argument.
                BEHAVIOR CHANGE: the default is now "service_account", so OAuth calls run as the service account
                (audit trails show it) instead of the human setup user. The output always has a "Running as:" line
                naming the identity actually in effect. Requires update_env=True to persist the service account's
                credentials to .env, and they are saved only when the OAuth application is verified as using the
                account (otherwise the output says they were not saved). The account's sys_id is always saved to .env
                (SERVICENOW_SA_SYS_ID_<ALIAS>) when the account was created, so uninstall can find it.
            create_service_account: DEPRECATED. Use oauth_identity. Only applies when oauth_identity is not passed:
                False means oauth_identity="human"; True or omitted means "service_account".

        Returns:
            OAuth application details with client_id, client_secret, and token endpoint URL
        """

        # Step 0: Resolve which identity the OAuth application runs as
        try:
            identity = resolve_oauth_identity(oauth_identity, create_service_account)
        except ValueError as e:
            return f"❌ Error: {e}"

        # Step 1: Validate instance confirmation for multi-instance setups
        confirmation_error = require_instance_confirmation(instance, "create OAuth application")
        if confirmation_error:
            return confirmation_error

        # Step 2: Validate required parameters
        if not name:
            return "❌ Error: Application name is required"

        if not user:
            return "❌ Error: OAuth Application User is required"

        # Step 3: Get client for the specified instance
        client = get_client(instance)
        instance_config = client.config

        # Short-circuit: if OAuth credentials are already configured for this instance,
        # the setup is already done — no need to create another oauth_entity record.
        if instance_config.uses_oauth:
            instance_label = instance_config.alias or instance_config.instance
            return (
                f"✅ OAuth is already configured for {instance_label}.\n\n"
                f"The instance is using client_id `{instance_config.client_id}` — "
                f"no setup needed.\n\n"
                f"If you're seeing authentication errors, use `inspect_oauth_entity` to "
                f"diagnose the existing OAuth application, or `get_mcp_status` to test "
                f"the connection."
            )

        # Step 4: Require explicit scope confirmation
        scope_error = require_scope_confirmation(scope, client, "create OAuth application")
        if scope_error:
            return scope_error

        # Step 5: Validate application scope exists
        # Get available scopes to validate against
        scopes_response = client.get_application_scopes()
        available_scopes = []

        if scopes_response["success"] and scopes_response["result"]:
            available_scopes = scopes_response["result"]

        # Validate the provided scope exists (skip validation for 'global' as it's always available)
        if scope and scope != "global":
            scope_exists = any(s.get("scope") == scope for s in available_scopes)
            if not scope_exists:
                scope_list = "\n".join(f"  • {s.get('scope')} - {s.get('name')}" for s in available_scopes[:15])
                if len(available_scopes) > 15:
                    scope_list += f"\n  ... and {len(available_scopes) - 15} more"
                return (
                    f"❌ Scope '{scope}' not found in ServiceNow instance.\n\n"
                    "Available scopes (use scope ID, not name):\n"
                    "  • global - Global scope (default)\n"
                    f"{scope_list}\n\n"
                    "Tip: Use the full scope ID (e.g., 'x_123_myapp'), not the display name."
                )

        # Step 6: Validate OAuth Application User exists
        user_valid, user_message, user_record = validate_user_exists(user, instance)
        if not user_valid:
            return user_message

        user_sys_id = user_record["sys_id"]
        user_display_name = user_record.get("name", user)

        # Step 7: Generate client_secret if not provided
        if not client_secret:
            client_secret = _generate_client_secret()
            secret_generated = True
        else:
            secret_generated = False

        # Step 8: Check/enable client_credentials grant type
        enabled, status_message = check_client_credentials_enabled(instance)
        property_output = ""
        if status_message:  # Show message whether success or warning
            property_output = f"\n{status_message}\n\n"

        # Step 9: Create OAuth Application (oauth_entity)
        # Append hostname to name so the ServiceNow record is self-identifying
        # across multiple machines connecting to the same instance.
        import socket
        try:
            hostname = instance_config.install_hostname or socket.gethostname() or ""
        except OSError:
            hostname = instance_config.install_hostname or ""
        app_name = f"{name} — {hostname}"

        # Pre-flight: check if a record with this name already exists. The oauth_entity
        # table has a unique constraint on name — a duplicate insert returns 403 with a
        # BatchUpdateException, not a 409, so we must detect this before attempting insert.
        existing_check = client.query_table(
            table_name="oauth_entity",
            query=f"name={app_name}",
            fields=["sys_id", "name", "client_id", "active", "sys_created_on", "sys_created_by"],
            limit=1,
        )
        if existing_check["success"] and existing_check["result"]:
            existing = existing_check["result"][0]
            existing_sys_id = existing.get("sys_id", "")
            existing_client_id = existing.get("client_id", "")
            existing_created = existing.get("sys_created_on", "")
            existing_by = existing.get("sys_created_by", "")

            # If the instance already has OAuth credentials in .env, the record is live
            # and in use — don't touch it, just confirm it's already set up.
            if instance_config.uses_oauth:
                return (
                    f"✅ OAuth is already configured for this instance.\n\n"
                    f"The existing oauth_entity (created {existing_created} by {existing_by}) "
                    f"matches the credentials in .env. No setup needed.\n\n"
                    f"If you're seeing authentication errors, use `inspect_oauth_entity` or "
                    f"`get_mcp_status` to diagnose."
                )

            # No credentials in .env — the ServiceNow record exists but setup never
            # completed (credentials were never saved). Auto-recover: delete the orphaned
            # record and proceed with a fresh creation.
            delete_result = client.glide_write(
                table="oauth_entity",
                operation="delete",
                data={},
                sys_id=existing_sys_id,
            )
            if not delete_result["success"]:
                return (
                    f"⚠️  Found an orphaned oauth_entity record from a previous incomplete "
                    f"setup (created {existing_created} by {existing_by}, "
                    f"sys_id: {existing_sys_id}), but could not delete it automatically.\n\n"
                    f"Delete it manually in ServiceNow, then retry this tool.\n\n"
                    f"Error: {delete_result.get('error', '')}"
                )
            # Record deleted — fall through to create a fresh one below

        oauth_app_data = {
            "name": app_name,
            "client_secret": client_secret,
            "type": "client",  # This is an OAuth client (inbound)
            "default_grant_type": "client_credentials",  # Correct field name
            "access_token_lifespan": access_token_lifespan,
            "refresh_token_lifespan": refresh_token_lifespan,
            "user": user_sys_id  # Correct field name (not oauth_application_user)
        }

        # Note: Scopes are managed via oauth_entity_scope table records, not a field
        # on oauth_entity. Proper scope assignment is backlogged.

        create_response = client.create_record(
            table_name="oauth_entity",
            data=oauth_app_data,
            scope=scope
        )

        if not create_response["success"]:
            status_code = create_response["status_code"]
            error_detail = create_response.get("error", "")
            # Surface the raw error body so the actual cause is visible (e.g. duplicate
            # name, permission denied, missing field). Do not assume a specific root cause.
            return (
                f"❌ Failed to create OAuth application (HTTP {status_code})\n\n"
                f"{format_error(status_code, error_detail)}\n\n"
                f"Common causes:\n"
                f"  • Duplicate name — an oauth_entity with this name already exists "
                f"(pre-flight check should have caught this; if it didn't, the record may\n"
                f"    have been created between the check and the insert)\n"
                f"  • Session scope — the configured user's UI scope is not Global\n"
                f"  • Insufficient permissions — the user lacks write access to oauth_entity\n\n"
                f"Check .mcp_diagnostic.log for the full ServiceNow response body."
            )

        app_record = create_response["result"]
        app_sys_id = app_record.get("sys_id")
        client_id = app_record.get("client_id")

        if not client_id:
            return (
                f"❌ OAuth application created but client_id was not generated.\n"
                f"Application sys_id: {app_sys_id}\n"
                f"Please check the oauth_entity record in ServiceNow."
            )

        # Re-fetch to verify actual stored scope — oauth_entity ignores sysparm_scope
        actual_scope = scope
        scope_warning = ""
        if app_sys_id:
            refetch = client.query_table(
                table_name="oauth_entity",
                query=f"sys_id={app_sys_id}",
                fields=["sys_id", "sys_scope"],
                limit=1,
                display_value="true"
            )
            if refetch["success"] and refetch["result"]:
                fetched_scope = refetch["result"][0].get("sys_scope", "") or ""
                if fetched_scope:
                    actual_scope = fetched_scope
                if scope and fetched_scope and fetched_scope.lower() != scope.lower():
                    scope_warning = (
                        f"⚠️  Scope mismatch: record created in '{fetched_scope}' "
                        f"instead of requested '{scope}'.\n"
                        f"   oauth_entity ignores sysparm_scope regardless of auth method — "
                        f"the record inherits your session's active application scope.\n"
                        f"   To create in global scope: open the Application Picker "
                        f"(top-right globe icon) → set Global as default → re-run setup."
                    )

        # Step 10: Store in keychain if requested
        keychain_output = ""
        if store_in_keychain:
            success, message = store_credentials_in_keychain(instance_config.alias, client_id, client_secret)
            keychain_output = f"\n💾 Credentials Storage:\n\n{message}\n\n"

        # Step 10b: Update .env file if requested
        env_output = ""
        if update_env:
            success, message = update_env_file(instance_config.alias, client_id, client_secret)
            env_output = f"\n📝 .env File Update:\n\n{message}\n\n"

        # Step 10c: Install Script Runner — integral to many tools; set up as part of bootstrap
        sr_output = ""
        if update_env:
            from ..code.scripts import install_script_runner
            sr_success, sr_message = install_script_runner(client)
            if sr_success:
                sr_output = f"\n🔧 Script Runner: {sr_message}\n"
            else:
                sr_output = f"\n⚠️  Script Runner setup failed (non-blocking): {sr_message}\n"

        # Step 10e: Suggest attributed service account if not requested
        sa_output = ""
        if identity == "human":
            attributed_name = f"{user_display_name} (Claude assisted)"
            sa_output = (
                f"\n💡 Recommended: AI-attributed service account\n\n"
                f"  API calls will appear in ServiceNow audit logs as '{attributed_name}'\n"
                f"  instead of '{user_display_name}', making AI-assisted changes\n"
                f"  distinguishable from human work.\n\n"
                f"  Re-run with oauth_identity='service_account' (and update_env=True) to set this up.\n"
            )

        # Step 10f: Create attributed service account if requested
        sa_creation_output = ""
        sa_result = None
        bind_result = None
        if identity == "service_account":
            from ...core.service_account import create_attributed_service_account

            if not client._prepare_request():
                sa_creation_output = "\n⚠️  Could not create attributed service account: authentication failed.\n"
            else:
                sa_result = create_attributed_service_account(
                    session=client.session,
                    instance_url=instance_config.instance,
                    setup_username=user,
                    setup_user_sys_id=user_sys_id,
                    setup_user_display_name=user_display_name,
                    hostname=hostname,
                )
                # Bind before reporting so the output reflects the identity actually in effect.
                bind_result = bind_oauth_identity(
                    client.session, instance_config.instance, app_sys_id,
                    "service_account", sa_result)
                if sa_result["success"]:
                    attributed_user = sa_result["user_name"]
                    roles_line = (
                        f"{sa_result['roles_assigned']} roles replicated"
                        if not sa_result["roles_skipped"]
                        else "⚠️  Roles not replicated (user_admin required — assign manually)"
                    )
                    sa_creation_output = (
                        f"\n✅ Attributed service account created\n\n"
                        f"  Account: {attributed_user}\n"
                        f"  Roles: {roles_line}\n"
                        f"  Groups added: {sa_result.get('groups_added', 0)}\n"
                    )
                    missing = sa_result.get("roles_missing") or []
                    if missing:
                        sa_creation_output += (
                            f"  ⚠️  Roles the setup user has that the account is missing: "
                            f"{', '.join(missing)}\n")
                    elevated = sa_result.get("roles_elevated_skipped") or []
                    if elevated:
                        sa_creation_output += (
                            f"  Elevated roles not replicated: {', '.join(elevated)}\n")
                    bound_verified = (bind_result["identity"] == "service_account"
                                      and bind_result.get("verified", True))
                    # A reused account has no password available (the account already existed), so
                    # writing its username alone would pair it with the previous human password.
                    write_creds = bound_verified and bool(sa_result.get("password"))
                    if update_env:
                        # The sys_id is not a credential: always save it so uninstall can find the
                        # account. Username/password only when the OAuth app is verified as using
                        # the account and its password is known.
                        env_ok, env_sa_msg = update_env_file(
                            instance_config.alias,
                            client_id,
                            client_secret,
                            username=attributed_user if write_creds else None,
                            password=sa_result["password"] if write_creds else None,
                            sa_sys_id=sa_result["sys_id"],
                        )
                    if update_env and write_creds:
                        sa_creation_output += f"  {env_sa_msg}\n"
                    elif update_env and bound_verified:
                        sa_creation_output += (
                            f"  The service account {attributed_user} already existed, so its "
                            f"password is not available: .env credentials were left unchanged and "
                            f"still hold whatever was there before (possibly the setup user's). "
                            f"Set the account's credentials in .env manually if you need them.\n")
                        if not env_ok:
                            sa_creation_output += (
                                f"  ⚠️  Could not save the service account sys_id to .env "
                                f"({env_sa_msg}); uninstall will NOT remove it.\n")
                    elif update_env:
                        sa_creation_output += (
                            "  Service account credentials were NOT saved to .env because the OAuth "
                            "application is not verified as using the account.\n")
                        if not env_ok:
                            sa_creation_output += (
                                f"  ⚠️  Could not save the service account sys_id to .env "
                                f"({env_sa_msg}); uninstall will NOT remove the account.\n")
                        if bind_result.get("verified", True):
                            saved_note = (
                                " (its sys_id is saved to .env, so uninstall will remove it)"
                                if env_ok else "")
                            sa_creation_output += (
                                f"  The service account {attributed_user} was created but is unused; "
                                f"delete it manually if you do not want it{saved_note}.\n")
                        else:
                            sa_creation_output += (
                                f"  The service account {attributed_user} was created; check "
                                f"oauth_entity.user before deleting it, because the update may have applied.\n")
                    else:
                        sa_creation_output += (
                            "  ⚠️  Credentials not saved — re-run with update_env=True to persist.\n"
                        )
                else:
                    sa_creation_output = (
                        f"\n⚠️  Attributed service account creation failed: {sa_result.get('error')}\n"
                        f"  OAuth setup completed successfully. Create the account manually.\n"
                    )

        # Step 10g: Bind the OAuth application to the chosen identity
        if identity == "service_account":
            if bind_result is None:  # account step did not run (auth failure)
                bind_result = bind_oauth_identity(
                    client.session, instance_config.instance, app_sys_id,
                    "service_account", sa_result)
        else:
            bind_result = {"identity": "human", "bound": True,
                           "reason": "bound to the requesting user by request"}
        if bind_result["identity"] == "service_account":
            effective_name = sa_result["user_name"]
            user_line = f"{effective_name} (service account)"
            running_as = effective_name
        else:
            user_line = f"{user_display_name} ({user})"
            running_as = user_display_name
            if identity == "service_account":
                if not bind_result.get("verified", True):
                    running_as = (f"UNVERIFIED — the update may have applied; "
                                  f"check oauth_entity.user ({bind_result['reason']})")
                else:
                    running_as += f" — fell back: {bind_result['reason']}"

        # Step 11: Format output
        token_endpoint = f"{instance_config.instance}/oauth_token.do"

        output = [
            "✅ OAuth application created successfully!",
            "",
            f"Application Name: {app_name}",
            f"Application sys_id: {app_sys_id}",
            f"Instance: {instance_config.instance}",
            f"Application Scope: {actual_scope}",
            f"OAuth Application User: {user_line}",
            f"Running as: {running_as}",
            *([f"Note: the service account was created but the OAuth application is NOT using it; "
               f"calls run as {user_display_name}. See the reason above."]
              if (identity == "service_account" and sa_result and sa_result.get("success")
                  and bind_result["identity"] == "human"
                  and bind_result.get("verified", True)) else []),
            f"Grant Type: client_credentials",
            "",
            "🔑 Client Credentials:",
            "",
            f"  Client ID: {client_id}",
            f"  Client Secret: {client_secret[:8]}{'*' * (len(client_secret) - 8)}" if len(client_secret) > 8 else f"  Client Secret: {client_secret}",
        ]

        if secret_generated:
            output.append(f"  (Secret was auto-generated)")

        output.extend([
            "",
            f"  Token Endpoint: {token_endpoint}",
        ])

        if scope_warning:
            output.append("")
            output.append(scope_warning)

        if property_output:
            output.extend(["", property_output.strip()])

        if keychain_output:
            output.append(keychain_output.strip())

        if env_output:
            output.append(env_output.strip())

        if sr_output:
            output.append(sr_output.strip())

        # Determine usage context for next steps
        usage_hints = []
        name_lower = name.lower()

        if "servicenow" in name_lower and "mcp" in name_lower:
            usage_hints.append("  • For ServiceNow MCP Server: Configure these credentials in your MCP settings")
            usage_hints.append("  • Navigate to: All > Model Context Protocol > MCP Server Settings")
        elif "mcp" in name_lower or "claude" in name_lower:
            usage_hints.append("  • Configure credentials in your application's .env or configuration file")
            usage_hints.append("  • Restart your MCP server or Claude Desktop to apply changes")
        elif "ci/cd" in name_lower or "github" in name_lower or "pipeline" in name_lower:
            usage_hints.append("  • Add credentials to your CI/CD secrets or environment variables")
            usage_hints.append("  • Reference these in your pipeline configuration")
        else:
            usage_hints.append("  • Configure these credentials in your application or tool")
            usage_hints.append("  • Refer to your application's OAuth documentation for setup")

        output.extend([
            "",
            "📋 Next Steps:",
            "",
            "  1. Test OAuth authentication:",
            "",
            f"     curl -X POST {token_endpoint} \\",
            f"       -u {client_id}:{client_secret} \\",
            f"       -d \"grant_type=client_credentials\"",
            "",
            "  2. Configure your application:",
            "",
        ])

        output.extend(usage_hints)

        output.extend([
            "",
            "  3. Example .env configuration (if applicable):",
            "",
            f"     SERVICENOW_INSTANCE={instance_config.instance}",
            f"     SERVICENOW_CLIENT_ID={client_id}",
            f"     SERVICENOW_CLIENT_SECRET={client_secret}",
            "",
            "💡 Security Tips:",
            "",
            "  • Client credentials grant full API access for the assigned user",
            "  • Use a dedicated service account with minimal required permissions",
            "  • Rotate credentials periodically (recommended: every 90 days)",
            "  • Monitor OAuth token usage in ServiceNow: System OAuth > OAuth Token Usage",
            "",
            f"📊 Token Lifespans:",
            "",
            f"  • Access Token: {access_token_lifespan} seconds ({access_token_lifespan // 60} minutes)",
        ])

        if refresh_token_lifespan > 0:
            output.append(f"  • Refresh Token: {refresh_token_lifespan} seconds ({refresh_token_lifespan // 60} minutes)")
        else:
            output.append(f"  • Refresh Token: Disabled (no refresh tokens)")

        if sa_output:
            output.append(sa_output.strip())
        if sa_creation_output:
            output.append(sa_creation_output.strip())

        return "\n".join(output)
