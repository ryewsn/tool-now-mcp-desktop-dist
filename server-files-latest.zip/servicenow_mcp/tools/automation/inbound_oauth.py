"""Inbound OAuth Application Setup Tools

Automates creation of OAuth applications in ServiceNow for inbound authentication
(external clients authenticating to ServiceNow APIs).
"""

import socket
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation, require_scope_confirmation
from ...core.formatters import format_error
from ...core.inbound_oauth import _generate_client_secret


def validate_user_exists(username: str, instance: str = None) -> tuple[bool, str, dict]:
    """
    Validate that a ServiceNow user exists and is active.

    Args:
        username: Username to validate
        instance: ServiceNow instance alias

    Returns:
        Tuple of (success: bool, message: str, user_record: dict)
    """
    client = get_client(instance)

    response = client.query_table(
        table_name="sys_user",
        query=f"user_name={username}^active=true",
        fields=["sys_id", "user_name", "name", "email", "active"],
        limit=1
    )

    if not response["success"]:
        return False, format_error(response["status_code"], response.get("error", "")), {}

    if not response["result"]:
        return False, f"❌ User '{username}' not found or is inactive in ServiceNow", {}

    user = response["result"][0]
    return True, "", user


def check_client_credentials_enabled(instance: str = None) -> tuple[bool, str]:
    """
    Check if client_credentials grant type is enabled in ServiceNow.
    Automatically enables it if not already enabled.

    Args:
        instance: ServiceNow instance alias

    Returns:
        Tuple of (enabled: bool, message: str)
    """
    client = get_client(instance)

    response = client.query_table(
        table_name="sys_properties",
        query="name=glide.oauth.inbound.client.credential.grant_type.enabled",
        fields=["sys_id", "name", "value"],
        limit=1
    )

    if not response["success"]:
        return False, format_error(response["status_code"], response.get("error", ""))

    # Property doesn't exist - create it
    if not response["result"]:
        create_response = client.create_record(
            table_name="sys_properties",
            data={
                "name": "glide.oauth.inbound.client.credential.grant_type.enabled",
                "value": "true",
                "type": "boolean",
                "description": "Enable client credentials grant type for inbound OAuth"
            }
        )

        if not create_response["success"]:
            return False, (
                f"⚠️  Could not create system property (admin role may be required).\n"
                f"Please manually create: glide.oauth.inbound.client.credential.grant_type.enabled = true\n"
                f"Error: {create_response.get('error', 'Unknown error')}"
            )

        return True, "✓ System property created and enabled (glide.oauth.inbound.client.credential.grant_type.enabled = true)"

    # Property exists - check if enabled
    prop = response["result"][0]
    if prop.get("value") != "true":
        # Update to enable it
        update_response = client.update_record(
            table_name="sys_properties",
            sys_id=prop["sys_id"],
            data={"value": "true"}
        )

        if not update_response["success"]:
            return False, (
                f"⚠️  Could not enable system property (admin role may be required).\n"
                f"Please manually set: glide.oauth.inbound.client.credential.grant_type.enabled = true\n"
                f"Error: {update_response.get('error', 'Unknown error')}"
            )

        return True, "✓ System property enabled (glide.oauth.inbound.client.credential.grant_type.enabled = true)"

    return True, "✓ System property already enabled"


def store_credentials_in_keychain(instance: str, client_id: str, client_secret: str) -> tuple[bool, str]:
    """
    Store OAuth credentials in macOS Keychain.

    Args:
        instance: ServiceNow instance alias
        client_id: OAuth client ID
        client_secret: OAuth client secret

    Returns:
        Tuple of (success: bool, message: str)
    """
    try:
        import keyring

        service_name = "servicenow-mcp"
        keyring.set_password(service_name, f"{instance}-client-id", client_id)
        keyring.set_password(service_name, f"{instance}-client-secret", client_secret)

        return True, (
            "✓ Credentials stored in macOS Keychain\n\n"
            f"  Retrieve with:\n"
            f"    keyring get {service_name} {instance}-client-id\n"
            f"    keyring get {service_name} {instance}-client-secret"
        )
    except ImportError:
        return False, (
            "⚠️  keyring package not installed. Credentials not stored in keychain.\n"
            "  Install with: pip install keyring"
        )
    except Exception as e:
        return False, f"⚠️  Failed to store credentials in keychain: {str(e)}"


def update_env_file(
    instance_alias: str,
    client_id: str,
    client_secret: str,
    username: str = None,
    password: str = None,
) -> tuple[bool, str]:
    """
    Update .env file with OAuth credentials for the specified instance.

    Adds CLIENT_ID and CLIENT_SECRET variables while preserving Basic Auth as fallback.
    Optionally writes SERVICENOW_USERNAME_<ALIAS> and SERVICENOW_PASSWORD_<ALIAS> when
    username and password are both provided (e.g. for AI-attributed service accounts).

    Args:
        instance_alias: Instance alias (e.g., "zyew", "prod")
        client_id: OAuth client ID
        client_secret: OAuth client secret
        username: Optional service account username to write to .env
        password: Optional service account password to write to .env

    Returns:
        Tuple of (success: bool, message: str)
    """
    # Find .env file in project root
    env_path = Path(__file__).parent.parent.parent.parent / ".env"

    if not env_path.exists():
        return False, f"⚠️  .env file not found at: {env_path}"

    # Append SERVICENOW_INSTALL_HOSTNAME if not already present
    try:
        existing_content = env_path.read_text()
        if "SERVICENOW_INSTALL_HOSTNAME" not in existing_content:
            try:
                detected_hostname = socket.gethostname() or ""
            except OSError:
                detected_hostname = ""
            if detected_hostname:
                with open(env_path, "a") as _f:
                    _f.write(f"SERVICENOW_INSTALL_HOSTNAME={detected_hostname}\n")
    except OSError:
        pass  # hostname append is best-effort; continue with credential update

    try:
        # Read current .env content
        with open(env_path, 'r') as f:
            lines = f.readlines()

        # Find the instance section and add OAuth credentials
        instance_upper = instance_alias.upper()
        client_id_var = f"SERVICENOW_CLIENT_ID_{instance_upper}"
        client_secret_var = f"SERVICENOW_CLIENT_SECRET_{instance_upper}"
        username_var = f"SERVICENOW_USERNAME_{instance_upper}"
        password_var = f"SERVICENOW_PASSWORD_{instance_upper}"

        # Check if OAuth credentials already exist
        has_client_id = any(client_id_var in line for line in lines)
        has_client_secret = any(client_secret_var in line for line in lines)

        if has_client_id and has_client_secret:
            # Update existing OAuth credentials
            has_username = any(username_var in line for line in lines)
            has_password = any(password_var in line for line in lines)

            new_lines = []
            for line in lines:
                if client_id_var in line and line.strip().startswith(client_id_var):
                    new_lines.append(f"{client_id_var}={client_id}\n")
                elif client_secret_var in line and line.strip().startswith(client_secret_var):
                    new_lines.append(f"{client_secret_var}={client_secret}\n")
                elif username and has_username and username_var in line and line.strip().startswith(username_var):
                    new_lines.append(f"{username_var}={username}\n")
                elif password and has_password and password_var in line and line.strip().startswith(password_var):
                    new_lines.append(f"{password_var}={password}\n")
                else:
                    new_lines.append(line)

            # Append username/password if not already present in file
            if username and password and (not has_username or not has_password):
                new_lines.append(f"{username_var}={username}\n")
                new_lines.append(f"{password_var}={password}\n")

            lines = new_lines
            action = "updated"
        else:
            # Add new OAuth credentials after instance URL line
            instance_url_var = f"SERVICENOW_INSTANCE_{instance_upper}"
            new_lines = []
            oauth_added = False

            for i, line in enumerate(lines):
                new_lines.append(line)
                # Add OAuth credentials after instance URL line
                if instance_url_var in line and not oauth_added:
                    # Add OAuth section
                    new_lines.append(f"# OAuth Authentication (recommended - provides better scope control)\n")
                    new_lines.append(f"{client_id_var}={client_id}\n")
                    new_lines.append(f"{client_secret_var}={client_secret}\n")
                    if username and password:
                        new_lines.append(f"{username_var}={username}\n")
                        new_lines.append(f"{password_var}={password}\n")
                    new_lines.append(f"# Basic Auth (fallback - OAuth takes priority if both configured)\n")
                    oauth_added = True

            lines = new_lines
            action = "added"

        # Write back to .env
        with open(env_path, 'w') as f:
            f.writelines(lines)

        return True, (
            f"✓ OAuth credentials {action} in .env file\n\n"
            f"  {client_id_var}={client_id}\n"
            f"  {client_secret_var}=********\n\n"
            f"  ⚠️  IMPORTANT: Restart Claude Desktop (Cmd+Q, then reopen) for changes to take effect."
        )

    except Exception as e:
        return False, f"⚠️  Failed to update .env file: {str(e)}"


def register_tools(mcp: FastMCP):
    """Register inbound OAuth application setup tools with the MCP server."""

    @mcp.tool()
    def setup_inbound_oauth(
        name: str,
        user: str,
        client_secret: str = "",
        scopes: str = "",
        refresh_token_lifespan: int = 0,
        access_token_lifespan: int = 1800,
        store_in_keychain: bool = False,
        update_env: bool = False,
        scope: str = None,
        create_service_account: bool = False,
        instance: str = None
    ) -> str:
        """
        Create an inbound OAuth application (oauth_entity) in ServiceNow so external clients can call ServiceNow APIs using client_credentials grant. Automatically enables glide.oauth.inbound.client.credential.grant_type.enabled (requires admin).

        **vs. Outbound OAuth — use setup_oauth_integration instead when:**
        - Inbound (this tool): external clients call ServiceNow. ServiceNow generates client_id/secret. Single oauth_entity record.
        - Outbound: ServiceNow calls external APIs. You provide credentials. 5-table chain.

        **Bootstrap workflow — setting up OAuth on a new instance:**
        1. The instance must already be registered with basic auth credentials. If it is not yet registered, call add_instance(auth_type="basic", username=..., password=...) first. Do NOT ask the user for a client_id or client_secret — those are the output of this tool, not inputs.
        2. Call this tool with update_env=True. It creates the OAuth app in ServiceNow and immediately writes the new client_id/client_secret to .env, replacing the basic auth bootstrap credentials.
        3. After this tool succeeds, the instance is already switched to OAuth. Do not ask the user whether to make the switch — it is automatic when update_env=True. Tell the user to restart Claude Desktop (Cmd+Q, then reopen) to pick up the new credentials.

        **CRITICAL — ServiceNow field names for oauth_entity (wrong names silently ignored):**
        - type = "client"  (not oauth_entity_type)
        - default_grant_type = "client_credentials"  (not grant_type)
        - user = <sys_id>  (not oauth_application_user)

        **CRITICAL — Scope behavior:** oauth_entity ignores sysparm_scope regardless of auth method; record inherits caller's active application scope. To land in global scope, user must set Global in the Application Picker before calling this tool.

        When multiple instances are configured and the user has not named one, ask which instance to use before calling this tool. If the user has already named the instance, proceed without asking.

        Args:
            name: For MCP server use "Now MCP for Claude" (hostname appended automatically).
            user: ServiceNow username for OAuth Application User.
            client_secret: Leave empty to auto-generate.
            scopes: Comma-separated API scopes (optional).
            refresh_token_lifespan: Seconds; 0 = no refresh tokens (default: 0).
            access_token_lifespan: Seconds (default: 1800).
            store_in_keychain: Store credentials in macOS Keychain (default: False).
            update_env: Update .env with CLIENT_ID/SECRET. Set True when bootstrapping OAuth for an instance — switches the instance from basic auth to OAuth automatically (default: False).
            scope: "global" or scope ID (e.g., "x_123_myapp"). Ignored with Basic Auth.
            create_service_account: When True, creates <username>.claude.<hostname> sys_user with replicated roles for audit attribution. Requires update_env=True to persist (default: False).

        Returns:
            OAuth application details with client_id, client_secret, and token endpoint URL
        """

        # Step 1: Validate instance confirmation for multi-instance setups
        confirmation_error = require_instance_confirmation(instance, "create OAuth application")
        if confirmation_error:
            return confirmation_error

        # Step 2: Validate required parameters
        if not name:
            return "❌ Error: Application name is required"

        if not user:
            return "❌ Error: OAuth Application User is required"

        # Step 3: Get client for the specified instance
        client = get_client(instance)
        instance_config = client.config

        # Short-circuit: if OAuth credentials are already configured for this instance,
        # the setup is already done — no need to create another oauth_entity record.
        if instance_config.uses_oauth:
            instance_label = instance_config.alias or instance_config.instance
            return (
                f"✅ OAuth is already configured for {instance_label}.\n\n"
                f"The instance is using client_id `{instance_config.client_id}` — "
                f"no setup needed.\n\n"
                f"If you're seeing authentication errors, use `inspect_oauth_entity` to "
                f"diagnose the existing OAuth application, or `get_mcp_status` to test "
                f"the connection."
            )

        # Step 4: Require explicit scope confirmation
        scope_error = require_scope_confirmation(scope, client, "create OAuth application")
        if scope_error:
            return scope_error

        # Step 5: Validate application scope exists
        # Get available scopes to validate against
        scopes_response = client.get_application_scopes()
        available_scopes = []

        if scopes_response["success"] and scopes_response["result"]:
            available_scopes = scopes_response["result"]

        # Validate the provided scope exists (skip validation for 'global' as it's always available)
        if scope and scope != "global":
            scope_exists = any(s.get("scope") == scope for s in available_scopes)
            if not scope_exists:
                scope_list = "\n".join(f"  • {s.get('scope')} - {s.get('name')}" for s in available_scopes[:15])
                if len(available_scopes) > 15:
                    scope_list += f"\n  ... and {len(available_scopes) - 15} more"
                return (
                    f"❌ Scope '{scope}' not found in ServiceNow instance.\n\n"
                    "Available scopes (use scope ID, not name):\n"
                    "  • global - Global scope (default)\n"
                    f"{scope_list}\n\n"
                    "Tip: Use the full scope ID (e.g., 'x_123_myapp'), not the display name."
                )

        # Step 6: Validate OAuth Application User exists
        user_valid, user_message, user_record = validate_user_exists(user, instance)
        if not user_valid:
            return user_message

        user_sys_id = user_record["sys_id"]
        user_display_name = user_record.get("name", user)

        # Step 7: Generate client_secret if not provided
        if not client_secret:
            client_secret = _generate_client_secret()
            secret_generated = True
        else:
            secret_generated = False

        # Step 8: Check/enable client_credentials grant type
        enabled, status_message = check_client_credentials_enabled(instance)
        property_output = ""
        if status_message:  # Show message whether success or warning
            property_output = f"\n{status_message}\n\n"

        # Step 9: Create OAuth Application (oauth_entity)
        # Append hostname to name so the ServiceNow record is self-identifying
        # across multiple machines connecting to the same instance.
        import socket
        try:
            hostname = instance_config.install_hostname or socket.gethostname() or ""
        except OSError:
            hostname = instance_config.install_hostname or ""
        app_name = f"{name} — {hostname}"

        # Pre-flight: check if a record with this name already exists. The oauth_entity
        # table has a unique constraint on name — a duplicate insert returns 403 with a
        # BatchUpdateException, not a 409, so we must detect this before attempting insert.
        existing_check = client.query_table(
            table_name="oauth_entity",
            query=f"name={app_name}",
            fields=["sys_id", "name", "client_id", "active", "sys_created_on", "sys_created_by"],
            limit=1,
        )
        if existing_check["success"] and existing_check["result"]:
            existing = existing_check["result"][0]
            existing_sys_id = existing.get("sys_id", "")
            existing_client_id = existing.get("client_id", "")
            existing_created = existing.get("sys_created_on", "")
            existing_by = existing.get("sys_created_by", "")
            existing_active = existing.get("active", "")
            return (
                f"⚠️  OAuth application already exists with this name.\n\n"
                f"An oauth_entity record named '{app_name}' was found:\n"
                f"  sys_id:      {existing_sys_id}\n"
                f"  client_id:   {existing_client_id}\n"
                f"  active:      {existing_active}\n"
                f"  created:     {existing_created} by {existing_by}\n\n"
                f"Options:\n"
                f"  1. Reuse this record — update your .env with the client_id above and the\n"
                f"     client_secret you set when it was originally created.\n"
                f"  2. Delete the existing record in ServiceNow, then retry this tool.\n"
                f"  3. Use a different name by passing a custom `name` argument to this tool.\n\n"
                f"If you no longer have the original client_secret, you must delete the record\n"
                f"and recreate it (option 2)."
            )

        oauth_app_data = {
            "name": app_name,
            "client_secret": client_secret,
            "type": "client",  # This is an OAuth client (inbound)
            "default_grant_type": "client_credentials",  # Correct field name
            "access_token_lifespan": access_token_lifespan,
            "refresh_token_lifespan": refresh_token_lifespan,
            "user": user_sys_id  # Correct field name (not oauth_application_user)
        }

        # Note: Scopes are managed via oauth_entity_scope table records, not a field
        # on oauth_entity. Proper scope assignment is backlogged.

        create_response = client.create_record(
            table_name="oauth_entity",
            data=oauth_app_data,
            scope=scope
        )

        if not create_response["success"]:
            status_code = create_response["status_code"]
            error_detail = create_response.get("error", "")
            # Surface the raw error body so the actual cause is visible (e.g. duplicate
            # name, permission denied, missing field). Do not assume a specific root cause.
            return (
                f"❌ Failed to create OAuth application (HTTP {status_code})\n\n"
                f"{format_error(status_code, error_detail)}\n\n"
                f"Common causes:\n"
                f"  • Duplicate name — an oauth_entity with this name already exists "
                f"(pre-flight check should have caught this; if it didn't, the record may\n"
                f"    have been created between the check and the insert)\n"
                f"  • Session scope — the configured user's UI scope is not Global\n"
                f"  • Insufficient permissions — the user lacks write access to oauth_entity\n\n"
                f"Check .mcp_diagnostic.log for the full ServiceNow response body."
            )

        app_record = create_response["result"]
        app_sys_id = app_record.get("sys_id")
        client_id = app_record.get("client_id")

        if not client_id:
            return (
                f"❌ OAuth application created but client_id was not generated.\n"
                f"Application sys_id: {app_sys_id}\n"
                f"Please check the oauth_entity record in ServiceNow."
            )

        # Re-fetch to verify actual stored scope — oauth_entity ignores sysparm_scope
        actual_scope = scope
        scope_warning = ""
        if app_sys_id:
            refetch = client.query_table(
                table_name="oauth_entity",
                query=f"sys_id={app_sys_id}",
                fields=["sys_id", "sys_scope"],
                limit=1,
                display_value="true"
            )
            if refetch["success"] and refetch["result"]:
                fetched_scope = refetch["result"][0].get("sys_scope", "") or ""
                if fetched_scope:
                    actual_scope = fetched_scope
                if scope and fetched_scope and fetched_scope.lower() != scope.lower():
                    scope_warning = (
                        f"⚠️  Scope mismatch: record created in '{fetched_scope}' "
                        f"instead of requested '{scope}'.\n"
                        f"   oauth_entity ignores sysparm_scope regardless of auth method — "
                        f"the record inherits your session's active application scope.\n"
                        f"   To create in global scope: open the Application Picker "
                        f"(top-right globe icon) → set Global as default → re-run setup."
                    )

        # Step 10: Store in keychain if requested
        keychain_output = ""
        if store_in_keychain:
            success, message = store_credentials_in_keychain(instance_config.alias, client_id, client_secret)
            keychain_output = f"\n💾 Credentials Storage:\n\n{message}\n\n"

        # Step 10b: Update .env file if requested
        env_output = ""
        if update_env:
            success, message = update_env_file(instance_config.alias, client_id, client_secret)
            env_output = f"\n📝 .env File Update:\n\n{message}\n\n"

        # Step 10c: Suggest attributed service account if not requested
        sa_output = ""
        if not create_service_account:
            attributed_name = f"{user_display_name} (Claude assisted)"
            sa_output = (
                f"\n💡 Recommended: AI-attributed service account\n\n"
                f"  API calls will appear in ServiceNow audit logs as '{attributed_name}'\n"
                f"  instead of '{user_display_name}', making AI-assisted changes\n"
                f"  distinguishable from human work.\n\n"
                f"  Re-run with create_service_account=True (and update_env=True) to set this up.\n"
            )

        # Step 10d: Create attributed service account if requested
        sa_creation_output = ""
        if create_service_account:
            from ...core.service_account import create_attributed_service_account

            if not client._prepare_request():
                sa_creation_output = "\n⚠️  Could not create attributed service account: authentication failed.\n"
            else:
                sa_result = create_attributed_service_account(
                    session=client.session,
                    instance_url=instance_config.instance,
                    setup_username=user,
                    setup_user_sys_id=user_sys_id,
                    setup_user_display_name=user_display_name,
                    setup_user_email=user_record.get("email", ""),
                    hostname=hostname,
                )
                if sa_result["success"]:
                    attributed_user = sa_result["user_name"]
                    roles_line = (
                        f"{sa_result['roles_assigned']} roles replicated"
                        if not sa_result["roles_skipped"]
                        else "⚠️  Roles not replicated (user_admin required — assign manually)"
                    )
                    sa_creation_output = (
                        f"\n✅ Attributed service account created\n\n"
                        f"  Account: {attributed_user}\n"
                        f"  Roles: {roles_line}\n"
                    )
                    if update_env:
                        _, env_sa_msg = update_env_file(
                            instance_config.alias,
                            client_id,
                            client_secret,
                            username=attributed_user,
                            password=sa_result["password"],
                        )
                        sa_creation_output += f"  {env_sa_msg}\n"
                    else:
                        sa_creation_output += (
                            "  ⚠️  Credentials not saved — re-run with update_env=True to persist.\n"
                        )
                else:
                    sa_creation_output = (
                        f"\n⚠️  Attributed service account creation failed: {sa_result.get('error')}\n"
                        f"  OAuth setup completed successfully. Create the account manually.\n"
                    )

        # Step 11: Format output
        token_endpoint = f"{instance_config.instance}/oauth_token.do"

        output = [
            "✅ OAuth application created successfully!",
            "",
            f"Application Name: {app_name}",
            f"Application sys_id: {app_sys_id}",
            f"Instance: {instance_config.instance}",
            f"Application Scope: {actual_scope}",
            f"OAuth Application User: {user_display_name} ({user})",
            f"Grant Type: client_credentials",
            "",
            "🔑 Client Credentials:",
            "",
            f"  Client ID: {client_id}",
            f"  Client Secret: {client_secret[:8]}{'*' * (len(client_secret) - 8)}" if len(client_secret) > 8 else f"  Client Secret: {client_secret}",
        ]

        if secret_generated:
            output.append(f"  (Secret was auto-generated)")

        output.extend([
            "",
            f"  Token Endpoint: {token_endpoint}",
        ])

        if scope_warning:
            output.append("")
            output.append(scope_warning)

        if property_output:
            output.extend(["", property_output.strip()])

        if keychain_output:
            output.append(keychain_output.strip())

        if env_output:
            output.append(env_output.strip())

        # Determine usage context for next steps
        usage_hints = []
        name_lower = name.lower()

        if "servicenow" in name_lower and "mcp" in name_lower:
            usage_hints.append("  • For ServiceNow MCP Server: Configure these credentials in your MCP settings")
            usage_hints.append("  • Navigate to: All > Model Context Protocol > MCP Server Settings")
        elif "mcp" in name_lower or "claude" in name_lower:
            usage_hints.append("  • Configure credentials in your application's .env or configuration file")
            usage_hints.append("  • Restart your MCP server or Claude Desktop to apply changes")
        elif "ci/cd" in name_lower or "github" in name_lower or "pipeline" in name_lower:
            usage_hints.append("  • Add credentials to your CI/CD secrets or environment variables")
            usage_hints.append("  • Reference these in your pipeline configuration")
        else:
            usage_hints.append("  • Configure these credentials in your application or tool")
            usage_hints.append("  • Refer to your application's OAuth documentation for setup")

        output.extend([
            "",
            "📋 Next Steps:",
            "",
            "  1. Test OAuth authentication:",
            "",
            f"     curl -X POST {token_endpoint} \\",
            f"       -u {client_id}:{client_secret} \\",
            f"       -d \"grant_type=client_credentials\"",
            "",
            "  2. Configure your application:",
            "",
        ])

        output.extend(usage_hints)

        output.extend([
            "",
            "  3. Example .env configuration (if applicable):",
            "",
            f"     SERVICENOW_INSTANCE={instance_config.instance}",
            f"     SERVICENOW_CLIENT_ID={client_id}",
            f"     SERVICENOW_CLIENT_SECRET={client_secret}",
            "",
            "💡 Security Tips:",
            "",
            "  • Client credentials grant full API access for the assigned user",
            "  • Use a dedicated service account with minimal required permissions",
            "  • Rotate credentials periodically (recommended: every 90 days)",
            "  • Monitor OAuth token usage in ServiceNow: System OAuth > OAuth Token Usage",
            "",
            f"📊 Token Lifespans:",
            "",
            f"  • Access Token: {access_token_lifespan} seconds ({access_token_lifespan // 60} minutes)",
        ])

        if refresh_token_lifespan > 0:
            output.append(f"  • Refresh Token: {refresh_token_lifespan} seconds ({refresh_token_lifespan // 60} minutes)")
        else:
            output.append(f"  • Refresh Token: Disabled (no refresh tokens)")

        if sa_output:
            output.append(sa_output.strip())
        if sa_creation_output:
            output.append(sa_creation_output.strip())

        return "\n".join(output)
