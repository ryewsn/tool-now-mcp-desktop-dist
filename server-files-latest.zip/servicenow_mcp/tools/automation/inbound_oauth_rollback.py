"""Inbound OAuth Rollback Tools

Provides rollback functionality to delete inbound OAuth applications
created by setup_inbound_oauth.
"""

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error
from datetime import datetime, timedelta


def register_tools(mcp: FastMCP):
    """Register inbound OAuth rollback tools with the MCP server."""

    @mcp.tool()
    def rollback_inbound_oauth(
        name: str,
        instance: str = None
    ) -> str:
        """
        Delete an inbound OAuth application (oauth_entity) created by setup_inbound_oauth and intelligently reverse system property changes. Use for cleanup, rollback after testing, or credential rotation.

        **Intelligent property rollback** (based on timestamp comparison within a 2-minute window):
        - setup CREATED property → rollback DELETES it
        - setup ENABLED property → rollback RESTORES to disabled
        - setup didn't touch it → NO ACTION

        When multiple instances are configured, you MUST ask the user which instance to use before calling this tool. Never assume which instance to use.

        Args:
            name: OAuth application name to delete.

        Returns:
            Summary of deleted objects and system property status
        """

        # Step 1: Validate instance confirmation for multi-instance setups
        confirmation_error = require_instance_confirmation(instance, "delete OAuth application")
        if confirmation_error:
            return confirmation_error

        # Step 2: Validate required parameters
        if not name:
            return "❌ Error: Application name is required"

        # Step 3: Get client for the specified instance
        client = get_client(instance)
        instance_config = client.config

        # Step 4: Find OAuth entity by name (with creation timestamp)
        query_response = client.query_table(
            table_name="oauth_entity",
            query=f"name={name}^type=client",
            fields=["sys_id", "name", "client_id", "user", "sys_created_on"],
            limit=1
        )

        if not query_response["success"]:
            return format_error(query_response["status_code"], query_response.get("error", ""))

        if not query_response["result"]:
            return (
                f"❌ OAuth application '{name}' not found\n\n"
                f"No inbound OAuth application with name '{name}' exists in {instance_config.instance}.\n\n"
                f"To see all OAuth applications:\n"
                f"  Navigate to: System OAuth > Application Registry\n"
                f"  Filter: Type = client"
            )

        oauth_entity = query_response["result"][0]
        oauth_sys_id = oauth_entity["sys_id"]
        oauth_name = oauth_entity["name"]
        client_id = oauth_entity.get("client_id", "N/A")
        oauth_created_on = oauth_entity.get("sys_created_on", "")

        # Step 5: Delete the OAuth entity
        delete_response = client.delete_record(
            table_name="oauth_entity",
            sys_id=oauth_sys_id
        )

        if not delete_response["success"]:
            return (
                f"❌ Failed to delete OAuth application\n\n"
                f"{format_error(delete_response['status_code'], delete_response.get('error', ''))}\n\n"
                f"You may need to delete it manually:\n"
                f"1. Navigate to: System OAuth > Application Registry\n"
                f"2. Search for: {oauth_name}\n"
                f"3. Open the record and click 'Delete'"
            )

        deleted_objects = [
            {
                "type": "OAuth Entity",
                "name": oauth_name,
                "sys_id": oauth_sys_id,
                "client_id": client_id
            }
        ]

        # Step 6: Intelligent system property rollback based on setup actions
        # Determine what setup did and reverse it:
        # - If setup CREATED the property → DELETE it
        # - If setup ENABLED the property → RESTORE to disabled
        # - If setup didn't touch it → DO NOTHING

        property_message = ""
        prop_query = client.query_table(
            table_name="sys_properties",
            query="name=glide.oauth.inbound.client.credential.grant_type.enabled",
            fields=["sys_id", "name", "value", "sys_created_on", "sys_updated_on"],
            limit=1
        )

        if prop_query["success"] and prop_query["result"]:
            prop = prop_query["result"][0]
            prop_sys_id = prop["sys_id"]
            prop_value = prop.get("value", "")
            prop_created_on = prop.get("sys_created_on", "")
            prop_updated_on = prop.get("sys_updated_on", "")

            # Parse timestamps (ServiceNow format: YYYY-MM-DD HH:MM:SS)
            try:
                oauth_time = datetime.strptime(oauth_created_on, "%Y-%m-%d %H:%M:%S")
                prop_created_time = datetime.strptime(prop_created_on, "%Y-%m-%d %H:%M:%S")
                prop_updated_time = datetime.strptime(prop_updated_on, "%Y-%m-%d %H:%M:%S")

                time_window = timedelta(minutes=2)  # Setup and rollback typically within 2 minutes

                # Decision logic based on timestamps
                if abs(prop_created_time - oauth_time) <= time_window:
                    # Property created around same time as OAuth app → setup created it → DELETE
                    prop_delete = client.delete_record(
                        table_name="sys_properties",
                        sys_id=prop_sys_id
                    )

                    if prop_delete["success"]:
                        deleted_objects.append({
                            "type": "System Property",
                            "name": "glide.oauth.inbound.client.credential.grant_type.enabled",
                            "sys_id": prop_sys_id
                        })
                        property_message = "\n✓ System property deleted (was created by setup)\n"
                    else:
                        property_message = f"\n⚠️  Could not delete system property: {prop_delete.get('error', 'Unknown error')}\n"

                elif prop_created_time < oauth_time and abs(prop_updated_time - oauth_time) <= time_window and prop_value == "true":
                    # Property existed before OAuth app but was updated around same time → setup enabled it → DISABLE
                    prop_update = client.update_record(
                        table_name="sys_properties",
                        sys_id=prop_sys_id,
                        data={"value": "false"}
                    )

                    if prop_update["success"]:
                        property_message = "\n✓ System property restored to disabled (was enabled by setup)\n"
                    else:
                        property_message = f"\n⚠️  Could not restore system property: {prop_update.get('error', 'Unknown error')}\n"

                else:
                    # Property was not modified by setup → DO NOTHING
                    property_message = "\n✓ System property unchanged (was already configured before setup)\n"

            except (ValueError, TypeError) as e:
                # Timestamp parsing failed - fall back to no action
                property_message = f"\n⚠️  Could not determine system property action (timestamp parsing failed): {str(e)}\n"
        else:
            # Property doesn't exist or query failed
            property_message = "\n✓ System property not found (no cleanup needed)\n"

        # Step 7: Format output
        output = [
            "✅ Inbound OAuth Application Rollback Complete!",
            "",
            f"Instance: {instance_config.instance}",
            f"Deleted {len(deleted_objects)} object(s)",
            "",
            "🗑️  Deleted Objects:",
            "",
        ]

        for obj in deleted_objects:
            output.append(f"  ✓ {obj['type']}: {obj['name']}")
            if obj['type'] == "OAuth Entity":
                output.append(f"    Client ID: {obj.get('client_id', 'N/A')}")
            output.append(f"    sys_id: {obj['sys_id']}")
            output.append("")

        if property_message:
            output.append(property_message)

        output.extend([
            "📋 Next Steps:",
            "",
            "  • OAuth application has been deleted from ServiceNow",
            "  • Any issued OAuth tokens are now invalid",
            "  • If you configured this app in .env, remove those credentials",
            "  • If you want to recreate, run setup_inbound_oauth again",
        ])

        return "\n".join(output)
