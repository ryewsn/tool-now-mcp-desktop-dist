"""Inbound OAuth Rollback Tools

Provides rollback functionality to delete inbound OAuth applications
created by setup_inbound_oauth.
"""

from mcp.server.mcpserver import MCPServer
from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error
from ...core.inbound_oauth import CLIENT_CREDENTIALS_PROPERTY, property_row_scope
from ...core.rest_verify import delete_with_readback
from ...core.script_runner import GLOBAL_SCOPE_SYS_ID
from datetime import datetime, timedelta


def register_tools(mcp: MCPServer):
    """Register inbound OAuth rollback tools with the MCP server."""

    @mcp.tool()
    def rollback_inbound_oauth(
        name: str,
        instance: str = None
    ) -> str:
        """
        Delete an inbound OAuth application (oauth_entity) created by setup_inbound_oauth and intelligently reverse system property changes. Use for cleanup, rollback after testing, or credential rotation.

        **Intelligent property rollback** (based on timestamp comparison within a 2-minute window):
        - setup CREATED property → rollback DELETES it
        - setup ENABLED property → rollback RESTORES to disabled
        - setup didn't touch it → NO ACTION

        The property step acts only on the Global row (rows in other scopes are reported, never changed); the evidence (seconds between the records) is shown in the result. Order: the OAuth entity is deleted first and read back by sys_id, and the property is touched only after that delete was accepted (a failed entity delete leaves the property alone). The exception is a self-delete, when this server authenticates with the application being deleted: then the property step runs FIRST and the entity LAST, because later calls can fail once the app is gone, and a failed final read-back is reported as "accepted, not verified". A 404 is reported as "not found or not visible", never as deleted. Requires no Script Runner.

        When multiple instances are configured, you MUST ask the user which instance to use before calling this tool. Never assume which instance to use.

        Args:
            name: OAuth application name to delete.

        Returns:
            Summary of deleted objects and system property status
        """

        # Step 1: Validate instance confirmation for multi-instance setups
        confirmation_error = require_instance_confirmation(instance, "delete OAuth application")
        if confirmation_error:
            return confirmation_error

        # Step 2: Validate required parameters
        if not name:
            return "❌ Error: Application name is required"

        # Step 3: Get client for the specified instance
        client = get_client(instance)
        instance_config = client.config

        # Step 4: Find OAuth entity by name (with creation timestamp)
        query_response = client.query_table(
            table_name="oauth_entity",
            query=f"name={name}^type=client",
            fields=["sys_id", "name", "client_id", "user", "sys_created_on"],
            limit=2
        )

        if not query_response["success"]:
            return format_error(query_response["status_code"], query_response.get("error", ""))

        if not query_response["result"]:
            return (
                f"❌ OAuth application '{name}' not found\n\n"
                f"No inbound OAuth application with name '{name}' exists in {instance_config.instance}.\n\n"
                f"To see all OAuth applications:\n"
                f"  Navigate to: System OAuth > Application Registry\n"
                f"  Filter: Type = client"
            )

        if len(query_response["result"]) > 1:
            candidates = "\n".join(
                f"  • {r.get('name')} (sys_id: {r['sys_id']}, client_id: {r.get('client_id', 'N/A')})"
                for r in query_response["result"]
            )
            return (
                f"❌ More than one inbound OAuth application is named '{name}'. Nothing was changed.\n\n"
                f"Candidates:\n{candidates}\n\n"
                f"Delete the right one manually (System OAuth > Application Registry) or rename the others first."
            )

        oauth_entity = query_response["result"][0]
        oauth_sys_id = oauth_entity["sys_id"]
        oauth_name = oauth_entity["name"]
        client_id = oauth_entity.get("client_id", "N/A")
        oauth_created_on = oauth_entity.get("sys_created_on", "")

        base_url = instance_config.instance
        if not client._prepare_request():
            return "❌ Authentication failed: could not prepare credentials for the delete requests. Nothing was deleted."

        # The session may authenticate with the very app being deleted. Then every request
        # after the entity delete can fail, so the entity is deleted LAST.
        self_delete = bool(instance_config.uses_oauth and instance_config.client_id
                           and client_id != "N/A" and instance_config.client_id == client_id)

        # System property rollback (acts on the Global row only; runs first only for a self-delete).
        # - setup CREATED the property (created within the window of the app) -> DELETE it
        # - setup ENABLED the property (existed before, updated within the window) -> DISABLE it
        # - otherwise -> NO ACTION
        # The evidence (seconds between the records) is always reported, never acted on silently.
        deleted_objects = []
        property_lines = []

        def _property_step():
            prop_name = CLIENT_CREDENTIALS_PROPERTY
            prop_query = client.query_table(
                table_name="sys_properties",
                query=f"name={prop_name}",
                fields=["sys_id", "name", "value", "sys_scope", "sys_created_on", "sys_updated_on"],
                limit=5
            )

            if not prop_query["success"]:
                property_lines.append(
                    f"⚠️  Could not read the system property (HTTP {prop_query['status_code']}); no property action taken"
                )
            else:
                rows = prop_query["result"]
                global_rows = [r for r in rows if property_row_scope(r) == GLOBAL_SCOPE_SYS_ID]
                strays = [r for r in rows if property_row_scope(r) != GLOBAL_SCOPE_SYS_ID]
                for r in strays:
                    if not property_row_scope(r):
                        property_lines.append(
                            f"⚠️  Property row {r['sys_id']}: scope not readable; no action taken."
                        )
                        continue
                    property_lines.append(
                        f"⚠️  Stray property row in scope '{property_row_scope(r)}' (sys_id {r['sys_id']}) left untouched; "
                        f"this property belongs to Global. Review it manually."
                    )

                if not global_rows:
                    property_lines.append("✓ No Global system property row found (no cleanup needed)")
                else:
                    prop = global_rows[0]
                    prop_sys_id = prop["sys_id"]
                    prop_value = prop.get("value", "")
                    try:
                        oauth_time = datetime.strptime(oauth_created_on, "%Y-%m-%d %H:%M:%S")
                        prop_created_time = datetime.strptime(prop.get("sys_created_on", ""), "%Y-%m-%d %H:%M:%S")
                        prop_updated_time = datetime.strptime(prop.get("sys_updated_on", ""), "%Y-%m-%d %H:%M:%S")
                    except (ValueError, TypeError) as e:
                        property_lines.append(
                            f"⚠️  Could not determine system property action (timestamp parsing failed): {str(e)}"
                        )
                    else:
                        window_s = 120  # setup and rollback are matched within 2 minutes
                        created_delta = int((prop_created_time - oauth_time).total_seconds())
                        updated_delta = int((prop_updated_time - oauth_time).total_seconds())
                        evidence = (
                            f"evidence: property created {created_delta:+d} s and last updated {updated_delta:+d} s "
                            f"relative to the app; decision window {window_s} s"
                        )

                        if abs(created_delta) <= window_s:
                            outcome = delete_with_readback(client.session, base_url, "sys_properties", prop_sys_id, timeout=30)
                            if outcome["outcome"] == "deleted":
                                deleted_objects.append({
                                    "type": "System Property",
                                    "name": prop_name,
                                    "sys_id": prop_sys_id
                                })
                                property_lines.append(f"✓ System property deleted (was created by setup; {evidence})")
                            elif outcome["outcome"] == "not_found":
                                property_lines.append(f"⚠️  System property {outcome['message']}; not counted as deleted ({evidence})")
                            else:
                                property_lines.append(f"⚠️  Could not delete system property: {outcome['message']} ({evidence})")

                        elif created_delta < 0 and abs(updated_delta) <= window_s and prop_value == "true":
                            prop_update = client.update_record(
                                table_name="sys_properties",
                                sys_id=prop_sys_id,
                                data={"value": "false"},
                                unscoped_ok="DEFERRED-F4 (backlog item Route the remaining raw REST writes (ledger T17)): sys_properties update by sys_id"
                            )
                            if not prop_update["success"]:
                                property_lines.append(
                                    f"⚠️  Could not restore system property: {prop_update.get('error', 'Unknown error')} ({evidence})"
                                )
                            else:
                                check = client.query_table(
                                    table_name="sys_properties",
                                    query=f"sys_id={prop_sys_id}",
                                    fields=["sys_id", "value"],
                                    limit=1
                                )
                                if check["success"] and check["result"] and check["result"][0].get("value") == "false":
                                    property_lines.append(f"✓ System property restored to disabled (was enabled by setup; confirmed by read-back; {evidence})")
                                else:
                                    property_lines.append(f"⚠️  System property update was accepted but the read-back did not show value=false ({evidence})")

                        else:
                            property_lines.append(f"✓ System property unchanged (no sign setup touched it; {evidence})")

        self_delete_warning = (
            "This server authenticates with this application, so its token stops working once the app is deleted."
            if self_delete else ""
        )

        # Order. When the server authenticates with the app being deleted, every call after the
        # entity delete can fail, so the property step runs FIRST and the entity is deleted LAST.
        # Otherwise keep the long-standing order: delete the entity first and touch the property
        # only after that delete was accepted (deleted, or accepted but not verified). A failed
        # entity delete (403, 404, still present, ...) leaves the property untouched.
        if self_delete:
            _property_step()

        # Delete the OAuth entity, then read it back
        entity_outcome = delete_with_readback(client.session, base_url, "oauth_entity", oauth_sys_id, timeout=30)

        entity_accepted = entity_outcome["outcome"] == "deleted" or (
            entity_outcome["outcome"] == "error" and entity_outcome.get("unverified"))
        if not self_delete:
            if entity_accepted:
                _property_step()
            else:
                property_lines.append(
                    "✓ System property left untouched (the OAuth application was not deleted)")

        property_message = "\n" + "\n".join(property_lines) + "\n"

        if entity_outcome["outcome"] == "deleted":
            deleted_objects.insert(0, {
                "type": "OAuth Entity",
                "name": oauth_name,
                "sys_id": oauth_sys_id,
                "client_id": client_id
            })
        elif entity_outcome["outcome"] == "error" and entity_outcome.get("unverified"):
            return (
                "⚠️  Inbound OAuth application delete accepted, not verified\n\n"
                f"Instance: {instance_config.instance}\n"
                f"The delete of '{oauth_name}' (sys_id: {oauth_sys_id}) was accepted (HTTP {entity_outcome['status_code']}), "
                f"but the read-back did not confirm it (read-back HTTP {entity_outcome.get('readback_status') or 'n/a'}). "
                "Deletion could not be confirmed from here.\n"
                + (f"{self_delete_warning}\n" if self_delete_warning else "")
                + f"{property_message}\n"
                "Confirm in ServiceNow: System OAuth > Application Registry, search for the name above.\n"
                "If you configured this app in .env, remove those credentials once deletion is confirmed."
            )
        else:
            heading = (
                "❔ OAuth application not found or not visible to this user (not counted as deleted)"
                if entity_outcome["outcome"] == "not_found"
                else "❌ Failed to delete OAuth application"
            )
            return (
                f"{heading}\n\n"
                f"{entity_outcome['message']}"
                + (f" (HTTP {entity_outcome['status_code']})" if entity_outcome.get("status_code") else "")
                + "\n"
                + (f"{self_delete_warning}\n" if self_delete_warning else "")
                + f"{property_message}\n"
                f"You may need to delete it manually:\n"
                f"1. Navigate to: System OAuth > Application Registry\n"
                f"2. Search for: {oauth_name}\n"
                f"3. Open the record and click 'Delete'"
            )

        # Step 7: Format output
        output = [
            "✅ Inbound OAuth Application Rollback Complete!",
            "",
            f"Instance: {instance_config.instance}",
            f"Deleted {len(deleted_objects)} object(s) (each confirmed gone by a read-back)",
            "",
            "🗑️  Deleted Objects:",
            "",
        ]

        for obj in deleted_objects:
            output.append(f"  ✓ {obj['type']}: {obj['name']}")
            if obj['type'] == "OAuth Entity":
                output.append(f"    Client ID: {obj.get('client_id', 'N/A')}")
            output.append(f"    sys_id: {obj['sys_id']}")
            output.append("")

        if property_message:
            output.append(property_message)

        output.extend([
            "📋 Next Steps:",
            "",
            "  • OAuth application has been deleted from ServiceNow",
            "  • Tokens issued by this app may stop working (not verified against a live instance)",
            "  • If you configured this app in .env, remove those credentials",
            "  • If you want to recreate, run setup_inbound_oauth again",
        ])
        if self_delete:
            output.append("  • Note: this server authenticates with this application, so it will need new credentials before its next call")

        return "\n".join(output)
