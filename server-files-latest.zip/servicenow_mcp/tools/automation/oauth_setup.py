"""OAuth Integration Setup Tools

Automates creation of OAuth-protected API integrations in ServiceNow by parsing
OpenAPI specifications. For non-OpenAPI documentation, Claude Desktop extracts
OAuth configuration before calling this tool.
"""

import re

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error
from ...core.oauth_utils import (
    parse_openapi_spec,
    OpenAPIParseError,
    format_scopes_for_servicenow
)


def detect_provider(base_url: str, token_url: str, auth_url: str = "") -> str:
    """Detect OAuth provider from URLs. Returns provider name (e.g., "GitHub", "Google") or "Unknown"."""
    all_urls = f"{base_url} {token_url} {auth_url}".lower()

    # Provider detection patterns
    if "github.com" in all_urls or "github.io" in all_urls:
        return "GitHub"
    elif "googleapis.com" in all_urls or "google.com" in all_urls:
        return "Google"
    elif "microsoft.com" in all_urls or "microsoftonline.com" in all_urls or "graph.microsoft.com" in all_urls:
        return "Microsoft"
    elif "salesforce.com" in all_urls or "force.com" in all_urls:
        return "Salesforce"
    elif "slack.com" in all_urls:
        return "Slack"
    elif "zoom.us" in all_urls:
        return "Zoom"
    elif "stripe.com" in all_urls:
        return "Stripe"
    elif "spotify.com" in all_urls:
        return "Spotify"
    elif "linkedin.com" in all_urls:
        return "LinkedIn"
    elif "twitter.com" in all_urls or "x.com" in all_urls:
        return "Twitter"
    elif "facebook.com" in all_urls or "fb.com" in all_urls:
        return "Facebook"

    return "Unknown"


def find_oauth_api_scripts(provider: str, instance: str = None) -> list:
    """Find OAuth API Scripts in sys_script_include matching the provider. Returns list of {"name", "sys_id"} dicts."""
    if provider == "Unknown":
        return []

    client = get_client(instance)

    # Search for Script Includes that match the provider and OAuth
    response = client.query_table(
        table_name="sys_script_include",
        query=f"nameLIKE{provider}^nameLIKEOAuth^ORnameLIKEoauth",
        fields=["name", "sys_id", "description"],
        limit=10
    )

    if not response["success"] or not response["result"]:
        return []

    return response["result"]


def register_tools(mcp: FastMCP):
    """Register OAuth automation tools with the MCP server."""

    @mcp.tool()
    def setup_oauth_integration(
        client_id: str,
        client_secret: str,
        spec_source: str = "",
        spec_type: str = "url",
        name: str = "",
        token_url: str = "",
        redirect_url: str = "",
        grant_type: str = "client_credentials",
        scopes: str = "",
        oauth_api_script: str = "",
        scope: str = "global",
        test_authentication: bool = True,
        instance: str = None
    ) -> str:
        """
        Create an OAuth integration in ServiceNow (oauth_entity, oauth_entity_profile, oauth_2_0_credentials,
        sys_alias, http_connection) from an OpenAPI spec or manual parameters.

        CRITICAL CONSTRAINTS (causes immediate failure if violated):
        1. sys_alias type="connection" — http_connection CANNOT pair with credential-only aliases (type="credential")
        2. Object creation order (ServiceNow Business Rule requirement):
           sys_alias MUST be created BEFORE http_connection. Full order:
           oauth_entity → oauth_2_0_credentials → sys_alias → http_connection → update sys_alias
        3. Application scope MUST be validated before creating any records (avoid partial state)
        4. All related objects MUST be created in the SAME application scope

        **Required roles:** oauth_admin (or admin) — missing role causes silent failures or 403 errors.
        **Basic Auth:** scope parameter ignored; records inherit user's active UI scope.

        Args:
            client_id: OAuth client ID (REQUIRED)
            client_secret: OAuth client secret (REQUIRED)
            spec_source: Documentation source (URL, file path, or content). Omit to provide all params manually.
            spec_type: "url", "content", or "filepath" (default: "url")
            token_url: OAuth token endpoint; extracted from spec if omitted
            redirect_url: OAuth redirect URI; auto-constructed as {instance}/oauth_redirect.do if omitted
            grant_type: client_credentials | authorization_code | password (deprecated) | implicit (deprecated)
            scopes: Space-separated OAuth scopes; extracted from spec if omitted
            oauth_api_script: Name of OAuth API Script Include (e.g., "OauthAPIScriptForGitHub")
            scope: ServiceNow application scope ID (default: "global"). Use "x_123_myapp" for scoped apps.
            test_authentication: Whether to test OAuth flow after creation (default: True)

        Returns:
            Summary of created objects with sys_ids and test results
        """

        # ============================================================
        # STEP 1: VALIDATE REQUIRED PARAMETERS AND INSTANCE
        # ============================================================

        # Check if instance confirmation is needed
        confirmation_error = require_instance_confirmation(instance, "create OAuth integration")
        if confirmation_error:
            return confirmation_error

        # Only client_id and client_secret are strictly required
        missing_params = []
        if not client_id:
            missing_params.append("client_id (OAuth client ID)")
        if not client_secret:
            missing_params.append("client_secret (OAuth client secret)")

        if missing_params:
            return (
                "❌ Missing required parameters:\n\n" +
                "\n".join(f"  • {p}" for p in missing_params) +
                "\n\nPlease provide these values and try again."
            )

        # ============================================================
        # STEP 2: PARSE OPENAPI SPEC (if provided)
        # ============================================================

        spec_data = {}

        if spec_source:
            try:
                spec_data = parse_openapi_spec(spec_source, spec_type)
            except OpenAPIParseError as e:
                return (
                    f"❌ spec_source is not valid OpenAPI format.\n\n"
                    f"Error: {e}\n\n"
                    f"If this is non-OpenAPI documentation (HTML, Markdown, etc.), please:\n"
                    f"  1. Read the documentation and extract OAuth configuration\n"
                    f"  2. Call this tool with explicit parameters:\n"
                    f"     - name: API name\n"
                    f"     - token_url: OAuth token endpoint\n"
                    f"     - grant_type: OAuth grant type\n"
                    f"     - scopes: OAuth scopes (space-separated)\n"
                    f"     - Do NOT provide spec_source for non-OpenAPI docs"
                )
            except Exception as e:
                return f"❌ Unexpected error parsing OpenAPI spec:\n\n{e}"

        # Extract configuration from spec (or use empty defaults)
        api_name = name or spec_data.get("name", "")
        base_url = spec_data.get("base_url")
        spec_token_url = spec_data.get("token_url")
        spec_auth_url = spec_data.get("auth_url")
        spec_scopes = spec_data.get("scopes", {})
        spec_grant_type = spec_data.get("grant_type")
        description = spec_data.get("description", "")

        # Validate we have minimum required info
        if not api_name:
            if not name:
                return (
                    "❌ Integration name is required.\n\n"
                    "Either provide 'name' parameter or 'spec_source' that contains API name."
                )
            api_name = name

        # Use provided values or fall back to spec values
        final_token_url = token_url or spec_token_url
        final_grant_type = grant_type if grant_type != "client_credentials" else (spec_grant_type or grant_type)
        final_scopes = scopes or format_scopes_for_servicenow(spec_scopes)

        # Validate we have required OAuth token URL
        if not final_token_url:
            return (
                "❌ OAuth token URL is required.\n\n"
                "Token URL not found in documentation and not provided manually.\n"
                "Please provide it using the 'token_url' parameter:\n"
                "  Example: token_url='https://auth.example.com/oauth/token'\n\n"
                "Common patterns:\n"
                "  • https://api.example.com/oauth/token\n"
                "  • https://oauth.example.com/token\n"
                "  • https://example.com/oauth2/token"
            )

        # ============================================================
        # STEP 3: GET CLIENT AND AUTO-CONSTRUCT REDIRECT URL
        # ============================================================

        client = get_client(instance)
        instance_config = client.config

        # Auto-construct redirect URL if not provided (ServiceNow standard pattern)
        if final_grant_type == "authorization_code" and not redirect_url:
            redirect_url = f"{instance_config.instance}/oauth_redirect.do"
            # Note: We don't error - we auto-construct it from instance URL

        # ============================================================
        # STEP 4: VALIDATE AND CONFIRM SCOPE
        # ============================================================

        # Get available scopes to show user
        scopes_response = client.get_application_scopes()
        available_scopes = []

        if scopes_response["success"] and scopes_response["result"]:
            available_scopes = scopes_response["result"]

        # Validate the provided scope exists (skip validation for 'global' as it's always available)
        if scope and scope != "global":
            scope_exists = any(s.get("scope") == scope for s in available_scopes)
            if not scope_exists:
                scope_list = "\n".join(f"  • {s.get('scope')} - {s.get('name')}" for s in available_scopes[:15])
                if len(available_scopes) > 15:
                    scope_list += f"\n  ... and {len(available_scopes) - 15} more"
                return (
                    f"❌ Scope '{scope}' not found in ServiceNow instance.\n\n"
                    "Available scopes (use scope ID, not name):\n"
                    "  • global - Global scope (default)\n"
                    f"{scope_list}\n\n"
                    "Tip: Use the full scope ID (e.g., 'x_123_myapp'), not the display name."
                )

        # ============================================================
        # STEP 5: CREATE SERVICENOW OBJECTS
        # ============================================================

        created_objects = {}

        try:
            # ---------------------------------------------------------
            # 4a. Create OAuth Entity (oauth_entity) - Main OAuth Provider
            # ---------------------------------------------------------

            oauth_entity_data = {
                "name": api_name,
                "type": "oauth_provider",
                "active": "true",
                "client_id": client_id,
                "client_secret": client_secret,
                "token_url": final_token_url,
                "default_grant_type": final_grant_type,
                "access": "public"
            }

            if spec_auth_url:
                oauth_entity_data["auth_url"] = spec_auth_url

            if redirect_url:
                oauth_entity_data["redirect_url"] = redirect_url

            oauth_entity_response = client.create_record("oauth_entity", oauth_entity_data, scope=scope)

            if not oauth_entity_response["success"]:
                return f"❌ Failed to create OAuth Entity:\n\n{oauth_entity_response.get('error', 'Unknown error')}"

            oauth_entity_sys_id = oauth_entity_response["result"].get("sys_id")
            created_objects["oauth_entity"] = {
                "sys_id": oauth_entity_sys_id,
                "name": oauth_entity_data["name"]
            }

            # ---------------------------------------------------------
            # 4a.1. Detect Provider and Find Matching OAuth API Scripts
            # ---------------------------------------------------------

            detected_provider = detect_provider(base_url, final_token_url, spec_auth_url or "")

            if detected_provider != "Unknown":
                matching_scripts = find_oauth_api_scripts(detected_provider, instance)

                if matching_scripts:
                    created_objects["provider_recommendation"] = {
                        "provider": detected_provider,
                        "scripts": matching_scripts,
                        "oauth_entity_sys_id": oauth_entity_sys_id
                    }

            # ---------------------------------------------------------
            # 4b. Get OAuth Entity Profile (auto-created by ServiceNow)
            # ---------------------------------------------------------

            # ServiceNow automatically creates an OAuth Entity Profile when the OAuth Entity is created
            # Query for it instead of creating a duplicate
            import time
            time.sleep(0.5)  # Brief pause to ensure profile is created

            profile_query_response = client.query_table(
                table_name="oauth_entity_profile",
                query=f"oauth_entity={oauth_entity_sys_id}^grant_type={final_grant_type}",
                fields=["sys_id", "name", "grant_type"],
                limit=1
            )

            if not profile_query_response["success"] or not profile_query_response["result"]:
                return f"❌ Failed to find auto-created OAuth Entity Profile:\n\n{profile_query_response.get('error', 'No profile found')}"

            oauth_profile_sys_id = profile_query_response["result"][0]["sys_id"]
            oauth_profile_name = profile_query_response["result"][0]["name"]

            # Note: Scopes are managed via oauth_entity_scope table records, not a field
            # on oauth_entity_profile. Proper scope assignment is backlogged.

            created_objects["oauth_entity_profile"] = {
                "sys_id": oauth_profile_sys_id,
                "name": oauth_profile_name,
                "note": "Auto-created by ServiceNow"
            }

            # ---------------------------------------------------------
            # 4c. Create OAuth 2.0 Credential (oauth_2_0_credentials)
            # ---------------------------------------------------------

            oauth_credential_data = {
                "name": api_name,
                "oauth_entity_profile": oauth_profile_sys_id,
                "type": "oauth_2_0",
                "classification": "oauth_2_0",
                "active": "true",
                "application": "global",
                "applies_to": "all"
            }

            oauth_credential_response = client.create_record("oauth_2_0_credentials", oauth_credential_data, scope=scope)

            if not oauth_credential_response["success"]:
                return f"❌ Failed to create OAuth 2.0 Credential:\n\n{oauth_credential_response.get('error', 'Unknown error')}"

            oauth_credential_sys_id = oauth_credential_response["result"].get("sys_id")
            created_objects["oauth_2_0_credentials"] = {
                "sys_id": oauth_credential_sys_id,
                "name": oauth_credential_data["name"]
            }

            # ---------------------------------------------------------
            # 4d. Create Connection & Credential Alias (sys_alias)
            # ---------------------------------------------------------
            # NOTE: Must create alias BEFORE HTTP Connection due to Business Rule

            # Create a clean ID from the API name (uppercase, replace spaces with underscores)
            alias_id = api_name.upper().replace(" ", "_").replace("-", "_")

            connection_alias_data = {
                "name": api_name,
                "id": alias_id,
                "connection_type": "http_connection",
                "type": "connection",
                "is_internal": "false",
                "multiple_connections": "false"
            }

            connection_alias_response = client.create_record("sys_alias", connection_alias_data, scope=scope)

            if not connection_alias_response["success"]:
                # Connection Alias creation failed, note this in output
                created_objects["connection_alias"] = {
                    "error": "Failed to create Connection & Credential Alias",
                    "details": connection_alias_response.get('error', 'Unknown error'),
                    "suggestion": "This is required for HTTP Connection. Check permissions on sys_alias table."
                }
            else:
                connection_alias_sys_id = connection_alias_response["result"].get("sys_id")
                created_objects["connection_alias"] = {
                    "sys_id": connection_alias_sys_id,
                    "name": connection_alias_data["name"],
                    "id": alias_id
                }

                # ---------------------------------------------------------
                # 4e. Create HTTP Connection (http_connection)
                # ---------------------------------------------------------
                # Now create HTTP Connection with reference to the alias

                from urllib.parse import urlparse
                parsed_url = urlparse(base_url)
                protocol = parsed_url.scheme or "https"
                host = parsed_url.netloc or parsed_url.path.split('/')[0]

                # Ensure base_url ends with / if it doesn't have a path
                connection_url = base_url if base_url.endswith('/') else base_url + '/'

                http_connection_data = {
                    "name": api_name,
                    "connection_url": connection_url,
                    "credential": oauth_credential_sys_id,
                    "connection_alias": connection_alias_sys_id,  # Required by Business Rule
                    "protocol": protocol,
                    "host": host,
                    "active": "true",
                    "is_internal": "false",
                    "mutual_auth": "false",
                    "use_mid": "false",
                    "order": 100
                }

                http_connection_response = client.create_record("http_connection", http_connection_data, scope=scope)

                if not http_connection_response["success"]:
                    # HTTP Connection creation failed
                    created_objects["http_connection"] = {
                        "error": "Failed to create HTTP Connection",
                        "details": http_connection_response.get('error', 'Unknown error'),
                        "suggestion": "Check permissions on http_connection table"
                    }
                else:
                    http_connection_sys_id = http_connection_response["result"].get("sys_id")
                    created_objects["http_connection"] = {
                        "sys_id": http_connection_sys_id,
                        "name": http_connection_data["name"]
                    }

        except Exception as e:
            return f"❌ Unexpected error during object creation:\n\n{e}\n\nSome objects may have been created. Check ServiceNow for partial configuration."

        # ============================================================
        # STEP 5: TEST OAUTH AUTHENTICATION (if enabled)
        # ============================================================

        test_result = None
        if test_authentication:
            # Note: Actual OAuth testing would require specific ServiceNow APIs
            # This is a placeholder for the test logic
            test_result = {
                "status": "⚠️  OAuth testing not yet fully implemented",
                "note": "Please test manually in ServiceNow using the created OAuth Credential"
            }

        # ============================================================
        # STEP 6: RETURN SUMMARY
        # ============================================================

        output = [
            "✅ OAuth integration setup complete!",
            "",
            f"Integration Name: {api_name}",
            f"Base URL: {base_url or '(not specified)'}",
            f"Grant Type: {final_grant_type}",
            f"Scope: {scope}",
            ""
            "",
            "📦 Created Objects:",
            ""
        ]

        # Add each created object
        if "oauth_entity" in created_objects:
            obj = created_objects["oauth_entity"]
            output.append(f"  ✓ OAuth Entity (Provider)")
            output.append(f"    Name: {obj['name']}")
            output.append(f"    Sys ID: {obj['sys_id']}")
            output.append("")

        if "oauth_entity_profile" in created_objects:
            obj = created_objects["oauth_entity_profile"]
            output.append(f"  ✓ OAuth Entity Profile (auto-created)")
            output.append(f"    Name: {obj['name']}")
            output.append(f"    Sys ID: {obj['sys_id']}")
            if "note" in obj:
                output.append(f"    Note: {obj['note']}")
            output.append("")

        if "oauth_2_0_credentials" in created_objects:
            obj = created_objects["oauth_2_0_credentials"]
            output.append(f"  ✓ OAuth 2.0 Credential")
            output.append(f"    Name: {obj['name']}")
            output.append(f"    Sys ID: {obj['sys_id']}")
            output.append("")

        if "http_connection" in created_objects:
            obj = created_objects["http_connection"]
            if "error" in obj:
                output.append(f"  ⚠️  HTTP Connection")
                output.append(f"    {obj['error']}")
                output.append(f"    {obj['suggestion']}")
            else:
                output.append(f"  ✓ HTTP Connection")
                output.append(f"    Name: {obj['name']}")
                output.append(f"    Sys ID: {obj['sys_id']}")
            output.append("")

        if "connection_alias" in created_objects:
            obj = created_objects["connection_alias"]
            if "error" in obj:
                output.append(f"  ⚠️  Connection & Credential Alias")
                output.append(f"    {obj['error']}")
                output.append(f"    {obj['suggestion']}")
            else:
                output.append(f"  ✓ Connection & Credential Alias")
                output.append(f"    Name: {obj['name']}")
                output.append(f"    ID: {obj['id']}")
                output.append(f"    Sys ID: {obj['sys_id']}")
            output.append("")

        # Add provider recommendation
        if "provider_recommendation" in created_objects:
            rec = created_objects["provider_recommendation"]
            provider = rec["provider"]
            scripts = rec["scripts"]

            output.append(f"🔍 Provider Detected: {provider}")
            output.append("")
            output.append(f"  ServiceNow has {len(scripts)} OAuth API Script(s) for {provider}:")
            output.append("")

            for script in scripts:
                output.append(f"  ✓ {script['name']}")
                output.append(f"    Sys ID: {script['sys_id']}")
                if script.get('description'):
                    output.append(f"    Description: {script['description']}")

            output.append("")
            output.append(f"  💡 Why This Matters:")
            output.append(f"     These scripts handle {provider}-specific OAuth requirements")
            output.append(f"     (e.g., URL-encoded responses, custom headers, PKCE settings)")
            output.append("")
            output.append(f"  ⚙️  Configuration Options:")
            output.append("")
            output.append(f"     Option 1: Apply Script Now (Recommended)")
            output.append(f"     ----------------------------------------")
            output.append(f"     Ask me to apply the script automatically:")
            output.append(f"       'Apply {scripts[0]['name']} to {api_name}'")
            output.append("")
            output.append(f"     Option 2: Test Without Script First")
            output.append(f"     ------------------------------------")
            output.append(f"     1. Go to System OAuth > Application Registry")
            output.append(f"     2. Open: {api_name}")
            output.append(f"     3. Click 'Get OAuth Token' to test")
            output.append(f"     4. If it fails, come back and apply the script")
            output.append("")
            output.append(f"     Option 3: Manual Configuration")
            output.append(f"     -------------------------------")
            output.append(f"     1. Go to System OAuth > Application Registry")
            output.append(f"     2. Open: {api_name}")
            output.append(f"     3. Set 'OAuth API Script' to: {scripts[0]['name']}")
            output.append(f"     4. Save and test 'Get OAuth Token'")
            output.append("")

        # Add test results
        if test_result:
            output.append("🧪 Authentication Test:")
            output.append(f"  {test_result['status']}")
            if "note" in test_result:
                output.append(f"  {test_result['note']}")
            output.append("")

        # Add next steps
        output.append("📋 Next Steps:")
        output.append("  1. Navigate to OAuth Entity in ServiceNow (System OAuth > Application Registry)")
        output.append("  2. Verify the OAuth Entity configuration and test token acquisition")
        output.append("  3. Create REST Message records for specific API endpoints")
        output.append("  4. Set up error handling and retry logic as needed")
        output.append("")
        output.append("💡 Tip: Find your OAuth records in ServiceNow:")
        output.append(f"   • OAuth Entity: Table oauth_entity, Name: {api_name}")
        output.append(f"   • OAuth Profile: Table oauth_entity_profile, Name: {api_name} default_profile")
        output.append(f"   • Credential: Table oauth_2_0_credentials, Name: {api_name}")
        if "connection_alias" in created_objects and "id" in created_objects["connection_alias"]:
            output.append(f"   • Connection & Credential Alias: Table sys_alias, ID: {created_objects['connection_alias']['id']}")
        if "http_connection" in created_objects and "sys_id" in created_objects["http_connection"]:
            output.append(f"   • HTTP Connection: Table http_connection, Name: {api_name}")

        return "\n".join(output)

    @mcp.tool()
    def rollback_oauth_integration(
        integration_name: str = "",
        oauth_entity_sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Delete an OAuth integration and all related objects from ServiceNow in reverse dependency order.

        Removes http_connection, sys_alias, oauth_2_0_credentials, oauth_entity_profile, and oauth_entity.
        Provide either integration_name OR oauth_entity_sys_id.

        Returns:
            Summary of deleted objects and any errors
        """

        # ============================================================
        # STEP 1: VALIDATE PARAMETERS AND INSTANCE
        # ============================================================

        # Check if instance confirmation is needed
        confirmation_error = require_instance_confirmation(instance, "delete OAuth integration")
        if confirmation_error:
            return confirmation_error

        if not integration_name and not oauth_entity_sys_id:
            return (
                "❌ Missing required parameters:\n\n"
                "Please provide either:\n"
                "  • integration_name (e.g., 'Test OAuth API')\n"
                "  • oauth_entity_sys_id (e.g., 'abc123...')\n"
            )

        client = get_client(instance)
        deleted_objects = []
        errors = []

        try:
            # ============================================================
            # STEP 2: FIND THE OAUTH ENTITY
            # ============================================================

            if oauth_entity_sys_id:
                # Verify the entity exists
                entity_response = client.query_table(
                    table_name="oauth_entity",
                    query=f"sys_id={oauth_entity_sys_id}",
                    fields=["sys_id", "name"],
                    limit=1
                )

                if not entity_response["success"] or not entity_response["result"]:
                    return f"❌ OAuth Entity not found with sys_id: {oauth_entity_sys_id}"

                entity = entity_response["result"][0]
                entity_sys_id = oauth_entity_sys_id
                entity_name = entity.get("name", "Unknown")

            else:
                # Find by name
                entity_response = client.query_table(
                    table_name="oauth_entity",
                    query=f"name={integration_name}",
                    fields=["sys_id", "name"],
                    limit=1
                )

                if not entity_response["success"] or not entity_response["result"]:
                    return f"❌ OAuth Entity not found with name: {integration_name}"

                entity = entity_response["result"][0]
                entity_sys_id = entity["sys_id"]
                entity_name = entity.get("name", "Unknown")

            # ============================================================
            # STEP 3: FIND ALL RELATED OBJECTS
            # ============================================================

            # Find OAuth Entity Profile(s)
            profile_response = client.query_table(
                table_name="oauth_entity_profile",
                query=f"oauth_entity={entity_sys_id}",
                fields=["sys_id", "name"],
                limit=10
            )

            profile_sys_ids = []
            if profile_response["success"] and profile_response["result"]:
                profile_sys_ids = [p["sys_id"] for p in profile_response["result"]]

            # Find OAuth 2.0 Credential(s)
            credential_sys_ids = []
            if profile_sys_ids:
                for profile_sys_id in profile_sys_ids:
                    cred_response = client.query_table(
                        table_name="oauth_2_0_credentials",
                        query=f"oauth_entity_profile={profile_sys_id}",
                        fields=["sys_id", "name"],
                        limit=10
                    )

                    if cred_response["success"] and cred_response["result"]:
                        credential_sys_ids.extend([c["sys_id"] for c in cred_response["result"]])

            # Find HTTP Connection(s)
            connection_sys_ids = []
            if credential_sys_ids:
                for cred_sys_id in credential_sys_ids:
                    conn_response = client.query_table(
                        table_name="http_connection",
                        query=f"credential={cred_sys_id}",
                        fields=["sys_id", "name"],
                        limit=10
                    )

                    if conn_response["success"] and conn_response["result"]:
                        connection_sys_ids.extend([c["sys_id"] for c in conn_response["result"]])

            # Find Connection & Credential Alias(es)
            connection_alias_sys_ids = []
            if connection_sys_ids:
                for conn_sys_id in connection_sys_ids:
                    alias_response = client.query_table(
                        table_name="sys_alias",
                        query=f"type=connection",
                        fields=["sys_id", "name", "id"],
                        limit=10
                    )

                    if alias_response["success"] and alias_response["result"]:
                        connection_alias_sys_ids.extend(alias_response["result"])

            # ============================================================
            # STEP 4: DELETE OBJECTS IN CORRECT ORDER
            # ============================================================

            # Delete Connection & Credential Aliases first
            for alias in connection_alias_sys_ids:
                try:
                    response = client.session.delete(
                        f"{client.config.instance}/api/now/table/sys_alias/{alias['sys_id']}"
                    )
                    if response.status_code in [204, 404]:
                        deleted_objects.append(("Connection & Credential Alias", alias.get("name"), alias.get("id")))
                    else:
                        errors.append(f"Failed to delete Connection & Credential Alias {alias.get('name')}: Status {response.status_code}")
                except Exception as e:
                    errors.append(f"Error deleting Connection & Credential Alias {alias.get('name')}: {e}")

            # Delete HTTP Connections
            for conn_sys_id in connection_sys_ids:
                try:
                    response = client.session.delete(
                        f"{client.config.instance}/api/now/table/http_connection/{conn_sys_id}"
                    )
                    if response.status_code in [204, 404]:
                        deleted_objects.append(("HTTP Connection", conn_sys_id, None))
                    else:
                        errors.append(f"Failed to delete HTTP Connection {conn_sys_id}: Status {response.status_code}")
                except Exception as e:
                    errors.append(f"Error deleting HTTP Connection {conn_sys_id}: {e}")

            # Delete OAuth 2.0 Credentials
            for cred_sys_id in credential_sys_ids:
                try:
                    response = client.session.delete(
                        f"{client.config.instance}/api/now/table/oauth_2_0_credentials/{cred_sys_id}"
                    )
                    if response.status_code in [204, 404]:
                        deleted_objects.append(("OAuth 2.0 Credential", cred_sys_id, None))
                    else:
                        errors.append(f"Failed to delete OAuth 2.0 Credential {cred_sys_id}: Status {response.status_code}")
                except Exception as e:
                    errors.append(f"Error deleting OAuth 2.0 Credential {cred_sys_id}: {e}")

            # Delete OAuth Entity Profiles
            for profile_sys_id in profile_sys_ids:
                try:
                    response = client.session.delete(
                        f"{client.config.instance}/api/now/table/oauth_entity_profile/{profile_sys_id}"
                    )
                    if response.status_code in [204, 404]:
                        deleted_objects.append(("OAuth Entity Profile", profile_sys_id, None))
                    else:
                        errors.append(f"Failed to delete OAuth Entity Profile {profile_sys_id}: Status {response.status_code}")
                except Exception as e:
                    errors.append(f"Error deleting OAuth Entity Profile {profile_sys_id}: {e}")

            # Delete OAuth Entity (last)
            try:
                response = client.session.delete(
                    f"{client.config.instance}/api/now/table/oauth_entity/{entity_sys_id}"
                )
                if response.status_code in [204, 404]:
                    deleted_objects.append(("OAuth Entity", entity_name, entity_sys_id))
                else:
                    errors.append(f"Failed to delete OAuth Entity {entity_name}: Status {response.status_code}")
            except Exception as e:
                errors.append(f"Error deleting OAuth Entity {entity_name}: {e}")

            # ============================================================
            # STEP 5: RETURN SUMMARY
            # ============================================================

            output = [
                "🧹 OAuth Integration Rollback Complete!",
                "",
                f"Integration Name: {entity_name}",
                f"Deleted {len(deleted_objects)} object(s)",
                ""
            ]

            if deleted_objects:
                output.append("🗑️  Deleted Objects:")
                output.append("")
                for obj_type, obj_name, obj_id in deleted_objects:
                    if obj_id and obj_id != obj_name:
                        output.append(f"  ✓ {obj_type}: {obj_name} ({obj_id})")
                    elif obj_name:
                        output.append(f"  ✓ {obj_type}: {obj_name}")
                    else:
                        output.append(f"  ✓ {obj_type}")
                output.append("")

            if errors:
                output.append("⚠️  Errors encountered:")
                output.append("")
                for error in errors:
                    output.append(f"  • {error}")
                output.append("")

            if not errors:
                output.append("✅ All objects deleted successfully!")
            else:
                output.append("⚠️  Rollback completed with some errors. Check ServiceNow for any remaining objects.")

            return "\n".join(output)

        except Exception as e:
            return f"❌ Unexpected error during rollback:\n\n{e}\n\nSome objects may have been deleted. Check ServiceNow."

    @mcp.tool()
    def apply_oauth_api_script(
        integration_name: str = "",
        oauth_entity_sys_id: str = "",
        script_name: str = "",
        script_sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Apply an OAuth API Script (sys_script_include) to an existing oauth_entity record.

        Provider-specific scripts handle non-standard response formats:
        - GitHub: OauthAPIScriptForGitHub — returns URL-encoded responses, not JSON
        - Google: custom token refresh logic
        - Microsoft: PKCE configuration differences

        Provide either integration_name OR oauth_entity_sys_id; either script_name OR script_sys_id.

        Returns:
            Confirmation with integration name, entity sys_id, and applied script name
        """

        # ============================================================
        # STEP 1: VALIDATE PARAMETERS AND INSTANCE
        # ============================================================

        # Check if instance confirmation is needed
        confirmation_error = require_instance_confirmation(instance, "modify OAuth entity")
        if confirmation_error:
            return confirmation_error

        if not integration_name and not oauth_entity_sys_id:
            return (
                "❌ Missing required parameters:\n\n"
                "Please provide either:\n"
                "  • integration_name (e.g., 'GitHub Integration')\n"
                "  • oauth_entity_sys_id (e.g., 'abc123...')\n"
            )

        if not script_name and not script_sys_id:
            return (
                "❌ Missing required parameters:\n\n"
                "Please provide either:\n"
                "  • script_name (e.g., 'OauthAPIScriptForGitHub')\n"
                "  • script_sys_id (e.g., 'def456...')\n"
            )

        client = get_client(instance)

        try:
            # ============================================================
            # STEP 2: FIND THE OAUTH ENTITY
            # ============================================================

            if oauth_entity_sys_id:
                # Verify the entity exists
                entity_response = client.query_table(
                    table_name="oauth_entity",
                    query=f"sys_id={oauth_entity_sys_id}",
                    fields=["sys_id", "name", "sys_scope"],
                    limit=1
                )

                if not entity_response["success"] or not entity_response["result"]:
                    return f"❌ OAuth Entity not found with sys_id: {oauth_entity_sys_id}"

                entity = entity_response["result"][0]
                entity_sys_id = oauth_entity_sys_id
                entity_name = entity.get("name", "Unknown")

            else:
                # Find by name
                entity_response = client.query_table(
                    table_name="oauth_entity",
                    query=f"name={integration_name}",
                    fields=["sys_id", "name", "sys_scope"],
                    limit=1
                )

                if not entity_response["success"] or not entity_response["result"]:
                    return f"❌ OAuth Entity not found with name: {integration_name}"

                entity = entity_response["result"][0]
                entity_sys_id = entity["sys_id"]
                entity_name = entity.get("name", "Unknown")

            # ============================================================
            # STEP 3: FIND THE OAUTH API SCRIPT
            # ============================================================

            if script_sys_id:
                # Verify the script exists
                script_response = client.query_table(
                    table_name="sys_script_include",
                    query=f"sys_id={script_sys_id}",
                    fields=["sys_id", "name", "description"],
                    limit=1
                )

                if not script_response["success"] or not script_response["result"]:
                    return f"❌ OAuth API Script not found with sys_id: {script_sys_id}"

                script = script_response["result"][0]
                final_script_sys_id = script_sys_id
                final_script_name = script.get("name", "Unknown")

            else:
                # Find by name
                script_response = client.query_table(
                    table_name="sys_script_include",
                    query=f"name={script_name}",
                    fields=["sys_id", "name", "description"],
                    limit=1
                )

                if not script_response["success"] or not script_response["result"]:
                    return f"❌ OAuth API Script not found with name: {script_name}"

                script = script_response["result"][0]
                final_script_sys_id = script["sys_id"]
                final_script_name = script.get("name", "Unknown")

            # ============================================================
            # STEP 4: UPDATE OAUTH ENTITY WITH SCRIPT
            # ============================================================

            # Get the scope of the OAuth Entity
            entity_scope = entity.get("sys_scope", "global")

            params = {}
            if entity_scope and entity_scope != "global":
                params["sysparm_scope"] = entity_scope

            update_response = client.session.patch(
                f"{client.config.instance}/api/now/table/oauth_entity/{entity_sys_id}",
                json={"oauth_api_script": final_script_sys_id},
                params=params if params else None
            )

            if update_response.status_code not in [200, 201]:
                return (
                    f"❌ Failed to update OAuth Entity with script:\n\n"
                    f"Status Code: {update_response.status_code}\n"
                    f"Response: {update_response.text}\n\n"
                    "Check permissions on oauth_entity table."
                )

            # ============================================================
            # STEP 5: RETURN SUCCESS MESSAGE
            # ============================================================

            output = [
                "✅ OAuth API Script Applied!",
                "",
                f"Integration: {entity_name}",
                f"OAuth Entity ID: {entity_sys_id}",
                "",
                f"Applied Script: {final_script_name}",
                f"Script ID: {final_script_sys_id}",
                "",
                "📋 Next Steps:",
                "  1. Navigate to System OAuth > Application Registry",
                f"  2. Open: {entity_name}",
                "  3. Verify 'OAuth API Script' field shows: " + final_script_name,
                "  4. Click 'Get OAuth Token' to test the configuration",
                "",
                "💡 What This Does:",
                f"  The {final_script_name} script handles provider-specific OAuth requirements,",
                "  such as custom response formats, headers, and authentication flows.",
                "  This ensures your OAuth integration works correctly with the provider's API."
            ]

            return "\n".join(output)

        except Exception as e:
            return f"❌ Unexpected error applying OAuth API Script:\n\n{e}"

    @mcp.tool()
    def inspect_oauth_entity(
        name_or_sys_id: str,
        instance: str = None
    ) -> str:
        """
        Return a full diagnostic snapshot of an oauth_entity record (oauth_entity table).

        Surfaces key config fields and flags common misconfigurations:
        - Wrong type (should be 'client' for inbound/MCP OAuth)
        - Wrong grant type (should be 'client_credentials')
        - Missing or inactive Application User
        - Non-global scope (oauth_entity inherits session scope; cannot be changed via API)

        Args:
            name_or_sys_id: oauth_entity sys_id (32-char hex) or partial name match
        """
        if not name_or_sys_id:
            return "name_or_sys_id is required."

        client = get_client(instance)
        is_sys_id = bool(re.match(r'^[0-9a-f]{32}$', name_or_sys_id))

        if is_sys_id:
            query = f"sys_id={name_or_sys_id}"
        else:
            query = f"nameLIKE{name_or_sys_id}"

        response = client.query_table(
            table_name="oauth_entity",
            query=query,
            fields=["sys_id", "name", "active", "type", "default_grant_type",
                    "user", "client_id", "sys_scope", "sys_package"],
            limit=5,
            display_value="all"
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        records = response["result"]
        if not records:
            label = "sys_id" if is_sys_id else "name"
            return f"No oauth_entity found with {label}: {name_or_sys_id}"

        def _dv(field):
            if isinstance(field, dict):
                return field.get("display_value", "") or field.get("value", "") or ""
            return str(field) if field else ""

        def _val(field):
            if isinstance(field, dict):
                return field.get("value", "") or ""
            return str(field) if field else ""

        def _format_record(r):
            name = _dv(r.get("name", ""))
            sys_id = _val(r.get("sys_id", ""))
            active = _dv(r.get("active", ""))
            type_val = _val(r.get("type", ""))
            grant_val = _val(r.get("default_grant_type", ""))
            user_val = _val(r.get("user", ""))
            user_dv = _dv(r.get("user", ""))
            client_id = _dv(r.get("client_id", ""))
            scope_dv = _dv(r.get("sys_scope", ""))
            package_dv = _dv(r.get("sys_package", "")) or "(none)"

            user_status = ""
            if user_val:
                user_resp = client.query_table(
                    table_name="sys_user",
                    query=f"sys_id={user_val}",
                    fields=["sys_id", "user_name", "active"],
                    limit=1
                )
                if user_resp["success"] and user_resp["result"]:
                    user_active = user_resp["result"][0].get("active", "true")
                    user_status = "active" if user_active == "true" else "INACTIVE"
                else:
                    user_status = "not found"

            user_line = f"{user_dv} ({user_status})" if user_val else "(none)"
            lines = [
                f"OAuth Entity: {name}",
                f"  sys_id:       {sys_id}",
                f"  active:       {active}",
                f"  type:         {type_val}",
                f"  grant type:   {grant_val}",
                f"  client_id:    {client_id}",
                f"  user:         {user_line}",
                f"  scope:        {scope_dv}",
                f"  package:      {package_dv}",
                "",
                "Diagnostic:",
            ]

            flags = []

            if type_val == "client":
                flags.append("  ✓ type = client")
            else:
                flags.append(f"  ⚠️ type = '{type_val}' — should be 'client' for inbound/MCP OAuth")

            if grant_val == "client_credentials":
                flags.append("  ✓ default_grant_type = client_credentials")
            else:
                flags.append(f"  ⚠️ default_grant_type = '{grant_val}' — should be 'client_credentials'")

            if not user_val:
                flags.append("  ⚠️ No Application User configured")
            elif user_status == "INACTIVE":
                flags.append(f"  ⚠️ Application User '{user_dv}' is inactive")
            elif user_status == "not found":
                flags.append(f"  ⚠️ Application User sys_id '{user_val}' not found in sys_user")
            else:
                flags.append(f"  ✓ Application User '{user_dv}' is active")

            if scope_dv.lower() in ("global", ""):
                flags.append("  ✓ scope = global")
            else:
                flags.append(
                    f"  ⚠️ scope = '{scope_dv}' (not global — oauth_entity inherits session scope "
                    f"and cannot be changed via API)"
                )

            lines.extend(flags)
            return "\n".join(lines)

        if len(records) == 1:
            return _format_record(records[0])

        blocks = [f"Found {len(records)} oauth_entity records matching '{name_or_sys_id}':\n"]
        for i, r in enumerate(records, 1):
            blocks.append(f"--- {i} of {len(records)} ---")
            blocks.append(_format_record(r))
        return "\n\n".join(blocks)
