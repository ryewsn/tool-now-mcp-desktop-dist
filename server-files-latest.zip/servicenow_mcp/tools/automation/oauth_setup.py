"""OAuth Integration Setup Tools

Automates creation of OAuth-protected API integrations in ServiceNow by parsing
OpenAPI specifications. For non-OpenAPI documentation, Claude Desktop extracts
OAuth configuration before calling this tool.
"""

import re

from mcp.server.mcpserver import MCPServer
from ...core.client import get_client, require_instance_confirmation, reset_client
from ...core.formatters import format_error
from ...core.scope_lookup import resolve_scope, scope_value
from ...core.script_runner import GLOBAL_SCOPE_SYS_ID
from ...core.rest_verify import delete_with_readback
from ...core.entity_landing import read_landing
from ...core.scope_pin import ensure_current_app, restore_current_app, pinned_scope_call
from ...core.oauth_utils import (
    parse_openapi_spec,
    OpenAPIParseError,
    format_scopes_for_servicenow
)


def detect_provider(base_url: str, token_url: str, auth_url: str = "") -> str:
    """Detect OAuth provider from URLs. Returns provider name (e.g., "GitHub", "Google") or "Unknown"."""
    all_urls = f"{base_url} {token_url} {auth_url}".lower()

    # Provider detection patterns
    if "github.com" in all_urls or "github.io" in all_urls:
        return "GitHub"
    elif "googleapis.com" in all_urls or "google.com" in all_urls:
        return "Google"
    elif "microsoft.com" in all_urls or "microsoftonline.com" in all_urls or "graph.microsoft.com" in all_urls:
        return "Microsoft"
    elif "salesforce.com" in all_urls or "force.com" in all_urls:
        return "Salesforce"
    elif "slack.com" in all_urls:
        return "Slack"
    elif "zoom.us" in all_urls:
        return "Zoom"
    elif "stripe.com" in all_urls:
        return "Stripe"
    elif "spotify.com" in all_urls:
        return "Spotify"
    elif "linkedin.com" in all_urls:
        return "LinkedIn"
    elif "twitter.com" in all_urls or "x.com" in all_urls:
        return "Twitter"
    elif "facebook.com" in all_urls or "fb.com" in all_urls:
        return "Facebook"

    return "Unknown"


def find_oauth_api_scripts(provider: str, instance: str = None) -> list:
    """Find OAuth API Scripts in sys_script_include matching the provider. Returns list of {"name", "sys_id"} dicts."""
    if provider == "Unknown":
        return []

    client = get_client(instance)

    # Search for Script Includes that match the provider and OAuth
    response = client.query_table(
        table_name="sys_script_include",
        query=f"nameLIKE{provider}^nameLIKEOAuth^ORnameLIKEoauth",
        fields=["name", "sys_id", "description"],
        limit=10
    )

    if not response["success"] or not response["result"]:
        return []

    return response["result"]


def register_tools(mcp: MCPServer):
    """Register OAuth automation tools with the MCP server."""

    @mcp.tool()
    def setup_oauth_integration(
        client_id: str,
        client_secret: str,
        spec_source: str = "",
        spec_type: str = "url",
        name: str = "",
        token_url: str = "",
        redirect_url: str = "",
        grant_type: str = "client_credentials",
        scopes: str = "",
        oauth_api_script: str = "",
        scope: str = "global",
        test_authentication: bool = True,
        instance: str = None
    ) -> str:
        """
        Create an OAuth integration in ServiceNow (oauth_entity, oauth_entity_profile, oauth_2_0_credentials,
        sys_alias, http_connection) from an OpenAPI spec or manual parameters.

        CRITICAL CONSTRAINTS (causes immediate failure if violated):
        1. sys_alias type="connection" — http_connection CANNOT pair with credential-only aliases (type="credential")
        2. Object creation order (ServiceNow Business Rule requirement):
           sys_alias MUST be created BEFORE http_connection. Full order:
           oauth_entity → oauth_2_0_credentials → sys_alias → http_connection → update sys_alias
        3. Application scope MUST be validated before creating any records (avoid partial state)
        4. All related objects MUST be in the SAME application scope. This tool does not
           guarantee it: it reports each record's scope (below) so a split can be seen.

        **Required roles:** oauth_admin (or admin) — missing role causes silent failures or 403 errors.
        **Where records land:** a REST insert lands in the MCP account's current application scope
        (its apps.current_app preference), not in `scope`; the oauth_entity_profile ServiceNow
        auto-creates follows that same scope. When the instance setting
        SERVICENOW_SCOPE_PIN_ACCOUNT_<ALIAS> is true (only for a dedicated MCP service account),
        the tool sets that preference to `scope` for the creates, then restores it and reads it
        back, so the entity and its profile should land in `scope` (not yet live-verified; the
        read-back reports where they did land). The pin writes the preference of
        SERVICENOW_USERNAME_<ALIAS>, so that must be the dedicated account the MCP's REST calls
        run as; a mismatch makes the pin ineffective and rewrites the wrong user's preference.
        The pin removes only the preference row it created itself (when there was no prior
        row), confirmed by read-back and reported. Otherwise (the default) nothing is pinned and the records land as before. Either way
        the summary reports where the entity, profile and alias landed (read back by sys_id); a
        record CONFIRMED outside `scope` is listed with its sys_id and the
        rollback_oauth_integration hint, never deleted. A read-back that cannot confirm only warns.
        oauth_2_0_credentials and http_connection have no column named sys_scope; they carry the
        scope in the `application` and `app_scope` references, which are read back by sys_id and
        reported the same way (a mismatch is shown, never fixed or deleted). The credential's
        `application` is always written as Global today, so a scoped request reports it as not in
        the requested scope; the tool does not move it. The alias id is shown as stored
        (ServiceNow stores it lowercased). No Script Runner needed.

        Args:
            client_id: OAuth client ID (REQUIRED)
            client_secret: OAuth client secret (REQUIRED)
            spec_source: Documentation source (URL, file path, or content). Omit to provide all params manually.
            spec_type: "url", "content", or "filepath" (default: "url")
            token_url: OAuth token endpoint; extracted from spec if omitted
            redirect_url: OAuth redirect URI; auto-constructed as {instance}/oauth_redirect.do if omitted
            grant_type: client_credentials | authorization_code | password (deprecated) | implicit (deprecated)
            scopes: Space-separated OAuth scopes; extracted from spec if omitted
            oauth_api_script: Name of OAuth API Script Include (e.g., "OauthAPIScriptForGitHub")
            scope: ServiceNow application scope ID (default: "global"). Use "x_123_myapp" for scoped apps.
            test_authentication: Whether to test OAuth flow after creation (default: True)

        Returns:
            Summary of created objects with sys_ids and test results
        """

        # ============================================================
        # STEP 1: VALIDATE REQUIRED PARAMETERS AND INSTANCE
        # ============================================================

        # Check if instance confirmation is needed
        confirmation_error = require_instance_confirmation(instance, "create OAuth integration")
        if confirmation_error:
            return confirmation_error

        # Only client_id and client_secret are strictly required
        missing_params = []
        if not client_id:
            missing_params.append("client_id (OAuth client ID)")
        if not client_secret:
            missing_params.append("client_secret (OAuth client secret)")

        if missing_params:
            return (
                "❌ Missing required parameters:\n\n" +
                "\n".join(f"  • {p}" for p in missing_params) +
                "\n\nPlease provide these values and try again."
            )

        # ============================================================
        # STEP 2: PARSE OPENAPI SPEC (if provided)
        # ============================================================

        spec_data = {}

        if spec_source:
            try:
                spec_data = parse_openapi_spec(spec_source, spec_type)
            except OpenAPIParseError as e:
                return (
                    f"❌ spec_source is not valid OpenAPI format.\n\n"
                    f"Error: {e}\n\n"
                    f"If this is non-OpenAPI documentation (HTML, Markdown, etc.), please:\n"
                    f"  1. Read the documentation and extract OAuth configuration\n"
                    f"  2. Call this tool with explicit parameters:\n"
                    f"     - name: API name\n"
                    f"     - token_url: OAuth token endpoint\n"
                    f"     - grant_type: OAuth grant type\n"
                    f"     - scopes: OAuth scopes (space-separated)\n"
                    f"     - Do NOT provide spec_source for non-OpenAPI docs"
                )
            except Exception as e:
                return f"❌ Unexpected error parsing OpenAPI spec:\n\n{e}"

        # Extract configuration from spec (or use empty defaults)
        api_name = name or spec_data.get("name", "")
        base_url = spec_data.get("base_url")
        spec_token_url = spec_data.get("token_url")
        spec_auth_url = spec_data.get("auth_url")
        spec_scopes = spec_data.get("scopes", {})
        spec_grant_type = spec_data.get("grant_type")
        description = spec_data.get("description", "")

        # Validate we have minimum required info
        if not api_name:
            if not name:
                return (
                    "❌ Integration name is required.\n\n"
                    "Either provide 'name' parameter or 'spec_source' that contains API name."
                )
            api_name = name

        # Use provided values or fall back to spec values
        final_token_url = token_url or spec_token_url
        final_grant_type = grant_type if grant_type != "client_credentials" else (spec_grant_type or grant_type)
        final_scopes = scopes or format_scopes_for_servicenow(spec_scopes)

        # Validate we have required OAuth token URL
        if not final_token_url:
            return (
                "❌ OAuth token URL is required.\n\n"
                "Token URL not found in documentation and not provided manually.\n"
                "Please provide it using the 'token_url' parameter:\n"
                "  Example: token_url='https://auth.example.com/oauth/token'\n\n"
                "Common patterns:\n"
                "  • https://api.example.com/oauth/token\n"
                "  • https://oauth.example.com/token\n"
                "  • https://example.com/oauth2/token"
            )

        # ============================================================
        # STEP 3: GET CLIENT AND AUTO-CONSTRUCT REDIRECT URL
        # ============================================================

        client = get_client(instance)
        instance_config = client.config

        # Auto-construct redirect URL if not provided (ServiceNow standard pattern)
        if final_grant_type == "authorization_code" and not redirect_url:
            redirect_url = f"{instance_config.instance}/oauth_redirect.do"
            # Note: We don't error - we auto-construct it from instance URL

        # ============================================================
        # STEP 4: VALIDATE AND CONFIRM SCOPE
        # ============================================================

        # Validate the provided scope with one exact lookup (no list-and-search). Its sys_id is
        # the scope the records are compared with after the creates ("global" -> Global).
        target_sys_id = None
        if scope:
            scope_check = resolve_scope(client, scope)
            if not scope_check["success"]:
                return f"❌ {scope_check['error']}"
            target_sys_id = scope_check.get("sys_id") or None

        # ============================================================
        # STEP 5: CREATE SERVICENOW OBJECTS
        # ============================================================

        created_objects = {}
        landing_lines = []   # "where each record landed", one line per record
        misplaced = []       # records CONFIRMED outside the requested scope

        def _report_landing(c, label, table, sys_id):
            """Read back the record's sys_scope; only a confirmed mismatch is misplaced."""
            landing = read_landing(c.session, c.config.instance, table, sys_id)
            if landing.kind == "unknown":
                landing_lines.append(f"  ⚠️  {label} {sys_id}: where it landed could not be confirmed "
                                     f"({landing.message}); check sys_scope in ServiceNow.")
            elif not target_sys_id:
                landing_lines.append(f"  • {label} {sys_id}: landed in scope {landing.scope} (read back)")
            elif landing.scope == target_sys_id:
                landing_lines.append(f"  ✓ {label} {sys_id}: in the requested scope {target_sys_id} (read back)")
            else:
                landing_lines.append(f"  ⚠️  {label} {sys_id}: landed in scope {landing.scope}, "
                                     f"not the requested {target_sys_id} (read back)")
                misplaced.append((label, sys_id, landing.scope))

        def _confirm_created(c, label, table, sys_id, field):
            """GET read-back of the scope reference on a table that has no column named
            sys_scope but carries its scope in `field` (oauth_2_0_credentials.application,
            http_connection.app_scope; audit S6 corrected 2026-11-20). Reported only: a
            mismatch neither changes success nor deletes anything."""
            check = c.query_table(table, query=f"sys_id={sys_id}", fields=["sys_id", field],
                                  limit=1, display_value="false")
            rows = check.get("result") if check.get("success") else None
            row = rows[0] if rows and isinstance(rows[0], dict) else None
            value = scope_value(row.get(field)) if row and scope_value(row.get("sys_id")) == sys_id else ""
            if value != GLOBAL_SCOPE_SYS_ID and not re.fullmatch(r"[0-9a-f]{32}", value):
                landing_lines.append(f"  ⚠️  {label} {sys_id}: created, but its {field} could not be "
                                     f"confirmed by read-back; check {table} in ServiceNow.")
            elif not target_sys_id:
                landing_lines.append(f"  • {label} {sys_id}: {field} is {value} (read back)")
            elif value == target_sys_id:
                landing_lines.append(f"  ✓ {label} {sys_id}: {field} is the requested scope "
                                     f"{target_sys_id} (read back)")
            else:
                landing_lines.append(f"  ⚠️  {label} {sys_id}: {field} is {value}, not the requested "
                                     f"{target_sys_id}; this record is not in the requested scope "
                                     f"(read back)")

        def _setup_oauth_creates(c, scope_param):
            """The creates of this tool, on client c, each read back.

            Runs inside pinned_scope_call (with the fresh client it passes) when
            scope_pin_account is true, otherwise on the tool's client as before. Returns
            {"success": True} or {"success": False, "abort": message}.
            """
            try:
                # ---------------------------------------------------------
                # 5a. Create OAuth Entity (oauth_entity) - Main OAuth Provider
                # ---------------------------------------------------------

                oauth_entity_data = {
                    "name": api_name,
                    "type": "oauth_provider",
                    "active": "true",
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "token_url": final_token_url,
                    "default_grant_type": final_grant_type,
                    "access": "public"
                }

                if spec_auth_url:
                    oauth_entity_data["auth_url"] = spec_auth_url

                if redirect_url:
                    oauth_entity_data["redirect_url"] = redirect_url

                oauth_entity_response = c.create_record(
                    "oauth_entity", oauth_entity_data, scope=scope_param,
                    unscoped_ok="oauth integration creates (pinned scope, REST, read back): oauth_entity create, scope read back by sys_id")

                if not oauth_entity_response["success"]:
                    return {"success": False, "abort": f"❌ Failed to create OAuth Entity:\n\n{oauth_entity_response.get('error', 'Unknown error')}"}

                oauth_entity_sys_id = oauth_entity_response["result"].get("sys_id")
                created_objects["oauth_entity"] = {
                    "sys_id": oauth_entity_sys_id,
                    "name": oauth_entity_data["name"]
                }

                # ---------------------------------------------------------
                # 5a.1. Detect Provider and Find Matching OAuth API Scripts
                # ---------------------------------------------------------

                detected_provider = detect_provider(base_url, final_token_url, spec_auth_url or "")

                if detected_provider != "Unknown":
                    matching_scripts = find_oauth_api_scripts(detected_provider, instance)

                    if matching_scripts:
                        created_objects["provider_recommendation"] = {
                            "provider": detected_provider,
                            "scripts": matching_scripts,
                            "oauth_entity_sys_id": oauth_entity_sys_id
                        }

                # ---------------------------------------------------------
                # 5b. Get OAuth Entity Profile (auto-created by ServiceNow)
                # ---------------------------------------------------------

                # ServiceNow automatically creates an OAuth Entity Profile when the OAuth Entity is
                # created, in the session's current application scope (spike S-A1). Query for it
                # instead of creating a duplicate.
                import time
                time.sleep(0.5)  # Brief pause to ensure profile is created

                profile_query_response = c.query_table(
                    table_name="oauth_entity_profile",
                    query=f"oauth_entity={oauth_entity_sys_id}^grant_type={final_grant_type}",
                    fields=["sys_id", "name", "grant_type", "sys_scope"],
                    limit=1,
                    display_value="false"
                )

                if not profile_query_response["success"] or not profile_query_response["result"]:
                    return {"success": False, "abort": f"❌ Failed to find auto-created OAuth Entity Profile:\n\n{profile_query_response.get('error', 'No profile found')}"}

                oauth_profile_sys_id = profile_query_response["result"][0]["sys_id"]
                oauth_profile_name = profile_query_response["result"][0]["name"]

                # Note: Scopes are managed via oauth_entity_scope table records, not a field
                # on oauth_entity_profile. Proper scope assignment is backlogged.

                created_objects["oauth_entity_profile"] = {
                    "sys_id": oauth_profile_sys_id,
                    "name": oauth_profile_name,
                    "note": "Auto-created by ServiceNow"
                }

                # ---------------------------------------------------------
                # 5c. Create OAuth 2.0 Credential (oauth_2_0_credentials)
                # ---------------------------------------------------------

                oauth_credential_data = {
                    "name": api_name,
                    "oauth_entity_profile": oauth_profile_sys_id,
                    "type": "oauth_2_0",
                    "classification": "oauth_2_0",
                    "active": "true",
                    "application": "global",
                    "applies_to": "all"
                }

                oauth_credential_response = c.create_record(
                    "oauth_2_0_credentials", oauth_credential_data, scope=scope_param,
                    unscoped_ok="oauth integration creates (pinned scope, REST, read back): oauth_2_0_credentials create, no column named sys_scope but the scope is in the application reference (audit S6 corrected 2026-11-20), written as today and read back by GET")

                if not oauth_credential_response["success"]:
                    return {"success": False, "abort": f"❌ Failed to create OAuth 2.0 Credential:\n\n{oauth_credential_response.get('error', 'Unknown error')}"}

                oauth_credential_sys_id = oauth_credential_response["result"].get("sys_id")
                created_objects["oauth_2_0_credentials"] = {
                    "sys_id": oauth_credential_sys_id,
                    "name": oauth_credential_data["name"]
                }

                # ---------------------------------------------------------
                # 5d. Create Connection & Credential Alias (sys_alias)
                # ---------------------------------------------------------
                # NOTE: Must create alias BEFORE HTTP Connection due to Business Rule

                # A clean ID from the API name (uppercase, spaces to underscores). The platform
                # stores it LOWERCASED (spike S-B), so the stored value is read back below.
                alias_id = api_name.upper().replace(" ", "_").replace("-", "_")

                connection_alias_data = {
                    "name": api_name,
                    "id": alias_id,
                    "connection_type": "http_connection",
                    "type": "connection",
                    "is_internal": "false",
                    "multiple_connections": "false"
                }

                connection_alias_response = c.create_record(
                    "sys_alias", connection_alias_data, scope=scope_param,
                    unscoped_ok="oauth integration creates (pinned scope, REST, read back): sys_alias create, scope and stored id read back")

                if not connection_alias_response["success"]:
                    # Connection Alias creation failed, note this in output (does not abort)
                    created_objects["connection_alias"] = {
                        "error": "Failed to create Connection & Credential Alias",
                        "details": connection_alias_response.get('error', 'Unknown error'),
                        "suggestion": "This is required for HTTP Connection. Check permissions on sys_alias table."
                    }
                else:
                    connection_alias_sys_id = connection_alias_response["result"].get("sys_id")
                    # A read-back that raises must not be reported as a failed create.
                    stored_id = None
                    try:
                        stored = c.query_table("sys_alias", query=f"sys_id={connection_alias_sys_id}",
                                               fields=["sys_id", "id"], limit=1, display_value="false")
                        stored_rows = stored.get("result") if stored.get("success") else None
                        stored_id = stored_rows[0].get("id") if stored_rows and isinstance(stored_rows[0], dict) else None
                    except Exception as exc:
                        landing_lines.append(f"  ⚠️  The stored alias id read-back could not be completed "
                                             f"({exc}); the alias was created.")
                    created_objects["connection_alias"] = {
                        "sys_id": connection_alias_sys_id,
                        "name": connection_alias_data["name"],
                        "id": stored_id or alias_id,
                    }
                    if not stored_id:
                        created_objects["connection_alias"]["id_note"] = (
                            "stored id could not be read back; ServiceNow may store it lowercased")

                    # ---------------------------------------------------------
                    # 5e. Create HTTP Connection (http_connection)
                    # ---------------------------------------------------------
                    # Now create HTTP Connection with reference to the alias (by sys_id)

                    from urllib.parse import urlparse
                    parsed_url = urlparse(base_url)
                    protocol = parsed_url.scheme or "https"
                    host = parsed_url.netloc or parsed_url.path.split('/')[0]

                    # Ensure base_url ends with / if it doesn't have a path
                    connection_url = base_url if base_url.endswith('/') else base_url + '/'

                    http_connection_data = {
                        "name": api_name,
                        "connection_url": connection_url,
                        "credential": oauth_credential_sys_id,
                        "connection_alias": connection_alias_sys_id,  # Required by Business Rule
                        "protocol": protocol,
                        "host": host,
                        "active": "true",
                        "is_internal": "false",
                        "mutual_auth": "false",
                        "use_mid": "false",
                        "order": 100
                    }

                    http_connection_response = c.create_record(
                        "http_connection", http_connection_data, scope=scope_param,
                        unscoped_ok="oauth integration creates (pinned scope, REST, read back): http_connection create, no column named sys_scope but the scope is in the app_scope reference (audit S6 corrected 2026-11-20), read back by GET")

                    if not http_connection_response["success"]:
                        # HTTP Connection creation failed
                        created_objects["http_connection"] = {
                            "error": "Failed to create HTTP Connection",
                            "details": http_connection_response.get('error', 'Unknown error'),
                            "suggestion": "Check permissions on http_connection table"
                        }
                    else:
                        http_connection_sys_id = http_connection_response["result"].get("sys_id")
                        created_objects["http_connection"] = {
                            "sys_id": http_connection_sys_id,
                            "name": http_connection_data["name"]
                        }

                # ---------------------------------------------------------
                # 5f. Read back where each record landed (REST GETs, no Script Runner)
                # ---------------------------------------------------------
                # Own try/except: the creates above are done, so a read-back that raises only
                # warns and never turns into "Unexpected error ... some objects may exist".
                try:
                    if c._prepare_request():
                        _report_landing(c, "OAuth Entity", "oauth_entity", oauth_entity_sys_id)
                        _report_landing(c, "OAuth Entity Profile", "oauth_entity_profile", oauth_profile_sys_id)
                        if "sys_id" in created_objects["connection_alias"]:
                            _report_landing(c, "Connection & Credential Alias", "sys_alias",
                                            created_objects["connection_alias"]["sys_id"])
                    else:
                        landing_lines.append("  ⚠️  Where the records landed could not be read back "
                                             "(authentication for the read-back failed).")
                    _confirm_created(c, "OAuth 2.0 Credential", "oauth_2_0_credentials",
                                     oauth_credential_sys_id, "application")
                    if "sys_id" in created_objects.get("http_connection", {}):
                        _confirm_created(c, "HTTP Connection", "http_connection",
                                         created_objects["http_connection"]["sys_id"], "app_scope")
                except Exception as exc:
                    landing_lines.append(f"  ⚠️  The read-back could not be completed ({exc}); the records "
                                         f"above were created, check sys_scope in ServiceNow.")
                return {"success": True}

            except Exception as e:
                return {"success": False, "abort": f"❌ Unexpected error during object creation:\n\n{e}\n\nSome objects may have been created. Check ServiceNow for partial configuration."}

        # Pin apps.current_app to the requested scope only when this instance's MCP account is a
        # dedicated service account (scope_pin_account, P1a). Otherwise create as before and
        # report where each record landed.
        pin_lines = []
        pin_wanted = getattr(instance_config, "scope_pin_account", False) is True
        if pin_wanted and target_sys_id:
            pin_state = {}
            ran = []

            def _ensure(cl, sys_id):
                st = ensure_current_app(cl, sys_id)
                pin_state.update(st)
                return st

            def _call(fresh):
                ran.append(True)
                # pinned: no scope= (the platform ignores it); not pinned (no username): as before
                return _setup_oauth_creates(fresh, scope if pin_state.get("skipped") else "")

            pinned = pinned_scope_call(client, target_sys_id, _call, ensure=_ensure,
                                       restore=restore_current_app, reset=reset_client, get=get_client)
            if ran:
                outcome = pinned["result"]
                if pin_state.get("skipped"):
                    pin_lines.append(f"  ⚠️  Scope pin not set: {pin_state['skipped']}; the records were "
                                     f"created in the account's current application scope.")
                else:
                    pin_lines.append(f"  ✓ Scope pin: apps.current_app was set to {target_sys_id} for these creates.")
                if pinned.get("pref_note"):
                    pin_lines.append(f"  {pinned['pref_note']}")
            else:
                # The pin could not be set: create as before, on the tool's (untouched) client.
                pin_lines.append(f"  ⚠️  Scope pin could not be set ({pin_state.get('error') or 'unknown error'}); "
                                 f"the records were created as before, in the account's current application scope.")
                outcome = _setup_oauth_creates(client, scope)
        else:
            if pin_wanted:
                pin_lines.append("  • Scope pin: not used (no scope was given).")
            else:
                pin_lines.append(f"  • Scope pin: off (SERVICENOW_SCOPE_PIN_ACCOUNT for instance "
                                 f"'{instance_config.alias}' is not true); records were created in the "
                                 f"account's current application scope, read back below.")
            outcome = _setup_oauth_creates(client, scope)

        if not outcome.get("success"):
            message = outcome.get("abort") or outcome.get("error") or "❌ OAuth integration setup failed."
            if pin_lines:
                message += "\n\n🎯 Scope handling:\n" + "\n".join(pin_lines)
            return message

        # ============================================================
        # STEP 5: TEST OAUTH AUTHENTICATION (if enabled)
        # ============================================================

        test_result = None
        if test_authentication:
            # Note: Actual OAuth testing would require specific ServiceNow APIs
            # This is a placeholder for the test logic
            test_result = {
                "status": "⚠️  OAuth testing not yet fully implemented",
                "note": "Please test manually in ServiceNow using the created OAuth Credential"
            }

        # ============================================================
        # STEP 6: RETURN SUMMARY
        # ============================================================

        header = ("✅ OAuth integration setup complete!" if not misplaced else
                  "⚠️  OAuth integration created, but not every record landed in the requested scope "
                  "(see Where each record landed)")
        output = [
            header,
            "",
            f"Integration Name: {api_name}",
            f"Base URL: {base_url or '(not specified)'}",
            f"Grant Type: {final_grant_type}",
            f"Scope: {scope}",
            ""
            "",
            "📦 Created Objects:",
            ""
        ]

        # Add each created object
        if "oauth_entity" in created_objects:
            obj = created_objects["oauth_entity"]
            output.append(f"  ✓ OAuth Entity (Provider)")
            output.append(f"    Name: {obj['name']}")
            output.append(f"    Sys ID: {obj['sys_id']}")
            output.append("")

        if "oauth_entity_profile" in created_objects:
            obj = created_objects["oauth_entity_profile"]
            output.append(f"  ✓ OAuth Entity Profile (auto-created)")
            output.append(f"    Name: {obj['name']}")
            output.append(f"    Sys ID: {obj['sys_id']}")
            if "note" in obj:
                output.append(f"    Note: {obj['note']}")
            output.append("")

        if "oauth_2_0_credentials" in created_objects:
            obj = created_objects["oauth_2_0_credentials"]
            output.append(f"  ✓ OAuth 2.0 Credential")
            output.append(f"    Name: {obj['name']}")
            output.append(f"    Sys ID: {obj['sys_id']}")
            output.append("")

        if "http_connection" in created_objects:
            obj = created_objects["http_connection"]
            if "error" in obj:
                output.append(f"  ⚠️  HTTP Connection")
                output.append(f"    {obj['error']}")
                output.append(f"    {obj['suggestion']}")
            else:
                output.append(f"  ✓ HTTP Connection")
                output.append(f"    Name: {obj['name']}")
                output.append(f"    Sys ID: {obj['sys_id']}")
            output.append("")

        if "connection_alias" in created_objects:
            obj = created_objects["connection_alias"]
            if "error" in obj:
                output.append(f"  ⚠️  Connection & Credential Alias")
                output.append(f"    {obj['error']}")
                output.append(f"    {obj['suggestion']}")
            else:
                output.append(f"  ✓ Connection & Credential Alias")
                output.append(f"    Name: {obj['name']}")
                output.append(f"    ID: {obj['id']}")
                if obj.get("id_note"):
                    output.append(f"    Note: {obj['id_note']}")
                output.append(f"    Sys ID: {obj['sys_id']}")
            output.append("")

        # Where each record landed (read back), and the scope pin, if any
        output.append("🎯 Scope handling:")
        output.extend(pin_lines)
        output.append("")
        if landing_lines:
            output.append("📍 Where each record landed:")
            output.extend(landing_lines)
            output.append("")
        if misplaced:
            output.append(f"⚠️  These records are NOT in the requested scope ({scope}, sys_id {target_sys_id}):")
            for label, sys_id, landed in misplaced:
                output.append(f"  • {label} {sys_id} (scope {landed})")
            entity_ref = created_objects.get("oauth_entity", {}).get("sys_id", "")
            output.append("  Nothing was deleted. To remove this integration and create it again, run "
                          f"rollback_oauth_integration (oauth_entity_sys_id={entity_ref}), switch the "
                          "account's application to the requested scope (or set "
                          "SERVICENOW_SCOPE_PIN_ACCOUNT for a dedicated MCP service account), then retry.")
            output.append("")

        # Add provider recommendation
        if "provider_recommendation" in created_objects:
            rec = created_objects["provider_recommendation"]
            provider = rec["provider"]
            scripts = rec["scripts"]

            output.append(f"🔍 Provider Detected: {provider}")
            output.append("")
            output.append(f"  ServiceNow has {len(scripts)} OAuth API Script(s) for {provider}:")
            output.append("")

            for script in scripts:
                output.append(f"  ✓ {script['name']}")
                output.append(f"    Sys ID: {script['sys_id']}")
                if script.get('description'):
                    output.append(f"    Description: {script['description']}")

            output.append("")
            output.append(f"  💡 Why This Matters:")
            output.append(f"     These scripts handle {provider}-specific OAuth requirements")
            output.append(f"     (e.g., URL-encoded responses, custom headers, PKCE settings)")
            output.append("")
            output.append(f"  ⚙️  Configuration Options:")
            output.append("")
            output.append(f"     Option 1: Apply Script Now (Recommended)")
            output.append(f"     ----------------------------------------")
            output.append(f"     Ask me to apply the script automatically:")
            output.append(f"       'Apply {scripts[0]['name']} to {api_name}'")
            output.append("")
            output.append(f"     Option 2: Test Without Script First")
            output.append(f"     ------------------------------------")
            output.append(f"     1. Go to System OAuth > Application Registry")
            output.append(f"     2. Open: {api_name}")
            output.append(f"     3. Click 'Get OAuth Token' to test")
            output.append(f"     4. If it fails, come back and apply the script")
            output.append("")
            output.append(f"     Option 3: Manual Configuration")
            output.append(f"     -------------------------------")
            output.append(f"     1. Go to System OAuth > Application Registry")
            output.append(f"     2. Open: {api_name}")
            output.append(f"     3. Set 'OAuth API Script' to: {scripts[0]['name']}")
            output.append(f"     4. Save and test 'Get OAuth Token'")
            output.append("")

        # Add test results
        if test_result:
            output.append("🧪 Authentication Test:")
            output.append(f"  {test_result['status']}")
            if "note" in test_result:
                output.append(f"  {test_result['note']}")
            output.append("")

        # Add next steps
        output.append("📋 Next Steps:")
        output.append("  1. Navigate to OAuth Entity in ServiceNow (System OAuth > Application Registry)")
        output.append("  2. Verify the OAuth Entity configuration and test token acquisition")
        output.append("  3. Create REST Message records for specific API endpoints")
        output.append("  4. Set up error handling and retry logic as needed")
        output.append("")
        output.append("💡 Tip: Find your OAuth records in ServiceNow:")
        output.append(f"   • OAuth Entity: Table oauth_entity, Name: {api_name}")
        output.append(f"   • OAuth Profile: Table oauth_entity_profile, Name: {api_name} default_profile")
        output.append(f"   • Credential: Table oauth_2_0_credentials, Name: {api_name}")
        if "connection_alias" in created_objects and "id" in created_objects["connection_alias"]:
            output.append(f"   • Connection & Credential Alias: Table sys_alias, ID: {created_objects['connection_alias']['id']}")
        if "http_connection" in created_objects and "sys_id" in created_objects["http_connection"]:
            output.append(f"   • HTTP Connection: Table http_connection, Name: {api_name}")

        return "\n".join(output)

    @mcp.tool()
    def rollback_oauth_integration(
        integration_name: str = "",
        oauth_entity_sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Delete an OAuth integration and all related objects from ServiceNow in reverse dependency order.

        Removes http_connection, sys_alias, oauth_2_0_credentials, oauth_entity_profile, and oauth_entity.
        Provide either integration_name OR oauth_entity_sys_id.

        Only this integration's own records are deleted. The alias is the one its HTTP connection points to (or, for a partly created integration, the alias with exactly this integration's name and its id, the id compared ignoring case because ServiceNow stores it lowercased); an alias that another HTTP connection also uses is skipped and reported. Each delete is read back by sys_id: a record counts as deleted only when the read-back shows it gone, a 404 is reported as "not found or not visible", and the summary says "All objects deleted successfully" only when nothing was skipped, not found or failed. Requires no Script Runner.

        Returns:
            Summary of deleted objects, not-found/not-visible objects, skipped aliases and any errors
        """

        # ============================================================
        # STEP 1: VALIDATE PARAMETERS AND INSTANCE
        # ============================================================

        # Check if instance confirmation is needed
        confirmation_error = require_instance_confirmation(instance, "delete OAuth integration")
        if confirmation_error:
            return confirmation_error

        if not integration_name and not oauth_entity_sys_id:
            return (
                "❌ Missing required parameters:\n\n"
                "Please provide either:\n"
                "  • integration_name (e.g., 'Test OAuth API')\n"
                "  • oauth_entity_sys_id (e.g., 'abc123...')\n"
            )

        client = get_client(instance)
        deleted_objects = []
        errors = []

        try:
            # ============================================================
            # STEP 2: FIND THE OAUTH ENTITY
            # ============================================================

            if oauth_entity_sys_id:
                # Verify the entity exists
                entity_response = client.query_table(
                    table_name="oauth_entity",
                    query=f"sys_id={oauth_entity_sys_id}",
                    fields=["sys_id", "name"],
                    limit=1
                )

                if not entity_response["success"] or not entity_response["result"]:
                    return f"❌ OAuth Entity not found with sys_id: {oauth_entity_sys_id}"

                entity = entity_response["result"][0]
                entity_sys_id = oauth_entity_sys_id
                entity_name = entity.get("name", "Unknown")

            else:
                # Find by name
                entity_response = client.query_table(
                    table_name="oauth_entity",
                    query=f"name={integration_name}",
                    fields=["sys_id", "name"],
                    limit=1
                )

                if not entity_response["success"] or not entity_response["result"]:
                    return f"❌ OAuth Entity not found with name: {integration_name}"

                entity = entity_response["result"][0]
                entity_sys_id = entity["sys_id"]
                entity_name = entity.get("name", "Unknown")

            # ============================================================
            # STEP 3: FIND ALL RELATED OBJECTS
            # ============================================================

            # Find OAuth Entity Profile(s)
            profile_response = client.query_table(
                table_name="oauth_entity_profile",
                query=f"oauth_entity={entity_sys_id}",
                fields=["sys_id", "name"],
                limit=10
            )

            profile_sys_ids = []
            if profile_response["success"] and profile_response["result"]:
                profile_sys_ids = [p["sys_id"] for p in profile_response["result"]]

            # Find OAuth 2.0 Credential(s)
            credential_sys_ids = []
            if profile_sys_ids:
                for profile_sys_id in profile_sys_ids:
                    cred_response = client.query_table(
                        table_name="oauth_2_0_credentials",
                        query=f"oauth_entity_profile={profile_sys_id}",
                        fields=["sys_id", "name"],
                        limit=10
                    )

                    if cred_response["success"] and cred_response["result"]:
                        credential_sys_ids.extend([c["sys_id"] for c in cred_response["result"]])

            # Find HTTP Connection(s)
            connection_sys_ids = []
            connection_alias_ids = set()
            if credential_sys_ids:
                for cred_sys_id in credential_sys_ids:
                    conn_response = client.query_table(
                        table_name="http_connection",
                        query=f"credential={cred_sys_id}",
                        fields=["sys_id", "name", "connection_alias"],
                        limit=10
                    )

                    if conn_response["success"] and conn_response["result"]:
                        for c in conn_response["result"]:
                            connection_sys_ids.append(c["sys_id"])
                            alias_ref = c.get("connection_alias")
                            alias_ref = alias_ref.get("value") if isinstance(alias_ref, dict) else alias_ref
                            if alias_ref:
                                connection_alias_ids.add(alias_ref)

            # Find the integration's OWN Connection & Credential Alias(es).
            # setup_oauth_integration creates the alias (name=<api name>, id=<UPPER_SNAKE name>,
            # type=connection) and links it from http_connection.connection_alias. Never look
            # aliases up by type alone: that matches every connection alias on the instance.
            def _ref(value):
                return value.get("value") if isinstance(value, dict) else value

            def _alias_row(alias_sys_id):
                r = client.query_table(
                    table_name="sys_alias",
                    query=f"sys_id={alias_sys_id}",
                    fields=["sys_id", "name", "id"],
                    limit=1
                )
                if r["success"] and r["result"]:
                    return r["result"][0]
                return None

            def _foreign_connections(alias_sys_id):
                """sys_ids of http_connection records outside this integration that use the alias,
                or None when the lookup failed (treated as: cannot prove it is ours)."""
                r = client.query_table(
                    table_name="http_connection",
                    query=f"connection_alias={alias_sys_id}",
                    fields=["sys_id"],
                    limit=20
                )
                if not r["success"]:
                    return None
                return [c["sys_id"] for c in r["result"] if c["sys_id"] not in connection_sys_ids]

            skipped = []
            alias_candidates = {}  # sys_id -> alias row

            for alias_sys_id in sorted(connection_alias_ids):
                row = _alias_row(alias_sys_id)
                if row:
                    alias_candidates[alias_sys_id] = row

            # A partially created integration has the alias but no connection yet: match on
            # the exact name AND the id the setup tool derives from that name. The platform
            # stores the id lowercased (spike S-B), so the id is compared case-insensitively
            # here rather than in the query.
            derived_alias_id = entity_name.upper().replace(" ", "_").replace("-", "_")
            partial = client.query_table(
                table_name="sys_alias",
                query=f"name={entity_name}^type=connection",
                fields=["sys_id", "name", "id"],
                limit=20
            )
            if partial["success"]:
                for row in partial["result"]:
                    if str(row.get("id") or "").lower() == derived_alias_id.lower():
                        alias_candidates.setdefault(row["sys_id"], row)

            connection_alias_sys_ids = []
            for alias_sys_id, row in alias_candidates.items():
                foreign = _foreign_connections(alias_sys_id)
                label = f"{row.get('name')} ({row.get('id')})"
                if foreign is None:
                    skipped.append(f"Connection & Credential Alias {label}: could not check whether another HTTP connection uses it")
                elif foreign:
                    skipped.append(f"Connection & Credential Alias {label}: also used by another HTTP connection ({', '.join(foreign)})")
                else:
                    connection_alias_sys_ids.append(row)

            if connection_sys_ids and not alias_candidates:
                skipped.append(
                    "No Connection & Credential Alias identified for this integration; check sys_alias manually"
                )

            # ============================================================
            # STEP 4: DELETE OBJECTS IN CORRECT ORDER (each delete is read back)
            # ============================================================

            not_found = []
            unverified = []
            base_url = client.config.instance

            if not client._prepare_request():
                return "❌ Authentication failed: could not prepare credentials for the delete requests. Nothing was deleted."

            def _delete(table, sys_id, label, name, ident=None):
                outcome = delete_with_readback(client.session, base_url, table, sys_id, timeout=30)
                if outcome["outcome"] == "deleted":
                    deleted_objects.append((label, name, ident))
                elif outcome["outcome"] == "not_found":
                    not_found.append(f"{label} {name or sys_id}: {outcome['message']}")
                elif outcome.get("unverified"):
                    unverified.append(f"{label} {name or sys_id}: {outcome['message']}")
                else:
                    errors.append(f"{label} {name or sys_id}: {outcome['message']}")

            # Reverse of creation order (oauth_entity -> credentials -> alias -> http_connection):
            # connection first, then its alias, then credentials, profiles, entity last.
            for conn_sys_id in connection_sys_ids:
                _delete("http_connection", conn_sys_id, "HTTP Connection", conn_sys_id)

            for alias in connection_alias_sys_ids:
                _delete("sys_alias", alias["sys_id"], "Connection & Credential Alias",
                        alias.get("name"), alias.get("id"))

            for cred_sys_id in credential_sys_ids:
                _delete("oauth_2_0_credentials", cred_sys_id, "OAuth 2.0 Credential", cred_sys_id)

            for profile_sys_id in profile_sys_ids:
                _delete("oauth_entity_profile", profile_sys_id, "OAuth Entity Profile", profile_sys_id)

            _delete("oauth_entity", entity_sys_id, "OAuth Entity", entity_name, entity_sys_id)

            # ============================================================
            # STEP 5: RETURN SUMMARY
            # ============================================================

            output = [
                "🧹 OAuth Integration Rollback Complete!",
                "",
                f"Integration Name: {entity_name}",
                f"Deleted {len(deleted_objects)} object(s)",
                ""
            ]

            if deleted_objects:
                output.append("🗑️  Deleted Objects (each confirmed gone by a read-back):")
                output.append("")
                for obj_type, obj_name, obj_id in deleted_objects:
                    if obj_id and obj_id != obj_name:
                        output.append(f"  ✓ {obj_type}: {obj_name} ({obj_id})")
                    elif obj_name:
                        output.append(f"  ✓ {obj_type}: {obj_name}")
                    else:
                        output.append(f"  ✓ {obj_type}")
                output.append("")

            if not_found:
                output.append("❔ Not found or not visible to this user (not counted as deleted):")
                output.append("")
                for item in not_found:
                    output.append(f"  • {item}")
                output.append("")

            if unverified:
                output.append("⚠️  Delete accepted, not verified (the confirming read-back could not run; check ServiceNow):")
                output.append("")
                for item in unverified:
                    output.append(f"  • {item}")
                output.append("")

            if skipped:
                output.append("⏭️  Skipped (not identified as this integration's own; left in place):")
                output.append("")
                for item in skipped:
                    output.append(f"  • {item}")
                output.append("")

            if errors:
                output.append("⚠️  Errors encountered:")
                output.append("")
                for error in errors:
                    output.append(f"  • {error}")
                output.append("")

            if not errors and not not_found and not skipped and not unverified:
                output.append("✅ All objects deleted successfully!")
            else:
                output.append("⚠️  Rollback finished, but not every object was confirmed deleted. Check ServiceNow for any remaining objects.")

            return "\n".join(output)

        except Exception as e:
            return f"❌ Unexpected error during rollback:\n\n{e}\n\nSome objects may have been deleted. Check ServiceNow."

    @mcp.tool()
    def apply_oauth_api_script(
        integration_name: str = "",
        oauth_entity_sys_id: str = "",
        script_name: str = "",
        script_sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Apply an OAuth API Script (sys_script_include) to an existing oauth_entity record.

        Provider-specific scripts handle non-standard response formats:
        - GitHub: OauthAPIScriptForGitHub — returns URL-encoded responses, not JSON
        - Google: custom token refresh logic
        - Microsoft: PKCE configuration differences

        Provide either integration_name OR oauth_entity_sys_id; either script_name OR script_sys_id.

        The update is read back: the stored oauth_api_script must equal the script written
        (a difference is an error) and the entity's scope must be unchanged (a change is a
        warning). A read-back that cannot confirm warns and keeps the success.

        Returns:
            Confirmation with integration name, entity sys_id, applied script name and read-back lines
        """

        # ============================================================
        # STEP 1: VALIDATE PARAMETERS AND INSTANCE
        # ============================================================

        # Check if instance confirmation is needed
        confirmation_error = require_instance_confirmation(instance, "modify OAuth entity")
        if confirmation_error:
            return confirmation_error

        if not integration_name and not oauth_entity_sys_id:
            return (
                "❌ Missing required parameters:\n\n"
                "Please provide either:\n"
                "  • integration_name (e.g., 'GitHub Integration')\n"
                "  • oauth_entity_sys_id (e.g., 'abc123...')\n"
            )

        if not script_name and not script_sys_id:
            return (
                "❌ Missing required parameters:\n\n"
                "Please provide either:\n"
                "  • script_name (e.g., 'OauthAPIScriptForGitHub')\n"
                "  • script_sys_id (e.g., 'def456...')\n"
            )

        client = get_client(instance)

        try:
            # ============================================================
            # STEP 2: FIND THE OAUTH ENTITY
            # ============================================================

            if oauth_entity_sys_id:
                # Verify the entity exists
                entity_response = client.query_table(
                    table_name="oauth_entity",
                    query=f"sys_id={oauth_entity_sys_id}",
                    fields=["sys_id", "name", "sys_scope"],
                    limit=1,
                    display_value="false"
                )

                if not entity_response["success"] or not entity_response["result"]:
                    return f"❌ OAuth Entity not found with sys_id: {oauth_entity_sys_id}"

                entity = entity_response["result"][0]
                entity_sys_id = oauth_entity_sys_id
                entity_name = entity.get("name", "Unknown")

            else:
                # Find by name
                entity_response = client.query_table(
                    table_name="oauth_entity",
                    query=f"name={integration_name}",
                    fields=["sys_id", "name", "sys_scope"],
                    limit=1,
                    display_value="false"
                )

                if not entity_response["success"] or not entity_response["result"]:
                    return f"❌ OAuth Entity not found with name: {integration_name}"

                entity = entity_response["result"][0]
                entity_sys_id = entity["sys_id"]
                entity_name = entity.get("name", "Unknown")

            # ============================================================
            # STEP 3: FIND THE OAUTH API SCRIPT
            # ============================================================

            if script_sys_id:
                # Verify the script exists
                script_response = client.query_table(
                    table_name="sys_script_include",
                    query=f"sys_id={script_sys_id}",
                    fields=["sys_id", "name", "description"],
                    limit=1
                )

                if not script_response["success"] or not script_response["result"]:
                    return f"❌ OAuth API Script not found with sys_id: {script_sys_id}"

                script = script_response["result"][0]
                final_script_sys_id = script_sys_id
                final_script_name = script.get("name", "Unknown")

            else:
                # Find by name
                script_response = client.query_table(
                    table_name="sys_script_include",
                    query=f"name={script_name}",
                    fields=["sys_id", "name", "description"],
                    limit=1
                )

                if not script_response["success"] or not script_response["result"]:
                    return f"❌ OAuth API Script not found with name: {script_name}"

                script = script_response["result"][0]
                final_script_sys_id = script["sys_id"]
                final_script_name = script.get("name", "Unknown")

            # ============================================================
            # STEP 4: UPDATE OAUTH ENTITY WITH SCRIPT
            # ============================================================

            # The scope the entity has BEFORE the update, raw value. An update by sys_id
            # never moves scope, and the platform ignores sysparm_scope on it, so none is
            # sent; the read-back below checks the scope really did not change.
            scope_before = scope_value(entity.get("sys_scope"))

            if not client._prepare_request():
                return "❌ Could not authenticate to ServiceNow. Check the instance credentials."

            update_response = client.session.patch(
                f"{client.config.instance}/api/now/table/oauth_entity/{entity_sys_id}",
                json={"oauth_api_script": final_script_sys_id},
            )

            if update_response.status_code not in [200, 201]:
                return (
                    f"❌ Failed to update OAuth Entity with script:\n\n"
                    f"Status Code: {update_response.status_code}\n"
                    f"Response: {update_response.text}\n\n"
                    "Check permissions on oauth_entity table."
                )

            # ============================================================
            # STEP 5: READ BACK THE UPDATE
            # ============================================================

            readback_lines = []
            stored_script, stored_scope = "", ""
            try:
                check = client.query_table(
                    table_name="oauth_entity", query=f"sys_id={entity_sys_id}",
                    fields=["sys_id", "oauth_api_script", "sys_scope"],
                    limit=1, display_value="false")
                rows = check.get("result") if check.get("success") else None
                row = rows[0] if rows and isinstance(rows[0], dict) else None
                if row and scope_value(row.get("sys_id")) == entity_sys_id:
                    stored_script = scope_value(row.get("oauth_api_script"))
                    stored_scope = scope_value(row.get("sys_scope"))
            except Exception:
                stored_script, stored_scope = "", ""

            if not stored_script:
                readback_lines.append(
                    "⚠️  The update was accepted, but the OAuth API Script field could not be "
                    "confirmed by read-back; check the OAuth Entity in ServiceNow.")
            elif stored_script != final_script_sys_id:
                return (
                    "❌ The OAuth Entity update did not take:\n\n"
                    f"OAuth Entity ID: {entity_sys_id}\n"
                    f"Wrote OAuth API Script: {final_script_sys_id}\n"
                    f"Read back OAuth API Script: {stored_script}\n\n"
                    "ServiceNow accepted the request but the stored value is different. "
                    "Check permissions and business rules on oauth_entity."
                )
            else:
                readback_lines.append(f"✓ OAuth API Script read back as {final_script_sys_id}")

            if stored_scope and scope_before and stored_scope != scope_before:
                readback_lines.append(
                    f"⚠️  The OAuth Entity's scope changed during the update: it was "
                    f"{scope_before} and is now {stored_scope} (read back).")

            # ============================================================
            # STEP 6: RETURN SUCCESS MESSAGE
            # ============================================================

            output = [
                "✅ OAuth API Script Applied!",
                "",
                f"Integration: {entity_name}",
                f"OAuth Entity ID: {entity_sys_id}",
                "",
                f"Applied Script: {final_script_name}",
                f"Script ID: {final_script_sys_id}",
                "",
                "📋 Next Steps:",
                "  1. Navigate to System OAuth > Application Registry",
                f"  2. Open: {entity_name}",
                "  3. Verify 'OAuth API Script' field shows: " + final_script_name,
                "  4. Click 'Get OAuth Token' to test the configuration",
                "",
                "💡 What This Does:",
                f"  The {final_script_name} script handles provider-specific OAuth requirements,",
                "  such as custom response formats, headers, and authentication flows.",
                "  This ensures your OAuth integration works correctly with the provider's API.",
                "",
                "🔎 Read-back:",
            ] + [f"  {line}" for line in readback_lines]

            return "\n".join(output)

        except Exception as e:
            return f"❌ Unexpected error applying OAuth API Script:\n\n{e}"

    @mcp.tool()
    def inspect_oauth_entity(
        name_or_sys_id: str,
        instance: str = None
    ) -> str:
        """
        Return a full diagnostic snapshot of an oauth_entity record (oauth_entity table).

        Surfaces key config fields and flags common misconfigurations:
        - Wrong type (should be 'client' for inbound/MCP OAuth)
        - Wrong grant type (should be 'client_credentials')
        - Missing or inactive Application User
        - Non-global scope (oauth_entity inherits session scope; cannot be changed via API)

        Args:
            name_or_sys_id: oauth_entity sys_id (32-char hex) or partial name match
        """
        if not name_or_sys_id:
            return "name_or_sys_id is required."

        client = get_client(instance)
        is_sys_id = bool(re.match(r'^[0-9a-f]{32}$', name_or_sys_id))

        if is_sys_id:
            query = f"sys_id={name_or_sys_id}"
        else:
            query = f"nameLIKE{name_or_sys_id}"

        response = client.query_table(
            table_name="oauth_entity",
            query=query,
            fields=["sys_id", "name", "active", "type", "default_grant_type",
                    "user", "client_id", "sys_scope", "sys_package"],
            limit=5,
            display_value="all"
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        records = response["result"]
        if not records:
            label = "sys_id" if is_sys_id else "name"
            return f"No oauth_entity found with {label}: {name_or_sys_id}"

        def _dv(field):
            if isinstance(field, dict):
                return field.get("display_value", "") or field.get("value", "") or ""
            return str(field) if field else ""

        def _val(field):
            if isinstance(field, dict):
                return field.get("value", "") or ""
            return str(field) if field else ""

        def _format_record(r):
            name = _dv(r.get("name", ""))
            sys_id = _val(r.get("sys_id", ""))
            active = _dv(r.get("active", ""))
            type_val = _val(r.get("type", ""))
            grant_val = _val(r.get("default_grant_type", ""))
            user_val = _val(r.get("user", ""))
            user_dv = _dv(r.get("user", ""))
            client_id = _dv(r.get("client_id", ""))
            scope_dv = _dv(r.get("sys_scope", ""))
            package_dv = _dv(r.get("sys_package", "")) or "(none)"

            user_status = ""
            if user_val:
                user_resp = client.query_table(
                    table_name="sys_user",
                    query=f"sys_id={user_val}",
                    fields=["sys_id", "user_name", "active"],
                    limit=1
                )
                if user_resp["success"] and user_resp["result"]:
                    user_active = user_resp["result"][0].get("active", "true")
                    user_status = "active" if user_active == "true" else "INACTIVE"
                else:
                    user_status = "not found"

            user_line = f"{user_dv} ({user_status})" if user_val else "(none)"
            lines = [
                f"OAuth Entity: {name}",
                f"  sys_id:       {sys_id}",
                f"  active:       {active}",
                f"  type:         {type_val}",
                f"  grant type:   {grant_val}",
                f"  client_id:    {client_id}",
                f"  user:         {user_line}",
                f"  scope:        {scope_dv}",
                f"  package:      {package_dv}",
                "",
                "Diagnostic:",
            ]

            flags = []

            if type_val == "client":
                flags.append("  ✓ type = client")
            else:
                flags.append(f"  ⚠️ type = '{type_val}' — should be 'client' for inbound/MCP OAuth")

            if grant_val == "client_credentials":
                flags.append("  ✓ default_grant_type = client_credentials")
            else:
                flags.append(f"  ⚠️ default_grant_type = '{grant_val}' — should be 'client_credentials'")

            if not user_val:
                flags.append("  ⚠️ No Application User configured")
            elif user_status == "INACTIVE":
                flags.append(f"  ⚠️ Application User '{user_dv}' is inactive")
            elif user_status == "not found":
                flags.append(f"  ⚠️ Application User sys_id '{user_val}' not found in sys_user")
            else:
                flags.append(f"  ✓ Application User '{user_dv}' is active")

            if scope_dv.lower() in ("global", ""):
                flags.append("  ✓ scope = global")
            else:
                flags.append(
                    f"  ⚠️ scope = '{scope_dv}' (not global — oauth_entity inherits session scope "
                    f"and cannot be changed via API)"
                )

            lines.extend(flags)
            return "\n".join(lines)

        if len(records) == 1:
            return _format_record(records[0])

        blocks = [f"Found {len(records)} oauth_entity records matching '{name_or_sys_id}':\n"]
        for i, r in enumerate(records, 1):
            blocks.append(f"--- {i} of {len(records)} ---")
            blocks.append(_format_record(r))
        return "\n\n".join(blocks)
