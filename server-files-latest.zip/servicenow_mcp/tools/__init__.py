"""Tool Registration - Central registry for all ServiceNow MCP tools"""

from mcp.server.fastmcp import FastMCP

def register_all_tools(mcp: FastMCP):
    """Register all tools with the MCP server."""

    # Import and register logging tools
    from .logging.syslog import register_tools as register_syslog_tools
    register_syslog_tools(mcp)

    # Import and register audit tools
    from .audit.audit import register_tools as register_audit_tools
    register_audit_tools(mcp)

    # Import and register flow tools
    from .flows.flow_debugging import register_tools as register_flow_tools
    register_flow_tools(mcp)

    # Import and register AI/GenAI tools
    from .ai.genai import register_tools as register_ai_tools
    register_ai_tools(mcp)

    # Import and register AI agent tools (split from agents.py)
    from .ai.agent_management import register_tools as register_agent_management_tools
    register_agent_management_tools(mcp)

    from .ai.tool_catalog import register_tools as register_tool_catalog_tools
    register_tool_catalog_tools(mcp)

    from .ai.tool_associations import register_tools as register_tool_association_tools
    register_tool_association_tools(mcp)

    from .ai.agent_versions import register_tools as register_agent_version_tools
    register_agent_version_tools(mcp)

    from .ai.agent_access import register_tools as register_agent_access_tools
    register_agent_access_tools(mcp)

    # Import and register AI execution tracing tools
    from .ai.execution import register_tools as register_ai_execution_tools
    register_ai_execution_tools(mcp)

    # Import and register agentic workflow tools
    from .ai.workflows import register_tools as register_ai_workflow_tools
    register_ai_workflow_tools(mcp)

    # Import and register NowAssist capability tools
    from .ai.nowassist import register_tools as register_nowassist_tools
    register_nowassist_tools(mcp)

    # Import and register AI Search tools
    from .ai.ai_search import register_tools as register_ai_search_tools
    register_ai_search_tools(mcp)

    # Import and register integration tools
    from .integration.rest_messages import register_tools as register_integration_tools
    register_integration_tools(mcp)

    # Import and register event and scheduled job tools
    from .events.events import register_tools as register_event_tools
    register_event_tools(mcp)

    # Import and register code retrieval tools
    from .code import register_tools as register_code_tools
    register_code_tools(mcp)

    # Import and register generic table query tools
    from .generic.table import register_tools as register_generic_tools
    register_generic_tools(mcp)

    # Import and register status tools
    from .generic.status import register_tools as register_status_tools
    register_status_tools(mcp)

    # Import and register schema tools
    from .generic.schema import register_tools as register_schema_tools
    register_schema_tools(mcp)

    # Import and register custom table tools
    from .generic.custom_table import register_tools as register_custom_table_tools
    register_custom_table_tools(mcp)

    # Import and register automation tools
    from .automation.oauth_setup import register_tools as register_automation_tools
    register_automation_tools(mcp)

    # Import and register inbound OAuth tools
    from .automation.inbound_oauth import register_tools as register_inbound_oauth_tools
    register_inbound_oauth_tools(mcp)

    # Import and register inbound OAuth rollback tools
    from .automation.inbound_oauth_rollback import register_tools as register_inbound_oauth_rollback_tools
    register_inbound_oauth_rollback_tools(mcp)

    # Import and register instance management tools
    from .instances.management import register_tools as register_instance_tools
    register_instance_tools(mcp)

    # Import and register UI Builder tools
    from .ui.macroponent import register_tools as register_macroponent_tools
    register_macroponent_tools(mcp)

    # Import and register UI Builder workspace tools
    from .ui.uib_workspace import register_tools as register_uib_workspace_tools
    register_uib_workspace_tools(mcp)

    # Import and register choice list management tools
    from .generic.choice_list import register_tools as register_choice_list_tools
    register_choice_list_tools(mcp)

    # Import and register MCP server update tools
    from .update import register_tools as register_update_tools
    register_update_tools(mcp)

    print("All tools registered successfully")
