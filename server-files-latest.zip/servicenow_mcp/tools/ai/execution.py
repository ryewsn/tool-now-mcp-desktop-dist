"""AI Agent Execution Tracing Tools — execution plans, tasks, tool calls, messages."""

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error


def register_tools(mcp: FastMCP):
    """Register AI agent execution tracing tools with the MCP server."""

    @mcp.tool()
    def query_ai_agent_executions(
        agent_name: str = "",
        status: str = "",
        created_by: str = "",
        state: str = "",
        run_type: str = "",
        limit: int = 500,
        minutes_ago: int = 15,
        instance: str = None
    ) -> str:
        """
        Query AI Agent execution plans (sn_aia_execution_plan) — top-level records showing what
        an agent planned to do, its outcome, and performance metrics. Start here when debugging
        Now Assist AI Agent behavior or tracing agentic workflows.

        Use when: agent isn't behaving as expected; agent failed to complete its objective;
        investigating agent orchestration or multi-step workflows.

        Use get_table_schema("sn_aia_execution_plan") for valid field names and values.

        Args:
            status: "success" or "error"
            state: ready, in_progress, completed, terminated, abandoned
            run_type: API, Chat, Testing, Trigger, Evaluation
            minutes_ago: default 15; pass 0 to remove time filter

        Key fields in results:
            state/state_reason: "terminated" or "abandoned" with state_reason explains why.
            execution_time_ms: Total wall-clock time; compare llm_p95_latency vs tool_p95_latency to find bottleneck.
            system_execution_time_ms: Platform overhead separate from LLM/tool time.
            llm_token_avg: Average tokens per LLM call (prompt size indicator).
            usecase: The agentic workflow (sn_aia_usecase) this execution belongs to.
            related_task_record/related_task_table: Task record that triggered this execution.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_like("agent", agent_name)
        builder.add_equals("status", status)
        builder.add_equals("sys_created_by", created_by)
        builder.add_equals("state", state)
        builder.add_equals("run_type", run_type)
        builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "DESC")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_execution_plan",
            query=query,
            fields=[
                "sys_id", "sys_created_on", "agent", "state", "state_reason",
                "status", "run_type", "execution_mode", "execution_time_ms",
                "llm_p95_latency", "tool_p95_latency", "llm_token_avg",
                "usecase", "start_time", "end_time", "sys_created_by", "objective",
                # New fields added during schema validation
                "conversation", "context", "structured_output",
                "related_task_record", "related_task_table",
                "system_execution_time_ms", "team"
            ],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No AI agent executions found matching your criteria."

        # Format output
        output = []
        for entry in results:
            state_reason = entry.get('state_reason', '')
            state_reason_line = f"\nState reason: {state_reason}" if state_reason else ""
            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('state', 'N/A')} | {entry.get('status', 'N/A')}\n"
                f"Agent: {entry.get('agent', 'N/A')} | Objective: {entry.get('objective', 'N/A')}\n"
                f"Run type: {entry.get('run_type', 'N/A')} | Mode: {entry.get('execution_mode', 'N/A')} | Created by: {entry.get('sys_created_by', 'N/A')}\n"
                f"Time: {entry.get('execution_time_ms', 'N/A')}ms | LLM P95: {entry.get('llm_p95_latency', 'N/A')}ms | Tool P95: {entry.get('tool_p95_latency', 'N/A')}ms"
                f"{state_reason_line}\n"
                f"Execution ID: {entry.get('sys_id', 'N/A')}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def query_execution_tasks(
        execution_plan: str = "",
        status: str = "",
        type: str = "",
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        Query AI Agent execution tasks (sn_aia_execution_task) — the ordered step-by-step
        breakdown of what the agent did within a single execution plan. Use when you have an
        execution_plan sys_id from query_ai_agent_executions and need to see each step's
        outcome, timing, and output. Results ordered by `order` ASC (chronological).

        Use when: a specific step failed; diagnosing per-step timing bottlenecks; tracing
        the sequence of LLM calls, tool calls, and orchestration steps.

        No `agent` field (comes from parent plan). No `error_message` — errors in `output`.
        Use get_table_schema("sn_aia_execution_task") for valid field names and values.

        Args:
            execution_plan: Parent execution plan sys_id
            status: "success" or "error"
            type: agent, manager, communicator, gen_ai, tool, access_verification

        Key fields in results:
            order: Chronological sequence within the plan.
            type: Execution layer — gen_ai (LLM call), tool, agent, manager, communicator, access_verification.
            output: Full task output; contains error details when status=error.
            target_document_id/target_document_table: Record this task operated on, if any.
            error_type: Branching signal — when set, check sn_aia_message for error details;
                when null, check sn_aia_tools_execution for tool call failures.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_equals("parent", execution_plan)
        builder.add_equals("status", status)
        builder.add_equals("type", type)

        # Order by order ASC to show chronological execution sequence
        query = builder.add_order_by("order", "")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_execution_task",
            query=query,
            fields=[
                "sys_id", "description", "type", "status", "order",
                "execution_time_ms", "start_time", "end_time", "output",
                "metadata", "parent", "task_dependencies",
                "target_document_id", "target_document_table", "error_type"
            ],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No execution tasks found matching your criteria."

        # Format output
        output = []
        for entry in results:
            order = entry.get('order', '?')
            task_type = entry.get('type', 'N/A')
            task_status = entry.get('status', 'N/A')
            exec_time = entry.get('execution_time_ms', 'N/A')
            description = entry.get('description', 'N/A')
            task_output = entry.get('output', '')
            metadata = entry.get('metadata', '')
            target_id = entry.get('target_document_id', '')
            target_table = entry.get('target_document_table', '')
            error_type = entry.get('error_type', '')

            line = f"[{order}] {task_type} ({task_status}) {exec_time}ms — {description}"

            if task_output:
                line += f"\n  Output: {task_output}"

            if metadata:
                line += f"\n  Metadata: {metadata}"

            if target_table and target_id:
                line += f"\n  Target: {target_table}/{target_id}"

            if error_type:
                line += f"\n  Error type: {error_type}"

            output.append(line)

        result = "\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def query_tool_executions(
        execution_plan_id: str = "",
        execution_status: str = "",
        tool: str = "",
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        Query AI Agent tool executions (sn_aia_tools_execution) — actual tool calls made
        during an agent execution with full request/response payloads. Use when you have an
        execution_plan sys_id from query_ai_agent_executions and need to inspect tool invocations.

        Use when: a tool call failed or timed out; tool stuck (filter execution_status=processing);
        debugging exact request/response payloads or per-tool timing.

        IMPORTANT: The FK to the parent execution plan is `execution_plan_id` (NOT
        `execution_plan` like other child tables). Schema inconsistency in ServiceNow's AI Agent tables.

        Use get_table_schema("sn_aia_tools_execution") for valid field names and values.

        Args:
            execution_plan_id: Parent execution plan sys_id — NOTE: named execution_plan_id, not execution_plan
            execution_status: "success", "error", "timeout", or "processing" (stuck/hung)

        Key fields in results:
            execution_status: success, error, timeout (distinct from error), or processing (hung).
            execution_mode: sync or async.
            request/response: Full JSON payloads (not truncated).
            error_message: Set when execution_status is error or timeout.
            run_as_user: User context the tool executed under.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_equals("execution_plan_id", execution_plan_id)
        builder.add_equals("execution_status", execution_status)
        builder.add_equals("tool", tool)

        query = builder.add_order_by("sys_created_on", "DESC")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_tools_execution",
            query=query,
            fields=[
                "sys_id", "tool", "execution_status", "execution_mode",
                "execution_time_ms", "request", "response", "error_message",
                "run_as_user"
            ],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No tool executions found matching your criteria."

        # Format output
        output = []
        for entry in results:
            tool_name = entry.get('tool', 'N/A')
            status = entry.get('execution_status', 'N/A')
            exec_time = entry.get('execution_time_ms', 'N/A')
            mode = entry.get('execution_mode', 'N/A')
            run_as = entry.get('run_as_user', 'N/A')
            request_data = entry.get('request', '')
            response_data = entry.get('response', '')
            error_msg = entry.get('error_message', '')
            sys_id = entry.get('sys_id', 'N/A')

            line = f"Tool: {tool_name} | Status: {status} | {exec_time}ms ({mode})"
            line += f"\nRun as: {run_as}"

            if request_data:
                line += f"\nRequest: {request_data}"

            if response_data:
                line += f"\nResponse: {response_data}"

            if error_msg:
                line += f"\nError: {error_msg}"

            line += f"\nsys_id: {sys_id}"

            output.append(line)

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def query_agent_messages(
        execution_plan: str = "",
        role: str = "",
        type: str = "",
        error_type: str = "",
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        Query AI Agent conversation messages (sn_aia_message) — the full chronological message
        thread for an execution: user inputs, agent responses, tool calls, and errors. Use when
        you have an execution_plan sys_id from query_ai_agent_executions and need to see the
        exact conversation or trace error messages to specific turns.

        Use when: debugging what the user asked vs what the agent understood; investigating
        guard rail or safety net violations; tracing tool_call/tool_response sequences.

        Two content fields: `message` (agent/system) and `user_message` (user). Ordered by
        message_sequence ASC. Use get_table_schema("sn_aia_message") for valid field names.

        Args:
            execution_plan: Parent execution plan sys_id
            role: user, agent, system
            type: conversational, error, tool_call, tool_response, etc.
            error_type: tool_failure, access_failure, guard_rail, safety_net, bad_request,
                response_format_error, internal_failure, unknown

        Key fields in results:
            message_sequence: Chronological position within the execution.
            message/user_message: Agent/system content vs user content (separate fields, not truncated).
            error_type: Richest error taxonomy (8 modes) — set when type=error.
            name: Tool or function name for tool_call/tool_response messages.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_equals("execution_plan", execution_plan)
        builder.add_equals("role", role)
        builder.add_equals("type", type)
        builder.add_equals("error_type", error_type)

        # Order by message_sequence ASC for chronological conversation flow
        query = builder.add_order_by("message_sequence", "")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_message",
            query=query,
            fields=[
                "sys_id", "role", "type", "message", "user_message",
                "message_sequence", "error_type", "name",
                "document_name", "document_table"
            ],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No agent messages found matching your criteria."

        # Format output as interleaved conversation
        output = []
        for entry in results:
            seq = entry.get('message_sequence', '?')
            msg_role = entry.get('role', 'N/A')
            msg_type = entry.get('type', 'N/A')
            msg_error_type = entry.get('error_type', '')
            message = entry.get('message', '')
            user_message = entry.get('user_message', '')

            # Header: [seq] role (type) — error_type (when present)
            header = f"[{seq}] {msg_role} ({msg_type})"
            if msg_error_type:
                header += f" \u2014 {msg_error_type}"

            # Content: show user_message for user role, message for agent/system
            if msg_role == "user":
                content = f"  User: {user_message}"
            else:
                content = f"  System: {message}"

            output.append(f"{header}\n{content}")

        result = "\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def get_execution_details(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Canonical starting point for AI Agent execution debugging. Aggregates the execution
        plan, tasks (ordered chronologically), tool calls (with request/response), and full
        conversation messages in a single call.

        Troubleshooting path from here:
          1. Check state/state_reason on the plan — terminated/abandoned with a reason narrows scope immediately.
          2. Scan tasks in order — find the first task with status=error. Check its error_type:
             - error_type is set → go to query_agent_messages (error lives in the message thread)
             - error_type is null → go to query_tool_executions (tool call failed)
          3. If no task-level error, check messages for guard_rail or safety_net error_type.
          4. For unexplained failures: use query_syslog with this execution_plan_sys_id to find
             stacktraces from scripts, subflows, or actions that ran during this execution.
          5. Remember: AI Agents execute on top of platform tools — Subflows, Script Includes,
             Skills, Actions. The failing task points to the underlying platform component.
             Pivot to query_flow_executions, get_script_include, or get_business_rule as needed.

        Args:
            sys_id: Execution plan sys_id to investigate
        """
        client = get_client(instance)

        # 1. Query execution plan
        plan_builder = QueryBuilder()
        plan_builder.add_equals("sys_id", sys_id)
        plan_query = plan_builder.build()

        plan_response = client.query_table(
            table_name="sn_aia_execution_plan",
            query=plan_query,
            fields=[
                "sys_id", "sys_created_on", "agent", "state", "state_reason",
                "status", "run_type", "execution_mode", "execution_time_ms",
                "llm_p95_latency", "tool_p95_latency", "llm_token_avg",
                "usecase", "start_time", "end_time", "sys_created_by", "objective",
                "conversation", "context", "structured_output",
                "related_task_record", "related_task_table",
                "system_execution_time_ms", "team"
            ],
            limit=1
        )

        if not plan_response["success"]:
            return format_error(plan_response["status_code"], plan_response.get("error", "Unknown error"))

        plan_results = plan_response["result"]
        if not plan_results:
            return f"Execution plan not found: {sys_id}"

        plan = plan_results[0]

        # 2. Query execution tasks (FK: parent)
        task_builder = QueryBuilder()
        task_builder.add_equals("parent", sys_id)
        task_query = task_builder.add_order_by("order", "")

        task_response = client.query_table(
            table_name="sn_aia_execution_task",
            query=task_query,
            fields=[
                "sys_id", "description", "type", "status", "order",
                "execution_time_ms", "start_time", "end_time", "output",
                "metadata", "parent", "task_dependencies",
                "target_document_id", "target_document_table", "error_type"
            ],
            limit=100
        )
        tasks = task_response["result"] if task_response["success"] else []

        # 3. Query tool executions (FK: execution_plan_id — NOT execution_plan)
        tool_builder = QueryBuilder()
        tool_builder.add_equals("execution_plan_id", sys_id)
        tool_query = tool_builder.add_order_by("sys_created_on", "DESC")

        tool_response = client.query_table(
            table_name="sn_aia_tools_execution",
            query=tool_query,
            fields=[
                "sys_id", "tool", "execution_status", "execution_mode",
                "execution_time_ms", "request", "response", "error_message",
                "run_as_user"
            ],
            limit=100
        )
        tool_execs = tool_response["result"] if tool_response["success"] else []

        # 4. Query messages (FK: execution_plan)
        msg_builder = QueryBuilder()
        msg_builder.add_equals("execution_plan", sys_id)
        msg_query = msg_builder.add_order_by("message_sequence", "")

        msg_response = client.query_table(
            table_name="sn_aia_message",
            query=msg_query,
            fields=[
                "sys_id", "role", "type", "message", "user_message",
                "message_sequence", "error_type", "name",
                "document_name", "document_table"
            ],
            limit=100
        )
        messages = msg_response["result"] if msg_response["success"] else []

        # Format aggregated output
        output = []

        # --- Plan header ---
        state_reason = plan.get('state_reason', '')
        state_reason_part = f" ({state_reason})" if state_reason else ""
        output.append(
            f"=== Execution Plan: {plan.get('sys_id', 'N/A')} ===\n"
            f"State: {plan.get('state', 'N/A')} ({plan.get('status', 'N/A')}){state_reason_part} | Agent: {plan.get('agent', 'N/A')}\n"
            f"Objective: {plan.get('objective', 'N/A')}\n"
            f"Run type: {plan.get('run_type', 'N/A')} | Mode: {plan.get('execution_mode', 'N/A')} | Created by: {plan.get('sys_created_by', 'N/A')}\n"
            f"Time: {plan.get('execution_time_ms', 'N/A')}ms | LLM P95: {plan.get('llm_p95_latency', 'N/A')}ms | Tool P95: {plan.get('tool_p95_latency', 'N/A')}ms"
        )

        # --- Tasks section ---
        output.append(f"\n--- Execution Tasks ({len(tasks)}) ---")
        for task in tasks:
            order = task.get('order', '?')
            task_type = task.get('type', 'N/A')
            task_status = task.get('status', 'N/A')
            exec_time = task.get('execution_time_ms', 'N/A')
            description = task.get('description', 'N/A')
            error_type = task.get('error_type', '')
            error_type_part = f" [error_type: {error_type}]" if error_type else ""
            output.append(f"[{order}] {task_type} ({task_status}) {exec_time}ms \u2014 {description}{error_type_part}")

        # --- Tool executions section ---
        output.append(f"\n--- Tool Executions ({len(tool_execs)}) ---")
        for te in tool_execs:
            tool_name = te.get('tool', 'N/A')
            status = te.get('execution_status', 'N/A')
            exec_time = te.get('execution_time_ms', 'N/A')
            mode = te.get('execution_mode', 'N/A')
            request_data = te.get('request', '')
            response_data = te.get('response', '')
            error_msg = te.get('error_message', '')

            line = f"Tool: {tool_name} | Status: {status} | {exec_time}ms ({mode})"
            if request_data:
                line += f"\nRequest: {request_data}"
            if response_data:
                line += f"\nResponse: {response_data}"
            if error_msg:
                line += f"\nError: {error_msg}"
            output.append(line)

        # --- Messages section ---
        output.append(f"\n--- Messages ({len(messages)}) ---")
        for msg in messages:
            seq = msg.get('message_sequence', '?')
            msg_role = msg.get('role', 'N/A')
            msg_type = msg.get('type', 'N/A')
            message = msg.get('message', '')
            user_message = msg.get('user_message', '')

            content = user_message if msg_role == "user" else message
            output.append(f"[{seq}] {msg_role} ({msg_type}): {content}")

        return "\n".join(output)

    @mcp.tool()
    def query_va_conversation(
        sys_id: str = "",
        user: str = "",
        state: str = "",
        channel_id: str = "",
        limit: int = 50,
        minutes_ago: int = 60,
        instance: str = None
    ) -> str:
        """
        Query Virtual Agent conversations (sys_va_conversation) — the VA/NLU session that
        an AI Agent execution runs within. Use when diagnosing channel or NLU issues, or
        when the execution plan's `conversation` field points here.

        The execution plan's `conversation` field is the sys_id of the VA conversation.
        Pass it as `sys_id` to retrieve the full session context.

        Use when: AI Agent is not triggering at all; NLU is misrouting the conversation;
        investigating what channel (web, mobile, Teams) the agent ran in; correlating
        VA session state with agent execution failures.

        Use get_table_schema("sys_va_conversation") for valid field names and values.

        Args:
            sys_id: sys_id of a specific conversation (from execution plan's `conversation` field)
            user: Filter by user sys_id or username
            state: active, closed, abandoned, transferred
            channel_id: e.g. sn_va_web_client, sn_va_teams, sn_va_mobile
            minutes_ago: Default 60; pass 0 to remove time filter
            instance: ServiceNow instance alias (e.g., "prod", "dev"). Uses default if not specified.

        Key fields in results:
            sys_id: The conversation's primary key. Pass to query_va_conversation to retrieve a specific session.
            state: active/closed/abandoned/transferred — abandoned may indicate NLU failure.
            channel_id: Which VA channel this ran on.
            client_session: FK to sys_cs_message — pass to query_conversation_messages for the full message thread.
        """
        builder = QueryBuilder()
        builder.add_equals("sys_id", sys_id)
        builder.add_like("user", user)
        builder.add_equals("state", state)
        builder.add_equals("channel_id", channel_id)
        builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_va_conversation",
            query=query,
            fields=[
                "sys_id", "sys_created_on", "state", "channel_id",
                "user", "sys_created_by", "client_session"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No VA conversations found matching your criteria."

        output = []
        for entry in results:
            output.append(
                f"[{entry.get('sys_created_on')}] State: {entry.get('state', 'N/A')} | Channel: {entry.get('channel_id', 'N/A')}\n"
                f"User: {entry.get('user', 'N/A')} | Created by: {entry.get('sys_created_by', 'N/A')}\n"
                f"sys_id: {entry.get('sys_id', 'N/A')} | Session: {entry.get('client_session', 'N/A')}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). Use filters to narrow results."
        return result

    @mcp.tool()
    def query_conversation_messages(
        client_session: str = "",
        direction: str = "",
        channel: str = "",
        limit: int = 200,
        minutes_ago: int = 60,
        instance: str = None
    ) -> str:
        """
        Query conversation messages (sys_cs_message) — the full requester/fulfiller/system
        message thread. Use this to see what the user actually sent and received, as opposed
        to what the agent internally processed (sn_aia_message).

        The VA conversation's `client_session` field is the FK to this table. Start from
        query_va_conversation to get the session sys_id, then pass it as `client_session` here.

        Use when: tracing the exact user-facing conversation step where things went wrong;
        seeing system messages injected by VA (greetings, errors, slot-filling prompts);
        understanding the difference between what the user asked and what the agent received.

        Use get_table_schema("sys_cs_message") for valid field names and values.

        Args:
            client_session: VA conversation session sys_id (from sys_va_conversation.client_session)
            direction: inbound (from user) or outbound (to user)
            channel: Channel identifier (e.g. sn_va_web_client)
            limit: Maximum records to return (default 200)
            minutes_ago: Default 60; pass 0 to remove time filter
            instance: ServiceNow instance alias (e.g., "prod", "dev"). Uses default if not specified.

        Key fields in results:
            body: The message text.
            direction: inbound = from user; outbound = to user/system response.
            client_session: Links back to sys_va_conversation.
        """
        builder = QueryBuilder()
        builder.add_equals("client_session", client_session)
        builder.add_equals("direction", direction)
        builder.add_equals("channel", channel)
        builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "")

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_cs_message",
            query=query,
            fields=[
                "sys_id", "sys_created_on", "body", "direction",
                "client_session", "channel", "sys_created_by"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No conversation messages found matching your criteria."

        output = []
        for entry in results:
            direction_val = entry.get('direction', 'N/A')
            prefix = ">" if direction_val == "inbound" else "<"
            output.append(
                f"[{entry.get('sys_created_on')}] {prefix} {direction_val} | {entry.get('sys_created_by', 'N/A')}\n"
                f"  {entry.get('body', '')}"
            )

        result = "\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). Use client_session filter to narrow."
        return result
