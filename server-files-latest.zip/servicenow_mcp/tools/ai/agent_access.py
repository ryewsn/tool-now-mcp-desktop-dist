"""AI Agent access control tools — ACL roles, run-as identity, and subflow ACLs."""

import re

from mcp.server.mcpserver import MCPServer
from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error
from ...core.scope_lookup import resolve_scope, scope_value
from ...core.scoped_write import scoped_delete, scoped_insert, scoped_update


def _describe_rows(rows) -> str:
    """List candidate records (sys_id, name, scope sys_id), one per line, for an ambiguity error."""
    return "\n".join(
        f"  - sys_id {scope_value(r.get('sys_id'))}, name '{r.get('name', '')}', "
        f"scope sys_id '{scope_value(r.get('sys_scope')) or '(none)'}'"
        for r in rows
    )


def register_tools(mcp: MCPServer):
    """Register AI agent access control tools with the MCP server."""

    @mcp.tool()
    def set_agent_acl_roles(
        agent_sys_id: str,
        role_sys_ids: list,
        agent_table: str = "sn_aia_agent",
        replace_existing: bool = False,
        action: str = "limit_to_roles",
        allow_all_session_roles: bool = False,
        acl_sys_id: str = None,
        instance: str = None
    ) -> str:
        """
        Set role access for an AI Agent or Agentic Workflow — both Define User Access
        (sys_security_acl_role) and Define Data Access (sys_agent_access_role_configuration)
        in a single call. Writes go through the Foundry Script Runner (GlideRecord) and each
        record is verified by read-back.

        Locates the sys_security_acl record by agent name within the agent's own application
        scope: names equal to the agent name or ending in ".<agent name>" are preferred over
        a looser LIKE match, which is never accepted on its own. It must resolve to exactly one
        record: if several remain, or only loose (LIKE) matches exist, the call is refused before
        anything is changed, the candidates (sys_id, name, scope) are listed, and the retry is
        acl_sys_id='<one of the listed sys_ids>'. role_sys_ids must be 32-character hex sys_ids of
        existing sys_user_role records; anything else is refused before any write. An existing
        sys_agent_access_role_configuration for the agent must also be unique; if duplicates
        exist, the refusal lists them and the fix is to remove the duplicate record by sys_id
        in the instance, then retry the same call. New records are created in the agent's scope.
        Replace mode first inserts the missing requested role links, then removes only the
        links that are not in the requested set (unchanged links are left alone); if any insert
        failed, nothing is removed, so a failure leaves a superset of the target roles, never
        an empty set. Counts reported are only removals and inserts confirmed by read-back,
        and any failure is listed.
        For agentic workflows pass agent_table="sn_aia_usecase".

        Args:
            agent_sys_id: sys_id of the AI Agent or Agentic Workflow
            role_sys_ids: List of role sys_ids to assign
            agent_table: Default "sn_aia_agent"; use "sn_aia_usecase" for workflows
            replace_existing: True = add missing roles, then remove links not in role_sys_ids (nothing removed if any insert fails); False = additive
            action: sys_agent_access_role_configuration action. Default "limit_to_roles" (only valid value)
            allow_all_session_roles: Whether to allow all session roles on data access config. Default: False
            acl_sys_id: Optional sys_id of the sys_security_acl record to use. It must exist, be in
                the agent's scope and be named for this agent. Use it to retry when the call refuses because several ACLs match.
        """
        if not agent_sys_id:
            return "Please provide an agent_sys_id."
        if acl_sys_id and not re.match(r'^[0-9a-f]{32}$', acl_sys_id):
            return f"Invalid acl_sys_id format: '{acl_sys_id}'. Expected a 32-character hex sys_id."
        if not role_sys_ids:
            return "Please provide at least one role_sys_id."

        if not re.match(r'^[0-9a-f]{32}$', agent_sys_id):
            return f"Invalid agent_sys_id format: '{agent_sys_id}'. Expected a 32-character hex sys_id."
        bad_roles = [str(r) for r in role_sys_ids if not re.match(r'^[0-9a-f]{32}$', str(r))]
        if bad_roles:
            return (f"role_sys_ids must be 32-character hex sys_user_role sys_ids; invalid: "
                    f"{', '.join(bad_roles)}. Nothing was changed. Look the sys_ids up with "
                    f"query_table on sys_user_role.")
        wanted_ids = list(dict.fromkeys(str(r) for r in role_sys_ids))

        confirmation_error = require_instance_confirmation(instance, "set agent ACL roles")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        # --- Pre-flight 1: get agent name and scope reference ---
        agent_resp = client.query_table(
            table_name=agent_table,
            query=f"sys_id={agent_sys_id}",
            fields=["name", "sys_scope"],
            limit=1
        )
        if not agent_resp["success"]:
            return format_error(agent_resp["status_code"], agent_resp.get("error", ""))
        if not agent_resp["result"]:
            return f"Agent not found with sys_id: {agent_sys_id} in table {agent_table}"

        agent_record = agent_resp["result"][0]
        agent_name = agent_record.get("name", "")
        scope_sys_id = scope_value(agent_record.get("sys_scope"))
        if not scope_sys_id:
            return (f"Agent {agent_sys_id} has no application scope on record; "
                    f"cannot place the ACL role records. Nothing was changed.")
        if not agent_name.strip():
            return f"Agent {agent_sys_id} has no name on record, so its ACL cannot be identified. Nothing was changed."
        if "^" in agent_name or "\n" in agent_name:
            return "The agent name contains '^' or a newline and cannot be used to find its ACL. Nothing was changed."

        # --- Pre-flight 2: resolve the agent's scope (exact lookup) ---
        resolved = resolve_scope(client, scope_sys_id)
        if not resolved["success"]:
            return resolved["error"]
        scope_label = f"{resolved['scope']} ({resolved['name']})"

        # --- Pre-flight 2b: every requested role must exist ---
        role_check = client.query_table(
            table_name="sys_user_role",
            query=f"sys_idIN{','.join(wanted_ids)}",
            fields=["sys_id"],
            limit=len(wanted_ids)
        )
        if not role_check["success"]:
            return format_error(role_check["status_code"], role_check.get("error", ""))
        found_roles = {scope_value(r.get("sys_id")) for r in role_check["result"] or []}
        missing_roles = [r for r in wanted_ids if r not in found_roles]
        if missing_roles:
            return (f"These role_sys_ids do not exist in sys_user_role: {', '.join(missing_roles)}. "
                    f"Nothing was changed.")

        # --- Pre-flight 3: resolve the sys_security_acl record to exactly one ---
        if acl_sys_id:
            acl_resp = client.query_table(
                table_name="sys_security_acl",
                query=f"sys_id={acl_sys_id}",
                fields=["sys_id", "name", "sys_scope"],
                limit=1
            )
            if not acl_resp["success"]:
                return format_error(acl_resp["status_code"], acl_resp.get("error", ""))
            acl_rows = acl_resp["result"] or []
            if not acl_rows:
                return f"acl_sys_id {acl_sys_id} was not found in sys_security_acl. Nothing was changed."
            if scope_value(acl_rows[0].get("sys_scope")) != resolved["sys_id"]:
                return (
                    f"acl_sys_id {acl_sys_id} is not in the agent's scope {scope_label}. "
                    f"Nothing was changed. Use an ACL from that scope."
                )
            override_name = acl_rows[0].get("name", "")
            if override_name != agent_name and not override_name.endswith("." + agent_name):
                return (
                    f"acl_sys_id {acl_sys_id} is named '{override_name}', which is not the ACL of "
                    f"agent '{agent_name}'. Nothing was changed. Use the ACL named for this agent."
                )
        else:
            acl_resp = client.query_table(
                table_name="sys_security_acl",
                query=f"nameLIKE{agent_name}^sys_scope={resolved['sys_id']}",
                fields=["sys_id", "name", "sys_scope"],
                limit=10
            )
            if not acl_resp["success"]:
                return format_error(acl_resp["status_code"], acl_resp.get("error", ""))
            acl_rows = acl_resp["result"] or []
            if not acl_rows:
                return (
                    f"No sys_security_acl record found for agent '{agent_name}' "
                    f"(scope: {scope_label}). "
                    f"Verify the ACL exists and the agent name matches exactly."
                )
            narrowed = [r for r in acl_rows
                        if r.get("name", "") == agent_name
                        or r.get("name", "").endswith("." + agent_name)]
            if not narrowed:
                return (
                    f"No sys_security_acl record is named for agent '{agent_name}' in scope "
                    f"{scope_label}; only loose name matches exist, which are not accepted, so "
                    f"nothing was changed. Candidates:\n{_describe_rows(acl_rows)}\n"
                    f"If one of them is this agent's ACL, retry with "
                    f"acl_sys_id='<its sys_id>' (its name must still end in '.{agent_name}')."
                )
            acl_rows = narrowed
            if len(acl_rows) > 1:
                return (
                    f"{len(acl_rows)} sys_security_acl records match agent '{agent_name}' in scope "
                    f"{scope_label}; the ACL to change is ambiguous, so nothing was changed. "
                    f"Candidates:\n{_describe_rows(acl_rows)}\n"
                    f"Retry with acl_sys_id='<one of the listed sys_ids>'."
                )
        acl_sys_id = scope_value(acl_rows[0].get("sys_id"))

        # --- Pre-flight 4: resolve the data-access config to at most one ---
        cfg_resp = client.query_table(
            table_name="sys_agent_access_role_configuration",
            query=f"agent={agent_sys_id}^agent_table={agent_table}",
            fields=["sys_id", "name", "sys_scope"],
            limit=10
        )
        if not cfg_resp["success"]:
            return format_error(cfg_resp["status_code"], cfg_resp.get("error", ""))
        cfg_rows = cfg_resp["result"] or []
        if len(cfg_rows) > 1:
            return (
                f"{len(cfg_rows)} sys_agent_access_role_configuration records match agent "
                f"{agent_sys_id}; the one to update is ambiguous, so nothing was changed. "
                f"Candidates:\n{_describe_rows(cfg_rows)}\n"
                f"Remove the duplicate record by sys_id in the instance, then retry the same call."
            )
        cfg_sys_id = scope_value(cfg_rows[0].get("sys_id")) if cfg_rows else ""

        # --- Existing role links on the single resolved ACL ---
        roles_resp = client.query_table(
            table_name="sys_security_acl_role",
            query=f"sys_security_acl={acl_sys_id}",
            fields=["sys_id", "sys_user_role"],
            limit=1000
        )
        if not roles_resp["success"]:
            return format_error(roles_resp["status_code"], roles_resp.get("error", ""))
        existing_roles = roles_resp["result"] or []

        errors = []
        roles_deleted = 0
        existing_role_ids = {scope_value(r.get("sys_user_role")) for r in existing_roles}

        # --- Insert missing role links first; count only inserts confirmed by read-back ---
        roles_inserted = 0
        for role_id in wanted_ids:
            if role_id in existing_role_ids:
                continue
            inserted = scoped_insert(
                client,
                "sys_security_acl_role",
                {"sys_security_acl": acl_sys_id, "sys_user_role": role_id},
                resolved["sys_id"],
                param_name="scope",
            )
            if inserted["success"]:
                roles_inserted += 1
            else:
                errors.append(f"insert {role_id}: {inserted.get('error', '')}")

        # --- Replace mode: only after every insert held, remove links not in the requested set ---
        removal_skipped = False
        if replace_existing:
            if errors:
                removal_skipped = True
            else:
                for row in existing_roles:
                    if scope_value(row.get("sys_user_role")) in wanted_ids:
                        continue
                    row_id = scope_value(row.get("sys_id"))
                    deleted = scoped_delete(client, "sys_security_acl_role", sys_id=row_id)
                    if deleted["success"]:
                        roles_deleted += 1
                    else:
                        errors.append(f"delete {row_id}: {deleted.get('error', '')}")

        # --- Data access config: update the one resolved record, or insert ---
        role_list_str = ",".join(wanted_ids)
        cfg_data = {
            "role_list": role_list_str,
            "action": action,
            "allow_all_session_roles": bool(allow_all_session_roles),
        }
        if cfg_sys_id:
            cfg = scoped_update(client, "sys_agent_access_role_configuration", cfg_data,
                                sys_id=cfg_sys_id)
            config_op = "updated"
        else:
            cfg = scoped_insert(
                client,
                "sys_agent_access_role_configuration",
                {**cfg_data, "agent": agent_sys_id, "agent_table": agent_table,
                 "name": agent_sys_id},
                resolved["sys_id"],
                param_name="scope",
            )
            config_op = "inserted"
        if cfg["success"]:
            config_line = (f"  sys_agent_access_role_configuration: {config_op} "
                           f"(sys_id: {cfg['result']['sys_id']})")
        else:
            config_line = "  sys_agent_access_role_configuration: NOT written"
            errors.append(f"configuration write: {cfg.get('error', '')}")

        if not errors:
            headline = "ACL roles set successfully."
        elif roles_inserted == 0 and not cfg["success"]:
            headline = "Failed to set roles."
        else:
            headline = "ACL roles set with errors."
        lines = [
            headline,
            f"  Agent: {agent_sys_id}",
            f"  ACL record: {acl_sys_id}",
            f"  Scope: {scope_label}",
        ]
        if replace_existing:
            lines.append(f"  sys_security_acl_role records removed: {roles_deleted}")
        lines.append(f"  sys_security_acl_role records inserted (confirmed by read-back): {roles_inserted}")
        lines.append(config_line)
        if removal_skipped:
            lines.append("  Nothing was removed because an insert failed; the ACL now holds a "
                         "superset of the requested roles.")
        if errors:
            lines.append("  Failed:")
            lines.extend(f"    {e}" for e in errors)
        return "\n".join(lines)

    @mcp.tool()
    def set_run_as_user(
        agent_sys_id: str,
        mode: str,
        user_sys_id: str = "",
        agent_table: str = "sn_aia_agent",
        instance: str = None
    ) -> str:
        """
        Set the "Run as" identity mode for an AI Agent (mirrors Agent Builder "Define data access").

        Modes:
        - "dynamic": Runs as requesting user. Restores prior role_list from the latest
          sys_update_xml history row (matched by type and target_name only, whatever its
          update set or scope — a best-effort recovery); if none found, creates config with
          allow_all_session_roles=true. The new config is created in the agent's scope.
        - "ai_user": Runs as a specific service account (user_sys_id). Deletes the agent's
          sys_agent_access_role_configuration records that are in the agent's own scope, one
          by one — the AI user's own ACL governs data access. Records for the agent in
          another scope are listed and left untouched.

        The agent's sn_aia_agent_config must resolve to exactly one record; if none or
        several match, the call is refused before anything is changed (several are listed
        with sys_id, name and scope). The removed count reports only deletes confirmed by
        read-back, and failures are listed. Writes go through the Foundry Script Runner.

        Args:
            agent_sys_id: sys_id of the AI Agent
            mode: "dynamic" or "ai_user"
            user_sys_id: Required when mode="ai_user" — sys_id of the user to run as
            agent_table: Default "sn_aia_agent". Agentic Workflows (sn_aia_usecase) are
                NOT supported by this tool — their run-as identity lives on a different
                table (sn_aia_usecase_config_override.run_as_user, joined via
                usecase_configuration=<usecase_sys_id>, NOT via "agent" or "usecase").
                Passing agent_table="sn_aia_usecase" will fail with
                "No sn_aia_agent_config found" because the underlying script always
                queries sn_aia_agent_config regardless of this parameter. To set a
                workflow's run-as user, update sn_aia_usecase_config_override.run_as_user
                directly via update_record instead.
        """
        if not agent_sys_id:
            return "Please provide an agent_sys_id."
        if mode not in ("dynamic", "ai_user"):
            return "mode must be 'dynamic' or 'ai_user'."
        if mode == "ai_user" and not user_sys_id:
            return "user_sys_id is required when mode='ai_user'."

        if not re.match(r'^[0-9a-f]{32}$', agent_sys_id):
            return f"Invalid agent_sys_id format: '{agent_sys_id}'. Expected a 32-character hex sys_id."
        if mode == "ai_user" and not re.match(r'^[0-9a-f]{32}$', user_sys_id):
            return f"Invalid user_sys_id format: '{user_sys_id}'. Expected a 32-character hex sys_id."

        confirmation_error = require_instance_confirmation(instance, "set agent run-as user")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        # --- Pre-flight 1: the agent and its scope (writes and deletes are limited to it) ---
        agent_resp = client.query_table(
            table_name=agent_table,
            query=f"sys_id={agent_sys_id}",
            fields=["name", "sys_scope"],
            limit=1
        )
        if not agent_resp["success"]:
            return format_error(agent_resp["status_code"], agent_resp.get("error", ""))
        if not agent_resp["result"]:
            return f"Agent not found with sys_id: {agent_sys_id} in table {agent_table}"
        agent_scope_id = scope_value(agent_resp["result"][0].get("sys_scope"))
        if not agent_scope_id:
            return (f"Agent {agent_sys_id} has no application scope on record, so its "
                    f"records cannot be placed or bounded. Nothing was changed.")
        resolved = resolve_scope(client, agent_scope_id)
        if not resolved["success"]:
            return resolved["error"]
        scope_label = f"{resolved['scope']} ({resolved['name']})"

        # --- Pre-flight 2: the agent's sn_aia_agent_config must be exactly one record ---
        config_resp = client.query_table(
            table_name="sn_aia_agent_config",
            query=f"agent={agent_sys_id}",
            fields=["sys_id", "name", "sys_scope"],
            limit=10
        )
        if not config_resp["success"]:
            return format_error(config_resp["status_code"], config_resp.get("error", ""))
        config_rows = config_resp["result"] or []
        if not config_rows:
            return f"Failed to set run-as user: No sn_aia_agent_config found for agent {agent_sys_id}"
        if len(config_rows) > 1:
            return (
                f"{len(config_rows)} sn_aia_agent_config records match agent {agent_sys_id}; the "
                f"one to update is ambiguous, so nothing was changed. Candidates:\n"
                f"{_describe_rows(config_rows)}\n"
                f"Remove the duplicate record by sys_id in the instance, then retry the same call."
            )
        config_sys_id = scope_value(config_rows[0].get("sys_id"))

        # --- Pre-flight 3: what the chosen mode will touch, resolved before any write ---
        in_scope = []
        out_of_scope = []
        role_list = ""
        if mode == "ai_user":
            access_resp = client.query_table(
                table_name="sys_agent_access_role_configuration",
                query=f"agent={agent_sys_id}^agent_table={agent_table}",
                fields=["sys_id", "name", "sys_scope"],
                limit=100
            )
            if not access_resp["success"]:
                return format_error(access_resp["status_code"], access_resp.get("error", ""))
            for row in access_resp["result"] or []:
                if scope_value(row.get("sys_scope")) == resolved["sys_id"]:
                    in_scope.append(row)
                else:
                    out_of_scope.append(row)
        else:
            # Latest history row by type and target_name only (any update set or scope): the
            # restored role list is a best-effort recovery, not a verified source of truth.
            xml_resp = client.query_table(
                table_name="sys_update_xml",
                query=(f"type=Agent Access Role Configuration^target_name={agent_sys_id}"
                       f"^ORDERBYDESCsys_updated_on"),
                fields=["payload"],
                limit=1
            )
            if not xml_resp["success"]:
                return format_error(xml_resp["status_code"], xml_resp.get("error", ""))
            xml_rows = xml_resp["result"] or []
            payload = (xml_rows[0].get("payload") or "") if xml_rows else ""
            start = payload.find("<role_list>")
            if start >= 0:
                end = payload.find("</role_list>", start)
                if end >= 0:
                    role_list = payload[start + len("<role_list>"):end]

        # --- Write 1: run_as_user on the one resolved config ---
        run_as_value = user_sys_id if mode == "ai_user" else ""
        updated = scoped_update(client, "sn_aia_agent_config", {"run_as_user": run_as_value},
                                sys_id=config_sys_id)
        if not updated["success"]:
            return (f"Failed to set run-as user: could not update sn_aia_agent_config "
                    f"{config_sys_id}: {updated.get('error', '')}")

        if mode == "ai_user":
            # --- Write 2: remove this agent's data-access configs in its own scope, each confirmed ---
            removed = 0
            failures = []
            for row in in_scope:
                row_id = scope_value(row.get("sys_id"))
                deleted = scoped_delete(client, "sys_agent_access_role_configuration", sys_id=row_id)
                if deleted["success"]:
                    removed += 1
                else:
                    failures.append(f"{row_id}: {deleted.get('error', '')}")
            lines = [
                "Run-as mode set to AI User.",
                f"  Agent: {agent_sys_id}",
                f"  run_as_user: {user_sys_id}",
                f"  Approved role config records removed (confirmed by read-back): {removed}",
            ]
            if failures:
                lines.append("  Could not be removed:")
                lines.extend(f"    {f}" for f in failures)
            if out_of_scope:
                lines.append(
                    f"  Records for this agent in another scope were left untouched "
                    f"(agent scope: {scope_label}):"
                )
                lines.append(_describe_rows(out_of_scope))
            return "\n".join(lines)

        # --- Write 2 (dynamic): create the data-access config in the agent's scope ---
        new_cfg = {
            "agent": agent_sys_id,
            "agent_table": agent_table,
            "action": "limit_to_roles",
            "name": agent_sys_id,
            "allow_all_session_roles": False if role_list else True,
        }
        if role_list:
            new_cfg["role_list"] = role_list
        created = scoped_insert(client, "sys_agent_access_role_configuration", new_cfg,
                                resolved["sys_id"], param_name="scope")
        if not created["success"]:
            return (
                f"Failed to set run-as user: run_as_user was cleared, but the approved role "
                f"config could not be created: {created.get('error', '')}"
            )
        return (
            f"Run-as mode set to Dynamic.\n"
            f"  Agent: {agent_sys_id}\n"
            f"  run_as_user: cleared\n"
            f"  Roles recovered from update history: {'yes' if role_list else 'no (new config allows all roles)'}\n"
            f"  Approved role config created: {created['result']['sys_id']}"
        )

    @mcp.tool()
    def create_subflow_acl(
        scope: str,
        subflow_name: str,
        role_sys_ids: str = "",
        instance: str = None
    ) -> str:
        """
        Create the invoke_from_ai ACL (sys_security_acl) required for a subflow-type AI Agent tool.

        Subflow tools need operation=invoke_from_ai before an AI Agent can invoke them.
        ACL name format: sn_aia_tool.<scope>.<subflow_name>. The ACL and its role links are
        created in the application scope named by `scope` (scope id, scope sys_id or "global"),
        so the record's own scope matches the name. Idempotent — returns the existing sys_id
        without changes if an ACL with that name and operation already exists in that scope.
        Uses Foundry Script Runner (sys_metadata tables return 403 via REST API); each record
        is verified by read-back.

        Args:
            scope: Application scope of the subflow (e.g. "x_myco_myapp")
            subflow_name: Subflow name as it appears in the ACL
            role_sys_ids: Comma-separated sys_user_role sys_ids. Empty = ACL with no roles
        """
        confirmation_error = require_instance_confirmation(instance, "create subflow ACL")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        resolved = resolve_scope(client, scope)
        if not resolved["success"]:
            return resolved["error"]

        acl_name = f"sn_aia_tool.{resolved['scope']}.{subflow_name}"
        if "^" in acl_name or "\n" in acl_name:
            return "scope and subflow_name must not contain '^' or newlines."
        role_ids = [r.strip() for r in role_sys_ids.split(",") if r.strip()]

        existing = client.query_table(
            "sys_security_acl",
            f"name={acl_name}^operation=invoke_from_ai^sys_scope={resolved['sys_id']}",
            fields=["sys_id"],
            limit=1,
        )
        if not existing["success"]:
            return format_error(existing["status_code"], existing.get("error", ""))
        rows = existing.get("result") or []
        if rows:
            existing_id = rows[0].get("sys_id")
            if isinstance(existing_id, dict):
                existing_id = existing_id.get("value", "")
            return (f"ACL already exists for {acl_name}\n"
                    f"  ACL sys_id:   {existing_id}\n"
                    f"  No changes made.")

        acl = scoped_insert(
            client,
            "sys_security_acl",
            {"name": acl_name, "operation": "invoke_from_ai"},
            resolved["sys_id"],
            param_name="scope",
        )
        if not acl["success"]:
            return f"ACL insert failed for '{acl_name}': {acl.get('error', '')}"
        acl_id = acl["result"]["sys_id"]

        roles_created = 0
        role_errors = []
        for role_id in role_ids:
            role = scoped_insert(
                client,
                "sys_security_acl_role",
                {"sys_security_acl": acl_id, "sys_user_role": role_id},
                resolved["sys_id"],
                param_name="scope",
            )
            if role["success"]:
                roles_created += 1
            else:
                role_errors.append(f"{role_id}: {role.get('error', '')}")

        message = (f"ACL created for {acl_name}\n"
                   f"  ACL sys_id:     {acl_id}\n"
                   f"  Scope:          {acl['result'].get('scope')}\n"
                   f"  Roles linked:   {roles_created}")
        if role_errors:
            message += "\n  Role links that failed:\n    " + "\n    ".join(role_errors)
        return message
