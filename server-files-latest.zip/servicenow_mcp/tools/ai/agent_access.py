"""AI Agent access control tools — ACL roles, run-as identity, and subflow ACLs."""

import json
import re

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error


def register_tools(mcp: FastMCP):
    """Register AI agent access control tools with the MCP server."""

    @mcp.tool()
    def set_agent_acl_roles(
        agent_sys_id: str,
        role_sys_ids: list,
        agent_table: str = "sn_aia_agent",
        replace_existing: bool = False,
        action: str = "limit_to_roles",
        allow_all_session_roles: bool = False,
        instance: str = None
    ) -> str:
        """
        Set role access for an AI Agent or Agentic Workflow — both Define User Access
        (sys_security_acl_role) and Define Data Access (sys_agent_access_role_configuration)
        in a single call via the Foundry Script Runner.

        Locates the sys_security_acl record automatically by agent name and application scope.
        For agentic workflows pass agent_table="sn_aia_usecase".

        Args:
            agent_sys_id: sys_id of the AI Agent or Agentic Workflow
            role_sys_ids: List of role sys_ids to assign
            agent_table: Default "sn_aia_agent"; use "sn_aia_usecase" for workflows
            replace_existing: True = delete all existing ACL roles then re-insert; False = additive
            action: sys_agent_access_role_configuration action. Default "limit_to_roles" (only valid value)
            allow_all_session_roles: Whether to allow all session roles on data access config. Default: False
        """
        if not agent_sys_id:
            return "Please provide an agent_sys_id."
        if not role_sys_ids:
            return "Please provide at least one role_sys_id."

        if not re.match(r'^[0-9a-f]{32}$', agent_sys_id):
            return f"Invalid agent_sys_id format: '{agent_sys_id}'. Expected a 32-character hex sys_id."

        confirmation_error = require_instance_confirmation(instance, "set agent ACL roles")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        # --- Pre-flight 1: get agent name and scope reference ---
        agent_resp = client.query_table(
            table_name=agent_table,
            query=f"sys_id={agent_sys_id}",
            fields=["name", "sys_scope"],
            limit=1
        )
        if not agent_resp["success"]:
            return format_error(agent_resp["status_code"], agent_resp.get("error", ""))
        if not agent_resp["result"]:
            return f"Agent not found with sys_id: {agent_sys_id} in table {agent_table}"

        agent_record = agent_resp["result"][0]
        agent_name = agent_record.get("name", "")
        scope_ref = agent_record.get("sys_scope", {})
        scope_sys_id = scope_ref.get("value", "") if isinstance(scope_ref, dict) else scope_ref

        # --- Pre-flight 2: resolve scope namespace value ---
        scope_value = ""
        if scope_sys_id:
            scope_resp = client.query_table(
                table_name="sys_scope",
                query=f"sys_id={scope_sys_id}",
                fields=["scope"],
                limit=1
            )
            if scope_resp["success"] and scope_resp["result"]:
                scope_value = scope_resp["result"][0].get("scope", "")

        # --- Pre-flight 3: find sys_security_acl record ---
        acl_query = f"nameLIKE{agent_name}"
        if scope_value:
            acl_query += f"^sys_scope.scope={scope_value}"

        acl_resp = client.query_table(
            table_name="sys_security_acl",
            query=acl_query,
            fields=["sys_id", "name"],
            limit=5
        )
        if not acl_resp["success"]:
            return format_error(acl_resp["status_code"], acl_resp.get("error", ""))
        if not acl_resp["result"]:
            return (
                f"No sys_security_acl record found for agent '{agent_name}' "
                f"(scope: {scope_value or 'unknown'}). "
                f"Verify the ACL exists and the agent name matches exactly."
            )

        acl_sys_id = acl_resp["result"][0]["sys_id"]
        if len(acl_resp["result"]) > 1:
            acl_names = ", ".join(r["name"] for r in acl_resp["result"])
            acl_warning = f"Multiple ACL records matched — using first: {acl_sys_id}. All matches: {acl_names}"
        else:
            acl_warning = ""

        # --- Script: manage sys_security_acl_role + sys_agent_access_role_configuration ---
        role_sys_ids_js = json.dumps(role_sys_ids)
        role_list_str = ",".join(str(r) for r in role_sys_ids)
        allow_all_js = "true" if allow_all_session_roles else "false"
        agent_table_json = json.dumps(agent_table)
        action_json = json.dumps(action)
        role_list_json = json.dumps(role_list_str)

        if replace_existing:
            acl_role_block = f"""
// --- sys_security_acl_role (replace mode: delete all then re-insert) ---
var delGr = new GlideRecord('sys_security_acl_role');
delGr.addQuery('sys_security_acl', aclSysId);
delGr.deleteMultiple();
var aclRolesInserted = 0;
for (var i = 0; i < roleList.length; i++) {{
    var roleGr = new GlideRecord('sys_security_acl_role');
    roleGr.setValue('sys_security_acl', aclSysId);
    roleGr.setValue('sys_user_role', roleList[i]);
    roleGr.insert();
    aclRolesInserted++;
}}
gs.info('acl_roles_inserted:' + aclRolesInserted);"""
        else:
            acl_role_block = f"""
// --- sys_security_acl_role (additive mode: skip duplicates) ---
var aclRolesInserted = 0;
for (var i = 0; i < roleList.length; i++) {{
    var checkGr = new GlideRecord('sys_security_acl_role');
    checkGr.addQuery('sys_security_acl', aclSysId);
    checkGr.addQuery('sys_user_role', roleList[i]);
    checkGr.query();
    if (checkGr.next()) {{ continue; }}
    var roleGr = new GlideRecord('sys_security_acl_role');
    roleGr.setValue('sys_security_acl', aclSysId);
    roleGr.setValue('sys_user_role', roleList[i]);
    roleGr.insert();
    aclRolesInserted++;
}}
gs.info('acl_roles_inserted:' + aclRolesInserted);"""

        script = f"""
var aclSysId = '{acl_sys_id}';
var agentSysId = '{agent_sys_id}';
var agentTable = {agent_table_json};
var roleList = {role_sys_ids_js};
var roleListStr = {role_list_json};
var action = {action_json};
var allowAll = {allow_all_js};
{acl_role_block}

// --- sys_agent_access_role_configuration (upsert) ---
var cfgGr = new GlideRecord('sys_agent_access_role_configuration');
cfgGr.addQuery('agent', agentSysId);
cfgGr.addQuery('agent_table', agentTable);
cfgGr.query();
if (cfgGr.next()) {{
    cfgGr.setValue('role_list', roleListStr);
    cfgGr.setValue('action', action);
    cfgGr.setValue('allow_all_session_roles', allowAll);
    cfgGr.update();
    gs.info('config_operation:updated');
    gs.info('config_sys_id:' + cfgGr.getUniqueValue());
}} else {{
    var newCfg = new GlideRecord('sys_agent_access_role_configuration');
    newCfg.setValue('agent', agentSysId);
    newCfg.setValue('agent_table', agentTable);
    newCfg.setValue('action', action);
    newCfg.setValue('name', agentSysId);
    newCfg.setValue('role_list', roleListStr);
    newCfg.setValue('allow_all_session_roles', allowAll);
    var newSysId = newCfg.insert();
    if (newSysId) {{
        gs.info('config_operation:inserted');
        gs.info('config_sys_id:' + newSysId);
    }} else {{
        gs.error('config_insert_failed');
    }}
}}
"""
        if not client._prepare_request():
            return "Authentication failed."

        url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
        script_response = client.session.post(url, json={"script": script})

        if script_response.status_code == 400 and "does not represent any resource" in script_response.text:
            return (
                "Setting ACL roles requires the Foundry Script Runner to be installed.\n"
                "Use the setup_script_runner tool to install it, then retry."
            )

        if script_response.status_code not in (200, 201):
            return format_error(script_response.status_code, script_response.text[:500])

        result = script_response.json().get("result", {})
        error = result.get("error")
        output = result.get("output", [])

        if error or any("config_insert_failed" in line for line in output):
            return f"Failed to set roles: {error or 'config insert returned null'}"

        acl_inserted = "?"
        config_op = "?"
        config_sys_id = ""
        for line in output:
            if line.startswith("acl_roles_inserted:"):
                acl_inserted = line.split(":", 1)[1]
            elif line.startswith("config_operation:"):
                config_op = line.split(":", 1)[1]
            elif line.startswith("config_sys_id:"):
                config_sys_id = line.split(":", 1)[1]

        lines = [
            "ACL roles set successfully.",
            f"  Agent: {agent_sys_id}",
            f"  ACL record: {acl_sys_id}",
            f"  sys_security_acl_role records inserted: {acl_inserted}",
            f"  sys_agent_access_role_configuration: {config_op} (sys_id: {config_sys_id})",
        ]
        if acl_warning:
            lines.append(f"  {acl_warning}")
        return "\n".join(lines)

    @mcp.tool()
    def set_run_as_user(
        agent_sys_id: str,
        mode: str,
        user_sys_id: str = "",
        agent_table: str = "sn_aia_agent",
        instance: str = None
    ) -> str:
        """
        Set the "Run as" identity mode for an AI Agent (mirrors Agent Builder "Define data access").

        Modes:
        - "dynamic": Runs as requesting user. Restores prior role_list from sys_update_xml
          history; if none found, creates config with allow_all_session_roles=true.
        - "ai_user": Runs as a specific service account (user_sys_id). Deletes
          sys_agent_access_role_configuration — the AI user's own ACL governs data access.

        Always updates both sn_aia_agent_config.run_as_user and
        sys_agent_access_role_configuration. Requires Foundry Script Runner.

        Args:
            agent_sys_id: sys_id of the AI Agent
            mode: "dynamic" or "ai_user"
            user_sys_id: Required when mode="ai_user" — sys_id of the user to run as
            agent_table: Default "sn_aia_agent". Agentic Workflows (sn_aia_usecase) are
                NOT supported by this tool — their run-as identity lives on a different
                table (sn_aia_usecase_config_override.run_as_user, joined via
                usecase_configuration=<usecase_sys_id>, NOT via "agent" or "usecase").
                Passing agent_table="sn_aia_usecase" will fail with
                "No sn_aia_agent_config found" because the underlying script always
                queries sn_aia_agent_config regardless of this parameter. To set a
                workflow's run-as user, update sn_aia_usecase_config_override.run_as_user
                directly via update_record instead.
        """
        if not agent_sys_id:
            return "Please provide an agent_sys_id."
        if mode not in ("dynamic", "ai_user"):
            return "mode must be 'dynamic' or 'ai_user'."
        if mode == "ai_user" and not user_sys_id:
            return "user_sys_id is required when mode='ai_user'."

        if not re.match(r'^[0-9a-f]{32}$', agent_sys_id):
            return f"Invalid agent_sys_id format: '{agent_sys_id}'. Expected a 32-character hex sys_id."
        if mode == "ai_user" and not re.match(r'^[0-9a-f]{32}$', user_sys_id):
            return f"Invalid user_sys_id format: '{user_sys_id}'. Expected a 32-character hex sys_id."

        confirmation_error = require_instance_confirmation(instance, "set agent run-as user")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        agent_table_json = json.dumps(agent_table)

        if mode == "ai_user":
            script = f"""
var agentSysId = '{agent_sys_id}';
var userSysId = '{user_sys_id}';
var agentTable = {agent_table_json};

// Update sn_aia_agent_config.run_as_user
var configGr = new GlideRecord('sn_aia_agent_config');
configGr.addQuery('agent', agentSysId);
configGr.setLimit(1);
configGr.query();
if (!configGr.next()) {{
    gs.info('ERROR:No sn_aia_agent_config found for agent ' + agentSysId);
}} else {{
    configGr.setValue('run_as_user', userSysId);
    configGr.update();
    gs.info('config_updated:' + configGr.getUniqueValue());
}}

// Delete sys_agent_access_role_configuration
var aclCfgGr = new GlideRecord('sys_agent_access_role_configuration');
aclCfgGr.addQuery('agent', agentSysId);
aclCfgGr.addQuery('agent_table', agentTable);
aclCfgGr.query();
var deleted = 0;
while (aclCfgGr.next()) {{
    aclCfgGr.deleteRecord();
    deleted++;
}}
gs.info('acl_config_deleted:' + deleted);
"""
        else:
            script = f"""
var agentSysId = '{agent_sys_id}';
var agentTable = {agent_table_json};

// Clear sn_aia_agent_config.run_as_user
var configGr = new GlideRecord('sn_aia_agent_config');
configGr.addQuery('agent', agentSysId);
configGr.setLimit(1);
configGr.query();
if (!configGr.next()) {{
    gs.info('ERROR:No sn_aia_agent_config found for agent ' + agentSysId);
}} else {{
    configGr.setValue('run_as_user', '');
    configGr.update();
    gs.info('config_updated:' + configGr.getUniqueValue());
}}

// Recover prior role_list from sys_update_xml payload
var roleList = '';
var xmlGr = new GlideRecord('sys_update_xml');
xmlGr.addQuery('type', 'Agent Access Role Configuration');
xmlGr.addQuery('target_name', agentSysId);
xmlGr.orderByDesc('sys_updated_on');
xmlGr.setLimit(1);
xmlGr.query();
if (xmlGr.next()) {{
    var payload = xmlGr.getValue('payload');
    if (payload) {{
        var startTag = '<role_list>';
        var endTag = '</role_list>';
        var startIdx = payload.indexOf(startTag);
        if (startIdx >= 0) {{
            var endIdx = payload.indexOf(endTag, startIdx);
            if (endIdx >= 0) {{
                roleList = payload.substring(startIdx + startTag.length, endIdx);
            }}
        }}
    }}
    gs.info('roles_recovered:' + (roleList ? 'true' : 'false'));
}}

// Create sys_agent_access_role_configuration
var newCfg = new GlideRecord('sys_agent_access_role_configuration');
newCfg.setValue('agent', agentSysId);
newCfg.setValue('agent_table', agentTable);
newCfg.setValue('action', 'limit_to_roles');
newCfg.setValue('name', agentSysId);
newCfg.setValue('allow_all_session_roles', roleList ? false : true);
if (roleList) {{
    newCfg.setValue('role_list', roleList);
}}
var newSysId = newCfg.insert();
if (newSysId) {{
    gs.info('acl_config_created:' + newSysId);
}} else {{
    gs.error('acl_config_create_failed');
}}
"""

        if not client._prepare_request():
            return "Authentication failed."

        url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
        script_response = client.session.post(url, json={"script": script})

        if script_response.status_code == 400 and "does not represent any resource" in script_response.text:
            return (
                "set_run_as_user requires the Foundry Script Runner to be installed.\n"
                "Use the setup_script_runner tool to install it, then retry."
            )

        if script_response.status_code not in (200, 201):
            return format_error(script_response.status_code, script_response.text[:500])

        result = script_response.json().get("result", {})
        error = result.get("error")
        output = result.get("output", [])

        if error or any(line.startswith("ERROR:") for line in output):
            error_line = next((l for l in output if l.startswith("ERROR:")), "")
            return f"Failed to set run-as user: {error or error_line}"

        if mode == "ai_user":
            acl_deleted = next((l.split(":", 1)[1] for l in output if l.startswith("acl_config_deleted:")), "0")
            return (
                f"Run-as mode set to AI User.\n"
                f"  Agent: {agent_sys_id}\n"
                f"  run_as_user: {user_sys_id}\n"
                f"  Approved role config records removed: {acl_deleted}"
            )
        else:
            roles_recovered = any("roles_recovered:true" in l for l in output)
            acl_created = next((l.split(":", 1)[1] for l in output if l.startswith("acl_config_created:")), "")
            return (
                f"Run-as mode set to Dynamic.\n"
                f"  Agent: {agent_sys_id}\n"
                f"  run_as_user: cleared\n"
                f"  Roles recovered from update history: {'yes' if roles_recovered else 'no (new config allows all roles)'}\n"
                f"  Approved role config created: {acl_created or 'failed'}"
            )

    @mcp.tool()
    def create_subflow_acl(
        scope: str,
        subflow_name: str,
        role_sys_ids: str = "",
        instance: str = None
    ) -> str:
        """
        Create the invoke_from_ai ACL (sys_security_acl) required for a subflow-type AI Agent tool.

        Subflow tools need operation=invoke_from_ai before an AI Agent can invoke them.
        ACL name format: sn_aia_tool.<scope>.<subflow_name>. Idempotent — returns existing
        sys_id without changes if ACL already exists. Uses Foundry Script Runner (sys_metadata
        tables return 403 via REST API).

        Args:
            scope: Application scope of the subflow (e.g. "x_myco_myapp")
            subflow_name: Subflow name as it appears in the ACL
            role_sys_ids: Comma-separated sys_user_role sys_ids. Empty = ACL with no roles
        """
        confirmation_error = require_instance_confirmation(instance, "create subflow ACL")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        if not client._prepare_request():
            return "Authentication failed."

        acl_name = f"sn_aia_tool.{scope}.{subflow_name}"
        role_ids = [r.strip() for r in role_sys_ids.split(",") if r.strip()]
        role_ids_json = json.dumps(role_ids)
        acl_name_json = json.dumps(acl_name)

        script = f"""
var aclName = {acl_name_json};

var existing = new GlideRecord('sys_security_acl');
existing.addQuery('name', aclName);
existing.addQuery('operation', 'invoke_from_ai');
existing.setLimit(1);
existing.query();
if (existing.next()) {{
    gs.info('existing_acl:' + existing.sys_id);
}} else {{
    var acl = new GlideRecord('sys_security_acl');
    acl.setValue('name', aclName);
    acl.setValue('operation', 'invoke_from_ai');
    var aclId = acl.insert();
    if (!aclId) {{
        gs.info('acl_insert_failed');
    }} else {{
        var roleIds = {role_ids_json};
        var rolesCreated = 0;
        for (var i = 0; i < roleIds.length; i++) {{
            var rl = new GlideRecord('sys_security_acl_role');
            rl.setValue('sys_security_acl', aclId);
            rl.setValue('sys_user_role', roleIds[i]);
            if (rl.insert()) rolesCreated++;
        }}
        gs.info('created_acl:' + aclId);
        gs.info('roles_created:' + rolesCreated);
    }}
}}
"""

        url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
        response = client.session.post(url, json={"script": script})

        if response.status_code == 400 and "does not represent any resource" in response.text:
            return ("Creating subflow ACLs requires the Foundry Script Runner to be installed.\n"
                    "Use the setup_script_runner tool to install it, then retry.")
        if response.status_code not in (200, 201):
            return format_error(response.status_code, response.text[:500])

        result = response.json().get("result", {})
        output = result.get("output", [])
        error = result.get("error")

        if error:
            return f"Script error: {error}"

        for line in output:
            if line.startswith("existing_acl:"):
                existing_id = line.split(":", 1)[1]
                return (f"ACL already exists for {acl_name}\n"
                        f"  ACL sys_id:   {existing_id}\n"
                        f"  No changes made.")

        if "acl_insert_failed" in output:
            return f"ACL insert failed for '{acl_name}'. Check scope and permissions."

        acl_id = ""
        roles_created = 0
        for line in output:
            if line.startswith("created_acl:"):
                acl_id = line.split(":", 1)[1]
            elif line.startswith("roles_created:"):
                try:
                    roles_created = int(line.split(":", 1)[1])
                except ValueError:
                    pass

        if not acl_id:
            return f"ACL creation may have failed. Script output: {output}"

        return (f"ACL created for {acl_name}\n"
                f"  ACL sys_id:     {acl_id}\n"
                f"  Roles linked:   {roles_created}")
