"""Agentic Workflow and Trigger Tools — workflows, triggers, and configuration."""

from mcp.server.mcpserver import MCPServer
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error
from ...core.scope_lookup import landed_scope_text, scope_value
from ...core.scoped_write import scoped_delete, scoped_update


def register_tools(mcp: MCPServer):
    """Register agentic workflow and trigger tools with the MCP server."""

    @mcp.tool()
    def list_agentic_workflows(
        name: str = "",
        execution_mode: str = "",
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        List Agentic Workflows from sn_aia_usecase. Note: sn_aia_usecase has no `active` or
        `state` field. For AI Agents, use list_ai_agents instead.

        Args:
            execution_mode: "autopilot" or "copilot"
            limit: CAUTION: on instances with many workflows, even limit=500 can exceed the
                response token cap. Start with limit=20-50 when exploring, or narrow with
                name/execution_mode first.

        Key fields in results:
            execution_mode: autopilot (independent) or copilot (assists user).
            record_type: Origin — custom, promoted, template, or aia_internal.
            condition: Encoded query controlling when the workflow applies.

        base_plan (the workflow's full instruction text) is intentionally excluded from this
        listing to keep results compact — fetch it via get_record(table="sn_aia_usecase",
        sys_id=...) once you've identified the workflow you need.
        """
        builder = QueryBuilder()
        builder.add_like("name", name)
        builder.add_equals("execution_mode", execution_mode)
        query = builder.add_order_by("sys_created_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_usecase",
            query=query,
            fields=[
                "sys_id", "name", "description", "execution_mode",
                "record_type", "strategy", "team",
                "condition", "sys_scope", "sys_created_on"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No agentic workflows found matching your criteria."

        output = []
        for entry in results:
            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('name', 'N/A')}\n"
                f"Mode: {entry.get('execution_mode', 'N/A')} | Record: {entry.get('record_type', 'N/A')}\n"
                f"Description: {entry.get('description', 'N/A')}\n"
                f"Team: {entry.get('team', 'N/A')} | Strategy: {entry.get('strategy', 'N/A')}\n"
                f"Condition: {entry.get('condition', 'N/A')}\n"
                f"Scope: {entry.get('sys_scope', 'N/A')}\n"
                f"sys_id: {entry.get('sys_id', 'N/A')}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def list_trigger_configurations(
        usecase: str = "",
        active: str = "",
        target_table: str = "",
        sys_scope: str = "",
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        List Trigger Configurations for Agentic Workflows (sn_aia_trigger_configuration).

        Trigger strategy is behavioral (how often the trigger fires), NOT event-type:
        - once: Fire once per matching record
        - unique_changes: Fire when record changes match condition (deduplicated)
        - always: Fire every time the condition is met
        - every: Fire on every evaluation cycle

        Do NOT join through sn_aia_trigger_agent_usecase_m2m.usecase to find triggers for a
        workflow or app — that field is not readable via REST query (403). Use the usecase or
        sys_scope filters on this table directly instead.

        Args:
            usecase: Filter by workflow sys_id (exact match)
            active: "true" or "false"
            sys_scope: Filter by application scope sys_id — use to find all triggers for a scoped app
            limit: CAUTION: unfiltered calls on instances with many triggers can exceed the
                response token cap. Narrow with usecase/sys_scope/target_table first.

        Key fields in results:
            trigger_strategy: once, unique_changes, always, every.
            objective_template: Agent's objective template (may contain ${field} placeholders).
            channel: Communication channel (e.g., nap).
            condition: Encoded query that activates the trigger.
            run_as: field_name identifying the run-as strategy.
            run_as_script: script evaluated at runtime, returns a sys_id string.
            run_as_user: reference to sys_user — the run-as identity when run_as is user-based.
            run_start, run_period, run_time: Schedule configuration.
        """
        builder = QueryBuilder()
        builder.add_equals("usecase", usecase)
        builder.add_equals("active", active)
        builder.add_like("target_table", target_table)
        builder.add_equals("sys_scope", sys_scope)
        query = builder.add_order_by("sys_created_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_trigger_configuration",
            query=query,
            fields=[
                "sys_id", "name", "active", "usecase", "target_table",
                "trigger_strategy", "condition", "objective_template",
                "channel", "run_as", "run_as_script", "run_as_user", "run_start", "run_period",
                "run_time", "run_dayofweek", "run_dayofmonth", "description",
                "sys_scope", "sys_created_on"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No trigger configurations found matching your criteria."

        output = []
        for entry in results:
            active_status = "active" if entry.get("active") == "true" else "inactive"
            lines = [
                f"[{entry.get('sys_created_on')}] {entry.get('name', 'N/A')} ({active_status})",
                f"Target: {entry.get('target_table', 'N/A')} | Strategy: {entry.get('trigger_strategy', 'N/A')}",
                f"Usecase: {entry.get('usecase', 'N/A')} | Channel: {entry.get('channel', 'N/A')}",
                f"Objective: {entry.get('objective_template', 'N/A')}",
                f"Description: {entry.get('description', 'N/A')}",
                f"Condition: {entry.get('condition', 'N/A')}",
                f"Run as: {entry.get('run_as', 'N/A')} | Run as user: {entry.get('run_as_user', 'N/A')}",
            ]
            if entry.get("run_as_script"):
                lines.append(f"Run as script: {entry.get('run_as_script')}")

            # Include schedule fields if any are populated
            run_start = entry.get("run_start", "")
            run_period = entry.get("run_period", "")
            run_time = entry.get("run_time", "")
            run_dayofweek = entry.get("run_dayofweek", "")
            run_dayofmonth = entry.get("run_dayofmonth", "")
            if run_start or run_period or run_time or run_dayofweek or run_dayofmonth:
                schedule_parts = []
                if run_start:
                    schedule_parts.append(run_start)
                if run_period:
                    schedule_parts.append(f"Period: {run_period}")
                if run_time:
                    schedule_parts.append(f"Time: {run_time}")
                if run_dayofweek:
                    schedule_parts.append(f"Day of week: {run_dayofweek}")
                if run_dayofmonth:
                    schedule_parts.append(f"Day of month: {run_dayofmonth}")
                lines.append(f"Schedule: {' | '.join(schedule_parts)}")

            lines.append(f"Scope: {entry.get('sys_scope', 'N/A')}")
            lines.append(f"sys_id: {entry.get('sys_id', 'N/A')}")

            output.append("\n".join(lines))

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def manage_agentic_workflow(
        name: str = "",
        description: str = "",
        execution_mode: str = "",
        base_plan: str = "",
        condition: str = "",
        scope_sys_id: str = "",
        sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create or update an Agentic Workflow in ServiceNow (sn_aia_usecase).

        Pass sys_id to update an existing workflow. Omit sys_id to create a new one.

        On create, an sn_aia_team record is automatically created and linked to the workflow
        so team members are visible in AI Agent Studio. This does not happen on update.

        **Instruction versioning:** If version records exist in sn_aia_version (query by
        target_id = workflow sys_id), use the version system — do NOT update base_plan directly.
        - Update active version: update_record on sn_aia_version (instructions field), then call
          manage_agentic_workflow to sync base_plan on sn_aia_usecase.
        - New version: create in AI Agent Studio UI, then populate via update_record.
        - Switch active version: set state to "published" — platform withdraws previous and syncs sn_aia_usecase.
        - Recovery (both withdrawn): publish correct version via update_record, then sync base_plan.

        If no version records exist, direct updates to base_plan are safe.

        Args:
            execution_mode: "autopilot" or "copilot". Defaults to "autopilot" on create.
            scope_sys_id: Target application scope: scope id (x_snc_...), scope sys_id or "global". Required on create (no default; a create without it is refused). Not used on update.
            base_plan: CAUTION: If version records exist in sn_aia_version, use the version system.
            sys_id: If provided, update this record instead of creating.
            instance: ServiceNow instance alias (uses default if not specified)
        """
        confirmation_error = require_instance_confirmation(instance, "manage agentic workflow")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        if sys_id:
            # Update mode
            data = {}
            if name:
                data["name"] = name
            if description:
                data["description"] = description
            if execution_mode:
                data["execution_mode"] = execution_mode
            if base_plan:
                data["base_plan"] = base_plan
            if condition:
                data["condition"] = condition

            response = client.glide_write(table="sn_aia_usecase", operation="update", data=data, sys_id=sys_id)
            if not response["success"]:
                return format_error(response["status_code"], response.get("error", "Unknown error"))
            return f"Agentic Workflow '{sys_id}' updated successfully."

        # Create mode
        if not name:
            return "name is required to create an agentic workflow."

        data = {
            "name": name,
            "description": description,
            "execution_mode": execution_mode if execution_mode else "autopilot",
        }
        if base_plan:
            data["base_plan"] = base_plan
        if condition:
            data["condition"] = condition

        # Step 1: Create the workflow record
        response = client.glide_write(table="sn_aia_usecase", operation="insert", data=data, scope_sys_id=scope_sys_id)
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        workflow_sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"

        # Step 2: Auto-create sn_aia_team (required for AI Agent Studio to show team members)
        team_response = client.glide_write(
            table="sn_aia_team", operation="insert", data={"name": f"{name} Team"},
            scope_sys_id=scope_sys_id,
        )
        if not team_response["success"]:
            return (
                f"Agentic Workflow '{name}' created (workflow_sys_id: {workflow_sys_id}), "
                f"but team auto-creation failed: {team_response.get('error', 'Unknown error')}\n"
                f"Create an sn_aia_team record manually and set sn_aia_usecase.team to link it."
            )

        team_result = team_response["result"]
        team_sys_id = team_result.get("sys_id", "unknown") if isinstance(team_result, dict) else "unknown"

        # Step 3: Link the team to the workflow
        link_response = client.glide_write(
            table="sn_aia_usecase", operation="update",
            data={"team": team_sys_id}, sys_id=workflow_sys_id
        )
        if not link_response["success"]:
            return (
                f"Agentic Workflow '{name}' created (workflow_sys_id: {workflow_sys_id}), "
                f"team created (team_sys_id: {team_sys_id}), "
                f"but team linking failed: {link_response.get('error', 'Unknown error')}"
            )

        return (
            f"Agentic Workflow '{name}' created successfully.\n"
            f"workflow_sys_id: {workflow_sys_id}\n"
            f"team_sys_id: {team_sys_id}"
        )

    @mcp.tool()
    def delete_agentic_workflow(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Delete an Agentic Workflow from ServiceNow (sn_aia_usecase). This action cannot be undone.

        Use list_agentic_workflows to find the workflow's sys_id first.
        """
        confirmation_error = require_instance_confirmation(instance, "delete agentic workflow")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        response = client.glide_write(table="sn_aia_usecase", operation="delete", data={}, sys_id=sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        return f"Agentic Workflow '{sys_id}' deleted successfully."

    @mcp.tool()
    def manage_trigger(
        name: str = "",
        target_table: str = "",
        condition: str = "",
        channel: str = "",
        objective_template: str = "",
        usecase: str = "",
        trigger_strategy: str = "",
        active: str = "",
        run_as_user: str = "",
        trigger_flow_definition_type: str = "",
        scope_sys_id: str = "",
        sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create or update a Trigger Configuration for an Agentic Workflow
        (sn_aia_trigger_configuration).

        Pass sys_id to update an existing trigger. Omit sys_id to create a new one.

        On create: if trigger_flow_definition_type is provided, also creates the Business Rule
        that fires the workflow. If usecase is provided, also creates the
        sn_aia_trigger_agent_usecase_m2m record so the trigger appears in AI Agent Studio.

        On update: trigger_flow_definition_type is ignored (BR is created at trigger creation only).
        If active is provided, also syncs active to all linked sn_aia_trigger_agent_usecase_m2m records.

        Args:
            target_table: Table the trigger monitors (e.g., "incident", "change_request")
            condition: Encoded query condition (e.g., "state=new^priority<=2")
            channel: "nap" (Now Assist Panel) or "nap_and_va"
            objective_template: Agent objective template — supports ${field_name} variables
            usecase: sn_aia_usecase sys_id to link this trigger to a workflow
            trigger_strategy: "once", "unique_changes", "always", "every". Default on create: "once"
            active: "true" or "false". Default on create: "true"
            trigger_flow_definition_type: (create only) "record_create", "record_update", "ui_action"
            scope_sys_id: Target application scope: scope id (x_snc_...), scope sys_id or "global". Required on create (no default; a create without it is refused). Not used on update.
            sys_id: If provided, update this record instead of creating.
            instance: ServiceNow instance alias (uses default if not specified)

        Scope: on create the trigger (and its business rule and workflow link) is placed in
        `scope_sys_id`, not inherited from an agent; the result shows a Scope line read back
        from the record. An update prints no Scope line (the record's scope never changes);
        syncing `active` to the workflow links goes through the scoped layer.
        `active` accepts true/false/1/0 (any case); anything else is refused before writing.
        Requires the Script Runner (setup_script_runner); without it the tool returns
        "Script Runner not installed — use setup_script_runner to install it".

        Note: Business Rule script body uses class sn_aia.AgenticWorkflowTriggerHandler.
        If a trigger does not fire, verify this class name against a wizard-created trigger.
        """
        confirmation_error = require_instance_confirmation(instance, "manage trigger configuration")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        # Same rule on create and update: true/false/1/0, any case; anything else is refused.
        if active:
            normalised = {"true": "true", "1": "true", "false": "false", "0": "false"}.get(
                str(active).strip().lower()
            )
            if normalised is None:
                return f"active must be 'true' or 'false' (got {active!r}). Nothing was written."
            active = normalised

        if sys_id:
            # Update mode — uses glide_write (sn_aia_trigger_configuration extends sys_metadata)
            data = {}
            if name:
                data["name"] = name
            if target_table:
                data["target_table"] = target_table
            if condition:
                data["condition"] = condition
            if channel:
                data["channel"] = channel
            if objective_template:
                data["objective_template"] = objective_template
            if usecase:
                data["usecase"] = usecase
            if trigger_strategy:
                data["trigger_strategy"] = trigger_strategy
            if active:
                data["active"] = active
            if run_as_user:
                data["run_as_user"] = run_as_user

            response = client.glide_write(
                table="sn_aia_trigger_configuration", operation="update",
                data=data, sys_id=sys_id
            )
            if not response["success"]:
                return format_error(response["status_code"], response.get("error", "Unknown error"))

            if not active:
                return f"Trigger '{sys_id}' updated successfully."

            # Sync active to the m2m join record — AI Agent Studio reads active from
            # sn_aia_trigger_agent_usecase_m2m.active, not sn_aia_trigger_configuration.active
            # (issue #195).
            builder = QueryBuilder()
            builder.add_equals("trigger_configuration", sys_id)
            builder.add_equals("related_resource_table", "sn_aia_usecase")
            m2m_response = client.query_table(
                table_name="sn_aia_trigger_agent_usecase_m2m",
                query=builder.build(),
                fields=["sys_id"],
                limit=50
            )

            if not m2m_response["success"]:
                return (
                    f"Trigger '{sys_id}' updated, but active could not be synced to workflow "
                    f"links: {m2m_response.get('error', 'Unknown error')}"
                )
            if not m2m_response["result"]:
                return f"Trigger '{sys_id}' updated successfully."

            sync_errors = []
            for m2m in m2m_response["result"]:
                m2m_id = scope_value(m2m.get("sys_id"))
                synced = scoped_update(
                    client, "sn_aia_trigger_agent_usecase_m2m", {"active": active},
                    sys_id=m2m_id,
                )
                if not synced["success"]:
                    sync_errors.append(f"  {m2m_id}: {synced.get('error', 'Unknown error')}")

            if sync_errors:
                return (
                    f"Trigger '{sys_id}' updated, but active was NOT synced to "
                    f"{len(sync_errors)} of {len(m2m_response['result'])} workflow link "
                    f"record(s) (sn_aia_trigger_agent_usecase_m2m), so AI Agent Studio may "
                    f"show the old value:\n" + "\n".join(sync_errors)
                )
            return f"Trigger '{sys_id}' updated successfully."

        # Create mode
        if not name:
            return "name is required to create a trigger."

        data = {
            "name": name,
            "target_table": target_table,
            "condition": condition,
            "channel": channel,
            "objective_template": objective_template,
            "trigger_strategy": trigger_strategy if trigger_strategy else "once",
            "active": active if active else "true",
        }
        if usecase:
            data["usecase"] = usecase
        if run_as_user:
            data["run_as_user"] = run_as_user
        if trigger_flow_definition_type:
            data["trigger_flow_definition_type"] = trigger_flow_definition_type

        response = client.glide_write(
            table="sn_aia_trigger_configuration", operation="insert",
            data=data, scope_sys_id=scope_sys_id
        )
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        trigger_sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"

        # Generate the Business Rule that fires the trigger logic (issue #190).
        br_sys_id = None
        br_link_error = ""
        if trigger_flow_definition_type and trigger_sys_id != "unknown":
            action_insert = "true" if trigger_flow_definition_type == "record_create" else "false"
            action_update = "true" if trigger_flow_definition_type == "record_update" else "false"
            if trigger_flow_definition_type not in ("record_create", "record_update"):
                action_insert = "true"
                action_update = "true"

            br_script = (
                f"sn_aia.AgenticWorkflowTriggerHandler"
                f".executeTrigger(current, previous, '{trigger_sys_id}');"
            )
            br_data = {
                "name": f"AIA Trigger - {name}",
                "collection": target_table,
                "when": "after",
                "active": active if active else "true",
                "action_insert": action_insert,
                "action_update": action_update,
                "filter_condition": condition,
                "script": br_script,
            }
            br_response = client.glide_write(
                table="sys_script", operation="insert",
                data=br_data, scope_sys_id=scope_sys_id
            )
            if br_response["success"]:
                br_result = br_response.get("result", {})
                br_sys_id = br_result.get("sys_id") if isinstance(br_result, dict) else None
                if br_sys_id:
                    link_response = client.glide_write(
                        table="sn_aia_trigger_configuration",
                        operation="update",
                        data={"business_rule": br_sys_id},
                        sys_id=trigger_sys_id
                    )
                    if not link_response.get("success"):
                        br_link_error = link_response.get("error", "Unknown error")

        # Create the m2m record linking trigger to workflow
        m2m_failure = None
        if usecase:
            m2m_data = {
                "trigger_configuration": trigger_sys_id,
                "related_resource_record": usecase,
                "related_resource_table": "sn_aia_usecase",
                "objective_template": objective_template,
                "active": active if active else "true",
            }
            m2m_response = client.glide_write(
                table="sn_aia_trigger_agent_usecase_m2m", operation="insert", data=m2m_data,
                scope_sys_id=scope_sys_id,
            )
            if not m2m_response["success"]:
                m2m_failure = m2m_response.get("error", "Unknown error")

        # Business-rule lines are shared by the success and the workflow-link-failure messages.
        br_lines = []
        if br_sys_id:
            br_lines.append(f"business_rule: {br_sys_id}")
            if br_link_error:
                br_lines.append(
                    f"Warning: the business rule was created but is not linked to the trigger "
                    f"(business_rule field not set): {br_link_error}"
                )
        elif trigger_flow_definition_type:
            br_lines.append(
                "Warning: Business rule creation failed — trigger will not fire automatically."
            )

        if m2m_failure is not None:
            return "\n".join([
                f"Trigger '{name}' created (sys_id: {trigger_sys_id}), "
                f"but workflow link (sn_aia_trigger_agent_usecase_m2m) failed: {m2m_failure}",
                "The trigger will not appear in AI Agent Studio without this link.",
                *br_lines,
            ])

        scope_lines = []
        if isinstance(result, dict) and "scope" in result:
            scope_lines.append(f"Scope: {landed_scope_text(result)}")
        return "\n".join(
            [f"Trigger '{name}' created successfully.", f"sys_id: {trigger_sys_id}",
             *scope_lines, *br_lines]
        )

    @mcp.tool()
    def delete_trigger(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Delete a Trigger Configuration from ServiceNow (sn_aia_trigger_configuration). This action cannot be undone.

        Use list_trigger_configurations to find the trigger's sys_id first.

        Success is reported only after a read-back confirms the record is gone; the result
        names the scope the trigger was in. Requires the Script Runner (setup_script_runner);
        without it the tool returns "Script Runner not installed — use setup_script_runner to
        install it".
        """
        confirmation_error = require_instance_confirmation(instance, "delete trigger configuration")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        response = scoped_delete(client, "sn_aia_trigger_configuration", sys_id=sys_id)

        if not response["success"]:
            return f"Error: {response.get('error', 'Unknown error')}"

        return (
            f"Trigger '{sys_id}' deleted successfully "
            f"(it was in scope {landed_scope_text(response['result'])})."
        )
