"""Agentic Workflow and Trigger Tools — workflows, triggers, and configuration."""

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error


def register_tools(mcp: FastMCP):
    """Register agentic workflow and trigger tools with the MCP server."""

    @mcp.tool()
    def list_agentic_workflows(
        name: str = "",
        execution_mode: str = "",
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        List Agentic Workflows from sn_aia_usecase. Note: sn_aia_usecase has no `active` or
        `state` field. For AI Agents, use list_ai_agents instead.

        Args:
            execution_mode: "autopilot" or "copilot"

        Key fields in results:
            execution_mode: autopilot (independent) or copilot (assists user).
            record_type: Origin — custom, promoted, template, or aia_internal.
            base_plan: Workflow's live instruction reference.
            condition: Encoded query controlling when the workflow applies.
        """
        builder = QueryBuilder()
        builder.add_like("name", name)
        builder.add_equals("execution_mode", execution_mode)
        query = builder.add_order_by("sys_created_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_usecase",
            query=query,
            fields=[
                "sys_id", "name", "description", "execution_mode",
                "record_type", "base_plan", "strategy", "team",
                "condition", "sys_scope", "sys_created_on", "sys_updated_on"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No agentic workflows found matching your criteria."

        output = []
        for entry in results:
            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('name', 'N/A')}\n"
                f"Mode: {entry.get('execution_mode', 'N/A')} | Record: {entry.get('record_type', 'N/A')}\n"
                f"Description: {entry.get('description', 'N/A')}\n"
                f"Team: {entry.get('team', 'N/A')} | Strategy: {entry.get('strategy', 'N/A')}\n"
                f"Scope: {entry.get('sys_scope', 'N/A')}\n"
                f"sys_id: {entry.get('sys_id', 'N/A')}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def list_trigger_configurations(
        usecase: str = "",
        active: str = "",
        target_table: str = "",
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        List Trigger Configurations for Agentic Workflows (sn_aia_trigger_configuration).

        Trigger strategy is behavioral (how often the trigger fires), NOT event-type:
        - once: Fire once per matching record
        - unique_changes: Fire when record changes match condition (deduplicated)
        - always: Fire every time the condition is met
        - every: Fire on every evaluation cycle

        Args:
            usecase: Filter by workflow sys_id (exact match)
            active: "true" or "false"

        Key fields in results:
            trigger_strategy: once, unique_changes, always, every.
            objective_template: Agent's objective template (may contain ${field} placeholders).
            channel: Communication channel (e.g., nap).
            condition: Encoded query that activates the trigger.
            run_start, run_period, run_time: Schedule configuration.
        """
        builder = QueryBuilder()
        builder.add_equals("usecase", usecase)
        builder.add_equals("active", active)
        builder.add_like("target_table", target_table)
        query = builder.add_order_by("sys_created_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_trigger_configuration",
            query=query,
            fields=[
                "sys_id", "name", "active", "usecase", "target_table",
                "trigger_strategy", "condition", "objective_template",
                "channel", "run_as", "run_as_user", "run_start", "run_period",
                "run_time", "run_dayofweek", "run_dayofmonth", "description",
                "sys_scope", "sys_created_on"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No trigger configurations found matching your criteria."

        output = []
        for entry in results:
            active_status = "active" if entry.get("active") == "true" else "inactive"
            lines = [
                f"[{entry.get('sys_created_on')}] {entry.get('name', 'N/A')} ({active_status})",
                f"Target: {entry.get('target_table', 'N/A')} | Strategy: {entry.get('trigger_strategy', 'N/A')}",
                f"Usecase: {entry.get('usecase', 'N/A')} | Channel: {entry.get('channel', 'N/A')}",
                f"Objective: {entry.get('objective_template', 'N/A')}",
                f"Condition: {entry.get('condition', 'N/A')}",
                f"Run as: {entry.get('run_as', 'N/A')}",
            ]

            # Include schedule fields if any are populated
            run_start = entry.get("run_start", "")
            run_period = entry.get("run_period", "")
            run_time = entry.get("run_time", "")
            if run_start or run_period or run_time:
                schedule_parts = []
                if run_start:
                    schedule_parts.append(run_start)
                if run_period:
                    schedule_parts.append(f"Period: {run_period}")
                if run_time:
                    schedule_parts.append(f"Time: {run_time}")
                lines.append(f"Schedule: {' | '.join(schedule_parts)}")

            lines.append(f"Scope: {entry.get('sys_scope', 'N/A')}")
            lines.append(f"sys_id: {entry.get('sys_id', 'N/A')}")

            output.append("\n".join(lines))

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def create_agentic_workflow(
        name: str,
        description: str,
        execution_mode: str = "autopilot",
        base_plan: str = "",
        condition: str = "",
        scope_sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create a new Agentic Workflow in ServiceNow (sn_aia_usecase).

        Note: sn_aia_usecase extends sys_metadata — use scope_sys_id to place the record
        in a specific application scope (default: Global).
        Instruction versioning (sn_aia_version) is managed via AI Agent Studio UI after creation.

        Args:
            execution_mode: "autopilot" or "copilot". Default: "autopilot"
            scope_sys_id: sys_id of the target application scope (default: Global).

        Key fields in results:
            sys_id: The unique identifier of the created workflow record.
        """
        confirmation_error = require_instance_confirmation(instance, "create agentic workflow")
        if confirmation_error:
            return confirmation_error

        data = {
            "name": name,
            "description": description,
            "execution_mode": execution_mode,
        }
        if base_plan:
            data["base_plan"] = base_plan
        if condition:
            data["condition"] = condition

        client = get_client(instance)

        # Step 1: Create the workflow record
        response = client.glide_write(table="sn_aia_usecase", operation="insert", data=data, scope_sys_id=scope_sys_id)
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        workflow_sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"

        # Step 2: Auto-create sn_aia_team (required for AI Agent Studio to show team members)
        team_response = client.glide_write(
            table="sn_aia_team", operation="insert", data={"name": f"{name} Team"}
        )
        if not team_response["success"]:
            return (
                f"Agentic Workflow '{name}' created (workflow_sys_id: {workflow_sys_id}), "
                f"but team auto-creation failed: {team_response.get('error', 'Unknown error')}\n"
                f"Create an sn_aia_team record manually and set sn_aia_usecase.team to link it."
            )

        team_result = team_response["result"]
        team_sys_id = team_result.get("sys_id", "unknown") if isinstance(team_result, dict) else "unknown"

        # Step 3: Link the team to the workflow
        link_response = client.glide_write(
            table="sn_aia_usecase", operation="update",
            data={"team": team_sys_id}, sys_id=workflow_sys_id
        )
        if not link_response["success"]:
            return (
                f"Agentic Workflow '{name}' created (workflow_sys_id: {workflow_sys_id}), "
                f"team created (team_sys_id: {team_sys_id}), "
                f"but team linking failed: {link_response.get('error', 'Unknown error')}"
            )

        return (
            f"Agentic Workflow '{name}' created successfully.\n"
            f"workflow_sys_id: {workflow_sys_id}\n"
            f"team_sys_id: {team_sys_id}"
        )

    @mcp.tool()
    def update_agentic_workflow(
        sys_id: str,
        name: str = "",
        description: str = "",
        execution_mode: str = "",
        base_plan: str = "",
        condition: str = "",
        instance: str = None
    ) -> str:
        """
Update an existing Agentic Workflow in ServiceNow (sn_aia_usecase).

Use list_agentic_workflows to find the workflow's sys_id first.

**Instruction versioning:** If version records exist in sn_aia_version (query by
target_id = workflow sys_id), use the version system — do NOT update base_plan directly.
- Update active version: update_record on sn_aia_version (instructions field), then call
  update_agentic_workflow to sync base_plan on sn_aia_usecase.
- New version: create in AI Agent Studio UI, then populate via update_record.
- Switch active version: set state to "published" — platform withdraws previous and syncs sn_aia_usecase.
- Recovery (both withdrawn): publish correct version via update_record, then sync base_plan to match.

If no version records exist, direct updates to base_plan are safe.

Args:
    execution_mode: "autopilot" or "copilot"
    base_plan: CAUTION: If version records exist in sn_aia_version, use the version system instead (see above).
"""
        confirmation_error = require_instance_confirmation(instance, "update agentic workflow")
        if confirmation_error:
            return confirmation_error

        data = {}
        if name:
            data["name"] = name
        if description:
            data["description"] = description
        if execution_mode:
            data["execution_mode"] = execution_mode
        if base_plan:
            data["base_plan"] = base_plan
        if condition:
            data["condition"] = condition

        client = get_client(instance)
        response = client.glide_write(table="sn_aia_usecase", operation="update", data=data, sys_id=sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        return f"Agentic Workflow '{sys_id}' updated successfully."

    @mcp.tool()
    def delete_agentic_workflow(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Delete an Agentic Workflow from ServiceNow (sn_aia_usecase). This action cannot be undone.

        Use list_agentic_workflows to find the workflow's sys_id first.
        """
        confirmation_error = require_instance_confirmation(instance, "delete agentic workflow")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        response = client.glide_write(table="sn_aia_usecase", operation="delete", data={}, sys_id=sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        return f"Agentic Workflow '{sys_id}' deleted successfully."

    @mcp.tool()
    def create_trigger(
        name: str,
        target_table: str,
        condition: str,
        channel: str,
        objective_template: str,
        usecase: str = "",
        trigger_strategy: str = "once",
        active: str = "true",
        run_as_user: str = "",
        trigger_flow_definition_type: str = "",
        scope_sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create a new Trigger Configuration for an Agentic Workflow (sn_aia_trigger_configuration).

        sn_aia_trigger_configuration extends sys_metadata — use scope_sys_id to place the record
        in a specific application scope (default: Global).

        When usecase is provided, also creates the required sn_aia_trigger_agent_usecase_m2m
        record so the trigger appears in AI Agent Studio. Without this m2m record the trigger
        exists in the database but is invisible in the Studio UI.

        Args:
            target_table: Table the trigger monitors (e.g., "incident", "change_request")
            condition: Encoded query condition (e.g., "state=new^priority<=2")
            channel: "nap" (Now Assist Panel) or "nap_and_va"
            objective_template: Agent objective template — supports ${field_name} variables
            usecase: sn_aia_usecase sys_id to link this trigger to a workflow
            trigger_strategy: "once", "unique_changes", "always", "every". Default: "once"
            active: "true" or "false". Default: "true"
            trigger_flow_definition_type: Event type — "record_create", "record_update", "ui_action".
                Required for the trigger to function; omitting leaves it null.
            scope_sys_id: sys_id of the target application scope (default: Global).

        Key fields in results:
            sys_id: The unique identifier of the created trigger record.

        Note: The Business Rule script body uses an unverified class name
        (sn_aia.AgenticWorkflowTriggerHandler). If a trigger created by this
        tool does not fire, verify this class name against a wizard-created
        trigger on the same instance using execute_script and update the tool
        accordingly. Gated by trigger_flow_definition_type — no BR created if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "create trigger configuration")
        if confirmation_error:
            return confirmation_error

        data = {
            "name": name,
            "target_table": target_table,
            "condition": condition,
            "channel": channel,
            "objective_template": objective_template,
            "trigger_strategy": trigger_strategy,
            "active": active,
        }
        if usecase:
            data["usecase"] = usecase
        if run_as_user:
            data["run_as_user"] = run_as_user
        if trigger_flow_definition_type:
            data["trigger_flow_definition_type"] = trigger_flow_definition_type

        client = get_client(instance)
        response = client.glide_write(table="sn_aia_trigger_configuration", operation="insert", data=data, scope_sys_id=scope_sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        trigger_sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"

        # Generate the Business Rule that fires the trigger logic (issue #190).
        # Only created when trigger_flow_definition_type is provided — without it we
        # can't determine action_insert/action_update and the BR would fire on all ops.
        br_sys_id = None
        if trigger_flow_definition_type and trigger_sys_id != "unknown":
            action_insert = "true" if trigger_flow_definition_type == "record_create" else "false"
            action_update = "true" if trigger_flow_definition_type == "record_update" else "false"
            if trigger_flow_definition_type not in ("record_create", "record_update"):
                # Unknown type — fire on both (safe fallback)
                action_insert = "true"
                action_update = "true"

            # BR script body: determined from investigation of wizard-created triggers
            # (issue #190 step 1). No wizard-created trigger with a linked business_rule
            # was found on the live instance — using the best-guess fallback class name.
            # UNVERIFIED: sn_aia.AgenticWorkflowTriggerHandler class name not confirmed
            # by live instance data.
            br_script = (
                f"sn_aia.AgenticWorkflowTriggerHandler"
                f".executeTrigger(current, previous, '{trigger_sys_id}');"
            )

            br_data = {
                "name": f"AIA Trigger - {name}",
                "collection": target_table,
                "when": "after",
                "active": active,
                "action_insert": action_insert,
                "action_update": action_update,
                "filter_condition": condition,
                "script": br_script,
            }
            br_response = client.glide_write(table="sys_script", operation="insert", data=br_data, scope_sys_id=scope_sys_id)
            if br_response["success"]:
                br_result = br_response.get("result", {})
                br_sys_id = br_result.get("sys_id") if isinstance(br_result, dict) else None
                if br_sys_id:
                    # Link the BR back to the trigger config
                    client.glide_write(
                        table="sn_aia_trigger_configuration",
                        operation="update",
                        data={"business_rule": br_sys_id},
                        sys_id=trigger_sys_id
                    )

        # Create the m2m record linking trigger to workflow so it appears in AI Agent Studio
        if usecase:
            m2m_data = {
                "trigger_configuration": trigger_sys_id,
                "related_resource_record": usecase,
                "related_resource_table": "sn_aia_usecase",
                "objective_template": objective_template,
                "active": "true",
            }
            m2m_response = client.glide_write(
                table="sn_aia_trigger_agent_usecase_m2m", operation="insert", data=m2m_data
            )
            if not m2m_response["success"]:
                return (
                    f"Trigger '{name}' created (sys_id: {trigger_sys_id}), "
                    f"but workflow link (sn_aia_trigger_agent_usecase_m2m) failed: "
                    f"{m2m_response.get('error', 'Unknown error')}\n"
                    f"The trigger will not appear in AI Agent Studio without this link."
                )

        result_lines = [f"Trigger '{name}' created successfully.", f"sys_id: {trigger_sys_id}"]
        if br_sys_id:
            result_lines.append(f"business_rule: {br_sys_id}")
        else:
            if trigger_flow_definition_type:
                result_lines.append(
                    "Warning: Business rule creation failed — trigger will not fire automatically. "
                    "Create the BR manually or re-run create_trigger."
                )
        return "\n".join(result_lines)

    @mcp.tool()
    def update_trigger(
        sys_id: str,
        name: str = "",
        target_table: str = "",
        condition: str = "",
        channel: str = "",
        objective_template: str = "",
        usecase: str = "",
        trigger_strategy: str = "",
        active: str = "",
        run_as_user: str = "",
        instance: str = None
    ) -> str:
        """
        Update an existing Trigger Configuration in ServiceNow (sn_aia_trigger_configuration).

        Use list_trigger_configurations to find the trigger's sys_id first.

        Args:
            channel: "nap" or "nap_and_va"
            trigger_strategy: "once", "unique_changes", "always", "every"
            active: "true" or "false"
        """
        confirmation_error = require_instance_confirmation(instance, "update trigger configuration")
        if confirmation_error:
            return confirmation_error

        data = {}
        if name:
            data["name"] = name
        if target_table:
            data["target_table"] = target_table
        if condition:
            data["condition"] = condition
        if channel:
            data["channel"] = channel
        if objective_template:
            data["objective_template"] = objective_template
        if usecase:
            data["usecase"] = usecase
        if trigger_strategy:
            data["trigger_strategy"] = trigger_strategy
        if active:
            data["active"] = active
        if run_as_user:
            data["run_as_user"] = run_as_user

        client = get_client(instance)
        response = client.update_record(table_name="sn_aia_trigger_configuration", sys_id=sys_id, data=data)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        if not active:
            return f"Trigger '{sys_id}' updated successfully."

        # Sync active to the m2m join record — AI Agent Studio reads active from
        # sn_aia_trigger_agent_usecase_m2m.active, not sn_aia_trigger_configuration.active
        # (issue #195).
        builder = QueryBuilder()
        builder.add_equals("trigger_configuration", sys_id)
        builder.add_equals("related_resource_table", "sn_aia_usecase")
        m2m_response = client.query_table(
            table_name="sn_aia_trigger_agent_usecase_m2m",
            query=builder.build(),
            fields=["sys_id"],
            limit=50
        )

        if not m2m_response["success"] or not m2m_response["result"]:
            return f"Trigger '{sys_id}' updated successfully."

        for m2m in m2m_response["result"]:
            client.update_record(
                table_name="sn_aia_trigger_agent_usecase_m2m",
                sys_id=m2m["sys_id"],
                data={"active": active}
            )

        return f"Trigger '{sys_id}' updated successfully."

    @mcp.tool()
    def delete_trigger(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Delete a Trigger Configuration from ServiceNow (sn_aia_trigger_configuration). This action cannot be undone.

        Use list_trigger_configurations to find the trigger's sys_id first.
        """
        confirmation_error = require_instance_confirmation(instance, "delete trigger configuration")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        response = client.delete_record(table_name="sn_aia_trigger_configuration", sys_id=sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        return f"Trigger '{sys_id}' deleted successfully."
