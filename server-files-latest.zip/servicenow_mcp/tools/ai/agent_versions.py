"""AI Agent instruction versioning tools."""

import json

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error


def register_tools(mcp: FastMCP):
    """Register AI agent versioning tools with the MCP server."""

    @mcp.tool()
    def list_versions(
        target_id: str,
        state: str = "",
        limit: int = 50,
        instance: str = None
    ) -> str:
        """
        List instruction versions for an AI Agent or Agentic Workflow (sn_aia_version).

        target_id is the parent record sys_id — sn_aia_agent (from list_ai_agents) or
        sn_aia_usecase (from list_agentic_workflows). Returns versions ordered newest-first
        with state (published = active, withdrawn = inactive) and instruction preview.

        IMPORTANT: After publishing a new version via update_record, sync the parent
        record's instructions (agents) or base_plan (workflows) using manage_ai_agent or
        manage_agentic_workflow. The platform reads from the parent record at runtime.

        Use when: comparing version history, checking version state after updates.

        Args:
            target_id: sys_id of the AI Agent or Agentic Workflow (required)
            state: Filter by version state — "published" or "withdrawn"
        """
        if not target_id:
            return "Please provide a target_id (the sys_id of an AI Agent or Agentic Workflow)."

        builder = QueryBuilder()
        builder.add_equals("target_id", target_id)
        builder.add_equals("state", state)

        query = builder.add_order_by("version_number", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_version",
            query=query,
            fields=[
                "sys_id", "version_number", "version_name", "state", "instructions",
                "sys_created_on", "sys_updated_on"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return f"No versions found for target_id {target_id}."

        output = [f"Versions found: {len(results)}", ""]
        for v in results:
            instructions = v.get("instructions", "") or ""
            instructions_length = len(instructions)
            instructions_preview = (instructions[:500] + "... (truncated)") if instructions_length > 500 else instructions

            output.append(
                f"Version {v.get('version_number', '?')} [{v.get('state', 'unknown')}] — {v.get('sys_id', '')}\n"
                f"  Name: {v.get('version_name') or '(unnamed)'}\n"
                f"  Created: {v.get('sys_created_on', 'N/A')} | Updated: {v.get('sys_updated_on', 'N/A')}\n"
                f"  Instructions ({instructions_length} chars): {instructions_preview or '(empty)'}"
            )

        return "\n\n".join(output)

    @mcp.tool()
    def update_agent_instructions(
        agent_sys_id: str,
        instructions: str,
        create_new_version: bool = False,
        instance: str = None
    ) -> str:
        """
        Update an AI Agent's instructions atomically, always leaving a published version.

        **BEFORE CALLING THIS TOOL**, ask the user: "Should I update the existing version
        in place, or create a new version? New version preserves current instructions in
        history — use for significant changes. In-place overwrites the current version."
        Set create_new_version accordingly.

        Behavior by mode:

        create_new_version=False (default):
        1. Published version exists → update in place, sync parent agent.
        2. Only withdrawn versions → update most recent withdrawn, republish, sync parent.
        3. No version records → update agent record directly.

        create_new_version=True:
        1. Determines next version number from existing records.
        2. Creates sn_aia_version (state="published") via Foundry Script Runner.
        3. Syncs parent agent. Prior versions remain (withdrawn).

        Known issue (create_new_version=True): target_id display value may not populate,
        disabling "View versions" in Agent Builder UI. Reliable alternative: use
        execute_script to set state="published" on sn_aia_version directly, then call
        manage_agentic_workflow to sync the parent.

        Args:
            agent_sys_id: sys_id of the AI Agent to update
            instructions: New instruction text
            create_new_version: True = new version record; False = update in place. Ask user first.
        """
        if not agent_sys_id:
            return "Please provide an agent_sys_id."
        if not instructions:
            return "Please provide instructions."

        confirmation_error = require_instance_confirmation(instance, "update agent instructions")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        if create_new_version:
            # version_number is read-only via the REST API (silently ignored on insert/update).
            # We must create the record server-side via the script runner so that version_number,
            # target_table, and version_name are all set correctly and the UI link resolves.
            instructions_json = json.dumps(instructions)
            script = f"""
var agentSysId = '{agent_sys_id}';

// Count existing versions to determine next version number (mirrors AgentVersionDao.__getNewVersionNumber)
var countGr = new GlideRecord('sn_aia_version');
countGr.addQuery('target_id', agentSysId);
countGr.query();
var versionNumber = countGr.getRowCount() + 1;
var versionName = 'V' + versionNumber;

var gr = new GlideRecord('sn_aia_version');
gr.setValue('target_id', agentSysId);
gr.setValue('target_table', 'sn_aia_agent');
gr.setValue('version_number', versionNumber);
gr.setValue('version_name', versionName);
gr.setValue('instructions', {instructions_json});
gr.setValue('state', 'published');
gr.setValue('sys_scope', 'global');
var newSysId = gr.insert();

if (newSysId) {{
    gs.info('version_number:' + versionNumber);
    gs.info('version_name:' + versionName);
    gs.info('sys_id:' + newSysId);
}} else {{
    gs.error('insert_failed');
}}
"""

            if not client._prepare_request():
                return "Authentication failed."

            url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
            script_response = client.session.post(url, json={"script": script})

            if script_response.status_code == 400 and "does not represent any resource" in script_response.text:
                return (
                    "Creating a new version requires the Foundry Script Runner to be installed.\n"
                    "Use the setup_script_runner tool to install it, then retry."
                )

            if script_response.status_code not in (200, 201):
                return format_error(script_response.status_code, script_response.text[:500])

            result = script_response.json().get("result", {})
            output = result.get("output", [])
            error = result.get("error")

            if error or any("insert_failed" in line for line in output):
                return f"Failed to create version record: {error or 'insert returned null'}"

            version_number = "?"
            version_name = "?"
            for line in output:
                if line.startswith("version_number:"):
                    version_number = line.split(":", 1)[1]
                elif line.startswith("version_name:"):
                    version_name = line.split(":", 1)[1]

            # Sync parent agent (after BR also handles this, but be explicit)
            sync_response = client.glide_write(
                table="sn_aia_agent", operation="update",
                data={"instructions": instructions}, sys_id=agent_sys_id
            )
            if not sync_response["success"]:
                return (
                    f"{version_name} created but failed to sync parent agent: "
                    f"{format_error(sync_response['status_code'], sync_response.get('error', ''))}"
                )

            return (
                f"Created new agent instruction version:\n"
                f"  {version_name} (version_number: {version_number}) created (published) ✓\n"
                f"  Parent agent synced ✓"
            )

        # Update in place — check for published version first
        builder = QueryBuilder()
        builder.add_equals("target_id", agent_sys_id)
        builder.add_equals("state", "published")
        version_query = builder.add_order_by("version", "DESC")

        version_response = client.query_table(
            table_name="sn_aia_version",
            query=version_query,
            fields=["sys_id", "version_number", "state"],
            limit=1
        )

        if not version_response["success"]:
            return format_error(version_response["status_code"], version_response.get("error", "Unknown error"))

        versions = version_response["result"]

        if versions:
            # Path 1: published version exists — update in place
            version_sys_id = versions[0]["sys_id"]
            version_num = versions[0].get("version_number", "?")

            update_response = client.glide_write(
                table="sn_aia_version", operation="update",
                data={"instructions": instructions}, sys_id=version_sys_id
            )
            if not update_response["success"]:
                return format_error(update_response["status_code"], update_response.get("error", "Unknown error"))

            sync_response = client.glide_write(
                table="sn_aia_agent", operation="update",
                data={"instructions": instructions}, sys_id=agent_sys_id
            )
            if not sync_response["success"]:
                return (
                    f"Version {version_num} updated but failed to sync parent agent: "
                    f"{format_error(sync_response['status_code'], sync_response.get('error', ''))}"
                )

            return (
                f"Updated agent instructions in place:\n"
                f"  Version {version_num} record updated ✓\n"
                f"  Parent agent synced ✓"
            )

        # No published version — check for withdrawn versions
        withdrawn_builder = QueryBuilder()
        withdrawn_builder.add_equals("target_id", agent_sys_id)
        withdrawn_builder.add_equals("state", "withdrawn")
        withdrawn_query = withdrawn_builder.add_order_by("version", "DESC")

        withdrawn_response = client.query_table(
            table_name="sn_aia_version",
            query=withdrawn_query,
            fields=["sys_id", "version_number", "state"],
            limit=1
        )

        if not withdrawn_response["success"]:
            return format_error(withdrawn_response["status_code"], withdrawn_response.get("error", "Unknown error"))

        withdrawn_versions = withdrawn_response["result"]

        if withdrawn_versions:
            # Path 2: withdrawn versions exist — update most recent and republish
            version_sys_id = withdrawn_versions[0]["sys_id"]
            version_num = withdrawn_versions[0].get("version_number", "?")

            update_response = client.glide_write(
                table="sn_aia_version", operation="update",
                data={"instructions": instructions, "state": "published"}, sys_id=version_sys_id
            )
            if not update_response["success"]:
                return format_error(update_response["status_code"], update_response.get("error", "Unknown error"))

            sync_response = client.glide_write(
                table="sn_aia_agent", operation="update",
                data={"instructions": instructions}, sys_id=agent_sys_id
            )
            if not sync_response["success"]:
                return (
                    f"Version {version_num} updated and republished but failed to sync parent agent: "
                    f"{format_error(sync_response['status_code'], sync_response.get('error', ''))}"
                )

            return (
                f"Updated agent instructions (republished withdrawn version):\n"
                f"  Version {version_num} instructions updated ✓\n"
                f"  Version {version_num} republished (withdrawn → published) ✓\n"
                f"  Parent agent synced ✓"
            )

        else:
            # Path 3: no version records at all — update agent directly
            update_response = client.glide_write(
                table="sn_aia_agent", operation="update",
                data={"instructions": instructions}, sys_id=agent_sys_id
            )
            if not update_response["success"]:
                return format_error(update_response["status_code"], update_response.get("error", "Unknown error"))

            return "Updated agent instructions directly (no version records found for this agent)."

    @mcp.tool()
    def verify_agent_version(
        agent_sys_id: str,
        instance: str = None
    ) -> str:
        """
        Check sn_aia_version records for an AI Agent or Agentic Workflow.

        Returns all versions with state; warns if no published version exists (required
        for the agent to execute). Use after update_agent_instructions or add_tool_to_agent.

        Args:
            agent_sys_id: sys_id of the AI Agent or Agentic Workflow to check
        """
        if not agent_sys_id:
            return "Please provide an agent_sys_id."

        client = get_client(instance)

        builder = QueryBuilder()
        builder.add_equals("target_id", agent_sys_id)
        query = builder.add_order_by("version_number", "DESC")

        response = client.query_table(
            table_name="sn_aia_version",
            query=query,
            fields=["sys_id", "version_name", "version_number", "state"],
            limit=50
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        versions = response["result"]

        if not versions:
            return f"No version records found for agent {agent_sys_id}."

        has_published = any(v.get("state") == "published" for v in versions)

        lines = [f"Versions for agent {agent_sys_id} ({len(versions)} total):"]
        for v in versions:
            lines.append(f"  {v.get('version_name', '?')}  state={v.get('state', '?')}  sys_id={v.get('sys_id', '?')}")

        if not has_published:
            lines.append("\nWARNING: No published version found. The agent will not execute correctly.")

        return "\n".join(lines)
