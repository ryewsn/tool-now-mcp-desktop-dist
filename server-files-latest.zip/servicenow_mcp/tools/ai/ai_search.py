"""AI Search tools: manage_search_profile, manage_search_source."""

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error


def register_tools(mcp: FastMCP):

    @mcp.tool()
    def manage_search_profile(
        name: str = "",
        description: str = "",
        scope_sys_id: str = "",
        sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create or update an AI Search profile (ais_search_profile).

        Pass sys_id to update an existing profile. Omit sys_id to create a new one.

        **After creating a profile, it must be published via the UI:**
        Setting state='PUBLISHED' via script is NOT sufficient. Open the direct URL
        returned by this tool and click the **Publish** button. The Publish action
        generates a `publish_id` UUID required for semantic search indexing — without
        it, RAG search returns "No information found."

        **Optional: wiring a profile to a search source**
        A profile can be associated with a search source via the M2M table
        `ais_search_profile_ais_search_source_m2m`. This is only needed when a
        rag-type AI Agent tool requires a specific profile. Use execute_script:
            var m2m = new GlideRecord('ais_search_profile_ais_search_source_m2m');
            m2m.setValue('profile', '<profile_sys_id>');       // NOT 'ais_search_profile'
            m2m.setValue('search_source', '<source_sys_id>');  // NOT 'ais_search_source'
            m2m.insert();

        Args:
            name: Profile display name (required on create)
            description: Optional description
            scope_sys_id: sys_id of the target application scope (default: Global)
            sys_id: If provided, update this record instead of creating
            instance: ServiceNow instance alias (uses default if not specified)
        """
        confirmation_error = require_instance_confirmation(instance, "manage search profile")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        if sys_id:
            # Update mode
            data = {}
            if name:
                data["name"] = name
            if description:
                data["description"] = description
            response = client.glide_write(
                table="ais_search_profile", operation="update",
                data=data, sys_id=sys_id, scope_sys_id=scope_sys_id
            )
            if not response["success"]:
                return format_error(response["status_code"], response.get("error", "Unknown error"))
            return f"Search profile '{sys_id}' updated successfully."

        # Create mode
        data = {"name": name}
        if description:
            data["description"] = description

        response = client.glide_write(
            table="ais_search_profile", operation="insert",
            data=data, scope_sys_id=scope_sys_id
        )
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        new_sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"
        record_url = f"{client.config.instance}/ais_search_profile.do?sys_id={new_sys_id}"

        return (
            f"Search profile '{name}' created successfully.\n"
            f"sys_id: {new_sys_id}\n"
            f"Direct URL: {record_url}\n"
            f"ACTION REQUIRED: Open the URL above and click 'Publish' to activate semantic search indexing."
        )

    @mcp.tool()
    def manage_search_source(
        name: str = "",
        datasource: str = "",
        condition: str = "",
        scope_sys_id: str = "",
        sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create or update an AI Search source (ais_search_source).

        Pass sys_id to update an existing source. Omit sys_id to create a new one.

        **Critical field names — these differ from what you might expect:**
          - `datasource`: the table to search (e.g. "kb_knowledge") — NOT `table_name`
          - `condition`: GlideRecord encoded query filter
              (e.g. "workflow_state=published^active=true") — NOT `filter`

        **Optional: wiring a source to a search profile**
        After creating both a profile and a source, associate them via execute_script:
            var m2m = new GlideRecord('ais_search_profile_ais_search_source_m2m');
            m2m.setValue('profile', '<profile_sys_id>');       // NOT 'ais_search_profile'
            m2m.setValue('search_source', '<source_sys_id>');  // NOT 'ais_search_source'
            m2m.insert();
        Only needed when a rag-type AI Agent tool requires a specific profile.

        Args:
            name: Source display name (required on create)
            datasource: Table to search (e.g. "kb_knowledge") — NOT table_name
            condition: GlideRecord encoded query filter — NOT filter
            scope_sys_id: sys_id of the target application scope (default: Global)
            sys_id: If provided, update this record instead of creating
            instance: ServiceNow instance alias (uses default if not specified)
        """
        confirmation_error = require_instance_confirmation(instance, "manage search source")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        if sys_id:
            # Update mode
            data = {}
            if name:
                data["name"] = name
            if datasource:
                data["datasource"] = datasource
            if condition:
                data["condition"] = condition
            response = client.glide_write(
                table="ais_search_source", operation="update",
                data=data, sys_id=sys_id, scope_sys_id=scope_sys_id
            )
            if not response["success"]:
                return format_error(response["status_code"], response.get("error", "Unknown error"))
            return f"Search source '{sys_id}' updated successfully."

        # Create mode
        data = {"name": name}
        if datasource:
            data["datasource"] = datasource
        if condition:
            data["condition"] = condition

        response = client.glide_write(
            table="ais_search_source", operation="insert",
            data=data, scope_sys_id=scope_sys_id
        )
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        new_sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"
        return f"Search source '{name}' created successfully.\nsys_id: {new_sys_id}"
