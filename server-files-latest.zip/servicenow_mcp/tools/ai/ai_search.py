"""AI Search tools: manage_search_profile, manage_search_source."""

from mcp.server.mcpserver import MCPServer
from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error


def register_tools(mcp: MCPServer):

    @mcp.tool()
    def manage_search_profile(
        label: str = "",
        description: str = "",
        scope_sys_id: str = "",
        sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create or update an AI Search profile (ais_search_profile).

        Pass sys_id to update an existing profile. Omit sys_id to create a new one.

        **`label` drives the profile name:**
        On create, a platform business rule ("Set name field") automatically generates
        the `name` field from `label` + application scope, following the OOTB convention
        `{scope}_{label_slug}` (e.g. `x_snc_uber_xml_incident_search`). Always set
        `label` — if it is empty, the business rule aborts the insert or falls back to
        the bare scope name, producing an unusable profile name.

        The `name` field is the key used by RAG tool `search_profile` inputs. The
        generated name is returned in this tool's response — use it when configuring
        the `search_profile` input on a rag-type AI Agent tool.

        **After creating a profile, it must be published via the UI:**
        Setting state='PUBLISHED' via script is NOT sufficient. Open the direct URL
        returned by this tool and click the **Publish** button. The Publish action
        generates a `publish_id` UUID required for semantic search indexing — without
        it, RAG search returns "No information found."

        **AI Search table surface area — known tables:**
        Core search configuration:
          - `ais_search_profile`                        — the search profile
          - `ais_search_source`                         — a source wired to a datasource
          - `ais_datasource`                            — the underlying data source (table + index config)
          - `ais_search_profile_ais_search_source_m2m`  — M2M linking profiles to sources
              (fields: `profile` → ais_search_profile, `search_source` → ais_search_source)

        Semantic index configuration (read-only; configured by platform):
          - `ais_datasource_field_attribute`    — field alias mapping (raw field → display name)
          - `ais_semantic_component_field`      — links a datasource to its semantic index configurations
          - `ais_semantic_index_configuration`  — defines the semantic index name via `semantic_field_name` field
              Use `semantic_field_name` values as `semantic_index_names` in RAG tool inputs (NOT raw field names).

        **Optional: wiring a profile to a search source**
        A profile can be associated with a search source via the M2M table
        `ais_search_profile_ais_search_source_m2m`. This is only needed when a
        rag-type AI Agent tool requires a specific profile. Prefer create_record on that
        table with `scope` set to the profile's scope (scope-safe, read back). If you use
        execute_script instead, pass allow_writes=true and expected_scope so a record that
        lands in another scope is reported (an unguarded run is labelled as such):
            var m2m = new GlideRecord('ais_search_profile_ais_search_source_m2m');
            m2m.setValue('profile', '<profile_sys_id>');       // NOT 'ais_search_profile'
            m2m.setValue('search_source', '<source_sys_id>');  // NOT 'ais_search_source'
            m2m.insert();

        Args:
            label: Human-readable display name shown in the UI (required on create).
                   Also drives auto-generation of the `name` slug via platform business rule.
            description: Optional description
            scope_sys_id: Target application scope: scope id (x_snc_...), scope sys_id or "global". Required on create (no default; a create without it is refused). On update it is optional: if given, the record must already be in that scope or the update is refused (a record never changes scope).
            sys_id: If provided, update this record instead of creating
            instance: ServiceNow instance alias (uses default if not specified)
        """
        confirmation_error = require_instance_confirmation(instance, "manage search profile")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        if sys_id:
            # Update mode
            data = {}
            if label:
                data["label"] = label
            if description:
                data["description"] = description
            response = client.glide_write(
                table="ais_search_profile", operation="update",
                data=data, sys_id=sys_id, scope_sys_id=scope_sys_id
            )
            if not response["success"]:
                return format_error(response["status_code"], response.get("error", "Unknown error"))
            return f"Search profile '{sys_id}' updated successfully."

        # Create mode — label is required; name is generated by platform BR
        if not label:
            return "Error: 'label' is required when creating a search profile."

        data = {"label": label}
        if description:
            data["description"] = description

        response = client.glide_write(
            table="ais_search_profile", operation="insert",
            data=data, scope_sys_id=scope_sys_id
        )
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        new_sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"

        # Fetch the generated name — set by platform BR from label + scope
        generated_name = "unknown"
        if new_sys_id != "unknown":
            record = client.get_record("ais_search_profile", new_sys_id, fields=["name"])
            if record.get("success") and isinstance(record.get("result"), dict):
                generated_name = record["result"].get("name", {})
                if isinstance(generated_name, dict):
                    generated_name = generated_name.get("value", "unknown")

        record_url = f"{client.config.instance}/ais_search_profile.do?sys_id={new_sys_id}"

        return (
            f"Search profile '{label}' created successfully.\n"
            f"sys_id: {new_sys_id}\n"
            f"name (use this as search_profile in RAG tool inputs): {generated_name}\n"
            f"Direct URL: {record_url}\n"
            f"ACTION REQUIRED: Open the URL above and click 'Publish' to activate semantic search indexing."
        )

    @mcp.tool()
    def manage_search_source(
        name: str = "",
        datasource: str = "",
        condition: str = "",
        scope_sys_id: str = "",
        sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create or update an AI Search source (ais_search_source).

        Pass sys_id to update an existing source. Omit sys_id to create a new one.

        **Critical field names — these differ from what you might expect:**
          - `datasource`: the table to search (e.g. "kb_knowledge") — NOT `table_name`
          - `condition`: GlideRecord encoded query filter
              (e.g. "workflow_state=published^active=true") — NOT `filter`

        **Optional: wiring a source to a search profile**
        After creating both a profile and a source, associate them. Prefer create_record on
        the M2M table with `scope` set (scope-safe, read back). If you use execute_script,
        pass allow_writes=true and expected_scope so a record that lands in another scope is
        reported (an unguarded run is labelled as such):
            var m2m = new GlideRecord('ais_search_profile_ais_search_source_m2m');
            m2m.setValue('profile', '<profile_sys_id>');       // NOT 'ais_search_profile'
            m2m.setValue('search_source', '<source_sys_id>');  // NOT 'ais_search_source'
            m2m.insert();
        Only needed when a rag-type AI Agent tool requires a specific profile.

        Args:
            name: Source display name (required on create)
            datasource: Table to search (e.g. "kb_knowledge") — NOT table_name
            condition: GlideRecord encoded query filter — NOT filter
            scope_sys_id: Target application scope: scope id (x_snc_...), scope sys_id or "global". Required on create (no default; a create without it is refused). On update it is optional: if given, the record must already be in that scope or the update is refused (a record never changes scope).
            sys_id: If provided, update this record instead of creating
            instance: ServiceNow instance alias (uses default if not specified)
        """
        confirmation_error = require_instance_confirmation(instance, "manage search source")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        if sys_id:
            # Update mode
            data = {}
            if name:
                data["name"] = name
            if datasource:
                data["datasource"] = datasource
            if condition:
                data["condition"] = condition
            response = client.glide_write(
                table="ais_search_source", operation="update",
                data=data, sys_id=sys_id, scope_sys_id=scope_sys_id
            )
            if not response["success"]:
                return format_error(response["status_code"], response.get("error", "Unknown error"))
            return f"Search source '{sys_id}' updated successfully."

        # Create mode
        data = {"name": name}
        if datasource:
            data["datasource"] = datasource
        if condition:
            data["condition"] = condition

        response = client.glide_write(
            table="ais_search_source", operation="insert",
            data=data, scope_sys_id=scope_sys_id
        )
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        new_sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"
        return f"Search source '{name}' created successfully.\nsys_id: {new_sys_id}"
