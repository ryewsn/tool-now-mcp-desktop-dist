"""AI and Generative AI Tools"""

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

def register_tools(mcp: FastMCP):
    """Register GenAI log and metadata tools with the MCP server."""

    @mcp.tool()
    def query_genai_logs(
        source: str = "",
        model_name: str = "",
        created_by: str = "",
        conversation: str = "",
        limit: int = 500,
        minutes_ago: int = 15,
        instance: str = None
    ) -> str:
        """
        Query Generative AI logs (sys_generative_ai_log) for actual prompts sent to LLMs and
        their responses. Use to debug NowAssist, AI Search, and other GenAI features.

        IMPORTANT: This table is only accessible to users with MAINT role. Query will fail
        for non-MAINT users.

        Look here when: NowAssist gives poor or incorrect responses; AI features time out or
        return errors; tracing all LLM calls within a single agentic workflow execution.

        Use `get_table_schema("sys_generative_ai_log")` for valid field names and values.

        Args:
            conversation: Filter all LLM calls for a specific conversation/execution
            minutes_ago: Time window in minutes (default 15; 0 removes time filter)

        Key fields in results:
            conversation: Links all LLM calls in one agentic workflow execution.
            prompt/response: Full LLM input/output for troubleshooting.
            output_metadata: JSON with tool calls, confidence scores, etc.
            status/error/error_code: LLM call success; check error for failure details.
            prompt_token_count/response_token_count: Token usage per call.
            response_token_count: Watch for values >4096 — large responses can cause
                the output to be used as a computation step, degrading agent performance.
            time_taken: LLM call duration in ms.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_like("source", source)
        builder.add_like("model_name", model_name)
        builder.add_equals("sys_created_by", created_by)
        builder.add_equals("conversation", conversation)
        builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "DESC")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_generative_ai_log",
            query=query,
            fields=[
                "sys_id", "sys_created_on", "source", "model_name", "sys_created_by",
                "prompt", "response", "prompt_token_count", "response_token_count",
                "time_taken", "conversation", "status", "error", "error_code",
                "model_version", "output_metadata", "started_at", "completed_at",
                "feedback", "caller"
            ],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No GenAI logs found matching your criteria. Note: This table requires MAINT role access."

        # Format output
        output = []
        for entry in results:
            resp_tokens = entry.get('response_token_count', '0')
            try:
                token_warning = f"\nWARNING: High response token count ({resp_tokens}) — large responses can result in output used as computation, degrading agent performance." if int(resp_tokens) > 4096 else ""
            except (ValueError, TypeError):
                token_warning = ""

            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('source', 'N/A')} | {entry.get('status', 'N/A')}\n"
                f"Model: {entry.get('model_name', 'N/A')} (v{entry.get('model_version', 'N/A')}) | "
                f"Tokens: {entry.get('prompt_token_count', 'N/A')}/{entry.get('response_token_count', 'N/A')} | "
                f"Time: {entry.get('time_taken', 'N/A')}ms\n"
                f"Created by: {entry.get('sys_created_by', 'N/A')} | Conversation: {entry.get('conversation', 'N/A')}\n"
                f"Prompt: {entry.get('prompt', 'N/A')}\n"
                f"Response: {entry.get('response', 'N/A')}"
                f"{token_warning}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def query_genai_metadata(
        feedback_type: str = "",
        interaction_id: str = "",
        conversation: str = "",
        limit: int = 500,
        minutes_ago: int = 15,
        instance: str = None
    ) -> str:
        """
        Query Generative AI metadata (sys_gen_ai_log_metadata) for user feedback and quality
        signals on AI responses. Use to identify patterns in helpful vs unhelpful responses.

        Look here when: users are rejecting AI suggestions; measuring AI feature effectiveness;
        correlating response quality with prompt types.

        Use `get_table_schema("sys_gen_ai_log_metadata")` for valid field names and values.

        Args:
            feedback_type: "positive", "negative", or "none"
            interaction_id: sys_id of a specific GenAI log entry (maps to gen_ai_log_id)
            conversation: Filter metadata for a specific conversation/execution
            minutes_ago: Time window in minutes (default 15; 0 removes time filter)

        Key fields in results:
            error/error_code: Check first for failed LLM calls.
            gen_ai_log_id: Links to the detailed record in sys_generative_ai_log.
            feedback: User thumbs up/down on this AI response.
            conversation: Links to parent conversation for full trace.
            status: Whether the underlying LLM call succeeded.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_equals("feedback", feedback_type)
        builder.add_equals("gen_ai_log_id", interaction_id)
        builder.add_equals("conversation", conversation)
        builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "DESC")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_gen_ai_log_metadata",
            query=query,
            fields=[
                "sys_id", "sys_created_on", "gen_ai_log_id", "feedback",
                "sys_created_by", "conversation", "error", "error_code",
                "model_name", "status", "additional_data", "output_metadata",
                "prompt_token_count", "response_token_count", "time_taken"
            ],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No GenAI metadata found matching your criteria."

        # Format output
        output = []
        for entry in results:
            error = entry.get('error', '')
            error_line = f"\nError: {error} ({entry.get('error_code', 'N/A')})" if error else ""
            output.append(
                f"[{entry.get('sys_created_on')}] Feedback: {entry.get('feedback', 'N/A')} | Status: {entry.get('status', 'N/A')}\n"
                f"Model: {entry.get('model_name', 'N/A')} | Created by: {entry.get('sys_created_by', 'N/A')}\n"
                f"Related log: {entry.get('gen_ai_log_id', 'N/A')} | Conversation: {entry.get('conversation', 'N/A')}"
                f"{error_line}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result
