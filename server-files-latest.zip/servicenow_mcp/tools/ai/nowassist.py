"""NowAssist Capability Tools — inspect NowAssist skills and their I/O schemas."""

import re

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

# Types to include — datasource is internal plumbing, always excluded
_CAPABILITY_TYPES = "skill,,websearch,retriever"


def register_tools(mcp: FastMCP):
    """Register NowAssist capability tools with the MCP server."""

    @mcp.tool()
    def list_nowassist_capabilities(
        name: str = "",
        type: str = "",
        active: str = "",
        limit: int = 200,
        instance: str = None
    ) -> str:
        """
        List NowAssist capabilities (sys_one_extend_capability) to discover available skills,
        their types, and sys_ids. datasource type is always excluded (internal plumbing).
        Use get_nowassist_capability for full I/O schema and provider detail.

        Note: Queries the implementation layer (sys_one_extend_capability), not the catalog
        wrapper (sn_nowassist_skill_config). Most capabilities have both; this is the reliable
        entry point.

        Use get_table_schema("sys_one_extend_capability") for valid field names and values.

        Args:
            type: "skill", "" (blank), "websearch", or "retriever"
            active: "true" or "false"
            limit: Default 200 — higher than standard for catalog listing

        Key fields in results:
            type: skill, blank, websearch, or retriever.
            description: Semantic context used in prompt assembly.
            sys_id: Pass to get_nowassist_capability for full detail.
        """
        builder = QueryBuilder()
        # Always exclude datasource type
        builder.add_custom(f"typeIN{_CAPABILITY_TYPES}")
        builder.add_like("name", name)
        if type:
            builder.add_equals("type", type)
        builder.add_equals("active", active)
        query = builder.add_order_by("name", "")

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_one_extend_capability",
            query=query,
            fields=["sys_id", "name", "type", "description", "active", "sys_scope"],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No NowAssist capabilities found matching your criteria."

        output = []
        for entry in results:
            cap_type = entry.get('type') or '(standard)'
            active_str = "active" if entry.get('active') == 'true' else "inactive"
            output.append(
                f"{entry.get('name', 'N/A')} [{cap_type}] [{active_str}]\n"
                f"Description: {entry.get('description', 'N/A')}\n"
                f"Scope: {entry.get('sys_scope', 'N/A')}\n"
                f"sys_id: {entry.get('sys_id', 'N/A')}"
            )

        result = f"NowAssist Capabilities ({len(results)} results):\n\n" + "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def get_nowassist_capability(
        name_or_sys_id: str,
        instance: str = None
    ) -> str:
        """
        Get full detail for a NowAssist capability — I/O schema, provider bindings, and catalog
        metadata. Joins across sys_one_extend_capability, sys_one_extend_definition_attribute,
        sys_one_extend_capability_definition, sys_one_extend_definition_config, and
        sn_nowassist_skill_config in one call.

        Note: Prompts are assembled at runtime by ServiceNow's Java layer (com.glide.one_extend)
        and are not stored in any queryable table field. description is the closest proxy.
        For actual prompt text from live executions, use query_genai_logs.

        Use get_table_schema("sys_one_extend_capability") for valid field names and values.

        Args:
            name_or_sys_id: Capability name (partial match) or 32-char hex sys_id

        Key fields in results:
            description: Semantic context fed into prompt assembly.
            Inputs: Parameters injected at runtime — names, data types, required flag.
            Outputs: Fields returned after LLM processing.
            Providers: LLM providers; DEFAULT marks the active one.
            NowAssist Catalog: display name, skill family, publication state, template status.
        """
        client = get_client(instance)

        # Determine if input looks like a sys_id (32-char hex) or a name
        is_sys_id = bool(re.match(r'^[0-9a-f]{32}$', name_or_sys_id.strip()))

        # Query 1: Capability record
        builder = QueryBuilder()
        if is_sys_id:
            builder.add_equals("sys_id", name_or_sys_id.strip())
        else:
            builder.add_like("name", name_or_sys_id.strip())
        query = builder.build()

        cap_response = client.query_table(
            table_name="sys_one_extend_capability",
            query=query,
            fields=["sys_id", "name", "type", "description", "active", "sys_scope",
                    "sys_created_on", "sys_updated_on"],
            limit=1
        )

        if not cap_response["success"]:
            return format_error(cap_response["status_code"], cap_response.get("error", "Unknown error"))

        if not cap_response["result"]:
            return f"No NowAssist capability found matching '{name_or_sys_id}'."

        cap = cap_response["result"][0]
        cap_sys_id = cap["sys_id"]

        # Query 2: I/O attributes
        attr_builder = QueryBuilder()
        attr_builder.add_equals("capability", cap_sys_id)
        attr_response = client.query_table(
            table_name="sys_one_extend_definition_attribute",
            query=attr_builder.build(),
            fields=["name", "type", "data_type", "description", "mandatory", "default_value"],
            limit=100
        )
        attributes = attr_response.get("result", []) if attr_response.get("success") else []

        # Query 3: Provider bindings
        prov_builder = QueryBuilder()
        prov_builder.add_equals("capability", cap_sys_id)
        prov_response = client.query_table(
            table_name="sys_one_extend_capability_definition",
            query=prov_builder.build(),
            fields=["sys_id", "provider_type", "name", "active"],
            limit=20
        )
        providers = prov_response.get("result", []) if prov_response.get("success") else []

        # Query 4: Default provider config
        config_builder = QueryBuilder()
        config_builder.add_equals("capability", cap_sys_id)
        config_response = client.query_table(
            table_name="sys_one_extend_definition_config",
            query=config_builder.build(),
            fields=["provider"],
            limit=1
        )
        default_provider_id = None
        if config_response.get("success") and config_response.get("result"):
            default_provider_id = config_response["result"][0].get("provider")

        # Query 5: NowAssist catalog wrapper
        wrapper_builder = QueryBuilder()
        wrapper_builder.add_equals("skill_id", cap_sys_id)
        wrapper_response = client.query_table(
            table_name="sn_nowassist_skill_config",
            query=wrapper_builder.build(),
            fields=["name", "skill_family", "state", "order", "is_template", "active"],
            limit=1
        )
        wrapper = None
        if wrapper_response.get("success") and wrapper_response.get("result"):
            wrapper = wrapper_response["result"][0]

        # Format output
        cap_type = cap.get('type') or '(standard)'
        active_str = "active" if cap.get('active') == 'true' else "inactive"

        lines = [
            f"=== NowAssist Capability: {cap.get('name', 'N/A')} ===",
            f"Type: {cap_type} | Status: {active_str}",
            f"Description: {cap.get('description', 'N/A')}",
            f"Scope: {cap.get('sys_scope', 'N/A')} | sys_id: {cap_sys_id}",
            f"Created: {cap.get('sys_created_on', 'N/A')} | Updated: {cap.get('sys_updated_on', 'N/A')}",
        ]

        # Inputs
        inputs = [a for a in attributes if a.get('type') == 'input']
        lines.append(f"\n--- Inputs ({len(inputs)}) ---")
        if inputs:
            for attr in inputs:
                mandatory = " (required)" if attr.get('mandatory') == 'true' else ""
                default = f" [default: {attr.get('default_value')}]" if attr.get('default_value') else ""
                lines.append(
                    f"  {attr.get('name')} ({attr.get('data_type', 'string')}){mandatory}{default}"
                    + (f": {attr.get('description')}" if attr.get('description') else "")
                )
        else:
            lines.append("  (none)")

        # Outputs
        outputs = [a for a in attributes if a.get('type') == 'output']
        lines.append(f"\n--- Outputs ({len(outputs)}) ---")
        if outputs:
            for attr in outputs:
                lines.append(
                    f"  {attr.get('name')} ({attr.get('data_type', 'string')})"
                    + (f": {attr.get('description')}" if attr.get('description') else "")
                )
        else:
            lines.append("  (none)")

        # Providers
        lines.append(f"\n--- Providers ({len(providers)}) ---")
        if providers:
            for prov in providers:
                is_default = " [DEFAULT]" if prov.get('sys_id') == default_provider_id else ""
                active_p = "" if prov.get('active') == 'true' else " [inactive]"
                lines.append(f"  {prov.get('provider_type', prov.get('name', 'N/A'))}{is_default}{active_p}")
        else:
            lines.append("  (none configured)")

        # NowAssist catalog
        lines.append("\n--- NowAssist Catalog ---")
        if wrapper:
            lines.append(f"  Display name: {wrapper.get('name', 'N/A')}")
            lines.append(f"  Family: {wrapper.get('skill_family', 'N/A')}")
            lines.append(f"  State: {wrapper.get('state', 'N/A')} | Active: {wrapper.get('active', 'N/A')}")
            lines.append(f"  Order: {wrapper.get('order', 'N/A')} | Template: {wrapper.get('is_template', 'N/A')}")
        else:
            lines.append("  Not registered in NowAssist catalog.")

        # Prompt text note — always present
        lines.append(
            "\n--- Prompt Text ---\n"
            "  Not accessible via Table API. Prompts are assembled at runtime by the\n"
            "  ServiceNow platform. Use query_genai_logs to retrieve prompt text from\n"
            "  live executions."
        )

        return "\n".join(lines)
