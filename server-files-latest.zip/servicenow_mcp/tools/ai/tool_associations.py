"""AI Agent tool association tools — wiring tools to agents via sn_aia_agent_tool_m2m."""

import json

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error


def _check_binding_health(tool_type, tool_name, inputs_field):
    """Validate a sn_aia_agent_tool_m2m.inputs field for CRUD-type tools.

    Returns a list of human-readable warning strings. Empty list means healthy.
    Non-CRUD tools always return an empty list (empty inputs is valid for
    script/action tools).

    Rules for CRUD tools, in order:
      1. inputs must parse as JSON (catches REST map-notation coercion).
      2. parsed value must be a non-empty list.
      3. list must contain an entry with name == "crudInputs".
      4. that entry's value must have non-null "operation" and "table".

    Args:
        tool_type: The linked sn_aia_tool.type (e.g. "crud", "action").
        tool_name: The m2m binding name, for inclusion in warning messages.
        inputs_field: The raw inputs value — may be a JSON string, a list, or None.
    """
    if tool_type != "crud":
        return []

    if inputs_field is None:
        return [f"{tool_name}: inputs field is empty"]

    if isinstance(inputs_field, str):
        stripped = inputs_field.strip()
        if not stripped or stripped == "[]":
            return [f"{tool_name}: inputs field is empty"]
        try:
            parsed = json.loads(stripped)
        except (json.JSONDecodeError, ValueError):
            return [
                f"{tool_name}: inputs field does not parse as JSON "
                f"(likely REST map-notation coercion; write path should stringify with json.dumps)"
            ]
    else:
        parsed = inputs_field

    if not isinstance(parsed, list):
        return [f"{tool_name}: inputs field is not a JSON array"]

    if len(parsed) == 0:
        return [f"{tool_name}: inputs field is empty"]

    crud_entry = next((e for e in parsed if isinstance(e, dict) and e.get("name") == "crudInputs"), None)
    if crud_entry is None:
        return [f"{tool_name}: inputs is populated but missing the crudInputs envelope"]

    value = crud_entry.get("value")
    if value is None:
        value = {}
    elif not isinstance(value, dict):
        return [f"{tool_name}: crudInputs.value is not an object"]

    warnings = []
    if not value.get("operation"):
        warnings.append(f"{tool_name}: crudInputs.operation is missing or null")
    table = value.get("table")
    if not table or (isinstance(table, dict) and not table.get("value")):
        warnings.append(f"{tool_name}: crudInputs.table is missing or null")
    return warnings


_ALLOWED_CRUD_OPERATIONS = ("create", "update", "lookup")


def _validate_crud_spec(crud_spec):
    """Validate a crud_spec dict for add_tool_to_agent. Raises ValueError on bad input.

    Required keys:
      - operation: one of "create", "update", "lookup"
      - table: non-empty string
    Operation-specific requirements:
      - create: field_bindings (non-empty dict)
      - update: field_bindings (non-empty dict) + query (non-empty string)
      - lookup: query (non-empty string) + return_fields (non-empty list)
    """
    if not isinstance(crud_spec, dict):
        raise ValueError("crud_spec must be a dict")

    operation = crud_spec.get("operation")
    if operation not in _ALLOWED_CRUD_OPERATIONS:
        raise ValueError(
            f"crud_spec.operation must be one of {_ALLOWED_CRUD_OPERATIONS}, got: {operation!r}"
        )

    table = crud_spec.get("table")
    if not isinstance(table, str) or not table:
        raise ValueError("crud_spec.table must be a non-empty string")

    if operation in ("create", "update"):
        field_bindings = crud_spec.get("field_bindings")
        if not isinstance(field_bindings, dict) or not field_bindings:
            raise ValueError(
                f"crud_spec.field_bindings must be a non-empty dict for operation={operation}"
            )

    if operation in ("update", "lookup"):
        query = crud_spec.get("query")
        if not isinstance(query, str) or not query:
            raise ValueError(
                f"crud_spec.query must be a non-empty string for operation={operation}"
            )

    if operation == "lookup":
        return_fields = crud_spec.get("return_fields")
        if not isinstance(return_fields, list) or not return_fields:
            raise ValueError("crud_spec.return_fields must be a non-empty list for operation=lookup")


def _fetch_crud_field_metadata(client, table, field_names):
    """Fetch sys_dictionary metadata for the named fields on a target table.

    Returns a dict keyed by field element name. Each value contains:
      - id: the field element name
      - name: the field element name (same as id — platform convention)
      - label: the column_label
      - type: the internal_type
      - referenceTable: the reference table name (empty string if not a reference)
      - referenceTableDefaultField: conventionally "sys_id" for reference fields
      - sublabel: copy of the element name
      - dictionary_sys_id: the sys_dictionary row sys_id

    Fields not found in sys_dictionary are silently omitted — caller must handle the gap.
    """
    if not field_names:
        return {}

    element_in = ",".join(field_names)
    query = f"name={table}^elementIN{element_in}^active=true"

    response = client.query_table(
        table_name="sys_dictionary",
        query=query,
        fields=["sys_id", "element", "column_label", "internal_type", "reference"],
        limit=200,
    )

    if not response.get("success") or not response.get("result"):
        return {}

    meta = {}
    for row in response["result"]:
        element = _unwrap_display_value(row.get("element"))
        if not element:
            continue
        field_type = _unwrap_display_value(row.get("internal_type"))
        reference = _unwrap_display_value(row.get("reference"))
        meta[element] = {
            "id": element,
            "name": element,
            "label": row.get("column_label", "") or "",
            "type": str(field_type),
            "referenceTable": str(reference),
            "referenceTableDefaultField": "sys_id" if reference else "",
            "sublabel": element,
            "dictionary_sys_id": row.get("sys_id", ""),
        }
    return meta


def _unwrap_display_value(v):
    """Unwrap ServiceNow display_value dicts to a plain string.

    Handles three shapes:
      - plain string: returned as-is (empty string for None/falsy)
      - {"value": "x", "display_value": "X"}: prefers "value" (programmatic name)
      - any other value: coerced via str() unless None

    Always returns a string, never None.
    """
    if isinstance(v, dict):
        return v.get("value") or v.get("display_value") or ""
    return v if isinstance(v, str) else ("" if v is None else str(v))


def _build_crud_inputs(tool_input_schema, crud_spec, field_metadata, tool_description):
    """Build the sn_aia_agent_tool_m2m.inputs array for a CRUD-type tool binding.

    Returns a list of dicts ready for json.dumps into the m2m `inputs` field.

    Args:
        tool_input_schema: JSON string from sn_aia_tool.input_schema — defines which
            parameter names appear on the binding.
        crud_spec: Validated crud_spec dict (see _validate_crud_spec).
        field_metadata: Dict from _fetch_crud_field_metadata — must contain an entry
            for every key in crud_spec["field_bindings"] (and each of return_fields
            for lookup).
        tool_description: The linked sn_aia_tool.description, used as crudInputs
            entry description.
    """
    if tool_input_schema:
        try:
            schema_entries = json.loads(tool_input_schema)
        except (json.JSONDecodeError, ValueError) as exc:
            raise ValueError(
                f"tool_input_schema is not valid JSON: {exc}. "
                f"Pass an empty string or None if the schema is genuinely absent."
            )
    else:
        schema_entries = []

    operation = crud_spec["operation"]
    table_name = crud_spec["table"]
    field_bindings = crud_spec.get("field_bindings", {}) or {}
    return_fields = crud_spec.get("return_fields", []) or []

    # Verify field_metadata covers every referenced field.
    needed = set(field_bindings.keys()) | set(return_fields)
    missing = sorted(n for n in needed if n not in field_metadata)
    if missing:
        raise ValueError(
            f"field_metadata missing entries for: {missing}. "
            f"Check that these fields exist on sys_dictionary for table {table_name!r}."
        )

    # Compose non-crudInputs entries first (one per schema entry, preserving order).
    inputs = []
    for entry in schema_entries:
        name = entry.get("name", "")
        if name == "crudInputs":
            continue
        inputs.append({
            "name": name,
            "value": "",
            "description": entry.get("description", "") or "",
            "mandatory": bool(entry.get("mandatory", False)),
            "invalidMessage": None,
        })

    def _field_shape(fname):
        m = field_metadata[fname]
        return {
            "id": m["id"],
            "name": m["name"],
            "label": m["label"],
            "type": m["type"],
            "referenceTable": m["referenceTable"],
            "referenceTableDefaultField": m["referenceTableDefaultField"],
            "dictionaryAttributes": [],
            "sublabel": m["sublabel"],
        }

    def _field_value_entry(fname, template):
        return {
            "field": _field_shape(fname),
            "value": {"fieldValue": template},
        }

    # table.displayValue is ideally the table's label (sys_db_object.label), but
    # looking that up would require another round-trip. Copying the sys name is
    # cosmetically imperfect (the UI may show the raw name in the label field)
    # but functionally correct — the platform reads table.value for the operation.
    crud_value = {
        "operation": operation,
        "table": {"value": table_name, "displayValue": table_name},
    }
    if operation in ("create", "update"):
        crud_value["fieldValues"] = [
            _field_value_entry(fname, template)
            for fname, template in field_bindings.items()
        ]
    if operation in ("update", "lookup"):
        crud_value["query"] = crud_spec["query"]
    if operation == "lookup":
        crud_value["returnFields"] = [{"field": _field_shape(fname)} for fname in return_fields]

    inputs.append({
        "name": "crudInputs",
        "value": crud_value,
        "description": tool_description or "CRUD Input Variables. These are already pre-defined.",
        "mandatory": False,
        "invalidMessage": None,
    })

    return inputs


def register_tools(mcp: FastMCP):
    """Register AI agent tool association tools with the MCP server."""

    @mcp.tool()
    def add_tool_to_agent(
        agent: str,
        tool: str,
        name: str,
        execution_mode: str = "copilot",
        max_auto_executions: int = 10,
        active: str = "true",
        crud_spec: dict = None,
        instance: str = None
    ) -> str:
        """
        Link a tool to an AI Agent via sn_aia_agent_tool_m2m.

        **BEFORE CALLING:** Call get_agent_details(agent_sys_id) first — if the tool is
        already listed, do not add a duplicate.

        **For CRUD-type tools — pass `crud_spec` to materialize the binding in one call.**
        The handler fetches the linked sn_aia_tool, resolves sys_dictionary metadata for
        each bound field, composes a complete `crudInputs` envelope, and writes the full
        `inputs` array in one create_record call. `description` and `display_output` are
        also populated automatically. A post-write read-back verifies binding health.

        **For non-CRUD tools (action/script) — omit crud_spec.** Creates the m2m record,
        then call update_record separately to populate description and inputs.

        **Field name disambiguation — `input_schema` vs `inputs`:**
        These are different fields on different tables:
          - `sn_aia_tool.input_schema`        — the tool's parameter schema template (read from the tool catalog)
          - `sn_aia_agent_tool_m2m.inputs`    — the per-agent binding configuration (written when wiring a tool)
        Never use `input_schema` when reading or writing the m2m record — it does not exist on
        that table and will silently return null.

        **For RAG-type tools — inputs format and semantic index names:**
        Multi-value fields (sources, fields, semantic_index_names) require both `value`
        AND `label` arrays — omitting `label` causes blank fields in the Agent Builder UI,
        even though the values are stored.

        CRITICAL: `semantic_index_names` values are NOT raw field names. They are the
        `semantic_field_name` values from `ais_semantic_index_configuration` records
        linked to the datasource. To find the correct values for a table:
          1. Find the datasource: query_table("ais_datasource", "datasource=<table>", limit=1)
          2. Find semantic component fields: execute_script querying
             `ais_semantic_component_field` where `datasource = <datasource_sys_id>`
          3. The `ais_semantic_index_configuration` record linked from each component
             contains the `semantic_field_name` to use here.

        Verified index names on zyew2:
          - incident text fields (short_description, description, close_notes) → `"body"`
          - kb_knowledge article fields → `"body"` (verify for other datasources)
          - sc_request has NO semantic index configuration → keyword search only

        Example inputs JSON structure for a hybrid incident + KB RAG tool:
            [
              {"name": "search_type",    "value": "hybrid"},
              {"name": "query",          "description": "Natural language query"},
              {"name": "search_profile", "value": "<profile_name>",
                                         "label": "<Profile Display Label>"},
              {"name": "sources",        "value": ["incident", "sc_request"],
                                         "label": ["Incident", "Requested Item"]},
              {"name": "fields",         "value": ["incident.short_description", ...],
                                         "label": ["Short description [incident]", ...]},
              {"name": "semantic_index_names", "value": ["body"],
                                               "label": ["body"]},
              {"name": "search_results_limit",      "value": "5"},
              {"name": "document_match_threshold",  "value": "0.5"}
            ]
        label arrays must have the same length as value arrays.

        **crud_spec shape:**
            {
              "operation": "create" | "update" | "lookup",
              "table": "incident",
              "field_bindings": {"state": "{{state_value}}"},   # create/update only
              "query": "number={{number}}",                      # update/lookup only
              "return_fields": ["sys_id", "state"]              # lookup only
            }

        **Versioning note:** Adding a tool withdraws any published sn_aia_version. After
        adding, republish via update_record on sn_aia_version (state="published").

        Args:
            agent: sys_id of the AI Agent (required)
            tool: sys_id of the tool to associate (required)
            name: Display name for the tool association (required)
            execution_mode: "copilot" (requires user approval) or "autopilot" (autonomous). Default: "copilot"
            active: "true" or "false". Default: "true"
            max_auto_executions: Max autonomous executions before requiring approval. Default: 10.
            crud_spec: CRUD materialization spec (see shape above). Tool must have type='crud'.

        Key fields in results:
            sys_id: The unique identifier of the created tool association record.
        """
        confirmation_error = require_instance_confirmation(instance, "add tool to agent")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        # Pre-flight: check if this tool name is already wired to this agent
        existing_builder = QueryBuilder()
        existing_builder.add_equals("agent", agent)
        existing_builder.add_equals("name", name)
        existing_check = client.query_table(
            table_name="sn_aia_agent_tool_m2m",
            query=existing_builder.build(),
            fields=["sys_id", "name", "active"],
            limit=1
        )
        if existing_check["success"] and existing_check["result"]:
            existing = existing_check["result"][0]
            return (
                f"Tool '{name}' is already wired to this agent "
                f"(m2m sys_id: {existing['sys_id']}, active: {existing.get('active', '?')}). "
                f"No action needed."
            )

        data = {
            "agent": agent,
            "tool": tool,
            "name": name,
            "execution_mode": execution_mode,
            "max_auto_executions": str(max_auto_executions),
            "active": active,
        }

        # When crud_spec is provided, materialize a complete CRUD binding in one call.
        if crud_spec is not None:
            try:
                _validate_crud_spec(crud_spec)
            except ValueError as exc:
                return f"Invalid crud_spec: {exc}"

            tool_lookup = client.query_table(
                table_name="sn_aia_tool",
                query=f"sys_id={tool}",
                fields=["sys_id", "type", "input_schema", "description"],
                limit=1,
            )
            if not tool_lookup.get("success") or not tool_lookup.get("result"):
                return format_error(
                    tool_lookup.get("status_code", 0),
                    tool_lookup.get("error", f"Tool {tool} not found"),
                )
            tool_record = tool_lookup["result"][0]
            tool_type = _unwrap_display_value(tool_record.get("type", ""))
            if tool_type != "crud":
                return (
                    f"Tool {tool} has type={tool_type!r}, not 'crud'. "
                    f"crud_spec is only valid for CRUD-type tools. "
                    f"Omit crud_spec to add non-CRUD tools."
                )

            field_names = list(crud_spec.get("field_bindings", {}).keys())
            field_names += list(crud_spec.get("return_fields", []) or [])
            try:
                field_metadata = _fetch_crud_field_metadata(
                    client, crud_spec["table"], field_names,
                )
                built_inputs = _build_crud_inputs(
                    tool_record.get("input_schema", ""),
                    crud_spec,
                    field_metadata,
                    tool_record.get("description", ""),
                )
            except ValueError as exc:
                return f"Failed to materialize inputs: {exc}"

            data["inputs"] = json.dumps(built_inputs)
            data["description"] = tool_record.get("description", "") or ""
            data["display_output"] = "false"

        response = client.create_record(table_name="sn_aia_agent_tool_m2m", data=data)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"

        if crud_spec is None:
            return (
                f"Tool '{name}' added to agent successfully.\n"
                f"sys_id: {sys_id}\n\n"
                f"Next: complete the standard procedure by calling update_record on "
                f"sn_aia_agent_tool_m2m (sys_id: {sys_id}) to set description, inputs, "
                f"and display_output from the tool record."
            )

        # Read back and assert binding health.
        readback = client.get_record(
            table_name="sn_aia_agent_tool_m2m", sys_id=sys_id,
        )
        readback_inputs = None
        if readback.get("success"):
            readback_result = readback.get("result") or {}
            readback_inputs = readback_result.get("inputs")
        warnings = _check_binding_health("crud", name, readback_inputs)
        if warnings:
            return (
                f"Tool '{name}' added to agent with crud_spec (sys_id: {sys_id}), "
                f"but the read-back check detected degraded state.\n"
                f"⚠ Health: {'; '.join(warnings)}\n"
                f"Inspect the record and repair manually before use."
            )
        return (
            f"Tool '{name}' added to agent successfully with fully materialized "
            f"CRUD envelope (operation={crud_spec['operation']}, "
            f"table={crud_spec['table']}).\n"
            f"sys_id: {sys_id}"
        )

    @mcp.tool()
    def remove_tool_from_agent(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Remove a tool from an AI Agent by deleting its sn_aia_agent_tool_m2m record.

        Use get_agent_details to find the tool association's sys_id first.

        **Versioning note:** Removing a tool withdraws any published sn_aia_version.
        After removing, republish via update_record on sn_aia_version (state="published").
        Mention this to the user so they can batch changes before republishing.

        This action cannot be undone.

        Args:
            sys_id: The sys_id of the sn_aia_agent_tool_m2m record to delete (required)
        """
        confirmation_error = require_instance_confirmation(instance, "remove tool from agent")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        response = client.delete_record(table_name="sn_aia_agent_tool_m2m", sys_id=sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        return f"Tool association '{sys_id}' removed successfully."
