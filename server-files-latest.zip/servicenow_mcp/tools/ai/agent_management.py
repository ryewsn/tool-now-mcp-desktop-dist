"""AI Agent management tools — CRUD, cloning, and team membership."""

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error
from .tool_associations import _unwrap_display_value, _check_binding_health


def register_tools(mcp: FastMCP):
    """Register AI agent management tools with the MCP server."""

    @mcp.tool()
    def list_ai_agents(
        name: str = "",
        agent_type: str = "",
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        List AI Agents (sn_aia_agent) — not Agentic Workflows (use list_agentic_workflows for those).
        Use to discover agents, find sys_ids for deeper inspection, or filter by type.
        Active status is on sn_aia_agent_config, not this table — use get_agent_details for it.

        Args:
            agent_type: "internal" (AI Agent), "external" (External AI Agent), "voice" (AI Phone Agent)

        Key fields in results:
            agent_type: internal / external / voice.
            role: Agent's persona.
            channel: nap (Now Assist Panel) or nap_and_va.
            record_type: custom / promoted / template / aia_internal.
        """
        builder = QueryBuilder()
        builder.add_like("name", name)
        builder.add_equals("agent_type", agent_type)
        query = builder.add_order_by("sys_created_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_agent",
            query=query,
            fields=[
                "sys_id", "name", "description", "agent_type", "role",
                "channel", "record_type", "sys_scope",
                "sys_created_on", "sys_updated_on"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No AI agents found matching your criteria."

        output = []
        for entry in results:
            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('name', 'N/A')}\n"
                f"Type: {entry.get('agent_type', 'N/A')} | Channel: {entry.get('channel', 'N/A')} | Record: {entry.get('record_type', 'N/A')}\n"
                f"Role: {entry.get('role', 'N/A')}\n"
                f"Description: {entry.get('description', 'N/A')}\n"
                f"Scope: {entry.get('sys_scope', 'N/A')} | Updated: {entry.get('sys_updated_on', 'N/A')}\n"
                f"sys_id: {entry.get('sys_id', 'N/A')}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def get_agent_details(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Get comprehensive details for a single AI Agent (sn_aia_agent), querying 6 related
        tables in one call: agent record, tool associations, config, team membership, approved
        roles, and published instruction version. Use list_ai_agents first to find the sys_id.

        **Call this tool first before any tool creation or wiring work.** The Tools section
        shows what is already wired via sn_aia_agent_tool_m2m — if the tools are already listed,
        no action is required.

        Key fields in results:
            Agent (sn_aia_agent): name, description, agent_type, role, channel, record_type, instructions, proficiency, inputs, outputs, compiled_handbook, advanced_mode, condition, strategy.
            Tools (sn_aia_agent_tool_m2m): name, execution_mode (autopilot/copilot), max_auto_executions, active, output_transformation_strategy, timeout. "⚠ Health:" appended when inputs is empty, unparseable, or missing crudInputs. Header shows "[N degraded]" when bindings are unhealthy.
            Config (sn_aia_agent_config): active, run_as_user, agent_learning, public, doc_url, icon_url.
            Team (sn_aia_team_member): team, memory_scope, sys_id.
            Approved Roles (sys_agent_access_role_configuration): allow_all_session_roles (true = any session role may invoke), role_list (approved role display names when allow_all is false).
            Published Version (sn_aia_version): sys_id, version_number, version_name. Use this sys_id with update_record to update instructions without a separate query.

        **For tools of type "action":** use list_flow_actions / get_flow_action for I/O variables.
        Script step source is NOT accessible via API — do not query sys_hub_step_* tables. Direct
        user to Flow Designer in the UI for script content.
        """
        client = get_client(instance)

        # Query 1: Agent record
        agent_response = client.query_table(
            table_name="sn_aia_agent",
            query=f"sys_id={sys_id}",
            fields=[
                "sys_id", "name", "description", "agent_type", "role",
                "channel", "record_type", "instructions", "proficiency",
                "inputs", "outputs", "compiled_handbook", "advanced_mode",
                "condition", "strategy", "sys_scope",
                "sys_created_on", "sys_updated_on"
            ],
            limit=1
        )

        if not agent_response["success"]:
            return format_error(agent_response["status_code"], agent_response.get("error", "Unknown error"))

        agents = agent_response["result"]
        if not agents:
            return f"Agent not found with sys_id: {sys_id}"

        agent = agents[0]

        # Query 2: Tool associations (m2m)
        tool_builder = QueryBuilder()
        tool_builder.add_equals("agent", sys_id)
        tool_query = tool_builder.build()

        tools_response = client.query_table(
            table_name="sn_aia_agent_tool_m2m",
            query=tool_query,
            fields=[
                "sys_id", "tool", "name", "active", "execution_mode",
                "max_auto_executions", "output_transformation_strategy",
                "description", "inputs", "timeout", "tool.type"
            ],
            limit=100
        )

        # Query 3: Agent configuration
        config_builder = QueryBuilder()
        config_builder.add_equals("agent", sys_id)
        config_query = config_builder.build()

        config_response = client.query_table(
            table_name="sn_aia_agent_config",
            query=config_query,
            fields=[
                "active", "run_as_user", "agent_learning",
                "public", "doc_url", "icon_url"
            ],
            limit=1,
            display_value="true"
        )

        # Query 4: Team membership
        team_builder = QueryBuilder()
        team_builder.add_equals("agent", sys_id)
        team_query = team_builder.build()

        team_response = client.query_table(
            table_name="sn_aia_team_member",
            query=team_query,
            fields=["sys_id", "team", "memory_scope"],
            limit=100
        )

        # Query 5: Approved role configuration
        access_role_builder = QueryBuilder()
        access_role_builder.add_equals("agent", sys_id)
        access_role_query = access_role_builder.build()

        access_role_response = client.query_table(
            table_name="sys_agent_access_role_configuration",
            query=access_role_query,
            fields=["allow_all_session_roles", "role_list"],
            limit=1
        )

        # Query 6: Published instruction version
        version_builder = QueryBuilder()
        version_builder.add_equals("target_id", sys_id)
        version_builder.add_equals("state", "published")
        version_query = version_builder.add_order_by("version_number", "DESC")

        version_response = client.query_table(
            table_name="sn_aia_version",
            query=version_query,
            fields=["sys_id", "version_number", "version_name", "state"],
            limit=1
        )

        # Format output
        output_lines = [
            f"=== AI Agent: {agent.get('name', 'N/A')} ===",
            f"Type: {agent.get('agent_type', 'N/A')} | Channel: {agent.get('channel', 'N/A')} | Record: {agent.get('record_type', 'N/A')}",
            f"Role: {agent.get('role', 'N/A')}",
            f"Description: {agent.get('description', 'N/A')}",
            f"Advanced mode: {agent.get('advanced_mode', 'N/A')} | Strategy: {agent.get('strategy', 'N/A')}",
            f"Condition: {agent.get('condition', 'N/A')}",
            f"Scope: {agent.get('sys_scope', 'N/A')}",
            f"Created: {agent.get('sys_created_on', 'N/A')} | Updated: {agent.get('sys_updated_on', 'N/A')}",
            f"sys_id: {agent.get('sys_id', 'N/A')}",
        ]

        # Instructions (no truncation)
        if agent.get("instructions"):
            output_lines.append(f"\n--- Instructions ---\n{agent.get('instructions')}")
        if agent.get("proficiency"):
            output_lines.append(f"\n--- Proficiency ---\n{agent.get('proficiency')}")
        if agent.get("inputs"):
            output_lines.append(f"\n--- Inputs ---\n{agent.get('inputs')}")
        if agent.get("outputs"):
            output_lines.append(f"\n--- Outputs ---\n{agent.get('outputs')}")
        if agent.get("compiled_handbook"):
            output_lines.append(f"\n--- Compiled Handbook ---\n{agent.get('compiled_handbook')}")

        # Tool associations
        tools = tools_response.get("result", []) if tools_response.get("success") else []

        # Compute health warnings for each tool so we can include a degraded count.
        tool_warnings = []
        for tool in tools:
            tool_type = _unwrap_display_value(tool.get("tool.type", ""))
            warnings = _check_binding_health(tool_type, tool.get("name", "(unnamed)"), tool.get("inputs"))
            tool_warnings.append(warnings)

        degraded_count = sum(1 for w in tool_warnings if w)
        header_suffix = f" [{degraded_count} degraded]" if degraded_count else ""
        output_lines.append(f"\n--- Agent Tools ({len(tools)}){header_suffix} ---")

        if tools:
            for i, (tool, warnings) in enumerate(zip(tools, tool_warnings), 1):
                active_status = "Active" if tool.get("active") == "true" else "Inactive"
                exec_mode = tool.get("execution_mode", "N/A")
                max_exec = tool.get("max_auto_executions", "N/A")
                output_lines.append(
                    f"{i}. {tool.get('name', 'N/A')} | {exec_mode} | Max: {max_exec} | {active_status}"
                )
                if tool.get("description"):
                    output_lines.append(f"   Description: {tool.get('description')}")
                if tool.get("output_transformation_strategy"):
                    output_lines.append(f"   Output strategy: {tool.get('output_transformation_strategy')}")
                if tool.get("timeout"):
                    output_lines.append(f"   Timeout: {tool.get('timeout')}")
                if tool.get("inputs"):
                    output_lines.append(f"   Inputs: {tool.get('inputs')}")
                output_lines.append(f"   sys_id: {tool.get('sys_id', 'N/A')}")
                if warnings:
                    output_lines.append(f"   ⚠ Health: {'; '.join(warnings)}")
        else:
            output_lines.append("No tools assigned to this agent.")

        # Configuration
        configs = config_response.get("result", []) if config_response.get("success") else []
        output_lines.append("\n--- Configuration ---")
        if configs:
            config = configs[0]
            run_as_raw = config.get('run_as_user', '')
            run_as_display = f"AI User: {run_as_raw}" if run_as_raw else "Dynamic"
            output_lines.append(
                f"Active: {config.get('active', 'N/A')} | "
                f"Run as: {run_as_display} | "
                f"Learning: {config.get('agent_learning', 'N/A')}"
            )
            access_roles = access_role_response.get("result", []) if access_role_response.get("success") else []
            if access_roles:
                role_config = access_roles[0]
                if role_config.get("allow_all_session_roles") == "true":
                    output_lines.append("Approved roles: All session roles allowed")
                else:
                    role_list = role_config.get("role_list", "")
                    output_lines.append(f"Approved roles: {role_list or '(none)'}")
            else:
                output_lines.append("Approved roles: Not configured")
            if config.get("public"):
                output_lines.append(f"Public: {config.get('public')}")
            if config.get("doc_url"):
                output_lines.append(f"Doc URL: {config.get('doc_url')}")
            if config.get("icon_url"):
                output_lines.append(f"Icon URL: {config.get('icon_url')}")
        else:
            output_lines.append("No configuration found for this agent.")

        # Team membership
        teams = team_response.get("result", []) if team_response.get("success") else []
        output_lines.append("\n--- Team Membership ---")
        if teams:
            for team in teams:
                output_lines.append(
                    f"Team: {team.get('team', 'N/A')} | Memory scope: {team.get('memory_scope', 'N/A')} | sys_id: {team.get('sys_id', 'N/A')}"
                )
        else:
            output_lines.append("Not a member of any team.")

        # Published version
        versions = version_response.get("result", []) if version_response.get("success") else []
        output_lines.append("\n--- Published Version ---")
        if versions:
            v = versions[0]
            output_lines.append(
                f"Version {v.get('version_number', '?')} — {v.get('version_name') or '(unnamed)'}\n"
                f"Version sys_id: {v.get('sys_id', 'N/A')}  ← use this with update_record to update instructions"
            )
        else:
            output_lines.append("No published version found. Use list_versions to inspect version history.")

        return "\n".join(output_lines)

    @mcp.tool()
    def manage_ai_agent(
        name: str = "",
        description: str = "",
        role: str = "",
        instructions: str = "",
        proficiency: str = "",
        agent_type: str = "",
        inputs: str = "",
        outputs: str = "",
        scope_sys_id: str = "",
        sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create or update an AI Agent in ServiceNow (sn_aia_agent).

        Pass sys_id to update an existing agent. Omit sys_id to create a new one.

        **Instruction versioning:** If version records exist in sn_aia_version (query by
        target_id = agent sys_id), use the version system — do NOT update instructions directly.
        - Update active version: update_record on sn_aia_version (instructions field), then call
          manage_ai_agent to sync instructions on sn_aia_agent.
        - New version: create in AI Agent Studio UI, then populate via update_record.
        - Switch active version: set state to "published" — platform withdraws previous and syncs sn_aia_agent.
        - Recovery (both withdrawn): publish correct version via update_record, then sync sn_aia_agent.

        If no version records exist, direct updates to instructions are safe.

        Args:
            agent_type: "internal" (AI Agent), "external" (External AI Agent), "voice" (AI Phone Agent).
                Defaults to "internal" on create.
            instructions: CAUTION: If version records exist in sn_aia_version, use the version
                system instead (see above).
            scope_sys_id: sys_id of the target application scope (default: Global). Create only.
            sys_id: If provided, update this record instead of creating.
            instance: ServiceNow instance alias (uses default if not specified)
        """
        confirmation_error = require_instance_confirmation(instance, "manage AI agent")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        if sys_id:
            # Update mode — no agent_type default applied
            data = {}
            if name:
                data["name"] = name
            if description:
                data["description"] = description
            if role:
                data["role"] = role
            if instructions:
                data["instructions"] = instructions
            if proficiency:
                data["proficiency"] = proficiency
            if agent_type:
                data["agent_type"] = agent_type
            if inputs:
                data["inputs"] = inputs
            if outputs:
                data["outputs"] = outputs

            response = client.glide_write(table="sn_aia_agent", operation="update", data=data, sys_id=sys_id)
            if not response["success"]:
                return format_error(response["status_code"], response.get("error", "Unknown error"))
            return f"AI Agent '{sys_id}' updated successfully."

        # Create mode
        data = {"name": name, "description": description}
        if role:
            data["role"] = role
        if instructions:
            data["instructions"] = instructions
        if proficiency:
            data["proficiency"] = proficiency
        data["agent_type"] = agent_type if agent_type else "internal"
        if inputs:
            data["inputs"] = inputs
        if outputs:
            data["outputs"] = outputs

        response = client.glide_write(table="sn_aia_agent", operation="insert", data=data, scope_sys_id=scope_sys_id)
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        new_sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"
        return f"AI Agent '{name}' created successfully.\nsys_id: {new_sys_id}"

    @mcp.tool()
    def delete_ai_agent(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Delete an AI Agent from ServiceNow (sn_aia_agent). This action cannot be undone.

        Use list_ai_agents to find the agent's sys_id first.
        """
        confirmation_error = require_instance_confirmation(instance, "delete AI agent")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        response = client.glide_write(table="sn_aia_agent", operation="delete", data={}, sys_id=sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        return f"AI Agent '{sys_id}' deleted successfully."

    @mcp.tool()
    def add_agent_to_team(
        agent: str,
        team: str,
        memory_scope: str = "",
        instance: str = None
    ) -> str:
        """
        Add an AI Agent to a team by creating a sn_aia_team_member record.

        The key field is `agent` (NOT `member`) — always use this tool rather than
        create_record to avoid field name errors. If a membership for this agent+team already
        exists the platform rejects the create — check get_agent_details first.

        Use list_ai_agents to find the agent's sys_id.

        The `team` parameter accepts either:
        - An sn_aia_team sys_id (returned as team_sys_id by manage_agentic_workflow)
        - An sn_aia_usecase (workflow) sys_id — the tool automatically resolves it to the
          linked sn_aia_team sys_id via the workflow's team field

        Args:
            agent: sys_id of the AI Agent to add
            team: sys_id of the sn_aia_team record, or the sn_aia_usecase (workflow) sys_id

        Key fields in results:
            sys_id: Created team member record identifier.
        """
        confirmation_error = require_instance_confirmation(instance, "add agent to team")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        # If the caller passed a workflow sys_id, resolve to the linked sn_aia_team sys_id
        team_sys_id = team
        usecase_response = client.query_table(
            table_name="sn_aia_usecase",
            query=f"sys_id={team}",
            fields=["team"],
            limit=1
        )
        if usecase_response.get("success") and usecase_response.get("result"):
            usecase = usecase_response["result"][0]
            team_ref = usecase.get("team", {})
            resolved = team_ref.get("value", "") if isinstance(team_ref, dict) else team_ref
            if resolved:
                team_sys_id = resolved

        data = {
            "agent": agent,
            "team": team_sys_id,
        }
        if memory_scope:
            data["memory_scope"] = memory_scope

        response = client.create_record(table_name="sn_aia_team_member", data=data)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"
        return f"Agent added to team successfully.\nsys_id: {sys_id}"

    @mcp.tool()
    def remove_agent_from_team(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Remove an AI Agent from a team by deleting the sn_aia_team_member record.
        This action cannot be undone.

        Use get_agent_details to find the team membership sys_id (listed under "Team Membership").

        Args:
            sys_id: sys_id of the sn_aia_team_member record to delete
        """
        confirmation_error = require_instance_confirmation(instance, "remove agent from team")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        response = client.delete_record(table_name="sn_aia_team_member", sys_id=sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        return f"Agent removed from team successfully (team member record '{sys_id}' deleted)."

    @mcp.tool()
    def clone_ai_agent(
        sys_id: str,
        new_name: str,
        instance: str = None
    ) -> str:
        """
        Clone an AI Agent (sn_aia_agent) and its tool associations (sn_aia_agent_tool_m2m).

        Use list_ai_agents to find the source agent's sys_id.

        Args:
            sys_id: sys_id of the source AI Agent to clone
            new_name: Name for the new cloned agent

        Key fields in results:
            sys_id: Newly created agent identifier.
            tools_cloned: Number of tool associations copied.
        """
        confirmation_error = require_instance_confirmation(instance, "clone AI agent")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        # Step 1: Read source agent
        agent_response = client.query_table(
            table_name="sn_aia_agent",
            query=f"sys_id={sys_id}",
            fields=[
                "sys_id", "name", "description", "agent_type", "role",
                "instructions", "proficiency", "inputs", "outputs", "channel"
            ],
            limit=1
        )

        if not agent_response["success"]:
            return format_error(agent_response["status_code"], agent_response.get("error", "Unknown error"))

        agents = agent_response["result"]
        if not agents:
            return f"Source agent not found with sys_id: {sys_id}"

        source = agents[0]

        # Step 2: Read source tool associations
        tool_response = client.query_table(
            table_name="sn_aia_agent_tool_m2m",
            query=f"agent={sys_id}",
            fields=["tool", "name", "execution_mode", "max_auto_executions", "active"],
            limit=100
        )

        source_tools = tool_response.get("result", []) if tool_response.get("success") else []

        # Step 3: Create new agent with source fields and new name
        clone_fields = ["description", "agent_type", "role", "instructions",
                        "proficiency", "inputs", "outputs", "channel"]
        new_agent_data = {"name": new_name}
        for field in clone_fields:
            value = source.get(field, "")
            if value:
                new_agent_data[field] = value

        create_response = client.glide_write(table="sn_aia_agent", operation="insert", data=new_agent_data)

        if not create_response["success"]:
            return format_error(create_response["status_code"], create_response.get("error", "Unknown error"))

        new_result = create_response["result"]
        new_agent_id = new_result.get("sys_id", "unknown") if isinstance(new_result, dict) else "unknown"

        # Step 4: Clone tool associations
        tools_cloned = 0
        for tool_m2m in source_tools:
            tool_ref = tool_m2m.get("tool", {})
            tool_sys_id = tool_ref.get("value", "") if isinstance(tool_ref, dict) else tool_ref
            m2m_data = {
                "agent": new_agent_id,
                "tool": tool_sys_id,
                "name": tool_m2m.get("name", ""),
                "execution_mode": tool_m2m.get("execution_mode", "copilot"),
                "max_auto_executions": tool_m2m.get("max_auto_executions", "10"),
                "active": tool_m2m.get("active", "true"),
            }
            m2m_response = client.create_record(table_name="sn_aia_agent_tool_m2m", data=m2m_data)
            if m2m_response.get("success"):
                tools_cloned += 1

        return (
            f"AI Agent '{new_name}' cloned successfully from '{source.get('name', sys_id)}'.\n"
            f"New agent sys_id: {new_agent_id}\n"
            f"Tool associations cloned: {tools_cloned}"
        )
