"""AI Agent tool catalog tools — CRUD for sn_aia_tool records."""

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error


def _format_record(entry: dict) -> str:
    active_status = "active" if entry.get("active") == "true" else "inactive"
    lines = [
        f"Name:                 {entry.get('name') or 'N/A'}",
        f"sys_id:               {entry.get('sys_id') or 'N/A'}",
        f"Type:                 {entry.get('type') or 'N/A'} | {active_status}",
        f"Record type:          {entry.get('record_type') or 'N/A'}",
        f"Scope:                {entry.get('sys_scope') or 'N/A'}",
        f"Description:          {entry.get('description') or 'N/A'}",
        f"Target table:         {entry.get('target_document_table') or 'N/A'}",
        f"Created:              {entry.get('sys_created_on') or 'N/A'}",
        f"Updated:              {entry.get('sys_updated_on') or 'N/A'}",
    ]
    if entry.get("input_schema"):
        lines.append(f"Input schema:\n{entry['input_schema']}")
    if entry.get("script"):
        lines.append(f"Script:\n{entry['script']}")
    return "\n".join(lines)


def register_tools(mcp: FastMCP):
    """Register AI agent tool catalog tools with the MCP server."""

    @mcp.tool()
    def list_agent_tools(
        name: str = "",
        type: str = "",
        active: str = "",
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        List AI Agent Tools from sn_aia_tool. Returns name, type, active status,
        input_schema, script, scope, and sys_id for each match.

        14 tool types: action, subflow, capability, script, topic, catalog, crud,
        mcp, web_automation, topic_block, rag, deep_research, knowledge_graph, desktop_automation.

        Use get_table_schema("sn_aia_tool") for valid field names and type values.

        **For tools of type "action" — use list_flow_actions / get_flow_action:**
        Tools of type "action" are backed by a Flow Designer action (sys_hub_action_type_definition).
        Use list_flow_actions to discover the action and get_flow_action to inspect its I/O variables
        parsed from label_cache. Script step source code is NOT accessible via the API — it is stored
        as a serialized snapshot. Do not attempt to query sys_hub_step_instance, sys_hub_step_ext,
        sys_hub_step_variable, sys_hub_step_config, or sys_hub_script_step — none expose readable
        script source. Tell the user to open Flow Designer in the ServiceNow UI for script content.

        Args:
            active: "true" or "false"

        Key fields in results:
            type: One of the 14 tool types above.
            input_schema: JSON schema for the tool's expected inputs.
            script: Implementation (script-type only; empty for action/subflow).
            record_type: Origin — custom, promoted, template, or aia_internal.
        """
        builder = QueryBuilder()
        builder.add_like("name", name)
        builder.add_equals("type", type)
        builder.add_equals("active", active)
        query = builder.add_order_by("sys_created_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sn_aia_tool",
            query=query,
            fields=[
                "sys_id", "name", "description", "type", "active",
                "input_schema", "script", "record_type", "sys_scope",
                "sys_created_on"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No agent tools found matching your criteria."

        output = []
        for entry in results:
            active_status = "active" if entry.get("active") == "true" else "inactive"
            lines = [
                f"[{entry.get('sys_created_on')}] {entry.get('name', 'N/A')} ({entry.get('type', 'N/A')} | {active_status})",
                f"Description: {entry.get('description', 'N/A')}",
            ]
            if entry.get("input_schema"):
                lines.append(f"Input schema: {entry.get('input_schema')}")
            if entry.get("script"):
                lines.append(f"Script: {entry.get('script')}")
            lines.append(f"Scope: {entry.get('sys_scope', 'N/A')}")
            lines.append(f"sys_id: {entry.get('sys_id', 'N/A')}")
            output.append("\n".join(lines))

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def get_tool(
        sys_id: str = "",
        name: str = "",
        instance: str = None
    ) -> str:
        """
        Get full details for a single AI Agent Tool record from sn_aia_tool —
        script, input_schema, target_document_table, record_type, and all metadata.
        Prefer sys_id (fastest); name is exact-match and may return multiple scope hits.

        Args:
            sys_id: Takes priority over name if both provided.
            name: Exact match. All scope matches returned if more than one found.

        Key fields in result:
            type: Tool type (script, action, subflow, mcp, crud, etc.)
            input_schema: JSON schema for the tool's inputs.
            script: Implementation (script-type only).
            target_document_table: Table the tool operates on (crud-type).
            record_type: Origin — custom, promoted, template, or aia_internal.
        """
        if not sys_id and not name:
            return (
                "❌ Provide at least one of: sys_id or name.\n\n"
                "  get_tool(sys_id='<sys_id>')         — look up by sys_id\n"
                "  get_tool(name='<exact tool name>')  — look up by name"
            )

        client = get_client(instance)

        builder = QueryBuilder()
        if sys_id:
            builder.add_equals("sys_id", sys_id)
        else:
            builder.add_equals("name", name)
        query = builder.build()

        response = client.query_table(
            table_name="sn_aia_tool",
            query=query,
            fields=[
                "sys_id", "name", "description", "type", "active",
                "input_schema", "script", "target_document_table",
                "record_type", "sys_scope", "sys_created_on", "sys_updated_on",
            ],
            limit=10,
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]

        if not results:
            if sys_id:
                return f"No tool found with sys_id: {sys_id}"
            return f"No tool found with name: {name}"

        limit_note = ""
        if not sys_id and len(results) == 10:
            limit_note = "\n\nNOTE: Result limit reached (10 returned). There may be additional matches. Use query_table('sn_aia_tool', 'name=<name>') to paginate."

        if len(results) == 1:
            return _format_record(results[0]) + limit_note

        header = f"Multiple tools matched name '{name}' across scopes ({len(results)} found):\n"
        return header + "\n\n---\n\n".join(_format_record(r) for r in results) + limit_note

    @mcp.tool()
    def create_tool(
        name: str,
        description: str,
        type: str = "script",
        active: str = "true",
        script: str = "",
        input_schema: str = "",
        scope: str = "global",
        flow_action_sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create a new tool in the ServiceNow AI Agent tool catalog (sn_aia_tool).
        Use add_tool_to_agent to wire the created tool to an agent after creation.

        **BEFORE CALLING THIS TOOL:** First call get_agent_details(agent_sys_id) and check
        the Tools section — if the tool is already wired to the agent, no action is required.
        If not yet wired, search for an existing record: query_table("sn_aia_tool", "name=<name>").
        Tool names must be unique per scope — if a match exists, wire it with add_tool_to_agent
        rather than creating a duplicate.

        14 tool types: action, subflow, capability, script, topic, catalog, crud,
        mcp, web_automation, topic_block, rag, deep_research, knowledge_graph, desktop_automation.

        **For crud-type tools — 3 required post-creation steps:**
        After creating a crud tool, the record operation dropdown and inputs will appear
        broken in Agent Builder UI unless you complete these steps via update_record:
        1. Set `script` on sn_aia_tool to the standard CRUD execution function body
           (fetch from an existing working crud tool using get_record or list_agent_tools)
        2. Set `target_document_table` on sn_aia_tool to the table the tool operates on
           (e.g., "sn_aia_tool", "incident", etc.)
        3. After wiring via add_tool_to_agent, move the input_schema value blob out of
           the sn_aia_tool record and into the `inputs` field on the sn_aia_agent_tool_m2m
           record — the UI reads inputs from the m2m record, not the tool record directly.
        These steps are in addition to the standard add_tool_to_agent procedure
        (description, inputs, display_output on the m2m record).

        Use get_table_schema("sn_aia_tool") for valid field names and values.

        Args:
            type: Tool type (default: "script"). See 14 types above.
            active: "true" or "false" (default: "true")
            scope: Accepted for backward compatibility but not forwarded to the write call.
            flow_action_sys_id: (action-type only) sys_id of the sys_hub_action_type_definition
                record to link. Sets target_document and target_document_table automatically.
                Use list_flow_actions / get_flow_action to find the sys_id.
        """
        confirmation_error = require_instance_confirmation(instance, "create tool")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)

        # Pre-flight: check if a tool with this name already exists
        existing_builder = QueryBuilder()
        existing_builder.add_equals("name", name)
        existing_check = client.query_table(
            table_name="sn_aia_tool",
            query=existing_builder.build(),
            fields=["sys_id", "name", "type", "active"],
            limit=1
        )
        if existing_check["success"] and existing_check["result"]:
            existing = existing_check["result"][0]
            return (
                f"A tool named '{name}' already exists (sys_id: {existing['sys_id']}, "
                f"type: {existing.get('type', '?')}, active: {existing.get('active', '?')}). "
                f"Use this sys_id with add_tool_to_agent rather than creating a duplicate."
            )

        data = {"name": name, "description": description}
        if type:
            data["type"] = type
        if active:
            data["active"] = active
        if script:
            data["script"] = script
        if input_schema:
            data["input_schema"] = input_schema

        response = client.glide_write(table="sn_aia_tool", operation="insert", data=data)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]
        sys_id = result.get("sys_id", "unknown") if isinstance(result, dict) else "unknown"

        if flow_action_sys_id and type == "action" and sys_id != "unknown":
            link_response = client.glide_write(
                table="sn_aia_tool",
                operation="update",
                sys_id=sys_id,
                data={
                    "target_document": flow_action_sys_id,
                    "target_document_table": "sys_hub_action_type_definition",
                }
            )
            if not link_response["success"]:
                return (
                    f"Tool '{name}' created (sys_id: {sys_id}) but flow action linking failed: "
                    + format_error(link_response["status_code"], link_response.get("error", ""))
                )
            return f"Tool '{name}' created and linked to flow action.\nsys_id: {sys_id}"

        return f"Tool '{name}' created successfully.\nsys_id: {sys_id}"

    @mcp.tool()
    def update_tool(
        sys_id: str,
        name: str = "",
        description: str = "",
        type: str = "",
        active: str = "",
        script: str = "",
        input_schema: str = "",
        instance: str = None
    ) -> str:
        """
        Update an existing tool in the ServiceNow AI Agent tool catalog (sn_aia_tool).
        Use list_agent_tools to find the sys_id first.
        Use get_table_schema("sn_aia_tool") for valid field names and values.

        Args:
            sys_id: sys_id of the tool to update (required)
            active: "true" or "false"
        """
        confirmation_error = require_instance_confirmation(instance, "update tool")
        if confirmation_error:
            return confirmation_error

        data = {}
        if name:
            data["name"] = name
        if description:
            data["description"] = description
        if type:
            data["type"] = type
        if active:
            data["active"] = active
        if script:
            data["script"] = script
        if input_schema:
            data["input_schema"] = input_schema

        client = get_client(instance)
        response = client.glide_write(table="sn_aia_tool", operation="update", data=data, sys_id=sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        if not input_schema:
            return f"Tool '{sys_id}' updated successfully."

        # Sync input_schema to inputs field on all linked sn_aia_agent_tool_m2m records.
        # The m2m inputs field is the per-agent source of truth; sn_aia_tool.input_schema
        # is a template only (issue #191).
        builder = QueryBuilder()
        builder.add_equals("tool", sys_id)
        m2m_response = client.query_table(
            table_name="sn_aia_agent_tool_m2m",
            query=builder.build(),
            fields=["sys_id"],
            limit=50
        )

        if not m2m_response["success"] or not m2m_response["result"]:
            return f"Tool '{sys_id}' updated successfully."

        synced = 0
        sync_failures = []
        for m2m in m2m_response["result"]:
            m2m_sys_id = m2m.get("sys_id")
            m2m_update = client.glide_write(
                table="sn_aia_agent_tool_m2m",
                operation="update",
                data={"inputs": input_schema},
                sys_id=m2m_sys_id
            )
            if m2m_update["success"]:
                synced += 1
            else:
                sync_failures.append(m2m_sys_id)

        if sync_failures:
            return (
                f"Tool '{sys_id}' updated successfully.\n"
                f"Warning: {synced}/{len(m2m_response['result'])} agent wiring(s) synced — "
                f"{len(sync_failures)} failed: {', '.join(f for f in sync_failures[:5])}"
            )

        return (
            f"Tool '{sys_id}' updated successfully.\n"
            f"{synced} agent wiring(s) synced (inputs field)."
        )

    @mcp.tool()
    def delete_tool(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Delete a tool from the ServiceNow AI Agent tool catalog (sn_aia_tool).
        This action cannot be undone. Use list_agent_tools to find the sys_id first.

        Args:
            sys_id: sys_id of the tool to delete (required)
        """
        confirmation_error = require_instance_confirmation(instance, "delete tool")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        response = client.glide_write(table="sn_aia_tool", operation="delete", data={}, sys_id=sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        return f"Tool '{sys_id}' deleted successfully."
