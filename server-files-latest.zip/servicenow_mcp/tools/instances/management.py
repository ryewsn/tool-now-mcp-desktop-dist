"""Instance Management MCP Tools.

Tools for managing ServiceNow instance configurations (.env file)
from within Claude Desktop. Allows adding, removing, listing, and
switching default instances conversationally.

These tools manage which ServiceNow instances THIS MCP server connects to.
They do NOT create OAuth applications in ServiceNow — for that, use
setup_inbound_oauth or setup_oauth_integration.
"""

import os

from mcp.server.fastmcp import FastMCP
from ...core.instance_manager import (
    add_instance as _add_instance,
    remove_instance as _remove_instance,
    set_default as _set_default,
    get_instances as _get_instances,
    extract_instance_name,
    instance_name_to_url,
    update_claude_desktop_config,
)
from ...config.settings import reload_config, get_config
from ...core.client import get_client, reset_clients
from ...core.query_builder import QueryBuilder


# Path to the .env file (project root)
ENV_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)
    )))),
    ".env"
)

# Path to the project root (for Claude Desktop config)
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)
))))


def _reload():
    """Reload config and reset clients after .env changes."""
    reload_config()
    reset_clients()


def register_tools(mcp: FastMCP):
    """Register instance management tools with the MCP server."""

    @mcp.tool()
    def list_instances() -> str:
        """List all configured ServiceNow instances for this MCP server.

        Shows name, URL, auth type (basic/OAuth), and which is the default.
        The default instance is used when no instance parameter is specified.
        """
        result = _get_instances(ENV_PATH)
        instances = result["instances"]
        default = result["default"]

        if not instances:
            return "No instances configured. Use add_instance to add one."

        output = [f"Configured instances ({len(instances)}):"]
        output.append("")

        for name, inst in instances.items():
            default_tag = " [DEFAULT]" if name == default else ""
            auth = "OAuth" if inst.get("client_id") else "basic auth"
            output.append(f"  {name}{default_tag}")
            output.append(f"    URL: {inst['url']}")
            output.append(f"    Auth: {auth}")
            if inst.get("username"):
                output.append(f"    User: {inst['username']}")
            output.append("")

        return "\n".join(output)

    @mcp.tool()
    def add_instance(
        name: str,
        auth_type: str,
        username: str = "",
        password: str = "",
        client_id: str = "",
        client_secret: str = "",
        set_as_default: bool = False,
        update_claude_desktop: bool = False,
    ) -> str:
        """Add a ServiceNow instance to this MCP server's .env config.

        Writes credentials locally. Does NOT create OAuth applications in ServiceNow
        — for that, use setup_inbound_oauth after adding. The instance is immediately
        usable via the instance parameter after adding.

        **Default assumption — always use basic auth when adding a new instance.**
        Do not ask the user which auth type they want — ask only for their username
        and password. After this tool succeeds, immediately call setup_inbound_oauth
        with instance=<alias>. Do not present OAuth as optional or ask for confirmation;
        it is always the correct next step. Basic auth is needed to bootstrap the OAuth
        application; setup_inbound_oauth makes OAuth the active auth method.

        Exceptions — skip OAuth only when the user explicitly states:
        - "just use basic auth" / "no OAuth" → use auth_type="basic" and stop after add_instance
        - "I already have OAuth credentials" → use auth_type="oauth" with client_id and client_secret

        **Rename / credential-mirror flows:** When mirroring an existing OAuth instance to a
        new alias, add_instance(auth_type="oauth") writes only CLIENT_ID and CLIENT_SECRET.
        If the source entry also has SERVICENOW_USERNAME_* and SERVICENOW_PASSWORD_*
        (set by setup_inbound_oauth's service account creation), manually copy those to the
        new alias in .env after calling this tool:

          SERVICENOW_USERNAME_<NEW_ALIAS_UPPER>=<value from old alias>
          SERVICENOW_PASSWORD_<NEW_ALIAS_UPPER>=<value from old alias>

        Args:
            name: Instance name or URL — "acme", "acme.service-now.com", or full URL.
                  Name is extracted automatically.
            auth_type: "basic" (username/password) or "oauth" (client_id/client_secret).
                       Default to "basic" unless user explicitly has OAuth credentials.
            username: Required when auth_type="basic".
            password: Required when auth_type="basic".
            client_id: Required when auth_type="oauth".
            client_secret: Required when auth_type="oauth".
            set_as_default: Make this the default. First instance added is always default.
            update_claude_desktop: Update Claude Desktop config to include this MCP server.
                                   Only needed on first setup.
        """
        if auth_type not in ("basic", "oauth"):
            return (
                "Invalid auth_type. Use 'basic' (username/password) "
                "or 'oauth' (client_id/client_secret)."
            )

        extracted_name = extract_instance_name(name) if name else ""

        if auth_type == "basic":
            data = {
                "url": instance_name_to_url(extracted_name) if extracted_name else "",
                "username": username,
                "password": password,
                "client_id": "",
                "client_secret": "",
            }
        else:
            data = {
                "url": instance_name_to_url(extracted_name) if extracted_name else "",
                "username": "",
                "password": "",
                "client_id": client_id,
                "client_secret": client_secret,
            }

        result = _add_instance(ENV_PATH, name, data, set_as_default=set_as_default)

        if not result["success"]:
            return result["message"]

        _reload()

        output = [result["message"]]

        count = len(result["instances"])
        output.append(
            f"Total: {count} instance{'s' if count != 1 else ''} "
            f"(default: {result['default']})"
        )
        output.append("")
        output.append(
            f"This instance is now available. Specify instance=\"{extracted_name}\" "
            "in tool calls, or omit to use the default."
        )

        if update_claude_desktop:
            if update_claude_desktop_config(PROJECT_DIR):
                output.append("")
                output.append(
                    "Claude Desktop config updated. "
                    "You can start using MCP tools with the new instance right away — no restart needed."
                )
            else:
                output.append("")
                output.append(
                    "Could not update Claude Desktop config. "
                    "See README.md for manual setup."
                )

        return "\n".join(output)

    @mcp.tool()
    def remove_instance(name: str, cleanup: bool = True) -> str:
        """Remove a ServiceNow instance from this MCP server's .env config.

        When cleanup=True (default) and the instance was configured with OAuth, attempts
        to delete the associated oauth_entity record from ServiceNow before removing the
        local config. Deletion failure is non-fatal — the local config is always removed.
        Does NOT touch the service account.

        If the removed instance was the default, the next available becomes default.
        Pass cleanup=False to skip the ServiceNow deletion and remove only the local entry.
        """
        instances_data = _get_instances(ENV_PATH)
        instances = instances_data["instances"]

        if name not in instances:
            available = ", ".join(instances.keys()) if instances else "none"
            return f"Instance '{name}' not found. Available: {available}."

        cleanup_notes = []

        if cleanup:
            client_id = instances[name].get("client_id", "")
            if client_id:
                try:
                    client = get_client(name)
                    qb = QueryBuilder()
                    qb.add_equals("client_id", client_id)
                    query_resp = client.query_table(
                        table_name="oauth_entity",
                        query=qb.build(),
                        fields=["sys_id"],
                        limit=1,
                    )
                    if not query_resp["success"]:
                        cleanup_notes.append(
                            f"⚠️  Could not query oauth_entity ({query_resp.get('status_code')}): "
                            f"{query_resp.get('error', '')} — local config will still be removed."
                        )
                    elif not query_resp["result"]:
                        cleanup_notes.append(
                            "ℹ️  OAuth application not found in ServiceNow (already removed or never created)."
                        )
                    else:
                        oauth_sys_id = query_resp["result"][0]["sys_id"]
                        del_resp = client.delete_record("oauth_entity", oauth_sys_id)
                        if del_resp["success"]:
                            cleanup_notes.append("✓ OAuth application deleted from ServiceNow.")
                        else:
                            cleanup_notes.append(
                                f"⚠️  Could not delete OAuth application "
                                f"({del_resp.get('status_code')}): {del_resp.get('error', '')} "
                                f"— local config will still be removed."
                            )
                except Exception as e:
                    cleanup_notes.append(
                        f"⚠️  OAuth cleanup error: {e} — local config will still be removed."
                    )

        result = _remove_instance(ENV_PATH, name)

        if not result["success"]:
            return result["message"]

        _reload()

        output = [result["message"]]

        if cleanup_notes:
            output.extend(cleanup_notes)

        if result["instances"]:
            count = len(result["instances"])
            output.append(
                f"{count} instance{'s' if count != 1 else ''} remaining "
                f"(default: {result['default']})."
            )
        else:
            output.append("No instances remaining. Use add_instance to add one.")

        return "\n".join(output)

    @mcp.tool()
    def set_default_instance(name: str) -> str:
        """Change which ServiceNow instance is used by default when no instance is specified."""
        result = _set_default(ENV_PATH, name)

        if not result["success"]:
            return result["message"]

        _reload()

        return result["message"]

    @mcp.tool()
    def get_connection_info(instance: str = None) -> str:
        """Return connection identity for this MCP server installation.

        Returns instance URL, OAuth client_id, and install hostname. Works offline
        — reads local config only, no network calls. Use the client_id to find the
        paired oauth_entity record in ServiceNow (query oauth_entity where
        client_id = <value from this tool>).

        NOTE: client_secret is intentionally not returned by this tool. For credential
        migration (e.g. rename flows), read the .env file directly:
          grep -i "<ALIAS_UPPERCASED>" ~/Applications/ServiceNow\ MCP/.env
        The relevant keys are SERVICENOW_CLIENT_ID_<ALIAS> and
        SERVICENOW_CLIENT_SECRET_<ALIAS>.
        """
        try:
            cfg = get_config().get_instance(instance)
        except ValueError as e:
            return str(e)

        hostname = cfg.install_hostname or "unknown"
        client_id_display = cfg.client_id or "not set (basic auth only)"

        lines = [
            "Connection info for this installation:",
            f"  Instance URL:      {cfg.instance}",
            f"  Client ID:         {client_id_display}",
            f"  Install hostname:  {hostname}",
            f"  Alias:             {cfg.alias}",
        ]
        if cfg.client_id:
            lines += [
                "",
                "To identify the paired OAuth record in ServiceNow:",
                f"  Query oauth_entity where client_id = {cfg.client_id}",
            ]
        return "\n".join(lines)

    @mcp.tool()
    def debug_server_process() -> str:
        """Debug tool to verify the MCP server process is persistent and reload_config() works.

        Returns the server process PID and current config state. Call this before and after
        modifying .env (via add_instance / remove_instance) to confirm:
        1. PID is the same across calls — the server process is persistent, not restarted
        2. Config object ID changes after reload — the singleton was reset and rebuilt
        3. Instance list reflects the updated .env without restarting Claude Desktop
        """
        import os as _os
        from ...config import settings as _settings

        cfg = get_config()
        instances = [
            f"  {alias}: {inst.instance} ({'OAuth' if inst.uses_oauth else 'basic auth'})"
            + (" (default)" if alias == cfg.default_instance else "")
            for alias, inst in cfg.instances.items()
        ]

        lines = [
            "=== MCP Server Process Debug ===",
            f"PID:            {_os.getpid()}",
            f"Config object:  id={id(_settings._config)}",
            f"Instances ({len(cfg.instances)}):",
        ] + instances

        return "\n".join(lines)
