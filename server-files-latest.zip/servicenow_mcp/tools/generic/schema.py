"""Table Schema Lookup Tool

Queries ServiceNow's sys_dictionary and sys_choice tables to return
field definitions and valid enum values for any table.
"""

from typing import Dict, List, Optional
from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, ServiceNowClient
from ...core.formatters import format_error

# Module-level cache, keyed by "{instance_alias}:{table_name}"
_schema_cache: Dict[str, str] = {}


def _resolve_table_hierarchy(table: str, client: ServiceNowClient) -> List[str]:
    """
    Walk the parent chain via sys_db_object to find all tables in the hierarchy.

    Args:
        table: Starting table name (e.g., "incident")
        client: ServiceNowClient instance

    Returns:
        List of table names from child to root (e.g., ["incident", "task"]).
        Empty list if the table is not found.
    """
    # First, look up the table by name
    response = client.query_table(
        table_name="sys_db_object",
        query=f"name={table}",
        fields=["name", "super_class", "sys_id"],
        limit=1,
    )

    if not response["success"] or not response["result"]:
        return []

    tables = []
    record = response["result"][0]
    tables.append(record["name"])

    # Walk up the parent chain by following super_class references
    for _ in range(10):  # Safety limit
        super_class = record.get("super_class", "")

        # super_class can be a string or a dict with "value" key (reference field)
        if isinstance(super_class, dict):
            super_class_id = super_class.get("value", "")
        else:
            super_class_id = super_class

        if not super_class_id:
            break

        # Query parent by sys_id
        response = client.query_table(
            table_name="sys_db_object",
            query=f"sys_id={super_class_id}",
            fields=["name", "super_class", "sys_id"],
            limit=1,
        )

        if not response["success"] or not response["result"]:
            break

        record = response["result"][0]
        parent_name = record.get("name", "")
        if not parent_name:
            break

        tables.append(parent_name)

    return tables


def _fetch_fields(tables: List[str], client: ServiceNowClient) -> Dict[str, dict]:
    """
    Fetch field definitions from sys_dictionary for the given tables.

    Args:
        tables: List of table names (e.g., ["incident", "task"])
        client: ServiceNowClient instance

    Returns:
        Dict keyed by field element name, each value is a dict with:
        - type: field type string (e.g., "string", "integer", "reference")
        - label: display label
        - mandatory: bool
        - read_only: bool
        - reference_table: str (only for reference fields)
    """
    if not tables:
        return {}

    # Build IN clause for all tables in hierarchy
    tables_in = ",".join(tables)
    query = f"nameIN{tables_in}^internal_type!=collection^active=true"

    response = client.query_table(
        table_name="sys_dictionary",
        query=query,
        fields=[
            "element", "internal_type", "column_label",
            "mandatory", "read_only", "reference", "name",
        ],
        limit=500,
    )

    if not response["success"] or not response["result"]:
        return {}

    fields = {}
    for record in response["result"]:
        element = record.get("element", "")
        if not element:
            continue  # Skip table-level entries (element is empty)

        # Parse internal_type — can be dict with display_value or plain string
        internal_type = record.get("internal_type", "")
        if isinstance(internal_type, dict):
            field_type = internal_type.get("display_value", str(internal_type))
        else:
            field_type = str(internal_type)

        # Parse reference table — can be dict with display_value or plain string
        reference = record.get("reference", "")
        if isinstance(reference, dict):
            reference_table = reference.get("display_value", "")
        else:
            reference_table = str(reference) if reference else ""

        fields[element] = {
            "type": field_type,
            "label": record.get("column_label", element),
            "mandatory": record.get("mandatory", "false") == "true",
            "read_only": record.get("read_only", "false") == "true",
            "reference_table": reference_table,
        }

    return fields


def _fetch_choices(tables: List[str], client: ServiceNowClient) -> Dict[str, List[dict]]:
    """
    Fetch choice values from sys_choice for the given tables.

    Args:
        tables: List of table names (e.g., ["incident", "task"])
        client: ServiceNowClient instance

    Returns:
        Dict keyed by field element name, each value is a list of
        {"value": str, "label": str} dicts sorted by value.
    """
    if not tables:
        return {}

    tables_in = ",".join(tables)
    query = f"nameIN{tables_in}^inactive=false^ORDERBYelement^ORDERBYsequence"

    response = client.query_table(
        table_name="sys_choice",
        query=query,
        fields=["element", "value", "label", "name"],
        limit=1000,
    )

    if not response["success"] or not response["result"]:
        return {}

    choices: Dict[str, List[dict]] = {}
    for record in response["result"]:
        element = record.get("element", "")
        if not element:
            continue

        if element not in choices:
            choices[element] = []

        choices[element].append({
            "value": record.get("value", ""),
            "label": record.get("label", ""),
        })

    return choices

def _format_schema(
    table: str,
    hierarchy: List[str],
    fields: Dict[str, dict],
    choices: Dict[str, List[dict]],
) -> str:
    """
    Format schema information as human-readable text.

    Args:
        table: Primary table name
        hierarchy: Full table hierarchy list (child first)
        fields: Field definitions from _fetch_fields
        choices: Choice values from _fetch_choices

    Returns:
        Formatted string for Claude to read
    """
    lines = []

    # Header
    if len(hierarchy) > 1:
        parents = ", ".join(hierarchy[1:])
        lines.append(f"Table: {table} (extends {parents})")
    else:
        lines.append(f"Table: {table}")

    lines.append(f"Total fields: {len(fields)}")
    lines.append("")

    # Fields in alphabetical order
    for field_name in sorted(fields.keys()):
        field = fields[field_name]
        field_type = field["type"]

        # Build type string
        if field_type == "reference" and field.get("reference_table"):
            type_str = f"reference -> {field['reference_table']}"
        else:
            type_str = field_type

        # Build tags
        tags = []
        if field.get("mandatory"):
            tags.append("Mandatory")
        if field.get("read_only"):
            tags.append("Read-only")

        # Build choice values string
        if field_name in choices:
            choice_strs = [f"{c['value']}={c['label']}" for c in choices[field_name]]
            tags.append(f"Choice values: {', '.join(choice_strs)}")

        # Assemble line
        tag_str = f" [{'] ['.join(tags)}]" if tags else ""
        lines.append(f"{field_name} ({type_str}) - {field['label']}{tag_str}")

    return "\n".join(lines)


def _get_table_schema_impl(table: str, instance: str = None) -> str:
    """
    Implementation of get_table_schema tool logic.

    Separated from the MCP tool registration to allow direct testing.

    Args:
        table: Table name (e.g., "incident")
        instance: Optional instance alias

    Returns:
        Formatted schema string or error message
    """
    client = get_client(instance)
    cache_key = f"{client.config.alias}:{table}"

    # Check cache
    if cache_key in _schema_cache:
        return _schema_cache[cache_key]

    # Resolve table hierarchy
    hierarchy = _resolve_table_hierarchy(table, client)
    if not hierarchy:
        return f"Table '{table}' not found in sys_db_object. Check the table name."

    # Fetch field definitions
    fields = _fetch_fields(hierarchy, client)

    # Fetch choice values
    choices = _fetch_choices(hierarchy, client)

    if not fields:
        return f"No fields found for table '{table}'. The table may be empty or restricted."

    # Format output
    result = _format_schema(table, hierarchy, fields, choices)

    # Cache the result
    _schema_cache[cache_key] = result

    return result


def register_tools(mcp: FastMCP):
    """Register schema tools with the MCP server."""

    @mcp.tool()
    def get_table_schema(table: str, instance: str = None) -> str:
        """
        Return field names, types, and valid choice values for any ServiceNow table
        (sources: sys_dictionary, sys_choice, sys_db_object for hierarchy). Use this
        before querying unfamiliar tables — ServiceNow silently ignores unknown field
        names, so verify field names and enum values here first.

        Use when:
        - You don't know the field names for a table
        - You need valid values for a choice/enum field (state, priority, etc.)
        - A query returned empty results and you suspect a wrong field name

        Key fields in results:
            field_name (type) — label [Choice values: val=Label, ...] [Mandatory] [Read-only]
            reference fields show the target table (e.g., reference -> sys_user)

        Args:
            table: Table name (e.g., "incident", "syslog", "oauth_entity")
        """
        return _get_table_schema_impl(table, instance)
