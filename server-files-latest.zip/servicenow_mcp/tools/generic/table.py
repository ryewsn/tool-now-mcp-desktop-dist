"""Generic Table Query and Update Tools"""

import json
import re

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error
from ...core.query_builder import QueryBuilder

_SYS_ID_PATTERN = re.compile(r'^[0-9a-fA-F]{32}$')

# Fields known to be silently dropped by ServiceNow ACL/scope policy on Table API writes.
# When any of these fields appear in an update_record call, a post-write re-fetch is triggered
# to detect silent rejection and surface a warning.
SILENT_DROP_FIELDS = frozenset({"sys_scope", "sys_package"})

BLOCKED_WRITES: dict[tuple[str, str], str] = {
    ("sn_aia_version", "instructions"): (
        "Use update_agent_instructions(agent_sys_id=..., instructions=...) instead. "
        "update_record on sn_aia_version.instructions skips the parent sync step, "
        "leaving the agent in a broken draft state in AI Agent Studio."
    ),
    ("sn_aia_tool", "action"): (
        "sn_aia_tool has no 'action' field. Use manage_tool(flow_action_sys_id=...) "
        "to link a Flow Designer action at creation time, which sets target_document "
        "and target_document_table automatically."
    ),
}

def register_tools(mcp: FastMCP):
    """Register generic table query tools with the MCP server."""

    @mcp.tool()
    def query_table(
        table: str,
        query: str = "",
        fields: str = "",
        limit: int = 20,
        display_value: str = None,
        instance: str = None
    ) -> str:
        """
        Generic fallback to query any ServiceNow table. Prefer specialized tools when available
        — they have optimized queries and better output formatting.

        Use when: no specialized tool exists for the table, or exploring unfamiliar tables.

        IMPORTANT: Use get_table_schema(table) first on unfamiliar tables — ServiceNow silently
        ignores unknown field names and returns empty results instead of an error.

        Args:
            fields: Comma-separated fields to return. If empty, returns sys_id and sys_created_on only.
            display_value: "true" = display values (e.g., "John Smith"), "false" = sys_ids (default),
                "all" = both (adds dv_ prefixed fields).
        """
        if not table:
            return "Please provide a table name to query."

        if not fields:
            fields = "sys_id,sys_created_on,sys_updated_on"

        # Build full query with ORDER BY
        full_query = query + "^ORDERBYDESCsys_created_on" if query else "ORDERBYDESCsys_created_on"

        # Execute query
        client = get_client(instance)
        # Convert fields string to list
        fields_list = [f.strip() for f in fields.split(",")]
        response = client.query_table(
            table_name=table,
            query=full_query,
            fields=fields_list,
            limit=limit,
            display_value=display_value
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return f"No records found in {table} matching your criteria."

        # Format output
        output = []
        for entry in results:
            lines = [f"{key}: {value}" for key, value in entry.items() if value]
            output.append("\n".join(lines))

        return "\n\n---\n\n".join(output)

    @mcp.tool()
    def update_record(
        table: str,
        sys_id: str,
        fields: str,
        instance: str = None
    ) -> str:
        """
        Update fields on an existing ServiceNow record by sys_id.

        Use when: correcting or enriching any record — renaming an oauth_entity, updating an
        incident field, patching a configuration value.

        IMPORTANT: Use get_table_schema(table) to verify field names first. ServiceNow silently
        ignores unknown field names — the update appears to succeed but the field will not change.

        Args:
            fields: JSON object of field names and new values
                    (e.g., '{"name": "My App - hostname", "active": "true"}')
        """
        if not table:
            return "Please provide a table name."
        if not sys_id:
            return "Please provide the sys_id of the record to update."
        if not fields:
            return "Please provide fields as a JSON object (e.g., '{\"name\": \"new value\"}')."

        confirmation_error = require_instance_confirmation(instance, f"update {table} record")
        if confirmation_error:
            return confirmation_error

        try:
            data = json.loads(fields)
        except json.JSONDecodeError as e:
            return f"Invalid JSON in fields parameter: {e}\nExpected format: {{\"field_name\": \"value\"}}"

        if not isinstance(data, dict) or not data:
            return "fields must be a non-empty JSON object mapping field names to values."

        blocked = {k: BLOCKED_WRITES[(table, k)] for k in data if (table, k) in BLOCKED_WRITES}
        if blocked:
            lines = [f"⛔ update_record cannot write {table}.{field} directly.\n\n{msg}"
                     for field, msg in blocked.items()]
            return "\n\n".join(lines)

        client = get_client(instance)
        response = client.update_record(
            table_name=table,
            sys_id=sys_id,
            data=data
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        updated = response.get("result", {})
        changed = "\n".join(f"  {k}: {updated.get(k, '(not returned)')}" for k in data)

        # Post-write verification for known silent-drop fields
        silent_candidates = {k: v for k, v in data.items() if k in SILENT_DROP_FIELDS}
        if silent_candidates:
            refetch = client.query_table(
                table_name=table,
                query=f"sys_id={sys_id}",
                fields=list(silent_candidates.keys()),
                limit=1,
                display_value="true"
            )
            if refetch["success"] and refetch["result"]:
                actual = refetch["result"][0]
                mismatches = {
                    k: {"requested": str(v), "actual": str(actual.get(k, ""))}
                    for k, v in silent_candidates.items()
                    if str(actual.get(k, "")).lower() != str(v).lower()
                }
                if mismatches:
                    warning_lines = ["Silent field rejection detected:"]
                    for field, vals in mismatches.items():
                        warning_lines.append(
                            f"  {field}: requested '{vals['requested']}', actual stored '{vals['actual']}'"
                        )
                    warning_lines.extend([
                        "  ServiceNow silently dropped this write. Likely cause: session scope differs from the record's scope.",
                        "  Use execute_script for cross-scope updates."
                    ])
                    return (
                        f"⚠️ Updated {table} record {sys_id} — some fields silently rejected\n\n"
                        f"Fields set:\n{changed}\n\n"
                        + "\n".join(warning_lines)
                    )

        return f"✅ Updated {table} record {sys_id}\n\nFields set:\n{changed}"

    @mcp.tool()
    def bulk_update_records(
        table: str,
        query: str,
        fields: str,
        limit: int = 200,
        instance: str = None
    ) -> str:
        """
        Update fields on all ServiceNow records matching a query — batch alternative to
        calling update_record N times.

        Use when: deactivating findings by run_id, resetting a field across a record set,
        bulk flagging records after analysis.

        IMPORTANT: Updates ALL records matching the query. Use a specific query to avoid
        unintended changes. Use get_table_schema(table) to verify field names — ServiceNow
        silently ignores unknown fields.

        Args:
            query: Encoded query to select records (e.g., "active=true^state=1"). Must not be empty.
            fields: JSON object of field names and values to apply to all matching records
                    (e.g., '{"active": "false", "state": "3"}')
            limit: Default 200; capped for safety — use encoded_query to scope updates precisely.
        """
        if not table:
            return "Please provide a table name."
        if not query:
            return "Please provide a query to select records. An empty query would update all records in the table."
        if not fields:
            return "Please provide fields as a JSON object (e.g., '{\"active\": \"false\"}')."

        confirmation_error = require_instance_confirmation(instance, f"bulk update {table} records")
        if confirmation_error:
            return confirmation_error

        try:
            data = json.loads(fields)
        except json.JSONDecodeError as e:
            return f"Invalid JSON in fields parameter: {e}"

        if not isinstance(data, dict) or not data:
            return "fields must be a non-empty JSON object."

        blocked = {k: BLOCKED_WRITES[(table, k)] for k in data if (table, k) in BLOCKED_WRITES}
        if blocked:
            lines = [f"⛔ bulk_update_records cannot write {table}.{field} directly.\n\n{msg}"
                     for field, msg in blocked.items()]
            return "\n\n".join(lines)

        client = get_client(instance)

        # Fetch matching records
        fetch_response = client.query_table(
            table_name=table,
            query=query,
            fields=["sys_id"],
            limit=limit
        )
        if not fetch_response["success"]:
            return format_error(fetch_response["status_code"], fetch_response.get("error", "Unknown error"))

        records = fetch_response["result"]
        if not records:
            return f"No records found in {table} matching: {query}"

        # Update each record
        succeeded = 0
        failures = []
        for record in records:
            sys_id = record.get("sys_id")
            response = client.update_record(table_name=table, sys_id=sys_id, data=data)
            if response["success"]:
                succeeded += 1
            else:
                failures.append(f"{sys_id}: {response.get('error', 'unknown error')}")

        result = f"Bulk updated {table}: {succeeded}/{len(records)} records updated."
        if len(records) == limit:
            result += f"\n⚠️ Result limit reached ({limit}). There may be more matching records."
        if failures:
            result += f"\n\nFailed ({len(failures)}):\n" + "\n".join(f"  {f}" for f in failures[:10])
            if len(failures) > 10:
                result += f"\n  ... and {len(failures) - 10} more"
        return result

    @mcp.tool()
    def create_record(
        table: str,
        fields: str,
        instance: str = None
    ) -> str:
        """
        Create a new record on any ServiceNow table. Use for tables without a dedicated
        creation tool — e.g., sys_ui_action, scheduled jobs, configuration records.

        **Do NOT use this tool to create custom tables.** Use create_custom_table
        instead — it handles sys_db_object, sys_dictionary, and sys_choice records
        in a single call with correct internal_type naming and scope handling.

        **Tables that require execute_script instead of this tool:**
        - `sys_security_acl`, `sys_security_acl_role` — ACL records extend sys_metadata and return 403 via REST API; use GlideRecord.insert() via execute_script
        - Any table extending sys_metadata (e.g., `sn_aia_*`, `sys_flow_*`, `sys_script*`) — REST API silently drops read-only fields and bypasses Business Rules; use execute_script with GlideRecord for reliable writes on these tables

        IMPORTANT: Use get_table_schema(table) on unfamiliar tables to discover valid field names,
        required fields, and choice values. ServiceNow silently ignores unknown field names —
        the record is created but those fields will be empty.

        Args:
            fields: JSON object of field names and values
                    (e.g., '{"name": "My Action", "table": "incident", "active": "true"}')
        """
        if not table:
            return "Please provide a table name."
        if not fields:
            return "Please provide fields as a JSON object (e.g., '{\"name\": \"value\"}')."

        confirmation_error = require_instance_confirmation(instance, f"create {table} record")
        if confirmation_error:
            return confirmation_error

        try:
            data = json.loads(fields)
        except json.JSONDecodeError as e:
            return f"Invalid JSON in fields parameter: {e}\nExpected format: {{\"field_name\": \"value\"}}"

        if not isinstance(data, dict) or not data:
            return "fields must be a non-empty JSON object mapping field names to values."

        client = get_client(instance)
        response = client.create_record(
            table_name=table,
            data=data
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        created = response.get("result", {})
        sys_id = created.get("sys_id", "(unknown)")
        field_lines = "\n".join(f"  {k}: {created.get(k, '(not returned)')}" for k in data)
        result_msg = f"✅ Created {table} record {sys_id}\n\nFields set:\n{field_lines}"

        warnings = response.get("warnings", [])
        if warnings:
            result_msg += "\n\n⚠️ Warnings:\n" + "\n".join(f"  - {w}" for w in warnings)

        return result_msg

    @mcp.tool()
    def get_record(
        sys_id: str,
        table: str = None,
        fields: str = None,
        display_value: str = None,
        instance: str = None
    ) -> str:
        """
        Fetch a single ServiceNow record by sys_id. Prefer over query_table when you
        have a sys_id and want full record detail.

        Use when: you see a sys_id in a log or execution result and need the full record —
        table is resolved automatically via sys_metadata or sys_audit if not provided.

        Args:
            table: If omitted, resolved automatically from sys_metadata or sys_audit.
            display_value: "true" = display values (e.g., "John Smith"), "false" = sys_ids (default),
                "all" = both (adds dv_ prefixed fields).
        """
        # Validate sys_id format
        if not _SYS_ID_PATTERN.match(sys_id):
            return (
                "Invalid sys_id format. Expected a 32-character hex string "
                "(e.g., '6816f79cc0a8016401c5a33be04be441')."
            )

        client = get_client(instance)

        # Resolve table if not provided
        resolved = False
        if not table:
            table = _resolve_table(client, sys_id)
            if not table:
                return (
                    "Could not determine table for this sys_id. "
                    "Please provide the table parameter."
                )
            resolved = True

        # Fetch the record
        fields_list = [f.strip() for f in fields.split(",")] if fields else None
        response = client.get_record(
            table_name=table,
            sys_id=sys_id,
            fields=fields_list,
            display_value=display_value
        )

        if not response["success"]:
            if resolved and response["status_code"] == 404:
                return (
                    f"Table resolved to '{table}' but the record was not found "
                    "— it may have been deleted."
                )
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        record = response["result"]
        if not record:
            return f"No record found in {table} with sys_id {sys_id}."

        # Format output
        lines = [f"Table: {table}", ""]
        lines.extend(f"{key}: {value}" for key, value in record.items() if value)
        return "\n".join(lines)

    @mcp.tool()
    def get_journal_entries(
        record_sys_id: str,
        field: str = "work_notes",
        limit: int = 5,
        instance: str = None
    ) -> str:
        """
        Get work notes or comments for a ServiceNow record (sys_journal_field).

        Use when: verifying an AI Agent posted a work note, or reviewing comment history
        on any task record (incident, change, etc.).

        Args:
            field: "work_notes" (default), "comments", or "" (returns both).
            limit: Default 5.

        Key fields: sys_created_on, sys_created_by, value (entry text),
            element ("work_notes"/"comments" — useful when field="" returns both).
        """
        if not re.match(r'^[0-9a-f]{32}$', record_sys_id):
            return f"Invalid sys_id format: '{record_sys_id}'. ServiceNow sys_ids are 32 lowercase hex characters."

        if field not in ("work_notes", "comments", ""):
            return "field must be 'work_notes', 'comments', or '' (returns both)."

        builder = QueryBuilder()
        builder.add_equals("element_id", record_sys_id)
        if field:
            builder.add_equals("element", field)
        query = builder.add_order_by("sys_created_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_journal_field",
            query=query,
            fields=["sys_created_on", "sys_created_by", "value", "element", "name"],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            field_label = field if field else "all fields"
            return f"No journal entries found for {record_sys_id} ({field_label})."

        field_label = field if field else "work_notes + comments"
        header = f"Journal entries for {record_sys_id} ({field_label}, {len(results)} shown):\n"

        output = []
        for entry in results:
            element_tag = f" [{entry.get('element', '')}]" if not field else ""
            output.append(
                f"[{entry.get('sys_created_on', 'N/A')}] {entry.get('sys_created_by', 'N/A')}{element_tag}\n"
                f"  {entry.get('value', '').strip()}"
            )

        return header + "\n\n".join(output)

    @mcp.tool()
    def get_table_acls(
        table: str,
        operation: str = "",
        include_field_acls: bool = False,
        instance: str = None
    ) -> str:
        """
        Return active ACLs for a table with role names already resolved — replaces the manual
        sys_security_acl → sys_security_acl_role → sys_user_role chain.

        Use when: diagnosing why a user was blocked from a table or field operation.

        Args:
            operation: "read", "write", "create", "delete", "execute", or "" (all). Default "".
            include_field_acls: When True, also returns field-level ACLs (e.g. "incident.caller_id").
                Default False (table-level only).

        Key fields: operation, condition (empty = roles-only), admin_overrides,
            roles (empty = condition-only ACL).
        """
        if not table:
            return "table is required."

        valid_operations = ("read", "write", "create", "delete", "execute", "")
        if operation not in valid_operations:
            return "operation must be one of: read, write, create, delete, execute, or '' (all)."

        if include_field_acls:
            name_filter = f"name={table}^ORnameSTARTSWITH{table}."
        else:
            name_filter = f"name={table}"

        parts = [name_filter, "type=record", "active=true"]
        if operation:
            parts.append(f"operation={operation}")
        query = "^".join(parts)

        client = get_client(instance)
        acl_response = client.query_table(
            table_name="sys_security_acl",
            query=query,
            fields=["sys_id", "name", "operation", "active", "condition", "admin_overrides"],
            limit=50
        )

        if not acl_response["success"]:
            return format_error(acl_response["status_code"], acl_response.get("error", "Unknown error"))

        acls = acl_response["result"]
        if not acls:
            op_label = f" (operation: {operation})" if operation else ""
            return f"No active ACLs found for table '{table}'{op_label}."

        acl_sys_ids = [a["sys_id"] for a in acls]
        role_response = client.query_table(
            table_name="sys_security_acl_role",
            query=f"sys_security_aclIN{','.join(acl_sys_ids)}",
            fields=["sys_security_acl", "sys_user_role"],
            limit=200,
            display_value="true"
        )

        roles_by_acl: dict = {sid: [] for sid in acl_sys_ids}
        if role_response["success"]:
            for r in role_response["result"]:
                acl_ref = r.get("sys_security_acl", "")
                role_name = r.get("sys_user_role", "")
                if acl_ref in roles_by_acl and role_name:
                    roles_by_acl[acl_ref].append(role_name)

        op_label = f", operation: {operation}" if operation else ""
        header = f"ACLs for table: {table}{op_label} ({len(acls)} found)\n"
        blocks = []
        for acl in acls:
            sid = acl["sys_id"]
            roles = roles_by_acl.get(sid, [])
            condition = acl.get("condition", "").strip()
            admin_ov = acl.get("admin_overrides", "false")
            blocks.append(
                f"{acl.get('name', 'N/A')} [{acl.get('operation', 'N/A')}]\n"
                f"  Active:          {acl.get('active', 'N/A')}\n"
                f"  Admin overrides: {admin_ov}\n"
                f"  Condition:       {condition if condition else '(none)'}\n"
                f"  Roles:           {', '.join(roles) if roles else '(none — condition-only ACL)'}"
            )

        return header + "\n\n".join(blocks)

    @mcp.tool()
    def check_user_role(
        user: str,
        role_name: str = "",
        instance: str = None
    ) -> str:
        """
        Check whether a user has a specific role, or list all their active roles.
        Resolves usernames to sys_ids automatically and separates direct from inherited roles.

        Use when: diagnosing access issues, verifying a user has a required role.

        Args:
            user: Username (e.g. "john.smith") or 32-char hex sys_id.
            role_name: Role to check (e.g. "itil", "admin"). Leave empty to list all roles.

        Key fields: inherited (false = direct, true = via group). Only active assignments returned.
        """
        if not user:
            return "user is required."

        client = get_client(instance)
        is_sys_id = bool(re.match(r'^[0-9a-f]{32}$', user))

        user_sys_id = user
        user_display = user

        if not is_sys_id:
            user_response = client.query_table(
                table_name="sys_user",
                query=f"user_name={user}",
                fields=["sys_id", "user_name", "name"],
                limit=1
            )
            if not user_response["success"]:
                return format_error(user_response["status_code"], user_response.get("error", "Unknown error"))
            user_results = user_response["result"]
            if not user_results:
                return f"User not found with username: {user}"
            user_sys_id = user_results[0]["sys_id"]
            user_display = user_results[0].get("user_name", user)

        all_roles_query = f"user={user_sys_id}^state=active"

        if role_name:
            check_response = client.query_table(
                table_name="sys_user_has_role",
                query=f"{all_roles_query}^role.name={role_name}",
                fields=["sys_id", "role", "inherited", "state"],
                limit=1,
                display_value="true"
            )
            if not check_response["success"]:
                return format_error(check_response["status_code"], check_response.get("error", "Unknown error"))
            check_result = check_response["result"]
        else:
            check_result = None

        all_response = client.query_table(
            table_name="sys_user_has_role",
            query=all_roles_query,
            fields=["sys_id", "role", "inherited", "state"],
            limit=200,
            display_value="true"
        )

        if not all_response["success"]:
            return format_error(all_response["status_code"], all_response.get("error", "Unknown error"))

        assignments = all_response["result"]

        lines = [f"User: {user_display} (sys_id: {user_sys_id})"]

        if role_name:
            if not check_result:
                lines.append(f"Role check: {role_name}")
                lines.append(f"  Result: ✗ Does not have role")
            else:
                a = check_result[0]
                how = "inherited via group" if a.get("inherited") == "true" else "directly assigned"
                lines.append(f"Role check: {role_name}")
                lines.append(f"  Result: ✓ HAS ROLE ({how})")
        else:
            if not assignments:
                lines.append("No active roles found.")
                return "\n".join(lines)

        direct = [a.get("role", "?") for a in assignments if a.get("inherited") != "true"]
        inherited = [a.get("role", "?") for a in assignments if a.get("inherited") == "true"]

        lines.append("")
        if role_name:
            lines.append(f"All active roles ({len(direct) + len(inherited)} total):")
        else:
            lines.append(f"Active roles ({len(direct) + len(inherited)} total):")

        if direct:
            lines.append(f"  Direct ({len(direct)}):    {', '.join(direct)}")
        else:
            lines.append("  Direct:     (none)")
        if inherited:
            lines.append(f"  Inherited ({len(inherited)}): {', '.join(inherited)}")
        else:
            lines.append("  Inherited:  (none)")

        return "\n".join(lines)

    @mcp.tool()
    def query_aggregate(
        table: str,
        query: str = "",
        group_by: str = "",
        aggregate: str = "COUNT",
        aggregate_field: str = "",
        display_value: str = None,
        instance: str = None
    ) -> str:
        """
        Run aggregate queries (COUNT, SUM, AVG, MIN, MAX) via the Stats API. Returns
        server-side aggregations without fetching records — far more efficient than
        query_table for analytical questions.

        Use when: "How many P1 incidents per group?", "Average resolution time this month?",
        "Total reassignment count by category?"

        Use get_table_schema(table) to discover valid field names for group_by and aggregate_field.

        Args:
            group_by: Comma-separated field(s) (e.g., "assignment_group", "priority,state").
            aggregate: COUNT (default), SUM, AVG, MIN, MAX.
            aggregate_field: Required for SUM/AVG/MIN/MAX (e.g., "reassignment_count").
            display_value: "true" = display values, "false" = sys_ids (default), "all" = both.
        """
        if not table:
            return "Please provide a table name to aggregate."

        agg = aggregate.upper()
        if agg in ("SUM", "AVG", "MIN", "MAX") and not aggregate_field:
            return f"{agg} requires an aggregate_field parameter (e.g., 'reassignment_count')."

        client = get_client(instance)
        response = client.query_stats(
            table_name=table,
            query=query,
            aggregate=agg,
            aggregate_field=aggregate_field,
            group_by=group_by,
            display_value=display_value
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        result = response["result"]

        # Ungrouped: result is {"stats": {"count": "42"}} or {"stats": {"avg": {"field": "3.5"}}}
        if isinstance(result, dict) and "stats" in result:
            return _format_stats(result["stats"], agg, aggregate_field, table)

        # Grouped: result is a list of {"groupby_fields": [...], "stats": {...}}
        if isinstance(result, list):
            if not result:
                return f"No results for {agg} on {table}."
            output = []
            for group in result:
                group_labels = []
                for gf in group.get("groupby_fields", []):
                    field = gf.get("field", "")
                    value = gf.get("value", "(empty)")
                    group_labels.append(f"{field}: {value}")
                label = ", ".join(group_labels) if group_labels else "(ungrouped)"
                stat_value = _extract_stat_value(group.get("stats", {}), agg, aggregate_field)
                output.append(f"{label} → {agg}: {stat_value}")
            return f"{agg} on {table}" + (f" (grouped by {group_by})" if group_by else "") + "\n\n" + "\n".join(output)

        return f"Unexpected response format from Stats API for {table}."


def _format_stats(stats: dict, agg: str, aggregate_field: str, table: str) -> str:
    """Format ungrouped stats result."""
    value = _extract_stat_value(stats, agg, aggregate_field)
    label = f"{agg} on {table}"
    if aggregate_field:
        label += f".{aggregate_field}"
    return f"{label}: {value}"


def _extract_stat_value(stats: dict, agg: str, aggregate_field: str) -> str:
    """Extract the stat value from a stats dict."""
    key = agg.lower()
    raw = stats.get(key, "")
    # For non-COUNT, value may be nested: {"avg": {"field_name": "3.5"}}
    if isinstance(raw, dict) and aggregate_field:
        return raw.get(aggregate_field, str(raw))
    return str(raw) if raw else "0"


def _resolve_table(client, sys_id: str) -> str | None:
    """Resolve a sys_id to its table name via sys_metadata then sys_audit."""
    # Try sys_metadata first (configuration records)
    response = client.query_table(
        table_name="sys_metadata",
        query=f"sys_id={sys_id}",
        fields=["sys_class_name", "sys_name"],
        limit=1
    )
    if response["success"] and response["result"]:
        return response["result"][0].get("sys_class_name", "")

    # Fall back to sys_audit (audited data records)
    response = client.query_table(
        table_name="sys_audit",
        query=f"documentkey={sys_id}",
        fields=["tablename"],
        limit=1
    )
    if response["success"] and response["result"]:
        return response["result"][0].get("tablename", "")

    return None
