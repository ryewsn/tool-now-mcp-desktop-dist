"""Generic table query tools"""
from .table import register_tools

__all__ = ["register_tools"]
