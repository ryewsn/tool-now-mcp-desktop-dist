"""create_custom_table tool — creates a new custom ServiceNow table end-to-end."""

import json
import re
from typing import List, Optional

from mcp.server.fastmcp import FastMCP

from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error

VALID_TYPES: frozenset = frozenset(
    {
        "string",
        "integer",
        "boolean",
        "reference",
        "choice",
        "glide_date_time",
        "glide_date",
        "json",
        "decimal",
        "float",
        "url",
        "email",
        "phone_number",
        "html",
        "script",
        "conditions",
        "journal",
        "journal_input",
        "glide_list",
        "currency",
        "translated_field",
        "document_id",
    }
)

# Types that map to long-text storage
_LARGE_TYPES = frozenset({"json", "html", "script", "conditions"})

# Name substrings mapped to max_length
_NAME_LENGTH_RULES = [
    ({"description", "notes", "comments"}, 4000),
    ({"name", "label"}, 100),
    ({"url", "link"}, 1024),
]

_SCRIPT_RUNNER_URL_TEMPLATE = "{instance}/api/now/foundry_script_runner/execute"

_TABLE_NAME_RE = re.compile(r'^[a-zA-Z0-9_.]+$')
_COLUMN_NAME_RE = re.compile(r'^[a-zA-Z0-9_]+$')


def _infer_max_length(name: str, field_type: str, explicit: Optional[int]) -> int:
    """Return max_length for a column, applying priority rules.

    Priority:
    1. Explicit value (always wins, including 0)
    2. Type-based: json/html/script/conditions → 65535; reference → 32
    3. Name-based substring match: description/notes/comments → 4000;
       name/label → 100; url/link → 1024
    4. Default: 40
    """
    if explicit is not None:
        return explicit

    if field_type in _LARGE_TYPES:
        return 65535

    if field_type == "reference":
        return 32

    name_lower = name.lower()
    for keywords, length in _NAME_LENGTH_RULES:
        if any(kw in name_lower for kw in keywords):
            return length

    return 40


def _validate_columns(columns: list) -> List[str]:
    """Validate a list of column definitions.

    Returns a list of error strings. An empty list means all columns are valid.

    Each error is prefixed with the 1-based column index and column name
    (if available), e.g. "Column 2 ('bad_col'): missing reference_table".
    """
    errors: List[str] = []

    for idx, col in enumerate(columns, start=1):
        col_name = col.get("name", "")
        prefix = f"Column {idx} ('{col_name}')" if col_name else f"Column {idx}"

        if not col_name:
            errors.append(f"{prefix}: name is required")
            # Re-derive prefix without name for subsequent errors on same column
            prefix = f"Column {idx}"

        if not col.get("label"):
            errors.append(f"{prefix}: label is required")

        field_type = col.get("type", "")
        if not field_type:
            errors.append(f"{prefix}: type is required")
        elif field_type not in VALID_TYPES:
            valid_list = ", ".join(sorted(VALID_TYPES))
            errors.append(
                f"{prefix}: invalid type '{field_type}'. Valid types: {valid_list}"
            )
        else:
            # Type-specific checks
            if field_type == "reference" and not col.get("reference_table"):
                errors.append(f"{prefix}: reference type requires reference_table")

            if field_type == "choice":
                choices = col.get("choices")
                if not choices:
                    errors.append(f"{prefix}: choice type requires a non-empty choices array")

    return errors


def register_tools(mcp: FastMCP) -> None:
    """Register the create_custom_table tool with the MCP server."""

    @mcp.tool()
    def create_custom_table(
        name: str,
        label: str,
        columns: str,
        scope: str = "",
        extends: str = "",
        instance: str = None,
    ) -> str:
        """Create a new custom table in ServiceNow end-to-end, writing to sys_db_object,
        sys_dictionary, and sys_choice. Performs three sequential operations: (1) creates the
        table in sys_db_object, (2) creates one sys_dictionary record per column, (3) inserts
        sys_choice records for any choice-type columns. Full table name is {scope}_{name}.

        Args:
            columns: JSON array of column objects. Each must have:
                - name (str): field element name
                - label (str): display label
                - type (str): one of: boolean, choice, conditions, currency, decimal,
                  document_id, email, float, glide_date, glide_date_time, glide_list,
                  html, integer, journal, journal_input, json, phone_number, reference,
                  script, string, translated_field, url
                - max_length (int, optional): overrides auto-inferred length. Defaults:
                  json/html/script/conditions → 65535; reference → 32;
                  *description/*notes/*comments → 4000; *name/*label → 100;
                  *url/*link → 1024; all others → 40
                - mandatory (bool, optional): field required. Default: false
                - reference_table (str): REQUIRED when type is "reference"
                - choices (list): REQUIRED when type is "choice". Each entry: {value, label}
            scope: REQUIRED. App scope prefix (e.g., "x_myapp"). Use get_table_schema on an
                   existing scoped table to find your app's prefix.
            extends: Parent table to inherit from (e.g., "task"). Parent must exist in
                     sys_db_object. Leave empty for a standalone table.

        Returns table sys_id, columns created vs attempted, choice values created, and any
        per-column or per-choice failures. Continues on partial failure. Use create_table_index
        to add indexes after creation.
        """
        # --- Input validation (no API calls) ---

        if not scope:
            return (
                f"Error: scope is required to create a scoped table.\n\n"
                f"For example, with scope 'x_myapp' and name '{name}', "
                f"the table would be 'x_myapp_{name}'.\n\n"
                f"Tip: Use get_table_schema on an existing table in your app to discover "
                f"its scope prefix."
            )

        if not name:
            return "Error: name is required."

        if not label:
            return "Error: label is required."

        try:
            parsed_columns = json.loads(columns)
        except (json.JSONDecodeError, ValueError) as exc:
            return f"Error: columns is not valid JSON — {exc}"

        if not parsed_columns:
            return "Error: columns must be a non-empty array."

        col_errors = _validate_columns(parsed_columns)
        if col_errors:
            return "Column validation errors:\n" + "\n".join(f"  - {e}" for e in col_errors)

        full_table_name = f"{scope}_{name}"

        client = get_client(instance)

        # --- Pre-flight: duplicate table check ---

        dup_resp = client.query_table(
            "sys_db_object",
            f"name={full_table_name}",
            fields=["sys_id", "name", "label"],
            limit=1,
        )
        if dup_resp["success"] and dup_resp.get("result"):
            existing = dup_resp["result"][0]
            return (
                f"Error: table '{full_table_name}' already exists "
                f"(sys_id: {existing.get('sys_id', 'unknown')})."
            )

        # --- Pre-flight: parent table lookup ---

        super_class_sys_id = ""
        if extends:
            parent_resp = client.query_table(
                "sys_db_object",
                f"name={extends}",
                fields=["sys_id", "name"],
                limit=1,
            )
            if not parent_resp["success"] or not parent_resp.get("result"):
                return f"Error: parent table '{extends}' not found in sys_db_object."
            super_class_sys_id = parent_resp["result"][0]["sys_id"]

        # --- Instance confirmation (after pre-flight, before writes) ---

        confirmation_error = require_instance_confirmation(instance, "create custom table")
        if confirmation_error:
            return confirmation_error

        # --- Create sys_db_object (the table itself) ---

        table_data: dict = {"name": full_table_name, "label": label}
        if super_class_sys_id:
            table_data["super_class"] = super_class_sys_id

        table_resp = client.create_record("sys_db_object", table_data, scope=scope)
        if not table_resp["success"]:
            return format_error(
                table_resp["status_code"],
                f"Failed to create table '{full_table_name}' in sys_db_object: {table_resp.get('error', '')}",
            )

        table_sys_id = table_resp["result"]["sys_id"]

        # --- Create sys_dictionary records (one per column) ---

        col_successes: List[str] = []
        col_failures: List[tuple] = []  # (col_name, error)

        for col in parsed_columns:
            col_name = col["name"]
            max_len = _infer_max_length(col_name, col["type"], col.get("max_length"))
            mandatory_val = "true" if col.get("mandatory") else "false"

            dict_data: dict = {
                "name": full_table_name,
                "element": col_name,
                "column_label": col["label"],
                "internal_type": col["type"],
                "max_length": str(max_len),
                "mandatory": mandatory_val,
            }
            if col["type"] == "reference" and col.get("reference_table"):
                dict_data["reference"] = col["reference_table"]

            dict_resp = client.create_record("sys_dictionary", dict_data, scope=scope)
            if dict_resp["success"]:
                col_successes.append(
                    f"  {col_name} ({col['type']}, max_length={max_len})"
                    + (" [mandatory]" if col.get("mandatory") else "")
                )
            else:
                col_failures.append(
                    (col_name, dict_resp.get("error", f"HTTP {dict_resp['status_code']}"))
                )

        # --- Create sys_choice records ---

        choice_successes: dict = {}  # col_name → list of values
        choice_failures: List[tuple] = []  # (col_name, value, error)

        for col in parsed_columns:
            if col["type"] != "choice":
                continue
            col_name = col["name"]
            choices = col.get("choices", [])
            for seq, choice in enumerate(choices):
                choice_data = {
                    "name": full_table_name,
                    "element": col_name,
                    "value": choice["value"],
                    "label": choice["label"],
                    "sequence": str(seq),
                }
                choice_resp = client.create_record("sys_choice", choice_data, scope=scope)
                if choice_resp["success"]:
                    choice_successes.setdefault(col_name, []).append(choice["value"])
                else:
                    choice_failures.append(
                        (
                            col_name,
                            choice["value"],
                            choice_resp.get("error", f"HTTP {choice_resp['status_code']}"),
                        )
                    )

        # --- Build summary ---

        lines: List[str] = [
            f"Created custom table: {full_table_name} ({label})",
            f"sys_id: {table_sys_id}",
            f"Scope: {scope}",
        ]
        if extends:
            lines.append(f"Extends: {extends}")

        total_cols = len(parsed_columns)
        lines.append(f"\nColumns created ({len(col_successes)}/{total_cols}):")
        lines.extend(col_successes)

        if choice_successes:
            total_choice_vals = sum(len(v) for v in choice_successes.values())
            total_choice_attempted = sum(
                len(c.get("choices", []))
                for c in parsed_columns
                if c["type"] == "choice"
            )
            lines.append(
                f"\nChoice values created ({total_choice_vals}/{total_choice_attempted}):"
            )
            for field, vals in choice_successes.items():
                lines.append(f"  {field}: {', '.join(vals)}")

        all_failures: List[str] = []
        for col_name, err in col_failures:
            all_failures.append(f"  Column '{col_name}': {err}")
        for col_name, val, err in choice_failures:
            all_failures.append(f"  Choice '{col_name}/{val}': {err}")

        if all_failures:
            lines.append("\nFailures:")
            lines.extend(all_failures)

        return "\n".join(lines)

    @mcp.tool()
    def create_table_index(
        table_name: str,
        column_name: str,
        unique: bool = False,
        instance: str = None,
    ) -> str:
        """Create a btree index on a ServiceNow table column to improve query performance.
        Indexes live in sys_index (NOT sys_db_index). Insert goes through GlideRecord via the
        Foundry Script Runner — the REST Table API silently drops fields on sys_metadata
        subclasses. Requires the Foundry Script Runner; use setup_script_runner if needed.

        Args:
            column_name: Element name of the column (e.g., "state"). Use get_table_schema to
                         find valid element names.
            unique: Set True only when column values are guaranteed unique across all rows.
                    Default: False.

        Returns index sys_id, table, and column on success, or an error if the column is not
        found, Script Runner is unavailable, or the GlideRecord insert fails.
        """
        # --- Input validation ---

        if not table_name:
            return "Error: table_name is required."

        if not column_name:
            return "Error: column_name is required."

        if not _TABLE_NAME_RE.match(table_name):
            return "Error: table_name contains invalid characters (only alphanumeric, underscore, dot allowed)."

        if not _COLUMN_NAME_RE.match(column_name):
            return "Error: column_name contains invalid characters (only alphanumeric, underscore allowed)."

        client = get_client(instance)

        # --- Look up sys_dictionary sys_id for the column ---

        dict_query = f"name={table_name}^element={column_name}"
        dict_resp = client.query_table(
            "sys_dictionary",
            dict_query,
            fields=["sys_id"],
            limit=1,
        )

        if not dict_resp["success"]:
            return format_error(
                dict_resp["status_code"],
                f"Failed to query sys_dictionary: {dict_resp.get('error', '')}",
            )

        if not dict_resp.get("result"):
            return (
                f"Error: column '{column_name}' not found on table '{table_name}' "
                f"in sys_dictionary. Use get_table_schema to verify the column element name."
            )

        col_sys_id = dict_resp["result"][0]["sys_id"]

        # --- Look up sys_db_object sys_id for the table ---

        dbo_resp = client.query_table(
            "sys_db_object",
            f"name={table_name}",
            fields=["sys_id"],
            limit=1,
        )

        if not dbo_resp["success"]:
            return format_error(
                dbo_resp["status_code"],
                f"Failed to query sys_db_object: {dbo_resp.get('error', '')}",
            )

        dbo_sys_id = dbo_resp["result"][0]["sys_id"] if dbo_resp.get("result") else ""

        # --- Instance confirmation before write ---

        confirmation_error = require_instance_confirmation(instance, "create table index")
        if confirmation_error:
            return confirmation_error

        # --- Build and execute GlideRecord insert script ---

        unique_js = "true" if unique else "false"
        table_line = f"idx.table = '{dbo_sys_id}';\n" if dbo_sys_id else ""
        script = (
            f"var idx = new GlideRecord('sys_index');\n"
            f"idx.logical_table_name = '{table_name}';\n"
            f"idx.col_name_string = '{column_name}';\n"
            f"idx.index_col_name = '{col_sys_id}';\n"
            f"idx.access_method = 'btree';\n"
            f"idx.unique_index = {unique_js};\n"
            f"{table_line}"
            f"var sys_id = idx.insert();\n"
            f"gs.print(sys_id ? 'created:' + sys_id : 'failed');\n"
        )

        if not client._prepare_request():
            return "Authentication failed."

        url = _SCRIPT_RUNNER_URL_TEMPLATE.format(instance=client.config.instance)
        response = client.session.post(url, json={"script": script, "timeout_ms": 30000})

        if response.status_code == 400 and "does not represent any resource" in response.text:
            return (
                "Index creation requires the Foundry Script Runner to be installed.\n"
                "Use setup_script_runner to install it, then retry."
            )

        if response.status_code not in (200, 201):
            return format_error(response.status_code, f"Script Runner error: {response.text[:200]}")

        result = response.json().get("result", {})
        output_lines = result.get("output", [])
        output = "\n".join(str(line) for line in output_lines)

        if "created:" in output:
            idx_sys_id = output.split("created:")[1].strip().splitlines()[0]
            unique_label = " (unique)" if unique else ""
            return (
                f"Index created{unique_label}\n"
                f"  Table:    {table_name}\n"
                f"  Column:   {column_name}\n"
                f"  Type:     btree\n"
                f"  sys_id:   {idx_sys_id}\n"
            )

        return (
            f"Error: GlideRecord insert returned 'failed' for {table_name}.{column_name}.\n"
            f"The column sys_id resolved correctly ({col_sys_id}) but the insert did not "
            f"return a sys_id. Check instance permissions on sys_index."
        )
