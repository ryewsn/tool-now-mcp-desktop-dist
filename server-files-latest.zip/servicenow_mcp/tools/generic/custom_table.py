"""create_custom_table tool — creates a new custom ServiceNow table end-to-end."""

import json
import re
from typing import List, Optional

from mcp.server.mcpserver import MCPServer

from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error
from ...core.scope_lookup import resolve_scope, scope_value
from ...core.script_runner import GLOBAL_SCOPE_SYS_ID
from ...core.scoped_write import scoped_insert

VALID_TYPES: frozenset = frozenset(
    {
        "string",
        "integer",
        "boolean",
        "reference",
        "choice",
        "glide_date_time",
        "glide_date",
        "json",
        "decimal",
        "float",
        "url",
        "email",
        "phone_number",
        "html",
        "script",
        "conditions",
        "journal",
        "journal_input",
        "glide_list",
        "currency",
        "translated_field",
        "document_id",
    }
)

# Types that map to long-text storage
_LARGE_TYPES = frozenset({"json", "html", "script", "conditions"})

# Name substrings mapped to max_length
_NAME_LENGTH_RULES = [
    ({"description", "notes", "comments"}, 4000),
    ({"name", "label"}, 100),
    ({"url", "link"}, 1024),
]


_TABLE_NAME_RE = re.compile(r'^[a-zA-Z0-9_.]+$')
_COLUMN_NAME_RE = re.compile(r'^[a-zA-Z0-9_]+$')


def _infer_max_length(name: str, field_type: str, explicit: Optional[int]) -> int:
    """Return max_length for a column, applying priority rules.

    Priority:
    1. Explicit value (always wins, including 0)
    2. Type-based: json/html/script/conditions → 65535; reference → 32
    3. Name-based substring match: description/notes/comments → 4000;
       name/label → 100; url/link → 1024
    4. Default: 40
    """
    if explicit is not None:
        return explicit

    if field_type in _LARGE_TYPES:
        return 65535

    if field_type == "reference":
        return 32

    name_lower = name.lower()
    for keywords, length in _NAME_LENGTH_RULES:
        if any(kw in name_lower for kw in keywords):
            return length

    return 40


def _validate_columns(columns: list) -> List[str]:
    """Validate a list of column definitions.

    Returns a list of error strings. An empty list means all columns are valid.

    Each error is prefixed with the 1-based column index and column name
    (if available), e.g. "Column 2 ('bad_col'): missing reference_table".
    """
    errors: List[str] = []

    for idx, col in enumerate(columns, start=1):
        col_name = col.get("name", "")
        prefix = f"Column {idx} ('{col_name}')" if col_name else f"Column {idx}"

        if not col_name:
            errors.append(f"{prefix}: name is required")
            # Re-derive prefix without name for subsequent errors on same column
            prefix = f"Column {idx}"
        elif not _COLUMN_NAME_RE.match(col_name):
            errors.append(
                f"{prefix}: name contains invalid characters "
                f"(only alphanumeric and underscore allowed)"
            )

        if not col.get("label"):
            errors.append(f"{prefix}: label is required")

        field_type = col.get("type", "")
        if not field_type:
            errors.append(f"{prefix}: type is required")
        elif field_type not in VALID_TYPES:
            valid_list = ", ".join(sorted(VALID_TYPES))
            errors.append(
                f"{prefix}: invalid type '{field_type}'. Valid types: {valid_list}"
            )
        else:
            # Type-specific checks
            if field_type == "reference" and not col.get("reference_table"):
                errors.append(f"{prefix}: reference type requires reference_table")

            if field_type == "choice":
                choices = col.get("choices")
                if not choices:
                    errors.append(f"{prefix}: choice type requires a non-empty choices array")

    return errors


def register_tools(mcp: MCPServer) -> None:
    """Register the create_custom_table tool with the MCP server."""

    @mcp.tool()
    def create_custom_table(
        name: str,
        label: str,
        columns: str,
        scope: str = "",
        extends: str = "",
        instance: str = None,
    ) -> str:
        """Create a new custom table in ServiceNow end-to-end, writing to sys_db_object,
        sys_dictionary, and sys_choice. Performs three sequential operations: (1) creates the
        table in sys_db_object, (2) creates one sys_dictionary record per column, (3) inserts
        sys_choice records for any choice-type columns. Full table name is {scope}_{name}.
        Writes go through GlideRecord with sys_scope set (REST ignores the requested scope and
        lands records in the session's current app). Requires the Foundry Script Runner; use
        setup_script_runner if needed. The table and columns are read back and verified; if
        the table did not land in the requested scope under the requested name, nothing more
        is written and the stray table's sys_id is reported (it is not deleted).

        Args:
            columns: JSON array of column objects. Each must have:
                - name (str): field element name
                - label (str): display label
                - type (str): one of: boolean, choice, conditions, currency, decimal,
                  document_id, email, float, glide_date, glide_date_time, glide_list,
                  html, integer, journal, journal_input, json, phone_number, reference,
                  script, string, translated_field, url
                - max_length (int, optional): overrides auto-inferred length. Defaults:
                  json/html/script/conditions → 65535; reference → 32;
                  *description/*notes/*comments → 4000; *name/*label → 100;
                  *url/*link → 1024; all others → 40
                - mandatory (bool, optional): field required. Default: false
                - reference_table (str): REQUIRED when type is "reference"
                - choices (list): REQUIRED when type is "choice". Each entry: {value, label}
            scope: REQUIRED. App scope prefix (e.g., "x_myapp"), or "global". Use
                   get_table_schema on an existing scoped table to find your app's prefix.
                   The table is named <scope>_<name>; for "global" it is u_<name>.
            extends: Parent table to inherit from (e.g., "task"). Parent must exist in
                     sys_db_object. Leave empty for a standalone table.

        Returns table sys_id, columns created vs attempted, choice values created, and any
        per-column or per-choice failures. Continues on partial failure. Use create_table_index
        to add indexes after creation.
        """
        # --- Input validation (no API calls) ---

        if not scope:
            return (
                f"Error: scope is required to create a scoped table.\n\n"
                f"For example, with scope 'x_myapp' and name '{name}', "
                f"the table would be 'x_myapp_{name}'.\n\n"
                f"Tip: Use get_table_schema on an existing table in your app to discover "
                f"its scope prefix."
            )

        if not name:
            return "Error: name is required."

        if not label:
            return "Error: label is required."

        for arg_name, arg_value in (("scope", scope), ("name", name), ("extends", extends)):
            if arg_value and not _TABLE_NAME_RE.match(arg_value):
                return (
                    f"Error: {arg_name} contains invalid characters "
                    f"(only alphanumeric, underscore, dot allowed)."
                )

        try:
            parsed_columns = json.loads(columns)
        except (json.JSONDecodeError, ValueError) as exc:
            return f"Error: columns is not valid JSON — {exc}"

        if not parsed_columns:
            return "Error: columns must be a non-empty array."

        col_errors = _validate_columns(parsed_columns)
        if col_errors:
            return "Column validation errors:\n" + "\n".join(f"  - {e}" for e in col_errors)

        client = get_client(instance)

        # --- Pre-flight: resolve the scope's sys_id (also rejects unknown scopes) ---

        scope_check = resolve_scope(client, scope)
        if not scope_check["success"]:
            return f"Error: {scope_check['error']}"
        scope_sys_id = scope_check["sys_id"]
        # Build the table name from the canonical scope id, not the raw input (which may
        # be a sys_id or "global")
        scope = scope_check["scope"]
        if scope_sys_id == GLOBAL_SCOPE_SYS_ID:
            # Global has no scope prefix: the platform stores a custom table there as
            # u_<name> (verified live on zyew2, 2026-11-19: a request for
            # global_<name> was stored as u_global_<name>)
            full_table_name = name if name.startswith("u_") else f"u_{name}"
        else:
            full_table_name = f"{scope}_{name}"

        # --- Pre-flight: duplicate table check ---

        dup_resp = client.query_table(
            "sys_db_object",
            f"name={full_table_name}",
            fields=["sys_id", "name", "label"],
            limit=1,
        )
        if dup_resp["success"] and dup_resp.get("result"):
            existing = dup_resp["result"][0]
            return (
                f"Error: table '{full_table_name}' already exists "
                f"(sys_id: {existing.get('sys_id', 'unknown')})."
            )

        # --- Pre-flight: parent table lookup ---

        super_class_sys_id = ""
        if extends:
            parent_resp = client.query_table(
                "sys_db_object",
                f"name={extends}",
                fields=["sys_id", "name"],
                limit=1,
            )
            if not parent_resp["success"] or not parent_resp.get("result"):
                return f"Error: parent table '{extends}' not found in sys_db_object."
            super_class_sys_id = parent_resp["result"][0]["sys_id"]

        # --- Instance confirmation (after pre-flight, before writes) ---

        confirmation_error = require_instance_confirmation(instance, "create custom table")
        if confirmation_error:
            return confirmation_error

        # --- Create sys_db_object (the table itself) ---

        table_data: dict = {"name": full_table_name, "label": label}
        if super_class_sys_id:
            table_data["super_class"] = super_class_sys_id

        table_resp = client.glide_write(
            "sys_db_object", "insert", table_data, scope_sys_id=scope_sys_id
        )
        if not table_resp["success"]:
            return format_error(
                table_resp["status_code"],
                f"Failed to create table '{full_table_name}' in sys_db_object: {table_resp.get('error', '')}",
            )

        table_sys_id = (table_resp.get("result") or {}).get("sys_id")
        if not table_sys_id:
            return (
                f"Error: the script runner reported success but returned no sys_id for "
                f"'{full_table_name}', so it cannot be verified. Check sys_db_object for it "
                f"before retrying."
            )

        # --- Read back: the table must exist under the requested name in the requested scope ---

        verify_resp = client.query_table(
            "sys_db_object",
            f"sys_id={table_sys_id}",
            fields=["sys_id", "name", "sys_scope"],
            limit=1,
        )
        if not verify_resp["success"] or not verify_resp.get("result"):
            return (
                f"Error: could not verify the new table by read-back. It was written "
                f"(sys_db_object sys_id: {table_sys_id}) but its name and scope are unconfirmed, "
                f"so no columns or choices were written. Inspect that record before retrying."
            )
        actual = verify_resp["result"][0]
        actual_name = actual.get("name")
        actual_scope = scope_value(actual.get("sys_scope"))
        if actual_name != full_table_name or actual_scope != scope_sys_id:
            return (
                f"Error: the table was created but not where requested, so no columns or "
                f"choices were written.\n"
                f"  Requested: {full_table_name} in scope {scope} ({scope_sys_id})\n"
                f"  Actual:    {actual_name} in scope sys_id {actual_scope}\n"
                f"  Stray table: sys_db_object sys_id {table_sys_id} (NOT removed).\n"
                f"To remove it, set apps.current_app to the scope it landed in, call "
                f"reset_client_session, then delete that record. Deletes only work from a "
                f"session in the record's own scope. If the table is in the scope you "
                f"requested and only the name differs, it is usable as it stands: add its "
                f"columns yourself or delete it."
            )

        # --- Create sys_dictionary records (one per column) ---

        col_successes: List[tuple] = []  # (col_name, summary line)
        col_failures: List[tuple] = []  # (col_name, error)

        for col in parsed_columns:
            col_name = col["name"]
            max_len = _infer_max_length(col_name, col["type"], col.get("max_length"))
            mandatory_val = "true" if col.get("mandatory") else "false"

            dict_data: dict = {
                "name": full_table_name,
                "element": col_name,
                "column_label": col["label"],
                "internal_type": col["type"],
                "max_length": str(max_len),
                "mandatory": mandatory_val,
            }
            if col["type"] == "reference" and col.get("reference_table"):
                dict_data["reference"] = col["reference_table"]

            dict_resp = client.glide_write(
                "sys_dictionary", "insert", dict_data, scope_sys_id=scope_sys_id
            )
            if dict_resp["success"]:
                col_successes.append((
                    col_name,
                    f"  {col_name} ({col['type']}, max_length={max_len})"
                    + (" [mandatory]" if col.get("mandatory") else ""),
                ))
            else:
                col_failures.append(
                    (col_name, dict_resp.get("error", f"HTTP {dict_resp['status_code']}"))
                )

        # --- Read back the columns: an accepted write stored under another name is a failure ---

        verify_note = ""
        if col_successes:
            written = [c for c, _ in col_successes]
            cols_resp = client.query_table(
                "sys_dictionary",
                f"name={full_table_name}^elementIN{','.join(written)}",
                fields=["element"],
                limit=len(written),
            )
            if cols_resp["success"]:
                stored = {r.get("element") for r in cols_resp.get("result", [])}
                for col_name in written:
                    if col_name not in stored:
                        col_failures.append((
                            col_name,
                            "accepted by the platform but not found under this name "
                            "afterwards (renamed or dropped)",
                        ))
                col_successes = [(c, line) for c, line in col_successes if c in stored]
            else:
                verify_note = "Warning: could not verify the columns by read-back; treat them as unconfirmed."

        # --- Create sys_choice records (no sys_scope field on sys_choice) ---

        choice_successes: dict = {}  # col_name → list of values
        choice_failures: List[tuple] = []  # (col_name, value, error)

        for col in parsed_columns:
            if col["type"] != "choice":
                continue
            col_name = col["name"]
            choices = col.get("choices", [])
            for seq, choice in enumerate(choices):
                choice_data = {
                    "name": full_table_name,
                    "element": col_name,
                    "value": choice["value"],
                    "label": choice["label"],
                    "sequence": str(seq),
                }
                choice_resp = client.glide_write("sys_choice", "insert", choice_data)
                if choice_resp["success"]:
                    choice_successes.setdefault(col_name, []).append(choice["value"])
                else:
                    choice_failures.append(
                        (
                            col_name,
                            choice["value"],
                            choice_resp.get("error", f"HTTP {choice_resp['status_code']}"),
                        )
                    )

        # --- Build summary ---

        lines: List[str] = [
            f"Created custom table: {full_table_name} ({label})",
            f"sys_id: {table_sys_id}",
            f"Scope: {scope} (verified by read-back)",
        ]
        if extends:
            lines.append(f"Extends: {extends}")

        total_cols = len(parsed_columns)
        lines.append(f"\nColumns created ({len(col_successes)}/{total_cols}):")
        lines.extend(line for _, line in col_successes)
        if verify_note:
            lines.append(verify_note)

        if choice_successes:
            total_choice_vals = sum(len(v) for v in choice_successes.values())
            total_choice_attempted = sum(
                len(c.get("choices", []))
                for c in parsed_columns
                if c["type"] == "choice"
            )
            lines.append(
                f"\nChoice values created ({total_choice_vals}/{total_choice_attempted}):"
            )
            for field, vals in choice_successes.items():
                lines.append(f"  {field}: {', '.join(vals)}")

        all_failures: List[str] = []
        for col_name, err in col_failures:
            all_failures.append(f"  Column '{col_name}': {err}")
        for col_name, val, err in choice_failures:
            all_failures.append(f"  Choice '{col_name}/{val}': {err}")

        if all_failures:
            lines.append("\nFailures:")
            lines.extend(all_failures)

        return "\n".join(lines)

    @mcp.tool()
    def create_table_index(
        table_name: str,
        column_name: str,
        unique: bool = False,
        instance: str = None,
    ) -> str:
        """Create a btree index on a ServiceNow table column to improve query performance.
        Indexes live in sys_index (NOT sys_db_index). Insert goes through GlideRecord via the
        Foundry Script Runner — the REST Table API silently drops fields on sys_metadata
        subclasses. Requires the Foundry Script Runner; use setup_script_runner if needed.
        The table is found by exact name and must match exactly one sys_db_object record; the
        index is created in that table's own application scope (not the session's) and is
        verified by read-back, and the result names the scope it landed in.

        Args:
            column_name: Element name of the column (e.g., "state"). Use get_table_schema to
                         find valid element names.
            unique: Set True only when column values are guaranteed unique across all rows.
                    Default: False.

        Returns index sys_id, table, and column on success, or an error if the column is not
        found, Script Runner is unavailable, or the GlideRecord insert fails.
        """
        # --- Input validation ---

        if not table_name:
            return "Error: table_name is required."

        if not column_name:
            return "Error: column_name is required."

        if not _TABLE_NAME_RE.match(table_name):
            return "Error: table_name contains invalid characters (only alphanumeric, underscore, dot allowed)."

        if not _COLUMN_NAME_RE.match(column_name):
            return "Error: column_name contains invalid characters (only alphanumeric, underscore allowed)."

        client = get_client(instance)

        # --- Look up sys_dictionary sys_id for the column ---

        dict_query = f"name={table_name}^element={column_name}"
        dict_resp = client.query_table(
            "sys_dictionary",
            dict_query,
            fields=["sys_id"],
            limit=1,
        )

        if not dict_resp["success"]:
            return format_error(
                dict_resp["status_code"],
                f"Failed to query sys_dictionary: {dict_resp.get('error', '')}",
            )

        if not dict_resp.get("result"):
            return (
                f"Error: column '{column_name}' not found on table '{table_name}' "
                f"in sys_dictionary. Use get_table_schema to verify the column element name."
            )

        col_sys_id = dict_resp["result"][0]["sys_id"]

        # --- Resolve the table to exactly one sys_db_object record (its scope is used below) ---

        dbo_resp = client.query_table(
            "sys_db_object",
            f"name={table_name}",
            fields=["sys_id", "name", "sys_scope"],
            limit=5,
        )

        if not dbo_resp["success"]:
            return format_error(
                dbo_resp["status_code"],
                f"Failed to query sys_db_object: {dbo_resp.get('error', '')}",
            )

        dbo_rows = dbo_resp.get("result") or []
        if not dbo_rows:
            return (
                f"Error: table '{table_name}' not found in sys_db_object. "
                f"Check the table name; nothing was created."
            )
        if len(dbo_rows) > 1:
            candidates = "\n".join(
                f"  - sys_id {scope_value(r.get('sys_id'))}, name '{r.get('name', '')}', "
                f"scope sys_id '{scope_value(r.get('sys_scope')) or '(none)'}'"
                for r in dbo_rows
            )
            return (
                f"Error: {len(dbo_rows)} sys_db_object records match '{table_name}', so the "
                f"table is ambiguous; nothing was created. Candidates:\n{candidates}\n"
                f"Remove the duplicate sys_db_object record by sys_id in the instance, then "
                f"retry the same call."
            )
        dbo_sys_id = scope_value(dbo_rows[0].get("sys_id"))
        table_scope_id = scope_value(dbo_rows[0].get("sys_scope"))
        if not table_scope_id:
            return (
                f"Error: table '{table_name}' has no application scope on its sys_db_object "
                f"record, so the index cannot be placed in the table's scope; nothing was created."
            )

        # --- Instance confirmation before write ---

        confirmation_error = require_instance_confirmation(instance, "create table index")
        if confirmation_error:
            return confirmation_error

        # --- Insert through the scope write layer, in the table's own scope ---

        created = scoped_insert(
            client,
            "sys_index",
            {
                "logical_table_name": table_name,
                "col_name_string": column_name,
                "index_col_name": col_sys_id,
                "access_method": "btree",
                "unique_index": bool(unique),
                "table": dbo_sys_id,
            },
            table_scope_id,
        )

        if not created["success"]:
            return (
                f"Error: could not create the index on {table_name}.{column_name}: "
                f"{created.get('error', '')}"
            )

        unique_label = " (unique)" if unique else ""
        result = created["result"]
        scope_line = ""
        if result.get("scope"):
            scope_line = f"  Scope:    {result['scope']}"
            if result.get("scope_name"):
                scope_line += f" ({result['scope_name']})"
            scope_line += "\n"
        return (
            f"Index created{unique_label}\n"
            f"  Table:    {table_name}\n"
            f"  Column:   {column_name}\n"
            f"  Type:     btree\n"
            f"  sys_id:   {result['sys_id']}\n"
            f"{scope_line}"
        )
