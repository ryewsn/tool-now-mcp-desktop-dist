"""Status and Configuration Tools

Provides tools to check MCP server configuration and authentication status.
"""

import re
import time
import xml.etree.ElementTree as ET

from mcp.server.fastmcp import FastMCP
from ... import __version__
from ...core.client import get_client
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error


def register_tools(mcp: FastMCP):
    """Register status tools with the MCP server."""

    @mcp.tool()
    def get_mcp_status(instance: str = None) -> str:
        """
        Show MCP server version, instance URL, and authentication status. For OAuth,
        actively tests token acquisition and reports expiry time or a classified error
        with a suggested fix. For Basic Auth, shows credentials without a live test.
        """
        client = get_client(instance)
        config = client.config

        output = [
            "🔧 ServiceNow MCP Server Status",
            f"Version: {__version__}",
            "",
            f"Instance: {config.alias}",
            f"URL: {config.instance}",
            "",
            "🔐 Authentication:",
        ]

        # Check authentication type
        if config.uses_oauth:
            # Actively test token acquisition
            token = client._get_oauth_token()

            output.extend([
                "  Type: OAuth (client_credentials)",
                f"  Client ID: {config.client_id}",
                f"  Client Secret: {'*' * 8}... (configured)",
            ])

            if token:
                expires_in_min = max(0, int((client._token_expiry - time.time() + 60) // 60))  # +60 undoes the safety buffer set in _get_oauth_token
                output.extend([
                    f"  ✅ Token acquired successfully (expires in ~{expires_in_min} min)",
                    "",
                    "Benefits:",
                    "  • Better security (no password in memory)",
                    "  • Proper application scope control via API",
                    "  • Token-based auth with automatic refresh",
                    "  • Independent of UI session context"
                ])
            else:
                error_info = client._last_oauth_error or {}
                message = error_info.get("message", "Token acquisition failed")
                suggestion = error_info.get("suggestion")
                output.append(f"  ❌ Token acquisition failed: {message}")
                if suggestion:
                    output.extend([
                        "",
                        f"  💡 Suggested fix: {suggestion}"
                    ])
        elif config.uses_basic_auth:
            output.extend([
                "  Type: Basic Auth (username/password)",
                "  ⚠️  Using Basic Authentication",
                f"  Username: {config.username}",
                f"  Password: {'*' * 8}... (configured)",
                "",
                "Limitations:",
                "  • Application scope inherited from UI session",
                "  • Cannot override scope via API parameters",
                "  • Must switch scope in ServiceNow UI manually",
                "",
                "💡 Tip: Switch to OAuth for better scope control!"
            ])
        else:
            output.extend([
                "  Type: None",
                "  ❌ No authentication configured!",
                "",
                "Please configure either OAuth or Basic Auth in .env file"
            ])

        # Show if both are configured
        if config.uses_oauth and config.uses_basic_auth:
            output.extend([
                "",
                "📝 Note: Both OAuth and Basic Auth are configured.",
                "   OAuth is prioritized and will be used."
            ])

        return "\n".join(output)

    @mcp.tool()
    def test_connection(instance: str = None) -> str:
        """
        Make a live API call to verify credentials are valid and the instance is
        reachable. Use after initial setup, credential rotation, or instance maintenance.
        For config details without a live test, use get_mcp_status instead.
        """
        try:
            client = get_client(instance)
        except ValueError as e:
            return f"Connection failed: {e}"

        config = client.config

        if config.uses_oauth:
            # OAuth: lightweight query to validate connectivity and token
            response = client.query_table(
                table_name="sys_properties",
                query="",
                fields=["name"],
                limit=1
            )
            if not response["success"]:
                return (
                    f"Connection failed to {config.instance}\n"
                    f"Status: {response['status_code']}\n"
                    f"Error: {response.get('error', 'Unknown error')}"
                )
            return f"Connected to {config.instance} via OAuth (token valid)"

        elif config.uses_basic_auth:
            # Basic Auth: query sys_user for the authenticated user
            response = client.query_table(
                table_name="sys_user",
                query=f"user_name={config.username}",
                fields=["user_name", "name", "email", "title", "active"],
                limit=1
            )
            if not response["success"]:
                return (
                    f"Connection failed to {config.instance}\n"
                    f"Status: {response['status_code']}\n"
                    f"Error: {response.get('error', 'Unknown error')}"
                )

            users = response["result"]
            if not users:
                return (
                    f"Connected to {config.instance} but user '{config.username}' "
                    "was not found in sys_user."
                )

            user = users[0]
            name = user.get("name", "Unknown")
            email = user.get("email", "")
            title = user.get("title", "")
            details = f"{name}"
            if email:
                details += f" ({email}"
                if title:
                    details += f", {title}"
                details += ")"
            elif title:
                details += f" ({title})"

            return f"Connected to {config.instance} as {details}"

        else:
            return "No authentication configured. Please set up OAuth or Basic Auth in .env."

    @mcp.tool()
    def get_instance_info(
        detail: str = "summary",
        instance: str = None
    ) -> str:
        """
        Return ServiceNow instance release, patch level, build date, and MID server
        status via xmlstats.do. Use to check what release is running (e.g., Zurich,
        Xanadu) when investigating version-specific behavior.

        Args:
            detail: "summary" (default) — release, patch, build date, MID servers (~3KB).
                    "full" — adds JVM, Tomcat, uptime, active sessions, CPU count (~70KB).
        """
        try:
            client = get_client(instance)
        except ValueError as e:
            return f"Failed to connect: {e}"

        include = "instance" if detail != "full" else "instance,servlet,jvm"
        response = client.get_xmlstats(include=include)

        if not response["success"]:
            return (
                f"Failed to retrieve instance info (status {response['status_code']})\n"
                f"Error: {response.get('error', 'Unknown error')}"
            )

        xml_text = response["result"]
        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError:
            return "Failed to parse instance info — unexpected response format (not XML)."

        # Check this is actually xmlstats output
        if root.tag != "xmlstats":
            return "Failed to parse instance info — unexpected XML root element."

        # Extract instance info
        name = _xml_text(root, "instance_name")
        inst_type = _xml_text(root, "instance_type")
        version_str = _xml_text(root, "instance_current_version")

        release, base_date, patch, build_date = _parse_version(version_str)

        output = [
            f"Instance: {name} ({inst_type})",
            f"Release: {release}",
            f"Patch: {patch}" if patch else "Patch: (none)",
            f"Build date: {build_date}" if build_date else f"Base date: {base_date}" if base_date else "",
            f"Version string: {version_str}",
        ]

        # MID servers
        mids_el = root.find("mids")
        if mids_el is not None:
            mid_servers = list(mids_el.findall("mid_server"))
            if mid_servers:
                up = sum(1 for m in mid_servers if _xml_text(m, "status") == "Up")
                down = len(mid_servers) - up
                output.append(f"MID servers: {len(mid_servers)} total ({up} up, {down} down)")

        # Full mode extras
        if detail == "full":
            output.append("")
            jvm_ver = _xml_text(root, "jvm.version")
            if jvm_ver:
                output.append(f"JVM: {jvm_ver}")
            servlet_info = _xml_text(root, "servlet.info")
            if servlet_info:
                output.append(f"Servlet: {servlet_info}")
            uptime = _xml_text(root, "jvm.time_friendly")
            if uptime:
                output.append(f"Uptime: {uptime}")
            sessions = _xml_text(root, "servlet.active.sessions")
            if sessions:
                output.append(f"Active sessions: {sessions}")
            cpu_count = _xml_text(root, "jvm.cpu.count")
            if cpu_count:
                output.append(f"CPUs: {cpu_count}")
            started = _xml_text(root, "servlet.started")
            if started:
                output.append(f"Started: {started}")

        return "\n".join(line for line in output if line)

    @mcp.tool()
    def list_plugins(
        name: str = "",
        active: str = "",
        limit: int = 100,
        instance: str = None
    ) -> str:
        """
        List installed ServiceNow plugins (v_plugin) with name, version, and active status.
        Use to check whether prerequisites like AI Agent Studio, NowAssist, Flow Designer,
        or Scripted REST API are enabled.

        Args:
            name: Partial match on plugin name (e.g., "NowAssist", "Agent")
            active: Filter by status — "active" or "inactive"
        """
        builder = QueryBuilder()
        builder.add_like("name", name)
        builder.add_equals("active", active)

        query = builder.add_order_by("name", "")

        client = get_client(instance)
        response = client.query_table(
            table_name="v_plugin",
            query=query,
            fields=["name", "version", "active", "license_model"],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No plugins found matching your criteria."

        output = [f"Plugins found: {len(results)}", ""]
        for plugin in results:
            status = plugin.get("active", "unknown")
            version = plugin.get("version", "")
            license_model = plugin.get("license_model", "")
            line = f"  {plugin.get('name', 'N/A')} — {status}"
            if version:
                line += f" (v{version})"
            if license_model:
                line += f" [{license_model}]"
            output.append(line)

        if len(results) == limit:
            output.append(f"\nNOTE: Result limit reached ({limit}). Use name filter to narrow results.")

        return "\n".join(output)


def _xml_text(root: ET.Element, tag: str) -> str:
    """Extract text content from an XML element by tag name."""
    el = root.find(tag)
    return (el.text or "").strip() if el is not None else ""


def _parse_version(version_str: str) -> tuple:
    """Parse a ServiceNow version string into (release, base_date, patch, build_date).

    Example: 'glide-zurich-07-01-2025__patch6-hotfix2-02-11-2026_02-19-2026_1250.zip'
    Returns: ('Zurich', '2025-07-01', 'patch6-hotfix2', '2026-02-19')
    """
    if not version_str:
        return ("Unknown", "", "", "")

    # Strip .zip suffix
    v = version_str.removesuffix(".zip")

    # Extract release name: glide-<name>-
    release_match = re.match(r"glide-([a-zA-Z]+)-", v)
    release = release_match.group(1).capitalize() if release_match else "Unknown"

    # Extract base date: first MM-DD-YYYY after release name
    base_date = ""
    base_match = re.match(r"glide-[a-zA-Z]+-(\d{2})-(\d{2})-(\d{4})", v)
    if base_match:
        base_date = f"{base_match.group(3)}-{base_match.group(1)}-{base_match.group(2)}"

    # Extract patch info: everything between __ and the next date pattern
    patch = ""
    patch_match = re.search(r"__([^_]+(?:-\d{2}-\d{2}-\d{4})?)", v)
    if patch_match:
        patch_str = patch_match.group(1)
        # Remove trailing date from patch string
        patch = re.sub(r"-\d{2}-\d{2}-\d{4}$", "", patch_str)

    # Extract build date: last date-like pattern (MM-DD-YYYY) before the build number
    build_date = ""
    date_matches = re.findall(r"(\d{2})-(\d{2})-(\d{4})", v)
    if len(date_matches) >= 2:
        # Last date before build number is the build date
        last = date_matches[-1]
        build_date = f"{last[2]}-{last[0]}-{last[1]}"

    return (release, base_date, patch, build_date)
