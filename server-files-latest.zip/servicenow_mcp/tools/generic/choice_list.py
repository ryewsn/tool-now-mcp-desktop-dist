"""sys_choice Management Tool"""

import json
from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error
from ...core.query_builder import QueryBuilder


def register_tools(mcp: FastMCP):

    @mcp.tool()
    def manage_choice_list(
        operation: str,
        table_name: str,
        field_name: str,
        value: str = "",
        label: str = "",
        sequence: int = 0,
        language: str = "en",
        confirm_delete: bool = False,
        instance: str = None,
    ) -> str:
        """
        Audit and manage choice list entries (sys_choice) for any table field.

        Operations:
          list       — Return all choices for the field ordered by sequence.
          add        — Create a new choice. Requires: value, label.
          deactivate — Hide a choice from new record forms (sets inactive=true). Requires: value.
          delete     — Permanently remove a choice. Requires: value, confirm_delete=True.

        Args:
            operation: One of "list", "add", "deactivate", "delete"
            table_name: Table the field belongs to (sys_choice.name, e.g., "incident")
            field_name: Field name (sys_choice.element, e.g., "state", "priority")
            value: Stored database value — required for add, deactivate, delete
            label: Display label shown in UI — required for add
            sequence: Sort order in dropdown (add only, default 0)
            language: Language code (add only, default "en")
            confirm_delete: Must be True to execute delete (safety guard)
        """
        if not table_name:
            return "table_name is required."
        if not field_name:
            return "field_name is required."

        valid_operations = ("list", "add", "deactivate", "delete")
        if operation not in valid_operations:
            return f"Invalid operation '{operation}'. Valid operations: {', '.join(valid_operations)}"

        client = get_client(instance)

        if operation == "list":
            builder = QueryBuilder()
            builder.add_equals("name", table_name)
            builder.add_equals("element", field_name)
            builder.add_equals("language", language)
            query = builder.add_order_by("sequence", "")

            response = client.query_table(
                table_name="sys_choice",
                query=query,
                fields=["sys_id", "value", "label", "sequence", "inactive", "language"],
                limit=500,
            )
            if not response["success"]:
                return format_error(response["status_code"], response.get("error", "Unknown error"))

            results = response["result"]
            if not results:
                return f"No choices found for {table_name}.{field_name} (language={language})."

            lines = [f"Choice list: {table_name}.{field_name} ({len(results)} entries)\n"]
            for r in results:
                inactive = r.get("inactive") == "true"
                status = " [inactive]" if inactive else ""
                lines.append(
                    f"  seq={r.get('sequence', '?'):>4}  value={r.get('value', '')!r:<20}  "
                    f"label={r.get('label', '')!r}{status}"
                )
                lines.append(f"           sys_id: {r.get('sys_id', 'N/A')}")
            return "\n".join(lines)

        # All mutating operations require instance confirmation
        confirmation_error = require_instance_confirmation(instance, f"{operation} sys_choice record")
        if confirmation_error:
            return confirmation_error

        if operation == "add":
            if not value:
                return "value is required for the add operation."
            if not label:
                return "label is required for the add operation."

            data = {
                "name": table_name,
                "element": field_name,
                "value": value,
                "label": label,
                "sequence": str(sequence),
                "language": language,
                "inactive": "false",
            }
            response = client.create_record(table_name="sys_choice", data=data)
            if not response["success"]:
                return format_error(response["status_code"], response.get("error", "Unknown error"))

            created = response["result"]
            return (
                f"✅ Choice added to {table_name}.{field_name}\n"
                f"  value:    {value!r}\n"
                f"  label:    {label!r}\n"
                f"  sequence: {sequence}\n"
                f"  language: {language}\n"
                f"  sys_id:   {created.get('sys_id', 'N/A')}"
            )

        if operation == "deactivate":
            if not value:
                return "value is required for the deactivate operation."

            # Find the record by table + field + value + language
            builder = QueryBuilder()
            builder.add_equals("name", table_name)
            builder.add_equals("element", field_name)
            builder.add_equals("value", value)
            builder.add_equals("language", language)
            find_response = client.query_table(
                table_name="sys_choice",
                query=builder.build(),
                fields=["sys_id", "inactive"],
                limit=1,
            )
            if not find_response["success"]:
                return format_error(find_response["status_code"], find_response.get("error", "Unknown error"))
            if not find_response["result"]:
                return f"No choice found with value={value!r} in {table_name}.{field_name} (language={language})."

            record = find_response["result"][0]
            if record.get("inactive") == "true":
                return f"Choice value={value!r} in {table_name}.{field_name} is already inactive."

            update_response = client.update_record(
                table_name="sys_choice",
                sys_id=record["sys_id"],
                data={"inactive": "true"},
            )
            if not update_response["success"]:
                return format_error(update_response["status_code"], update_response.get("error", "Unknown error"))

            return (
                f"✅ Choice deactivated in {table_name}.{field_name}\n"
                f"  value: {value!r}\n"
                f"  sys_id: {record['sys_id']}"
            )

        if operation == "delete":
            if not value:
                return "value is required for the delete operation."
            if not confirm_delete:
                return (
                    f"⚠️  Deletion requires confirm_delete=true.\n\n"
                    f"  This will permanently remove value={value!r} from {table_name}.{field_name}.\n"
                    f"  Re-run with confirm_delete=true to proceed."
                )

            # Find the record
            builder = QueryBuilder()
            builder.add_equals("name", table_name)
            builder.add_equals("element", field_name)
            builder.add_equals("value", value)
            builder.add_equals("language", language)
            find_response = client.query_table(
                table_name="sys_choice",
                query=builder.build(),
                fields=["sys_id"],
                limit=1,
            )
            if not find_response["success"]:
                return format_error(find_response["status_code"], find_response.get("error", "Unknown error"))
            if not find_response["result"]:
                return f"No choice found with value={value!r} in {table_name}.{field_name} (language={language})."

            sys_id = find_response["result"][0]["sys_id"]
            delete_response = client.delete_record(table_name="sys_choice", sys_id=sys_id)
            if not delete_response["success"]:
                return format_error(delete_response["status_code"], delete_response.get("error", "Unknown error"))

            return (
                f"✅ Choice permanently deleted from {table_name}.{field_name}\n"
                f"  value: {value!r}\n"
                f"  sys_id: {sys_id}"
            )
