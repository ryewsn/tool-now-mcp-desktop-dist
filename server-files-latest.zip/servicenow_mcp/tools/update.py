from __future__ import annotations

from mcp.server.fastmcp import FastMCP
from servicenow_mcp.core.lifecycle import fetch_server_files, pip_install


def _server_dir():
    from pathlib import Path
    return Path(__file__).resolve().parents[2]


def register_tools(mcp: FastMCP) -> None:
    @mcp.tool()
    def update_mcp_server() -> str:
        """Update the ServiceNow MCP server to the latest version in-place.

        Call this when the user asks to update ServiceNow MCP, install updates,
        upgrade to the latest version, or when an update notice appears in a
        tool response.

        Auto-detects install type (GUI installer vs. git clone) and applies the
        correct update method — no credential re-entry required.

        Always tell the user to restart Claude Desktop after a successful update
        (Cmd+Q then reopen on macOS; close and reopen on Windows).
        """
        from servicenow_mcp.core.update_check import _read_current_version, _fetch_latest_version

        current = _read_current_version()
        latest = _fetch_latest_version()

        if latest is None:
            return "Could not reach the update server. Check your connection and try again."
        if latest == current:
            return f"Already on the latest version ({current}). No update needed."

        server_dir = _server_dir()

        status = fetch_server_files(server_dir)
        if status != "ok":
            return status

        pip_status = pip_install()
        if pip_status != "ok":
            return pip_status

        new_version = _read_current_version()
        return (
            f"Update complete ({current} → {new_version}). "
            "Restart Claude Desktop (Cmd+Q, then reopen) to load the new version."
        )
