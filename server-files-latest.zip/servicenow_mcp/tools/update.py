from __future__ import annotations
import os
import shutil
import sys
import subprocess
import tempfile
import zipfile
import urllib.request
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from servicenow_mcp.core.update_check import SERVER_FILES_URL as _SERVER_FILES_URL

_PACKAGES = ["mcp", "requests", "python-dotenv", "keyring"]
_DOWNLOAD_TIMEOUT = 30
_GIT_TIMEOUT = 60
_PIP_TIMEOUT = 120


def _server_dir() -> Path:
    # This file is at servicenow_mcp/tools/update.py — two levels up is the project root.
    return Path(__file__).resolve().parents[2]


def _is_git_install(server_dir: Path) -> bool:
    return (server_dir / ".git").exists()


def _run_git_update(server_dir: Path) -> str:
    result = subprocess.run(
        ["git", "-C", str(server_dir), "pull"],
        capture_output=True, text=True, timeout=_GIT_TIMEOUT,
    )
    if result.returncode != 0:
        stderr = result.stderr.strip()
        if "local changes" in stderr or "conflict" in stderr.lower():
            return (
                "Update failed — local changes detected. "
                "Run `git stash` in the install directory then retry."
            )
        return f"Update failed: {stderr}"
    return "ok"


def _run_installer_update(server_dir: Path) -> str:
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
            tmp_path = tmp.name
        try:
            req = urllib.request.Request(
                _SERVER_FILES_URL,
                headers={"User-Agent": "servicenow-mcp-installer"},
            )
            with urllib.request.urlopen(req, timeout=_DOWNLOAD_TIMEOUT) as resp:
                with open(tmp_path, "wb") as f:
                    f.write(resp.read())
        except Exception as exc:
            return (
                f"Could not reach the update server. "
                f"Check your connection and try again. ({exc})"
            )
        # Wipe servicenow_mcp/ before extracting so renamed/removed modules
        # don't linger — mirrors the installer's full directory removal.
        mcp_dir = server_dir / "servicenow_mcp"
        if mcp_dir.is_dir():
            shutil.rmtree(mcp_dir)
        with zipfile.ZipFile(tmp_path) as zf:
            for member in zf.namelist():
                if (
                    member in ("server.py", "pyproject.toml")
                    or member.startswith("servicenow_mcp/")
                ):
                    zf.extract(member, server_dir)
        return "ok"
    except PermissionError as exc:
        return (
            f"Permission denied updating files: {exc}. "
            "Re-run the installer from SharePoint as a fallback."
        )
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass


def _pip_upgrade() -> str:
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade"] + _PACKAGES,
        capture_output=True, text=True, timeout=_PIP_TIMEOUT,
    )
    if result.returncode != 0:
        return f"Files updated but pip upgrade failed: {result.stderr.strip()}"
    return "ok"


def register_tools(mcp: FastMCP) -> None:
    @mcp.tool()
    def update_mcp_server() -> str:
        """Update the ServiceNow MCP server to the latest version in-place.

        Call this when the user asks to update ServiceNow MCP, install updates,
        upgrade to the latest version, or when an update notice appears in a
        tool response.

        Auto-detects install type (GUI installer vs. git clone) and applies the
        correct update method — no credential re-entry required.

        Always tell the user to restart Claude Desktop after a successful update
        (Cmd+Q then reopen on macOS; close and reopen on Windows).
        """
        from servicenow_mcp.core.update_check import _read_current_version, _fetch_latest_version

        current = _read_current_version()
        latest = _fetch_latest_version()

        if latest is None:
            return "Could not reach the update server. Check your connection and try again."
        if latest == current:
            return f"Already on the latest version ({current}). No update needed."

        server_dir = _server_dir()

        if _is_git_install(server_dir):
            status = _run_git_update(server_dir)
        else:
            status = _run_installer_update(server_dir)

        if status != "ok":
            return status

        pip_status = _pip_upgrade()
        if pip_status != "ok":
            return pip_status

        new_version = _read_current_version()
        return (
            f"Update complete ({current} → {new_version}). "
            "Restart Claude Desktop (Cmd+Q, then reopen) to load the new version."
        )
