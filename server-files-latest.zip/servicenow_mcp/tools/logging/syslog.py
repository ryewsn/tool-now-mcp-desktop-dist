"""System Log Query Tools"""

from datetime import datetime, timedelta
from mcp.server.fastmcp import FastMCP
from ...core.client import get_client
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

def register_tools(mcp: FastMCP):
    """Register syslog-related tools with the MCP server."""

    @mcp.tool()
    def query_syslog(
        message_contains: str = "",
        message_contains_any: str = "",
        source: str = "",
        level: str = "",
        stack_trace: bool = False,
        limit: int = 500,
        minutes_ago: int = 15,
        execution_plan_sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Query the ServiceNow system log (syslog). Covers Business Rules, Script Includes,
        Scheduled Jobs, Flow Designer, and platform components.

        Use when:
        - Scripts throwing errors or exceptions
        - Background jobs failing silently
        - Tracing gs.info/gs.error execution flow
        - Unexpected failures with no visible error surface

        Log levels: error (most severe) → warning → info → debug (most verbose)

        CRITICAL: Use 5-15 minute windows — syslog can have millions of entries/hour.

        Key fields in results:
            level: 0=debug, 1=info, 2=warning, 3=error. Start with level=error.
            source: Script, flow, or component that logged the message.
            message: Full log text including stack traces and gs.* output.

        Args:
            message_contains: Filter by message text (single keyword or phrase).
            message_contains_any: Comma-separated keywords, OR-matched. Mutually exclusive with message_contains.
            source: Script name, flow name, or component (e.g., "Flow Designer", "MacroponentRuntimeFactory")
            level: "error", "warning", "info", or "debug"
            stack_trace: Default False. Set True to include the full Java stack trace.
            minutes_ago: Default 15, recommended 5-15.
            execution_plan_sys_id: Optional. When provided, automatically scopes the syslog
                query to the exact time window of that AI Agent execution plan, replacing
                minutes_ago. Use this instead of manually computing time ranges.
        """
        # Build query
        builder = QueryBuilder()

        if message_contains_any:
            keywords = [kw.strip() for kw in message_contains_any.split(",") if kw.strip()]
            if keywords:
                or_condition = "^OR".join(f"messageLIKE{kw}" for kw in keywords)
                builder.add_custom(or_condition)
        else:
            builder.add_like("message", message_contains)

        builder.add_like("source", source)
        builder.add_equals("level", level)

        # Get client before time filter so we can fetch the execution plan if needed
        client = get_client(instance)

        # Build time filter — scope to execution plan window if provided
        plan_scoped = False
        if execution_plan_sys_id:
            plan_builder = QueryBuilder()
            plan_builder.add_equals("sys_id", execution_plan_sys_id)
            plan_response = client.query_table(
                table_name="sn_aia_execution_plan",
                query=plan_builder.build(),
                fields=["sys_created_on", "end_time"],
                limit=1
            )
            if plan_response.get("success") and plan_response.get("result"):
                plan = plan_response["result"][0]
                start_str = plan.get("sys_created_on", "")
                end_str = plan.get("end_time", "")
                if start_str:
                    try:
                        start_dt = datetime.strptime(start_str, "%Y-%m-%d %H:%M:%S")
                        if end_str:
                            end_dt = datetime.strptime(end_str, "%Y-%m-%d %H:%M:%S")
                        else:
                            end_dt = start_dt + timedelta(minutes=15)
                        start_date = start_dt.strftime("%Y-%m-%d")
                        start_time = start_dt.strftime("%H:%M:%S")
                        end_date = end_dt.strftime("%Y-%m-%d")
                        end_time = end_dt.strftime("%H:%M:%S")
                        builder.add_custom(
                            f"sys_created_onBETWEENjavascript:gs.dateGenerate('{start_date}','{start_time}')"
                            f"@javascript:gs.dateGenerate('{end_date}','{end_time}')"
                        )
                        plan_scoped = True
                    except ValueError:
                        pass

        if not plan_scoped:
            builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "DESC")

        # Execute query
        fields = ["sys_created_on", "level", "source", "message"]
        if stack_trace:
            fields.append("stack_trace")
        response = client.query_table(
            table_name="syslog",
            query=query,
            fields=fields,
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No syslog entries found matching your criteria."

        # Format output
        output = []
        for entry in results:
            level_display = entry.get('level', 'N/A').upper() if entry.get('level') else 'N/A'
            lines = [
                f"[{entry.get('sys_created_on')}] {level_display} | {entry.get('source', 'N/A')}",
                entry.get('message', 'No message'),
            ]
            if entry.get('stack_trace'):
                lines.append(f"Stack trace:\n{entry['stack_trace']}")
            output.append("\n".join(lines))

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def query_syslog_transaction(
        url_contains: str = "",
        created_by: str = "",
        type: str = "",
        min_duration_ms: int = 0,
        limit: int = 500,
        minutes_ago: int = 15,
        instance: str = None
    ) -> str:
        """
        Query transaction-level logs (syslog_transaction). More granular than syslog —
        shows individual HTTP requests with timing breakdown. Use when syslog shows
        a failure but you need to trace the request path or identify performance bottlenecks.

        Use when:
        - Pages or API calls are slow and you need to identify bottlenecks
        - Correlating a user action with backend processing
        - Tracing a request from receipt through response

        Key fields in results:
            response_time: Total wall-clock time in ms. >1000ms warrants investigation.
            type: Transaction type (REST, Scheduler, Form, List, etc.).
            sql_time/sql_count: Time in SQL and number of queries. High sql_count (>1000) indicates missing index or GlideRecord loops.
            business_rule_time/business_rule_count: Time in Business Rules. Helps identify BR cascades.
            cpu_time: Server CPU time. Large gap vs response_time suggests I/O waits.
            system_id: Application node. Useful for node-specific performance issues.

        Args:
            url_contains: Filter by request URL path (e.g., "/api/now/table/incident")
            created_by: Filter by user who initiated the transaction
            type: Filter by transaction type (e.g., "REST", "Scheduler", "Form", "List")
            min_duration_ms: Only show transactions longer than this many milliseconds
            minutes_ago: Default 15.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_like("url", url_contains)
        builder.add_equals("sys_created_by", created_by)
        builder.add_equals("type", type)
        if min_duration_ms > 0:
            builder.add_custom(f"response_time>={min_duration_ms}")
        builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "DESC")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="syslog_transaction",
            query=query,
            fields=[
                "sys_created_on", "url", "response_time", "sys_created_by",
                "type", "sql_time", "sql_count", "business_rule_time",
                "business_rule_count", "cpu_time", "system_id"
            ],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No transaction logs found matching your criteria."

        # Format output
        output = []
        for entry in results:
            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('response_time', 'N/A')}ms | {entry.get('type', 'N/A')}\n"
                f"URL: {entry.get('url', 'N/A')}\n"
                f"Created by: {entry.get('sys_created_by', 'N/A')} | Node: {entry.get('system_id', 'N/A')}\n"
                f"SQL: {entry.get('sql_time', 'N/A')}ms ({entry.get('sql_count', 'N/A')} queries) | "
                f"BR: {entry.get('business_rule_time', 'N/A')}ms ({entry.get('business_rule_count', 'N/A')} rules) | "
                f"CPU: {entry.get('cpu_time', 'N/A')}ms"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result
