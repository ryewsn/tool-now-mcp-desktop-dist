"""UI Builder Workspace Tools — navigate workspaces, configure components, client scripts, and data broker scriptlets."""

import json
import re

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

SCRIPT_RUNNER_ERROR = "Requires the Foundry Script Runner. Use setup_script_runner to install it."
SYS_ID_RE = re.compile(r'^[0-9a-f]{32}$')


def _validate_sys_id(sys_id: str) -> str | None:
    """Return error string if sys_id is invalid, else None."""
    if not SYS_ID_RE.match(sys_id):
        return f"Invalid sys_id format: '{sys_id}'. ServiceNow sys_ids are 32 lowercase hex characters."
    return None


def _run_script(client, script: str, timeout_ms: int = 10000):
    """Execute a script via the Foundry Script Runner.

    Returns (output_lines, error_str). output_lines is the list of gs.info() output
    strings on success. error_str is non-None if the request itself failed (auth,
    HTTP error, Script Runner not installed) or if the script set result.error.
    """
    if not client._prepare_request():
        return [], "Authentication failed."
    url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
    resp = client.session.post(url, json={"script": script, "timeout_ms": timeout_ms})
    if resp.status_code == 400 and "does not represent any resource" in resp.text:
        return [], SCRIPT_RUNNER_ERROR
    if resp.status_code not in (200, 201):
        return [], format_error(resp.status_code, resp.text[:500])
    result = resp.json().get("result", {})
    output = result.get("output", [])
    script_error = result.get("error")
    if script_error:
        return output, f"Script error: {script_error}"
    return output, None


def register_tools(mcp: FastMCP):

    @mcp.tool()
    def get_workspace(
        name: str,
        instance: str = None
    ) -> str:
        """
        Find a UI Builder workspace by name (sys_ux_app_config) and list its page macroponents.

        Pages are sys_ux_macroponent records with category='page' scoped to the workspace's sys_scope
        — NOT in sys_ux_page_registry (that is for Unified Navigation routes only).

        Use when: starting any UIB session to get page sys_ids for get_uib_page and other tools.

        Args:
            name: Partial workspace name (case-insensitive LIKE)
        """
        builder = QueryBuilder()
        builder.add_like("name", name)
        query = builder.add_order_by("name", "")

        client = get_client(instance)
        ws_response = client.query_table(
            table_name="sys_ux_app_config",
            query=query,
            fields=["sys_id", "name", "landing_path", "sys_scope", "active", "sys_updated_on"],
            limit=10,
            display_value="all"
        )

        if not ws_response["success"]:
            return format_error(ws_response["status_code"], ws_response.get("error", ""))

        workspaces = ws_response["result"]
        if not workspaces:
            return f"No workspace found matching '{name}'."

        lines = []
        for ws in workspaces:
            ws_id = ws.get("sys_id", "")
            ws_name = ws.get("name", "")
            scope_field = ws.get("sys_scope", {})
            scope_id = scope_field.get("value", "") if isinstance(scope_field, dict) else scope_field
            scope_name = scope_field.get("display_value", scope_id) if isinstance(scope_field, dict) else scope_id

            lines.append(f"Workspace: {ws_name}")
            lines.append(f"  sys_id:       {ws_id}")
            lines.append(f"  scope:        {scope_name} ({scope_id})")
            lines.append(f"  landing_path: {ws.get('landing_path', '')}")
            lines.append(f"  active:       {ws.get('active', '')}")
            lines.append(f"  updated:      {ws.get('sys_updated_on', '')}")

            if scope_id:
                page_resp = client.query_table(
                    table_name="sys_ux_macroponent",
                    query=f"category=page^sys_scope={scope_id}",
                    fields=["sys_id", "name", "sys_updated_on"],
                    limit=100
                )
                if page_resp["success"] and page_resp["result"]:
                    pages = page_resp["result"]
                    lines.append(f"\n  Pages ({len(pages)}):")
                    for p in pages:
                        lines.append(f"    {p.get('name', 'N/A')}  sys_id: {p.get('sys_id', '')}")
                else:
                    lines.append(f"\n  Pages: none found in scope {scope_name}")
            lines.append("")

        return "\n".join(lines)

    @mcp.tool()
    def get_uib_page(
        macroponent_sys_id: str,
        instance: str = None
    ) -> str:
        """
        Get summary details (name, category, scope, dependencies) for a UI Builder page macroponent.

        Use when: inspecting a specific page before calling get_macroponent_composition.

        Args:
            macroponent_sys_id: sys_id of the page macroponent (from get_workspace)
        """
        err = _validate_sys_id(macroponent_sys_id)
        if err:
            return err

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_ux_macroponent",
            query=f"sys_id={macroponent_sys_id}",
            fields=["sys_id", "name", "category", "sys_scope", "sys_updated_on",
                    "macroponent_dependencies", "description"],
            limit=1,
            display_value="true"
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", ""))

        results = response["result"]
        if not results:
            return f"No page found with sys_id: {macroponent_sys_id}"

        r = results[0]
        lines = [
            f"Page: {r.get('name', 'N/A')}",
            f"  sys_id:      {macroponent_sys_id}",
            f"  category:    {r.get('category', 'N/A')}",
            f"  scope:       {r.get('sys_scope', 'N/A')}",
            f"  updated:     {r.get('sys_updated_on', 'N/A')}",
        ]
        if r.get('description'):
            lines.append(f"  description: {r.get('description')}")
        deps = r.get('macroponent_dependencies', '')
        if deps:
            lines.append(f"  dependencies: {deps}")
        lines.append("")
        lines.append("Use get_macroponent_composition to inspect the component tree.")
        return "\n".join(lines)

    @mcp.tool()
    def get_macroponent_composition(
        macroponent_sys_id: str,
        instance: str = None
    ) -> str:
        """
        Parse a UI Builder macroponent's composition tree server-side, returning up to 50 elements.

        The composition field (80–380 KB) causes context overflow if read directly. Returns
        elementId, label, defType, and propertyValues bindings per element. Binding types:
          JSON_LITERAL   — static value: {"type":"JSON_LITERAL","value":"My Title"}
          ELEMENT_BINDING — address path: {"type":"ELEMENT_BINDING","binding":{"address":[...]}}

        Requires the Foundry Script Runner (setup_script_runner).

        Use when: finding elementIds and binding details before update_component_property_binding.

        Args:
            macroponent_sys_id: sys_id of the sys_ux_macroponent record
        """
        err = _validate_sys_id(macroponent_sys_id)
        if err:
            return err

        client = get_client(instance)

        script = f"""
var gr = new GlideRecord('sys_ux_macroponent');
if (!gr.get('{macroponent_sys_id}')) {{
    gs.info('not_found');
}} else {{
    var raw = gr.getValue('composition');
    if (!raw) {{ gs.info('empty_composition'); }}
    else {{
        var comp;
        try {{ comp = JSON.parse(raw); }} catch(e) {{ gs.info('parse_error:' + e); }}
        if (comp) {{
            var elements = [];
            var LIMIT = 50;
            function collectElements(node, depth) {{
                if (!node || typeof node !== 'object' || depth > 10) return;
                if (node.elementId) {{
                    elements.push({{
                        elementId: node.elementId,
                        elementLabel: node.elementLabel || '',
                        defType: (node.definition && node.definition.type) ? node.definition.type : '',
                        defId: (node.definition && node.definition.id) ? node.definition.id : '',
                        propertyValues: node.propertyValues || {{}}
                    }});
                }}
                var children = node.items || (node.overrides && node.overrides.composition) || [];
                for (var i = 0; i < children.length && elements.length < LIMIT; i++) {{
                    collectElements(children[i], depth + 1);
                }}
            }}
            var roots = Object.keys(comp);
            for (var r = 0; r < roots.length && elements.length < LIMIT; r++) {{
                collectElements(comp[roots[r]], 0);
            }}
            var total = elements.length;
            gs.info('COUNT=' + total);
            for (var i = 0; i < elements.length; i++) {{
                gs.info('ELEMENT:' + JSON.stringify(elements[i]));
            }}
            if (total >= LIMIT) {{ gs.info('TRUNCATED'); }}
        }}
    }}
}}
"""
        output, err = _run_script(client, script)
        if err:
            return err

        if "not_found" in output:
            return f"Macroponent not found with sys_id: {macroponent_sys_id}"
        if "empty_composition" in output:
            return f"Macroponent {macroponent_sys_id} has no composition."
        if any("parse_error" in l for l in output):
            return "Composition JSON is malformed. Inspect the record via get_record."

        count_line = next((l for l in output if l.startswith("COUNT=")), None)
        count = int(count_line.split("=")[1]) if count_line else 0
        truncated = any(l == "TRUNCATED" for l in output)

        elements = []
        for line in output:
            if line.startswith("ELEMENT:"):
                try:
                    elements.append(json.loads(line[8:]))
                except Exception:
                    pass

        if not elements:
            return f"No component elements found in composition for {macroponent_sys_id}."

        lines = [f"Macroponent {macroponent_sys_id} — composition ({count} element(s) shown):\n"]
        for el in elements:
            pv = el.get("propertyValues", {})
            pv_summary = []
            for k, v in list(pv.items())[:5]:
                t = v.get("type", "?") if isinstance(v, dict) else "?"
                if t == "ELEMENT_BINDING":
                    addr = v.get("binding", {}).get("address", [])
                    pv_summary.append(f"{k}→ELEMENT_BINDING({addr})")
                else:
                    val = v.get("value", "?") if isinstance(v, dict) else v
                    pv_summary.append(f"{k}={repr(str(val)[:30])}")
            lines.append(f"elementId:    {el.get('elementId', 'N/A')}")
            lines.append(f"  label:      {el.get('elementLabel', '')}")
            lines.append(f"  type:       {el.get('defType', 'N/A')}")
            if pv_summary:
                lines.append(f"  props:      {', '.join(pv_summary)}")
            lines.append("")

        if truncated:
            lines.append(f"NOTE: Showing first 50 elements — composition has {count}+ total. Use element_id filters or get_record for full access.")

        return "\n".join(lines)

    @mcp.tool()
    def update_component_property_binding(
        macroponent_sys_id: str,
        element_id: str,
        property_name: str,
        binding_type: str,
        binding_value: str,
        instance: str = None
    ) -> str:
        """
        Set a component's propertyValues binding in a UI Builder macroponent composition.

        Recursively finds the element by elementId and writes propertyValues[property_name].
        Requires the Foundry Script Runner (setup_script_runner).

        Use when: changing a property after get_macroponent_composition revealed valid elementIds.

        Args:
            macroponent_sys_id: sys_id of the sys_ux_macroponent record
            element_id: elementId from get_macroponent_composition
            property_name: property to set (e.g. "title", "items", "isHidden")
            binding_type: "JSON_LITERAL" (static value) or "ELEMENT_BINDING" (address path)
            binding_value: JSON-encoded value for JSON_LITERAL, or JSON array for ELEMENT_BINDING
                e.g. JSON_LITERAL: '"My Title"' or 'true' or '42'
                e.g. ELEMENT_BINDING: '["myCSP","value"]'
        """
        err = _validate_sys_id(macroponent_sys_id)
        if err:
            return err
        if binding_type not in ("JSON_LITERAL", "ELEMENT_BINDING"):
            return f"binding_type must be 'JSON_LITERAL' or 'ELEMENT_BINDING', got '{binding_type}'."
        try:
            parsed_value = json.loads(binding_value)
        except json.JSONDecodeError as e:
            return f"Invalid JSON in binding_value: {e}"
        if binding_type == "ELEMENT_BINDING" and not isinstance(parsed_value, list):
            return "For ELEMENT_BINDING, binding_value must be a JSON array (the address path)."

        confirmation_err = require_instance_confirmation(instance, f"update macroponent {macroponent_sys_id} composition")
        if confirmation_err:
            return confirmation_err

        client = get_client(instance)

        if binding_type == "JSON_LITERAL":
            new_pv_json = json.dumps({"type": "JSON_LITERAL", "value": parsed_value})
        else:
            new_pv_json = json.dumps({"type": "ELEMENT_BINDING", "binding": {"address": parsed_value}})

        prop_json = json.dumps(property_name)
        elem_json = json.dumps(element_id)

        script = f"""
var gr = new GlideRecord('sys_ux_macroponent');
if (!gr.get('{macroponent_sys_id}')) {{
    gs.info('not_found');
}} else {{
    var raw = gr.getValue('composition');
    var comp;
    try {{ comp = JSON.parse(raw || '{{}}'); }} catch(e) {{ gs.info('parse_error:' + e); }}
    if (comp) {{
        var targetId = {elem_json};
        var propName = {prop_json};
        var newPv = {new_pv_json};
        var found = false;
        function patchElement(node) {{
            if (!node || typeof node !== 'object') return;
            if (node.elementId === targetId) {{
                if (!node.propertyValues) node.propertyValues = {{}};
                node.propertyValues[propName] = newPv;
                found = true;
                return;
            }}
            var children = node.items || (node.overrides && node.overrides.composition) || [];
            for (var i = 0; i < children.length && !found; i++) patchElement(children[i]);
        }}
        var roots = Object.keys(comp);
        for (var r = 0; r < roots.length && !found; r++) patchElement(comp[roots[r]]);
        if (!found) {{
            gs.info('element_not_found');
        }} else {{
            gr.setValue('composition', JSON.stringify(comp));
            gr.update();
            gs.info('updated:true');
        }}
    }}
}}
"""
        output, err = _run_script(client, script)
        if err:
            return err

        if "not_found" in output:
            return f"Macroponent not found with sys_id: {macroponent_sys_id}"
        if "element_not_found" in output:
            return (f"Component '{element_id}' not found in composition. "
                    f"Use get_macroponent_composition to list valid elementId values.")
        if any("parse_error" in l for l in output):
            return "Composition JSON is malformed. Inspect via get_record."
        if "updated:true" not in output:
            return f"Update may have failed. Script output: {output}"

        return (
            f"Composition binding updated.\n"
            f"  Macroponent: {macroponent_sys_id}\n"
            f"  elementId:   {element_id}\n"
            f"  property:    {property_name}\n"
            f"  binding:     {binding_type} = {binding_value}"
        )

    @mcp.tool()
    def get_client_state_parameters(
        macroponent_sys_id: str,
        instance: str = None
    ) -> str:
        """
        List client state parameters (sys_ux_macroponent.state_properties) for a macroponent.

        Returns name, fieldType, id, initialValue, and description for each CSP.
        Requires the Foundry Script Runner (setup_script_runner).

        Use when: inspecting existing CSPs before create_client_state_parameter or update_client_state_parameter.

        Args:
            macroponent_sys_id: sys_id of the sys_ux_macroponent record
        """
        err = _validate_sys_id(macroponent_sys_id)
        if err:
            return err

        client = get_client(instance)
        script = f"""
var gr = new GlideRecord('sys_ux_macroponent');
if (!gr.get('{macroponent_sys_id}')) {{
    gs.info('not_found');
}} else {{
    var raw = gr.getValue('state_properties');
    if (!raw || raw === '[]' || raw === 'null') {{ gs.info('empty_state'); }}
    else {{
        var csps;
        try {{ csps = JSON.parse(raw); }} catch(e) {{ gs.info('parse_error:' + e); }}
        if (csps) {{
            gs.info('COUNT=' + csps.length);
            for (var i = 0; i < csps.length; i++) {{
                gs.info('CSP:' + JSON.stringify({{
                    name: csps[i].name || '',
                    fieldType: csps[i].fieldType || '',
                    id: csps[i].id || '',
                    initialValue: csps[i].initialValue || {{}},
                    description: csps[i].description || ''
                }}));
            }}
        }}
    }}
}}
"""
        output, err = _run_script(client, script)
        if err:
            return err
        if "not_found" in output:
            return f"Macroponent not found with sys_id: {macroponent_sys_id}"
        if "empty_state" in output:
            return f"Macroponent {macroponent_sys_id} has no client state parameters."

        csps = []
        for line in output:
            if line.startswith("CSP:"):
                try:
                    csps.append(json.loads(line[4:]))
                except Exception:
                    pass

        if not csps:
            return f"No client state parameters found for {macroponent_sys_id}."

        lines = [f"Macroponent {macroponent_sys_id} — {len(csps)} CSP(s):\n"]
        for csp in csps:
            lines.append(f"name:         {csp.get('name', 'N/A')}")
            lines.append(f"  fieldType:    {csp.get('fieldType', 'N/A')}")
            lines.append(f"  id:           {csp.get('id', 'N/A')}")
            iv = csp.get('initialValue', {})
            lines.append(f"  initialValue: {iv}")
            if csp.get('description'):
                lines.append(f"  description:  {csp['description']}")
            lines.append("")
        return "\n".join(lines)

    @mcp.tool()
    def create_client_state_parameter(
        macroponent_sys_id: str,
        name: str,
        field_type: str,
        initial_value: str,
        description: str = "",
        instance: str = None
    ) -> str:
        """
        Add a new client state parameter to a UI Builder macroponent's state_properties.

        Requires the Foundry Script Runner (setup_script_runner).

        Use when: adding a CSP that doesn't yet exist (name must be unique on this macroponent).

        Args:
            macroponent_sys_id: sys_id of the sys_ux_macroponent record
            name: CSP name — must be unique within this macroponent
            field_type: string | boolean | json | number | array
            initial_value: JSON-encoded initial value matching field_type, e.g. '""', 'false', '0', '[]'
            description: optional description
        """
        err = _validate_sys_id(macroponent_sys_id)
        if err:
            return err
        if field_type not in ("string", "boolean", "json", "number", "array"):
            return f"field_type must be one of: string, boolean, json, number, array. Got '{field_type}'."
        try:
            parsed_initial = json.loads(initial_value)
        except json.JSONDecodeError as e:
            return f"Invalid JSON in initial_value: {e}"

        confirmation_err = require_instance_confirmation(instance, f"create CSP on macroponent {macroponent_sys_id}")
        if confirmation_err:
            return confirmation_err

        client = get_client(instance)

        new_csp = {
            "name": name,
            "fieldType": field_type,
            "id": "",
            "initialValue": {"type": "JSON_LITERAL", "value": parsed_initial},
            "description": description
        }
        new_csp_json = json.dumps(new_csp)
        name_json = json.dumps(name)

        script = f"""
var gr = new GlideRecord('sys_ux_macroponent');
if (!gr.get('{macroponent_sys_id}')) {{
    gs.info('not_found');
}} else {{
    var raw = gr.getValue('state_properties');
    var csps;
    try {{ csps = JSON.parse(raw || '[]'); }} catch(e) {{ gs.info('parse_error:' + e); }}
    if (csps) {{
        var isDuplicate = false;
        for (var i = 0; i < csps.length; i++) {{
            if (csps[i].name === {name_json}) {{ isDuplicate = true; break; }}
        }}
        if (isDuplicate) {{
            gs.info('duplicate_name');
        }} else {{
            csps.push({new_csp_json});
            gr.setValue('state_properties', JSON.stringify(csps));
            gr.update();
            gs.info('created:true');
        }}
    }}
}}
"""
        output, err = _run_script(client, script)
        if err:
            return err
        if "not_found" in output:
            return f"Macroponent not found with sys_id: {macroponent_sys_id}"
        if "duplicate_name" in output:
            return (f"A CSP named '{name}' already exists on macroponent {macroponent_sys_id}. "
                    f"Use update_client_state_parameter to modify it.")
        if "created:true" not in output:
            return f"Create may have failed. Script output: {output}"

        return (
            f"Client state parameter created.\n"
            f"  Macroponent: {macroponent_sys_id}\n"
            f"  name:        {name}\n"
            f"  fieldType:   {field_type}\n"
            f"  initialValue: {initial_value}"
        )

    @mcp.tool()
    def update_client_state_parameter(
        macroponent_sys_id: str,
        csp_name: str,
        patch: str,
        instance: str = None
    ) -> str:
        """
        Merge a patch into an existing client state parameter in a macroponent's state_properties.

        Finds the CSP by name; only specified keys are changed. Requires the Foundry Script Runner (setup_script_runner).

        Use when: modifying an existing CSP after get_client_state_parameters revealed its current values.

        Args:
            macroponent_sys_id: sys_id of the sys_ux_macroponent record
            csp_name: name of the CSP to update (from get_client_state_parameters)
            patch: JSON object of keys to update, e.g. '{"fieldType":"boolean"}' or '{"description":"..."}'
        """
        err = _validate_sys_id(macroponent_sys_id)
        if err:
            return err
        try:
            patch_dict = json.loads(patch)
        except json.JSONDecodeError as e:
            return f"Invalid JSON in patch: {e}"
        if not isinstance(patch_dict, dict):
            return "patch must be a JSON object."

        confirmation_err = require_instance_confirmation(instance, f"update CSP on macroponent {macroponent_sys_id}")
        if confirmation_err:
            return confirmation_err

        client = get_client(instance)
        patch_json = json.dumps(patch_dict)
        name_json = json.dumps(csp_name)

        script = f"""
var gr = new GlideRecord('sys_ux_macroponent');
if (!gr.get('{macroponent_sys_id}')) {{
    gs.info('not_found');
}} else {{
    var raw = gr.getValue('state_properties');
    var csps;
    try {{ csps = JSON.parse(raw || '[]'); }} catch(e) {{ gs.info('parse_error:' + e); }}
    if (csps) {{
        var found = false;
        var patch = {patch_json};
        for (var i = 0; i < csps.length; i++) {{
            if (csps[i].name === {name_json}) {{
                for (var k in patch) {{ csps[i][k] = patch[k]; }}
                found = true;
                break;
            }}
        }}
        if (!found) {{ gs.info('csp_not_found'); }}
        else {{
            gr.setValue('state_properties', JSON.stringify(csps));
            gr.update();
            gs.info('updated:true');
        }}
    }}
}}
"""
        output, err = _run_script(client, script)
        if err:
            return err
        if "not_found" in output:
            return f"Macroponent not found with sys_id: {macroponent_sys_id}"
        if "csp_not_found" in output:
            return f"No CSP named '{csp_name}' found on macroponent {macroponent_sys_id}."
        if "updated:true" not in output:
            return f"Update may have failed. Script output: {output}"

        return (
            f"Client state parameter updated.\n"
            f"  Macroponent: {macroponent_sys_id}\n"
            f"  CSP name:    {csp_name}\n"
            f"  Patched keys: {list(patch_dict.keys())}"
        )

    @mcp.tool()
    def get_client_scripts(
        macroponent_sys_id: str,
        instance: str = None
    ) -> str:
        """
        List client scripts (sys_ux_client_script) attached to a UI Builder macroponent.

        Returns name, type (default=event-driven, transform=property-compute), target, and sys_id.

        Use when: finding which scripts exist before calling get_client_script for the full body.

        Args:
            macroponent_sys_id: sys_id of the sys_ux_macroponent record
        """
        err = _validate_sys_id(macroponent_sys_id)
        if err:
            return err

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_ux_client_script",
            query=f"macroponent={macroponent_sys_id}",
            fields=["sys_id", "name", "type", "target", "sys_updated_on"],
            limit=100
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", ""))

        results = response["result"]
        if not results:
            return f"No client scripts found for macroponent {macroponent_sys_id}."

        lines = [f"Client scripts for macroponent {macroponent_sys_id} ({len(results)}):\n"]
        for r in results:
            lines.append(f"{r.get('name', 'N/A')}")
            lines.append(f"  sys_id:   {r.get('sys_id', '')}")
            lines.append(f"  type:     {r.get('type', 'N/A')}")
            lines.append(f"  target:   {r.get('target', 'N/A')}")
            lines.append(f"  updated:  {r.get('sys_updated_on', '')}")
            lines.append("")
        return "\n".join(lines)

    @mcp.tool()
    def get_client_script(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Get the full script body and metadata for a single sys_ux_client_script record.

        Use when: reading the current script content before update_client_script.

        Args:
            sys_id: sys_id of the sys_ux_client_script record
        """
        err = _validate_sys_id(sys_id)
        if err:
            return err

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_ux_client_script",
            query=f"sys_id={sys_id}",
            fields=["sys_id", "name", "type", "target", "script", "script_api_version",
                    "macroponent", "sys_updated_on"],
            limit=1,
            display_value="true"
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", ""))

        results = response["result"]
        if not results:
            return f"Client script not found with sys_id: {sys_id}"

        r = results[0]
        return "\n".join([
            f"Client Script: {r.get('name', 'N/A')}",
            f"  sys_id:      {sys_id}",
            f"  type:        {r.get('type', 'N/A')}",
            f"  target:      {r.get('target', 'N/A')}",
            f"  macroponent: {r.get('macroponent', 'N/A')}",
            f"  api_version: {r.get('script_api_version', 'N/A')}",
            f"  updated:     {r.get('sys_updated_on', '')}",
            "",
            "Script:",
            r.get('script', ''),
        ])

    @mcp.tool()
    def create_client_script(
        macroponent_sys_id: str,
        name: str,
        script: str,
        script_type: str = "default",
        scope_sys_id: str = "",
        instance: str = None
    ) -> str:
        """
        Create a new client script (sys_ux_client_script) for a UI Builder macroponent.

        sys_ux_client_script extends sys_metadata — uses server-side GlideRecord via glide_write.
        Requires the Foundry Script Runner (setup_script_runner).

        Use when: adding a new script that doesn't yet exist (use update_client_script to change an existing one).

        Args:
            macroponent_sys_id: sys_id of the sys_ux_macroponent to attach this script to
            name: script name (e.g. "Set initial data", "button_1/label")
            script: full script body
            script_type: "default" (event-driven; handler({api,event,helpers})) or
                         "transform" (property-compute; evaluateProperty({api,helpers}) must return value)
            scope_sys_id: sys_id of the target application scope (default: Global).
        """
        err = _validate_sys_id(macroponent_sys_id)
        if err:
            return err
        if script_type not in ("default", "transform"):
            return f"script_type must be 'default' or 'transform', got '{script_type}'."

        confirmation_err = require_instance_confirmation(instance, "create client script")
        if confirmation_err:
            return confirmation_err

        client = get_client(instance)
        data = {
            "macroponent": macroponent_sys_id,
            "name": name,
            "script": script,
            "type": script_type,
            "target": "macroponent",
        }
        response = client.glide_write(table="sys_ux_client_script", operation="insert", data=data, scope_sys_id=scope_sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", ""))

        new_sys_id = response.get("result", {}).get("sys_id", "unknown")
        return (
            f"Client script created.\n"
            f"  sys_id:      {new_sys_id}\n"
            f"  name:        {name}\n"
            f"  type:        {script_type}\n"
            f"  macroponent: {macroponent_sys_id}"
        )

    @mcp.tool()
    def update_client_script(
        sys_id: str,
        script: str,
        name: str = "",
        instance: str = None
    ) -> str:
        """
        Replace the script body (and optionally the name) of an existing sys_ux_client_script.

        sys_ux_client_script extends sys_metadata — uses server-side GlideRecord via glide_write.
        Requires the Foundry Script Runner (setup_script_runner).

        Use when: replacing script content after get_client_script confirmed the current body.

        Args:
            sys_id: sys_id of the sys_ux_client_script record
            script: new script body (full replacement)
            name: new name — omit to keep current name
        """
        err = _validate_sys_id(sys_id)
        if err:
            return err

        confirmation_err = require_instance_confirmation(instance, "update client script")
        if confirmation_err:
            return confirmation_err

        client = get_client(instance)
        data = {"script": script}
        if name:
            data["name"] = name

        response = client.glide_write(table="sys_ux_client_script", operation="update", data=data, sys_id=sys_id)

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", ""))

        return (
            f"Client script updated.\n"
            f"  sys_id: {sys_id}"
            + (f"\n  name:   {name}" if name else "")
        )

    @mcp.tool()
    def get_data_broker_scriptlets(
        scope: str = "",
        name_filter: str = "",
        instance: str = None
    ) -> str:
        """
        List data broker scriptlets (sys_ux_data_broker_scriptlet) filtered by scope and name.

        Scriptlets are the server-side scripts powering UIB data resources, identified by api_name (scope.name format).

        Use when: finding scriptlets before get_data_broker_scriptlet to retrieve the full script body.

        Args:
            scope: partial application scope name filter (e.g. "Service Operations")
            name_filter: partial scriptlet name filter
        """
        builder = QueryBuilder()
        builder.add_like("sys_scope.name", scope)
        builder.add_like("name", name_filter)
        query = builder.add_order_by("name", "")

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_ux_data_broker_scriptlet",
            query=query,
            fields=["sys_id", "name", "api_name", "mutates_server_data", "sys_updated_on"],
            limit=100
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", ""))

        results = response["result"]
        if not results:
            filters = []
            if scope:
                filters.append(f"scope='{scope}'")
            if name_filter:
                filters.append(f"name='{name_filter}'")
            suffix = f" matching {', '.join(filters)}" if filters else ""
            return f"No data broker scriptlets found{suffix}."

        lines = [f"Data broker scriptlets ({len(results)}):\n"]
        for r in results:
            mutates = "✓ mutates" if r.get("mutates_server_data") == "true" else "read-only"
            lines.append(f"{r.get('name', 'N/A')}")
            lines.append(f"  sys_id:   {r.get('sys_id', '')}")
            lines.append(f"  api_name: {r.get('api_name', 'N/A')}")
            lines.append(f"  type:     {mutates}")
            lines.append(f"  updated:  {r.get('sys_updated_on', '')}")
            lines.append("")
        return "\n".join(lines)

    @mcp.tool()
    def get_data_broker_scriptlet(
        sys_id_or_api_name: str,
        instance: str = None
    ) -> str:
        """
        Get the full script body, output_schema, and metadata for a single data broker scriptlet.

        Use when: reading a scriptlet's current content before update_data_broker_scriptlet.

        Args:
            sys_id_or_api_name: sys_id (32-char hex) or api_name (e.g. "sn_sow.Fetch alerts")
        """
        is_sys_id = bool(SYS_ID_RE.match(sys_id_or_api_name))
        query = f"sys_id={sys_id_or_api_name}" if is_sys_id else f"api_name={sys_id_or_api_name}"

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_ux_data_broker_scriptlet",
            query=query,
            fields=["sys_id", "name", "api_name", "script", "output_schema",
                    "props", "mutates_server_data", "sys_updated_on"],
            limit=1
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", ""))

        results = response["result"]
        if not results:
            return f"Data broker scriptlet not found with identifier: {sys_id_or_api_name}"

        r = results[0]
        mutates = "Yes" if r.get("mutates_server_data") == "true" else "No"
        return "\n".join([
            f"Data Broker Scriptlet: {r.get('name', 'N/A')}",
            f"  sys_id:       {r.get('sys_id', '')}",
            f"  api_name:     {r.get('api_name', 'N/A')}",
            f"  mutates_data: {mutates}",
            f"  updated:      {r.get('sys_updated_on', '')}",
            "",
            "Output schema:",
            r.get('output_schema', '(none)') or '(none)',
            "",
            "Script:",
            r.get('script', ''),
        ])

    @mcp.tool()
    def update_data_broker_scriptlet(
        sys_id: str,
        script: str,
        instance: str = None
    ) -> str:
        """
        Replace the script body of a data broker scriptlet (sys_ux_data_broker_scriptlet).

        Extends sys_metadata — uses server-side GlideRecord via glide_write.
        Requires the Foundry Script Runner (setup_script_runner).

        Use when: updating server-side scriptlet logic after get_data_broker_scriptlet confirmed the current content.

        Args:
            sys_id: sys_id of the sys_ux_data_broker_scriptlet record
            script: new script body (full replacement)
        """
        err = _validate_sys_id(sys_id)
        if err:
            return err

        confirmation_err = require_instance_confirmation(instance, "update data broker scriptlet")
        if confirmation_err:
            return confirmation_err

        client = get_client(instance)
        response = client.glide_write(
            table="sys_ux_data_broker_scriptlet",
            operation="update",
            data={"script": script},
            sys_id=sys_id
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", ""))

        return f"Data broker scriptlet updated.\n  sys_id: {sys_id}"

    @mcp.tool()
    def list_uib_components(
        filter: str = "",
        instance: str = None
    ) -> str:
        """
        List available UI Builder component tags from sys_ux_lib_component.

        Returns tags (e.g. "now-button") usable in composition definitions.
        Common components and key props:
          now-button        — label, variant(primary|secondary|tertiary|warning|danger), size(sm|md|lg), icon, disabled
          now-heading       — label, level(1-6), variant(display|h1-h6|body-md/sm/xs)
          now-icon          — icon(e.g. "plus-fill"), size(sm|md|lg), variant
          now-badge         — label, variant(primary|secondary|positive|negative|warning)
          now-alert         — status(info|success|warning|critical), content, dismissible
          now-card          — header via now-card-header, footer via now-card-footer
          now-dropdown      — items(array), placeholder, size(sm|md|lg)
          now-input         — value, placeholder, type(text|number|email), readonly
          now-textarea      — value, placeholder, rows, readonly
          now-checkbox      — checked, label, disabled
          now-toggle        — checked, label, disabled
          now-chart-bar     — data(array), xAxisField, yAxisField
          now-chart-donut-pie — data(array), labelField, valueField
          now-chart-timeseries — series(array), xAxisField
          now-grid          — columns, gap
          now-accordion     — contains now-accordion-item children
          now-avatar        — name, size(sm|md|lg), src
          now-empty-state   — label, description, icon
          now-breadcrumbs   — items(array of {label,href})
          now-tabs          — items(array of {label,id})
        Full schemas: developer.servicenow.com/dev.do#!/reference/next-experience/components

        Args:
            filter: partial tag name (e.g. "chart" → all now-chart-* components)
        """
        builder = QueryBuilder()
        builder.add_like("tag", filter)
        query = builder.add_order_by("tag", "")

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_ux_lib_component",
            query=query,
            fields=["sys_id", "tag", "sys_name", "source_script_name", "deprecated"],
            limit=200
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", ""))

        results = response["result"]
        if not results:
            return f"No components found" + (f" matching '{filter}'." if filter else ".")

        lines = [f"UI Builder components ({len(results)}):\n"]
        for r in results:
            deprecated = " [DEPRECATED]" if r.get("deprecated") == "true" else ""
            pkg = r.get("source_script_name", "")
            lines.append(f"{r.get('tag', 'N/A')}{deprecated}")
            if pkg and pkg != r.get('tag'):
                lines.append(f"  package: {pkg}")
        lines.append("")
        lines.append("For full prop schemas: developer.servicenow.com/dev.do#!/reference/next-experience/components")
        return "\n".join(lines)
