"""UI Builder Macroponent Tools — inspect and edit sys_ux_macroponent data resources."""

import json
import re

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.formatters import format_error


def register_tools(mcp: FastMCP):

    @mcp.tool()
    def get_macroponent_data_resources(
        macroponent_sys_id: str,
        instance: str = None
    ) -> str:
        """
        Parse and return data resource definitions from a UI Builder macroponent (sys_ux_macroponent.data).

        Fetches server-side to avoid context overflow; returns elementId, type, inputValues, and
        eventMappings for each resource. Requires the Foundry Script Runner (setup_script_runner).

        Use when: inspecting data resources before patching with update_macroponent_data_resource.

        Args:
            macroponent_sys_id: sys_id of the sys_ux_macroponent record
        """
        if not re.match(r'^[0-9a-f]{32}$', macroponent_sys_id):
            return f"Invalid sys_id format: '{macroponent_sys_id}'. ServiceNow sys_ids are 32 lowercase hex characters."

        client = get_client(instance)
        if not client._prepare_request():
            return "Authentication failed."

        script = f"""
var gr = new GlideRecord('sys_ux_macroponent');
if (!gr.get('{macroponent_sys_id}')) {{
    gs.info('not_found');
}} else {{
    var raw = gr.getValue('data');
    if (!raw) {{
        gs.info('empty_data');
    }} else {{
        var resources;
        try {{ resources = JSON.parse(raw); }} catch(e) {{ gs.info('parse_error:' + e); }}
        if (resources) {{
            gs.info('count=' + resources.length);
            for (var i = 0; i < resources.length; i++) {{
                var r = resources[i];
                gs.info('RESOURCE:' + JSON.stringify({{
                    elementId: r.elementId || '',
                    type: (r.definition && r.definition.type) ? r.definition.type : '',
                    readEvaluationMode: r.readEvaluationMode || '',
                    inputValues: r.inputValues || {{}},
                    eventMappings: r.eventMappings || []
                }}));
            }}
        }}
    }}
}}
"""

        url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
        response = client.session.post(url, json={"script": script})

        if response.status_code == 400 and "does not represent any resource" in response.text:
            return "Requires the Foundry Script Runner. Use setup_script_runner to install it."
        if response.status_code not in (200, 201):
            return format_error(response.status_code, response.text[:500])

        result = response.json().get("result", {})
        output = result.get("output", [])
        error = result.get("error")

        if error:
            return f"Script error: {error}"
        if "not_found" in output:
            return f"Macroponent not found with sys_id: {macroponent_sys_id}"
        if "empty_data" in output:
            return f"Macroponent {macroponent_sys_id} has no data field content."
        if any("parse_error" in line for line in output):
            return f"Failed to parse macroponent data field: {[l for l in output if 'parse_error' in l]}"

        count_line = next((l for l in output if l.startswith("count=")), None)
        count = int(count_line.split("=")[1]) if count_line else 0

        resources = []
        for line in output:
            if line.startswith("RESOURCE:"):
                try:
                    resources.append(json.loads(line[len("RESOURCE:"):]))
                except Exception:
                    pass

        if not resources:
            return f"No data resources found in macroponent {macroponent_sys_id}."

        lines = [f"Macroponent {macroponent_sys_id} — {count} data resource(s):\n"]
        for r in resources:
            lines.append(f"elementId: {r.get('elementId', 'N/A')}")
            lines.append(f"  type:               {r.get('type', 'N/A')}")
            lines.append(f"  readEvaluationMode: {r.get('readEvaluationMode', 'N/A')}")
            input_vals = r.get('inputValues', {})
            if input_vals:
                lines.append(f"  inputValues:")
                for k, v in input_vals.items():
                    lines.append(f"    {k}: {v}")
            event_maps = r.get('eventMappings', [])
            if event_maps:
                lines.append(f"  eventMappings: {event_maps}")
            lines.append("")

        return "\n".join(lines)

    @mcp.tool()
    def update_macroponent_data_resource(
        macroponent_sys_id: str,
        element_id: str,
        input_values_patch: str,
        instance: str = None
    ) -> str:
        """
        Atomically merge input_values_patch into a single data resource's inputValues in sys_ux_macroponent.data.

        Finds the resource by elementId, merges only the specified keys, and writes the whole field
        back. Other resources and unspecified keys are preserved.
        Requires the Foundry Script Runner (setup_script_runner).

        Use when: patching a data resource after get_macroponent_data_resources revealed the elementId.

        Args:
            macroponent_sys_id: sys_id of the sys_ux_macroponent record
            element_id: elementId of the target resource (from get_macroponent_data_resources)
            input_values_patch: JSON object of inputValues keys to update, e.g. '{"encodedQuery": "active=true"}'
        """
        if not re.match(r'^[0-9a-f]{32}$', macroponent_sys_id):
            return f"Invalid sys_id format: '{macroponent_sys_id}'. ServiceNow sys_ids are 32 lowercase hex characters."
        if "'" in element_id or "\\" in element_id:
            return "element_id contains unsafe characters (single quotes or backslashes are not allowed)."

        try:
            patch = json.loads(input_values_patch)
        except json.JSONDecodeError as e:
            return f"Invalid JSON in input_values_patch: {e}"
        if not isinstance(patch, dict):
            return "input_values_patch must be a JSON object."

        confirmation_error = require_instance_confirmation(instance, f"update macroponent {macroponent_sys_id}")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        if not client._prepare_request():
            return "Authentication failed."

        patch_json = json.dumps(patch)

        script = f"""
var gr = new GlideRecord('sys_ux_macroponent');
if (!gr.get('{macroponent_sys_id}')) {{
    gs.info('not_found');
}} else {{
    var raw = gr.getValue('data');
    var data;
    try {{ data = JSON.parse(raw || '[]'); }} catch(e) {{ gs.info('parse_error:' + e); }}
    if (data) {{
        var found = false;
        for (var i = 0; i < data.length; i++) {{
            if (data[i].elementId === '{element_id}') {{
                var patch = {patch_json};
                var inputValues = data[i].inputValues || {{}};
                for (var key in patch) {{ inputValues[key] = patch[key]; }}
                data[i].inputValues = inputValues;
                found = true;
                break;
            }}
        }}
        if (!found) {{
            gs.info('element_not_found');
        }} else {{
            gr.setValue('data', JSON.stringify(data));
            gr.update();
            gs.info('updated:true');
        }}
    }}
}}
"""

        url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
        response = client.session.post(url, json={"script": script})

        if response.status_code == 400 and "does not represent any resource" in response.text:
            return "Requires the Foundry Script Runner. Use setup_script_runner to install it."
        if response.status_code not in (200, 201):
            return format_error(response.status_code, response.text[:500])

        result = response.json().get("result", {})
        output = result.get("output", [])
        error = result.get("error")

        if error:
            return f"Script error: {error}"
        if "not_found" in output:
            return f"Macroponent not found with sys_id: {macroponent_sys_id}"
        if "element_not_found" in output:
            return f"No resource with elementId '{element_id}' found in macroponent {macroponent_sys_id}."
        if any("parse_error" in line for line in output):
            return f"Failed to parse macroponent data field: {[l for l in output if 'parse_error' in l]}"
        if "updated:true" not in output:
            return f"Update may have failed. Script output: {output}"

        return (
            f"Macroponent data resource updated.\n"
            f"  Macroponent: {macroponent_sys_id}\n"
            f"  elementId:   {element_id}\n"
            f"  Patched keys: {list(patch.keys())}"
        )

    @mcp.tool()
    def find_macroponent_bindings(
        scriptlet_sys_id: str,
        instance: str = None
    ) -> str:
        """
        Scan all sys_ux_macroponent.data records for bindings referencing a given scriptlet sys_id.

        Returns macroponent name/sys_id, elementId, inputKey, and address for each match.
        May be slow on large instances. Requires the Foundry Script Runner (setup_script_runner).

        Use when: the UI Builder binding picker doesn't surface all valid binding address patterns.

        Args:
            scriptlet_sys_id: sys_id of the sys_ux_data_broker_scriptlet to search for
        """
        if not re.match(r'^[0-9a-f]{32}$', scriptlet_sys_id):
            return f"Invalid sys_id format: '{scriptlet_sys_id}'. ServiceNow sys_ids are 32 lowercase hex characters."

        client = get_client(instance)
        if not client._prepare_request():
            return "Authentication failed."

        script = f"""
var results = [];
var gr = new GlideRecord('sys_ux_macroponent');
gr.query();
while (gr.next()) {{
    __checkTimeout();
    var raw = gr.getValue('data');
    if (!raw) continue;
    var data;
    try {{ data = JSON.parse(raw); }} catch(e) {{ continue; }}
    for (var i = 0; i < data.length; i++) {{
        var r = data[i];
        var inputValues = r.inputValues || {{}};
        for (var key in inputValues) {{
            var v = inputValues[key];
            if (v && typeof v === 'object' && v.value && v.value.address) {{
                var addrStr = JSON.stringify(v.value.address);
                if (addrStr.indexOf('{scriptlet_sys_id}') !== -1) {{
                    results.push({{
                        macroponent_name: gr.getDisplayValue('name'),
                        macroponent_sys_id: gr.getValue('sys_id'),
                        elementId: r.elementId || '',
                        inputKey: key,
                        address: v.value.address
                    }});
                }}
            }}
        }}
    }}
}}
gs.info('RESULTS:' + JSON.stringify(results));
"""

        url = f"{client.config.instance}/api/now/foundry_script_runner/execute"
        response = client.session.post(url, json={"script": script, "timeout_ms": 30000})

        if response.status_code == 400 and "does not represent any resource" in response.text:
            return "Requires the Foundry Script Runner. Use setup_script_runner to install it."
        if response.status_code not in (200, 201):
            return format_error(response.status_code, response.text[:500])

        result = response.json().get("result", {})
        output = result.get("output", [])
        error = result.get("error")
        timed_out = result.get("timed_out", False)

        if timed_out:
            return f"Search timed out. Try narrowing the scope or increasing timeout_ms.\n{error or ''}"
        if error:
            return f"Script error: {error}"

        results = []
        for line in output:
            if line.startswith("RESULTS:"):
                try:
                    results = json.loads(line[len("RESULTS:"):])
                except Exception:
                    pass
                break

        if not results:
            return f"No macroponent bindings found referencing scriptlet {scriptlet_sys_id}."

        lines = [f"Found {len(results)} binding(s) referencing scriptlet {scriptlet_sys_id}:\n"]
        for r in results:
            lines.append(f"Macroponent: {r.get('macroponent_name', 'N/A')} ({r.get('macroponent_sys_id', 'N/A')})")
            lines.append(f"  elementId:  {r.get('elementId', 'N/A')}")
            lines.append(f"  inputKey:   {r.get('inputKey', 'N/A')}")
            lines.append(f"  address:    {r.get('address', 'N/A')}")
            lines.append("")

        return "\n".join(lines)
