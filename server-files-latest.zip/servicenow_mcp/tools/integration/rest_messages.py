"""Integration and REST API Tools"""

from mcp.server.fastmcp import FastMCP
from ...core.client import get_client
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

def register_tools(mcp: FastMCP):
    """Register integration-related tools with the MCP server."""

    @mcp.tool()
    def query_rest_message_logs(
        url_contains: str = "",
        hostname: str = "",
        method: str = "",
        status: str = "",
        transaction_name: str = "",
        limit: int = 500,
        minutes_ago: int = 15,
        instance: str = None
    ) -> str:
        """
        Query outbound HTTP request logs (sys_outbound_http_log). Shows full request/response payloads,
        headers, timing, and source context for calls ServiceNow made to external systems.

        Use when:
        - An outbound integration is failing or returning unexpected responses
        - OAuth token requests to external systems are rejected
        - API calls are timing out or authentication is failing

        Args:
            method: "GET", "POST", "PUT", or "DELETE"
            status: HTTP response status code (e.g., "200", "401", "500")

        Key fields:
            request_body/response_body: Full payloads — not truncated.
            request_headers/response_headers: Full headers for auth debugging.
            rst/rrt: Request send time / response receive time (for timing analysis).
            source_table/source_record: What triggered this call.
            transaction_name: Links to the REST Message configuration.
        """
        # Build query
        builder = QueryBuilder()
        builder.add_like("url", url_contains)
        builder.add_equals("hostname", hostname)
        builder.add_equals("method", method)
        builder.add_equals("response_status", status)
        builder.add_like("transaction_name", transaction_name)
        builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "DESC")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_outbound_http_log",
            query=query,
            fields=[
                "sys_created_on", "url", "hostname", "path", "method",
                "response_status", "response_time", "rst", "rrt",
                "request_headers", "request_body", "response_headers",
                "response_body", "request_length", "response_length",
                "transaction_name", "source_table", "source_record",
                "mid_server", "system_id", "app_scope"
            ],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No outbound HTTP logs found matching your criteria."

        # Format output
        output = []
        for entry in results:
            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('method', 'N/A')} {entry.get('url', 'N/A')}\n"
                f"Status: {entry.get('response_status', 'N/A')} | Time: {entry.get('response_time', 'N/A')}ms | "
                f"Source: {entry.get('source_table', 'N/A')}/{entry.get('source_record', 'N/A')}\n"
                f"Transaction: {entry.get('transaction_name', 'N/A')} | Node: {entry.get('system_id', 'N/A')} | Scope: {entry.get('app_scope', 'N/A')}\n"
                f"Request ({entry.get('request_length', 'N/A')} bytes): {entry.get('request_body', 'N/A')}\n"
                f"Response ({entry.get('response_length', 'N/A')} bytes): {entry.get('response_body', 'N/A')}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result
