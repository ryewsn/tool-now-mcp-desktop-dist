"""Flow Designer Debugging Tools"""

import re
from mcp.server.fastmcp import FastMCP
from ...core.client import get_client
from ...core.query_builder import QueryBuilder
from ...core.formatters import format_error

def register_tools(mcp: FastMCP):
    """Register flow-related tools with the MCP server."""

    @mcp.tool()
    def query_flow_executions(
        flow_name: str = "",
        state: str = "",
        is_test_run: str = "",
        limit: int = 500,
        minutes_ago: int = 15,
        instance: str = None
    ) -> str:
        """
        Query Flow Designer execution records (sys_flow_context) — the starting point for
        debugging Flow Designer issues. Shows run status, timing, trigger source, and error
        details for each flow execution.

        Use when:
        - A flow isn't triggering, is failing, or completing with errors
        - You need a run history or want to count how many times a flow executed
        - Debugging trigger conditions or flow-level logic

        State choices: WAITING, IN_PROGRESS, COMPLETE, ERROR, CANCELLED, QUEUED,
        PAUSED, PRESUMED_INTERRUPTED, PAUSED_IN_DEBUG

        Use `get_table_schema("sys_flow_context")` to discover all available fields.

        Key fields in results:
        - state: Flow lifecycle state
        - error_message / error_state: Why the flow failed
        - run_time: Execution duration
        - source_table / source_record: Record that triggered the flow
        - sys_id: Pass to query_flow_logs as flow_execution_id (NOT execution_id — that is a public string identifier only)
        - is_test_run / claimed_by: Test flag and cluster node

        Args:
            state: Exact state value (COMPLETE, ERROR, IN_PROGRESS, etc.)
            is_test_run: "true" or "false"
            minutes_ago: Only return executions from the last N minutes (0 removes the time filter)
        """
        # Build query
        builder = QueryBuilder()
        builder.add_like("name", flow_name)
        builder.add_equals("state", state)
        builder.add_equals("is_test_run", is_test_run)
        builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "DESC")

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_flow_context",
            query=query,
            fields=[
                "sys_id", "sys_created_on", "name", "state", "error_message",
                "error_state", "run_time", "source_table", "source_record",
                "execution_id", "is_test_run", "design_source", "claimed_by"
            ],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No flow executions found matching your criteria."

        # Format output
        output = []
        for entry in results:
            error_msg = entry.get('error_message', '')
            error_line = f"\nError: {error_msg}" if error_msg else ""
            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('state', 'N/A')}\n"
                f"Flow: {entry.get('name', 'N/A')} | Run time: {entry.get('run_time', 'N/A')}\n"
                f"Source: {entry.get('source_table', 'N/A')}/{entry.get('source_record', 'N/A')}\n"
                f"Context sys_id: {entry.get('sys_id', 'N/A')} (use with query_flow_logs)\n"
                f"Execution ID: {entry.get('execution_id', 'N/A')} | Test run: {entry.get('is_test_run', 'N/A')}"
                f"{error_line}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def query_flow_logs(
        flow_execution_id: str = "",
        action: str = "",
        level: str = "",
        limit: int = 500,
        instance: str = None
    ) -> str:
        """
        Query flow step log entries (sys_flow_log) for a specific execution. Use after
        query_flow_executions to drill into which step failed, what branch was taken, or
        what messages individual actions emitted — ordered by execution sequence.

        Use when:
        - You know which execution failed and need step-level detail
        - Debugging which conditional branch was taken
        - An action is producing errors or warnings

        Level choices: 0=Info, 1=Warning, 2=Error, -1=Debug

        Use `get_table_schema("sys_flow_log")` to discover all available fields.

        Key fields in results:
        - action / operation: Which step produced the entry and what it did
        - level: Severity (0=Info, 1=Warn, 2=Error, -1=Debug)
        - message: Log content
        - order: Execution sequence number

        Args:
            flow_execution_id: sys_id from the "Context sys_id" field in query_flow_executions output.
                If the public execution_id string is passed instead, it is resolved automatically.
            level: Exact level value — "0"=Info, "1"=Warning, "2"=Error, "-1"=Debug
        """
        # Build query
        builder = QueryBuilder()
        builder.add_equals("context", flow_execution_id)
        builder.add_like("action", action)
        builder.add_equals("level", level)

        # Special handling for ORDER BY - order by execution sequence
        query_str = builder.build()
        if query_str:
            query = f"{query_str}^ORDERBYorder"
        else:
            query = "ORDERBYorder"

        # Execute query
        client = get_client(instance)
        response = client.query_table(
            table_name="sys_flow_log",
            query=query,
            fields=[
                "sys_id", "sys_created_on", "context", "action", "operation",
                "level", "message", "order"
            ],
            limit=limit
        )

        # Handle response
        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]

        # Self-correcting: if no results and a flow_execution_id was provided, the caller
        # may have passed the public execution_id string instead of the sys_flow_context sys_id.
        # Resolve it automatically and retry once.
        if not results and flow_execution_id:
            ctx_response = client.query_table(
                table_name="sys_flow_context",
                query=f"execution_id={flow_execution_id}",
                fields=["sys_id"],
                limit=1
            )
            if ctx_response["success"] and ctx_response["result"]:
                resolved_sys_id = ctx_response["result"][0]["sys_id"]
                builder2 = QueryBuilder()
                builder2.add_equals("context", resolved_sys_id)
                builder2.add_like("action", action)
                builder2.add_equals("level", level)
                query_str2 = builder2.build()
                retry_query = f"{query_str2}^ORDERBYorder" if query_str2 else "ORDERBYorder"
                retry_response = client.query_table(
                    table_name="sys_flow_log",
                    query=retry_query,
                    fields=[
                        "sys_id", "sys_created_on", "context", "action", "operation",
                        "level", "message", "order"
                    ],
                    limit=limit
                )
                if retry_response["success"] and retry_response["result"]:
                    results = retry_response["result"]

        if not results:
            return "No flow log entries found matching your criteria."

        # Format output
        level_map = {"0": "INFO", "1": "WARN", "2": "ERROR", "-1": "DEBUG"}
        output = []
        for entry in results:
            level_display = level_map.get(str(entry.get('level', '')), entry.get('level', 'N/A'))
            output.append(
                f"Step {entry.get('order', '?')}: [{level_display}] {entry.get('action', 'N/A')}\n"
                f"Operation: {entry.get('operation', 'N/A')}\n"
                f"Message: {entry.get('message', 'N/A')}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def query_flow_reports(
        flow_execution_id: str = "",
        flow_name: str = "",
        limit: int = 500,
        minutes_ago: int = 15,
        instance: str = None
    ) -> str:
        """
        Query flow step runtime data (sys_flow_report_doc_chunk) — the actual inputs and
        outputs passed between flow steps, powering the Flow Designer execution detail view.
        Use after query_flow_executions when you need the data values, not just log messages.

        Use when:
        - A flow produced the wrong output and you need to see what data each step received/emitted
        - Debugging what values an If/Else branch evaluated
        - Tracing data transformations through the flow

        Use `get_table_schema("sys_flow_report_doc_chunk")` to discover all available fields.

        Key fields in results:
        - element_type: Flow element type (ACTION, FLOW_LOGIC, etc.)
        - stage: INPUT or OUTPUT data for the step
        - data: Serialized runtime data (truncated at 1000 chars in output)
        - context: FK to sys_flow_context

        Args:
            flow_execution_id: Context sys_id from query_flow_executions
            minutes_ago: Only return data from the last N minutes (0 removes the time filter)
        """
        builder = QueryBuilder()
        builder.add_equals("context", flow_execution_id)
        builder.add_like("name", flow_name)
        builder.add_relative_time("sys_created_on", minutes_ago)

        query = builder.add_order_by("sys_created_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_flow_report_doc_chunk",
            query=query,
            fields=[
                "sys_id", "sys_created_on", "context", "element_id",
                "element_type", "name", "stage", "data"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No flow report data found matching your criteria."

        # Format output
        output = []
        for entry in results:
            data = entry.get('data', '')
            if data and len(data) > 1000:
                data = data[:1000] + "... (truncated)"

            output.append(
                f"[{entry.get('sys_created_on')}] {entry.get('name', 'N/A')}\n"
                f"Type: {entry.get('element_type', 'N/A')} | Stage: {entry.get('stage', 'N/A')}\n"
                f"Context: {entry.get('context', 'N/A')}\n"
                f"Data: {data or '(empty)'}"
            )

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def list_flow_actions(
        name: str = "",
        state: str = "",
        active: str = "",
        sys_scope: str = "",
        limit: int = 100,
        instance: str = None
    ) -> str:
        """
        List Flow Designer action definitions (sys_hub_action_type_definition). Flow actions
        are the reusable building blocks that flows and subflows call as steps. Use this to
        discover available actions and find sys_ids before calling get_flow_action for I/O details.
        Also the correct tool when an AI Agent tool of type "action" references a flow action
        and you need to inspect its metadata.

        **CRITICAL — script content is NOT accessible via the API:** Script steps are stored
        as serialized snapshots. Do not query sys_hub_step_instance, sys_hub_step_ext,
        sys_hub_step_variable, sys_hub_step_config, or sys_hub_script_step — none expose
        readable script source. Direct the user to open Flow Designer in the ServiceNow UI.

        Use get_table_schema("sys_hub_action_type_definition") for all available fields.

        Args:
            state: Exact state — "published", "draft", or "checking_out"
            active: "true" or "false"

        Key fields in results:
        - state: published, draft, or checking_out
        - internal_name: Unique programmatic name (snake_case)
        - access: public or private
        - callable_by_client_api: Whether the action can be invoked via REST API
        - sys_scope: Application scope that owns this action
        """
        import json

        builder = QueryBuilder()
        builder.add_like("name", name)
        builder.add_equals("state", state)
        builder.add_equals("active", active)
        builder.add_like("sys_scope", sys_scope)
        query = builder.add_order_by("sys_updated_on", "DESC")

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_hub_action_type_definition",
            query=query,
            fields=[
                "sys_id", "name", "internal_name", "description", "state",
                "active", "access", "callable_by_client_api",
                "sys_scope", "sys_created_by", "sys_created_on", "sys_updated_on"
            ],
            limit=limit
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return "No flow actions found matching your criteria."

        output = []
        for entry in results:
            lines = [
                f"[{entry.get('sys_updated_on')}] {entry.get('name', 'N/A')}",
                f"State: {entry.get('state', 'N/A')} | Active: {entry.get('active', 'N/A')} | Access: {entry.get('access', 'N/A')}",
                f"Internal name: {entry.get('internal_name', 'N/A')}",
                f"Scope: {entry.get('sys_scope', 'N/A')} | Created by: {entry.get('sys_created_by', 'N/A')}",
                f"Callable by API: {entry.get('callable_by_client_api', 'N/A')}",
            ]
            desc = entry.get('description', '')
            if desc:
                lines.append(f"Description: {desc}")
            lines.append(f"sys_id: {entry.get('sys_id', 'N/A')}")
            output.append("\n".join(lines))

        result = "\n\n---\n\n".join(output)
        if len(results) == limit:
            result += f"\n\nNOTE: Result limit reached ({limit} returned). There may be additional records not shown. Use filters or increase the limit."
        return result

    @mcp.tool()
    def get_flow_action(
        sys_id: str,
        instance: str = None
    ) -> str:
        """
        Get full details for a single Flow Designer action (sys_hub_action_type_definition),
        including I/O variables parsed from label_cache. Use list_flow_actions first to find
        the sys_id.

        **CRITICAL — script content is NOT accessible via the API:** The label_cache field
        provides I/O variable names and types only. Do not query sys_hub_step_instance or
        related tables for script source — they do not expose it. Direct the user to open
        Flow Designer in the ServiceNow UI.

        Args:
            sys_id: sys_id of the flow action to inspect (required)
        """
        import json

        if not sys_id:
            return "Please provide a sys_id."

        client = get_client(instance)
        response = client.query_table(
            table_name="sys_hub_action_type_definition",
            query=f"sys_id={sys_id}",
            fields=[
                "sys_id", "name", "internal_name", "description", "state",
                "active", "access", "callable_by_client_api", "label_cache",
                "sys_scope", "sys_package", "sys_created_by", "sys_created_on",
                "sys_updated_by", "sys_updated_on", "authored_on_release_version"
            ],
            limit=1
        )

        if not response["success"]:
            return format_error(response["status_code"], response.get("error", "Unknown error"))

        results = response["result"]
        if not results:
            return f"No flow action found with sys_id {sys_id}."

        entry = results[0]

        lines = [
            f"=== Flow Action: {entry.get('name', 'N/A')} ===",
            f"Internal name: {entry.get('internal_name', 'N/A')}",
            f"State: {entry.get('state', 'N/A')} | Active: {entry.get('active', 'N/A')} | Access: {entry.get('access', 'N/A')}",
            f"Callable by API: {entry.get('callable_by_client_api', 'N/A')}",
            f"Scope: {entry.get('sys_scope', 'N/A')} | Package: {entry.get('sys_package', 'N/A')}",
            f"Created by: {entry.get('sys_created_by', 'N/A')} on {entry.get('sys_created_on', 'N/A')}",
            f"Updated by: {entry.get('sys_updated_by', 'N/A')} on {entry.get('sys_updated_on', 'N/A')}",
            f"sys_id: {entry.get('sys_id', 'N/A')}",
        ]

        desc = entry.get('description', '')
        if desc:
            lines.append(f"Description: {desc}")

        # Parse label_cache for I/O variable summary
        label_cache_raw = entry.get('label_cache', '')
        if label_cache_raw:
            try:
                labels = json.loads(label_cache_raw)
                inputs = [l for l in labels if l.get('type') == 'action']
                step_outputs = [l for l in labels if l.get('type') == 'step']

                lines.append("\n--- Inputs ---")
                if inputs:
                    for var in inputs:
                        lines.append(f"  {var.get('label', 'N/A')} ({var.get('base_type', 'N/A')})")
                else:
                    lines.append("  (none)")

                lines.append("\n--- Step Outputs ---")
                if step_outputs:
                    for var in step_outputs:
                        lines.append(f"  {var.get('label', 'N/A')} ({var.get('base_type', 'N/A')})")
                else:
                    lines.append("  (none)")

                lines.append(
                    "\nNOTE: Script step source code is NOT accessible via the API — "
                    "open Flow Designer in the ServiceNow UI to inspect script content."
                )
            except (json.JSONDecodeError, TypeError):
                lines.append("\n--- I/O Variables ---")
                lines.append("  (label_cache could not be parsed)")
        else:
            lines.append("\n--- I/O Variables ---")
            lines.append("  (no label_cache available)")

        return "\n".join(lines)

    @mcp.tool()
    def get_flow_execution_error_details(
        execution_id_or_sys_id: str,
        instance: str = None
    ) -> str:
        """
        Get a full failure diagnostic for a Flow Designer execution in one call. Combines
        sys_flow_context (state, error details, run time) with all sys_flow_log entries
        ordered by execution sequence. The first ERROR-level log entry is marked as the
        likely root cause. Use query_flow_executions first, then pass the Context sys_id
        or Execution ID to this tool.

        Accepts either:
          - sys_flow_context sys_id (32-char lowercase hex) — used directly
          - public execution_id string from query_flow_executions — resolved automatically

        Key fields in results:
        - state: ERROR, COMPLETE, CANCELLED, IN_PROGRESS, etc.
        - error_state: ERROR_CAUGHT or ERROR_SKIPPED
        - error_message: Top-level error from sys_flow_context
        - level 2 entries: ERROR-level logs — the first is the likely root cause

        Args:
            execution_id_or_sys_id: sys_flow_context sys_id (32 lowercase hex chars) or
                public execution_id from query_flow_executions output
        """
        if not execution_id_or_sys_id:
            return "execution_id_or_sys_id is required."

        client = get_client(instance)
        is_sys_id = bool(re.match(r'^[0-9a-f]{32}$', execution_id_or_sys_id))

        if is_sys_id:
            ctx_query = f"sys_id={execution_id_or_sys_id}"
        else:
            ctx_query = f"execution_id={execution_id_or_sys_id}"

        ctx_response = client.query_table(
            table_name="sys_flow_context",
            query=ctx_query,
            fields=["sys_id", "name", "state", "error_state", "error_message",
                    "run_time", "execution_id"],
            limit=1
        )

        if not ctx_response["success"]:
            return format_error(ctx_response["status_code"], ctx_response.get("error", "Unknown error"))

        ctx_results = ctx_response["result"]
        if not ctx_results:
            label = "sys_id" if is_sys_id else "execution_id"
            return f"Flow execution not found for {label}: {execution_id_or_sys_id}"

        ctx = ctx_results[0]
        context_sys_id = ctx.get("sys_id", "")

        log_response = client.query_table(
            table_name="sys_flow_log",
            query=f"context={context_sys_id}^ORDERBYorder",
            fields=["sys_id", "action", "operation", "level", "message", "order"],
            limit=500
        )

        if not log_response["success"]:
            return format_error(log_response["status_code"], log_response.get("error", "Unknown error"))

        log_entries = log_response["result"]

        run_ms = ctx.get("run_time", "")
        run_display = f"{run_ms}ms" if run_ms else "N/A"
        error_state = ctx.get("error_state", "")
        error_msg = ctx.get("error_message", "")

        lines = [
            f"Flow Execution: {ctx.get('name', 'N/A')}",
            f"  Context sys_id:  {context_sys_id}",
            f"  Execution ID:    {ctx.get('execution_id', 'N/A')}",
            f"  State:           {ctx.get('state', 'N/A')}",
        ]
        if error_state:
            lines.append(f"  Error state:     {error_state}")
        if error_msg:
            lines.append(f"  Error message:   {error_msg}")
        lines.append(f"  Run time:        {run_display}")

        if not log_entries:
            lines.append("")
            lines.append("No log entries found for this execution.")
            return "\n".join(lines)

        level_map = {"0": "INFO", "1": "WARN", "2": "ERROR", "-1": "DEBUG"}
        first_error_marked = False
        log_lines = [f"\nLog entries ({len(log_entries)} total):"]

        for entry in log_entries:
            level_str = level_map.get(entry.get("level", "0"), entry.get("level", "?"))
            action = entry.get("action", "N/A")
            operation = entry.get("operation", "")
            message = entry.get("message", "")
            order = entry.get("order", "")

            log_lines.append("")
            log_lines.append(f"[{level_str}] {action}" + (f" (#{order})" if order else ""))
            if operation:
                log_lines.append(f"  Operation: {operation}")
            if message:
                log_lines.append(f"  Message:   {message}")
            if level_str == "ERROR" and not first_error_marked:
                log_lines.append("  ← LIKELY ROOT CAUSE")
                first_error_marked = True

        lines.extend(log_lines)
        return "\n".join(lines)
