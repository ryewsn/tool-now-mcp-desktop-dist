"""SDK-backed Flow Action tools — authors Flow Designer Custom Actions via the ServiceNow Fluent SDK.

Registration is gated by SNMCP_ENABLE_SDK_TOOLS=true in .env.

All tools require:
  - Node.js 22+ (NOW_NODE_BIN in .env, set by installer)
  - @servicenow/sdk (NOW_SDK_BIN in .env, installed by installer)
  - Foundry Script Runner (for GitHub credential retrieval)
  - A Fluent scope initialized via init_scope_workspace

Phase 2 (next PR): this workspace will be extended to author AiAgent and AiTool
definitions alongside CustomAction — the SDK supports all three entity types in one
project (confirmed empirically on zyew2, 2026-06-16).
"""
import datetime
from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core import sdk_workspace as ws
from ...core.sdk_runner import run_sdk_command, SdkRunnerError
from ...core.formatters import format_error


def _resolve_scope_prefix(client, scope: str) -> str:
    """Resolve scope prefix or sys_id to a scope prefix string."""
    if len(scope) == 32 and all(c in "0123456789abcdef" for c in scope):
        qb = QueryBuilder()
        qb.add_equals("sys_id", scope)
    else:
        qb = QueryBuilder()
        qb.add_equals("scope", scope)
    resp = client.query_table("sys_scope", query=qb.build(), fields=["scope", "sys_id"], limit=1)
    if resp["success"] and resp.get("result"):
        return resp["result"][0]["scope"]
    return scope  # fall back to as-given


def _build_instance_config(client) -> dict:
    """Build instance_config dict for sdk_runner from client.config."""
    cfg = client.config
    # Determine auth type — check for OAuth attributes first
    has_oauth = bool(getattr(cfg, "client_id", None) and getattr(cfg, "client_secret", None))
    auth_type = "oauth" if has_oauth else "basic"
    config = {"url": cfg.instance, "auth_type": auth_type}
    if auth_type == "oauth":
        config["client_id"] = cfg.client_id
        config["client_secret"] = cfg.client_secret
    else:
        config["username"] = getattr(cfg, "username", "")
        config["password"] = getattr(cfg, "password", "")
    return config


def register_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    def init_scope_workspace(
        scope: str,
        github_org: str = None,
        repo_name: str = None,
        instance: str = None,
    ) -> str:
        """Initialize a git-backed SDK project workspace for a Fluent scope.

        Creates a local workspace at ~/.snmcp/sdk-projects/<scope>/ (or
        SNMCP_SDK_WORKSPACE_DIR), initializes a git repo, creates a GitHub
        remote using the GitHub credential stored in discovery_credentials,
        and pushes the initial commit.

        Safe to call for both MCP-created and UI-created scopes. Idempotent —
        returns a message if workspace already exists.

        Requires the Foundry Script Runner (setup_script_runner) to retrieve
        the GitHub token from discovery_credentials.

        Authoring workflow:
          1. init_scope_workspace — create workspace (this tool)
          2. Fetch SDK docs for your entity type, author TypeScript content
          3. write_workspace_entity — write the .ts file to the workspace
          4. deploy_scope_entities — build and deploy to the instance

        SDK type reference: https://servicenow.github.io/sdk/category/guides
        Unsupported features guide: https://servicenow.github.io/sdk/guides/playbook-unsupported-features-guide

        Args:
            scope: Fluent scope prefix (e.g. "x_snc_myapp_sdk") or sys_id.
            github_org: GitHub org or username to create the repo under.
                        Auto-discovered from your GitHub token if omitted.
                        Required when you have multiple GitHub orgs.
            repo_name: GitHub repo name. Defaults to "snmcp-<scope-prefix>".
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(
            instance, "create a GitHub repository and initialize an SDK workspace"
        )
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        scope_prefix = _resolve_scope_prefix(client, scope)

        if ws.workspace_exists(scope_prefix):
            try:
                existing_manifest = ws.read_manifest(scope_prefix)
            except ws.WorkspaceError:
                existing_manifest = {}
            if existing_manifest.get("github_repo"):
                return (
                    f"Workspace already exists at {ws.get_workspace_path(scope_prefix)}.\n"
                    "Use write_workspace_entity to add entities."
                )
            # Workspace exists but GitHub remote is not configured — resume setup

        try:
            username, token = ws.get_github_credentials(client)
        except ws.WorkspaceError as e:
            return str(e)

        owners = ws.get_github_owner_options(token)
        if not owners:
            return (
                "Could not retrieve GitHub account information. "
                "Ensure the GitHub credential token has 'repo' and 'read:org' scopes."
            )

        selected_owner = github_org
        if not selected_owner:
            if len(owners) == 1:
                selected_owner = owners[0]["login"]
            else:
                owner_list = "\n".join(
                    f"  {i+1}. {o['login']} ({o['type']})" for i, o in enumerate(owners)
                )
                return (
                    "Multiple GitHub accounts found. Call init_scope_workspace again "
                    f"with github_org set to one of:\n{owner_list}"
                )

        if not repo_name:
            repo_name = f"snmcp-{scope_prefix.replace('_', '-')}"

        if not ws.workspace_exists(scope_prefix):
            try:
                ws.init_workspace(scope_prefix, instance or "default")
            except ws.WorkspaceError as e:
                return f"Failed to initialize workspace: {e}"

        try:
            clone_url = ws.create_github_repo(token, selected_owner, repo_name)
        except ws.WorkspaceError as e:
            return f"Failed to create GitHub repo: {e}"

        try:
            ws.git_set_remote_and_push(scope_prefix, username, token, clone_url)
        except ws.WorkspaceError as e:
            return f"Failed to push to remote: {e}"

        manifest = ws.read_manifest(scope_prefix)
        manifest["github_repo"] = clone_url
        ws.write_manifest(scope_prefix, manifest)
        ws.git_commit(scope_prefix, "chore: add github_repo to manifest")

        workspace_path = str(ws.get_workspace_path(scope_prefix))
        return "\n".join([
            f"SDK workspace initialized for scope '{scope_prefix}'.",
            f"  Workspace: {workspace_path}",
            f"  GitHub:    {clone_url}",
            "",
            "Next: use write_workspace_entity to author entities, then deploy_scope_entities to build and deploy.",
        ])

    @mcp.tool()
    def list_scope_entities(scope: str) -> str:
        """List all entities in a scope's local SDK workspace with pending/deployed status.

        Reads the local manifest — does not query the ServiceNow instance.
        Use this to see what has been authored and what is pending deployment.

        Args:
            scope: Fluent scope prefix only (e.g. "x_snc_myapp_sdk"). Sys_id not
                   supported — this tool reads the local workspace only.
        """
        if not ws.workspace_exists(scope):
            return (
                f"No workspace found for scope '{scope}'. "
                "Run init_scope_workspace first."
            )

        try:
            manifest = ws.read_manifest(scope)
        except ws.WorkspaceError as e:
            return str(e)

        entities = manifest.get("entities", {})
        if not entities:
            return f"No entities in workspace for scope '{scope}'. Use write_workspace_entity to add one."

        lines = [f"Scope: {manifest['scope']} | Instance: {manifest.get('instance', 'unknown')}"]
        lines.append(f"GitHub: {manifest.get('github_repo') or 'not configured'}")
        lines.append("")

        for filename, meta in entities.items():
            last_deployed = meta.get("last_deployed")
            if last_deployed:
                status = f"deployed {last_deployed}"
                last_modified = meta.get("last_modified", "")
                if last_modified and last_modified > last_deployed:
                    status = f"PENDING (modified since last deploy at {last_deployed})"
            else:
                status = "PENDING (never deployed)"

            entity_type = meta.get("entity_type", "unknown")
            lines.append(f"• {filename} ({entity_type})")
            lines.append(f"  Status: {status}")

        return "\n".join(lines)

    @mcp.tool()
    def write_workspace_entity(
        scope: str,
        filename: str,
        content: str,
        entity_type: str,
        instance: str = None,
    ) -> str:
        """Write a TypeScript entity file to the scope's SDK workspace.

        Author the TypeScript content by fetching the SDK docs for the entity type,
        then pass the complete file content here. The file is written to
        src/entities/<filename>, tracked in the workspace manifest, and git-committed.

        SDK type reference: https://servicenow.github.io/sdk/category/guides
        Complete examples by type:
          - CustomAction: https://servicenow.github.io/sdk/api/flow/custom-action-api
          - AiAgent + AiAgenticWorkflow: https://servicenow.github.io/sdk/guides/building-ai-agents-guide
          - NowAssistSkillConfig: https://servicenow.github.io/sdk/guides/nowassist-skills-guide

        Idempotent — calling with the same filename overwrites the existing file.
        Run deploy_scope_entities when ready to build and push to the instance.

        Args:
            scope: Fluent scope prefix (e.g. "x_snc_myapp_sdk") or sys_id.
            filename: TypeScript filename, e.g. "get_alert_context.ts". Must end in .ts.
            content: Complete TypeScript source for the entity definition.
            entity_type: Fluent entity class name, e.g. "CustomAction", "AiAgent",
                         "AiAgenticWorkflow", "NowAssistSkillConfig".
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        if not filename.endswith(".ts"):
            return (
                f"filename must end in .ts (got '{filename}'). "
                "Example: 'get_alert_context.ts'"
            )

        client = get_client(instance)
        scope_prefix = _resolve_scope_prefix(client, scope)

        if not ws.workspace_exists(scope_prefix):
            return (
                f"No workspace found for scope '{scope_prefix}'. "
                "Run init_scope_workspace first."
            )

        ws.write_entity_file(scope_prefix, filename, content)

        now = datetime.datetime.utcnow().isoformat() + "Z"
        ws.update_manifest_entity(scope_prefix, filename, {
            "entity_type": entity_type,
            "last_modified": now,
            "last_deployed": None,
        })

        ws.git_commit(scope_prefix, f"feat: write entity '{filename}'")

        workspace_path = str(ws.get_workspace_path(scope_prefix))
        return (
            f"Written: {filename} ({entity_type})\n"
            f"  Workspace: {workspace_path}/src/entities/{filename}\n"
            "\nRun deploy_scope_entities when ready to build and push to the instance."
        )

    @mcp.tool()
    def deploy_scope_entities(
        scope: str,
        instance: str = None,
    ) -> str:
        """Build and deploy all entities in a scope's workspace to ServiceNow.

        Runs `sdk build` (with --errorOnConflict) then `sdk deploy` for the scope's
        local workspace. Reports pending entities (never deployed or modified since
        last deploy) and warns before overwriting any previously deployed entities.

        Build failures return the TypeScript compiler output — fix the source
        via write_workspace_entity then retry. No changes are deployed if build fails.

        Expected duration: ~60 seconds for build + deploy.

        ⚠ Re-deploying will overwrite any edits made in Flow Designer since the
        last deployment. The workspace is the source of truth — UI edits are lost.

        Post-deploy verification (SDK 4.7.2 known behaviors):
        - CustomAction types that land in Draft state are automatically published.
        - Flows that were reset to inactive by SDK install are flagged with instructions
          to open each in Flow Designer → Edit → Save → Activate (use plain Activate
          only with a fresh snapshot to avoid Service Portal catalog crashes).

        Args:
            scope: Fluent scope prefix (e.g. "x_snc_myapp_sdk") or sys_id.
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        client = get_client(instance)
        scope_prefix = _resolve_scope_prefix(client, scope)

        if not ws.workspace_exists(scope_prefix):
            return (
                f"No workspace found for scope '{scope_prefix}'. "
                "Run init_scope_workspace first."
            )

        try:
            manifest = ws.read_manifest(scope_prefix)
        except ws.WorkspaceError as e:
            return str(e)

        actions = manifest.get("entities", {})
        if not actions:
            return f"No entities in workspace for scope '{scope_prefix}'. Use write_workspace_entity first."

        previously_deployed = [
            a for a in actions.values() if a.get("last_deployed")
        ]

        lines = [f"Deploying {len(actions)} entity/entities to '{manifest.get('instance', 'instance')}'..."]

        if previously_deployed:
            lines.append("")
            lines.append(
                "⚠ Previously deployed entities will be overwritten. "
                "Any Flow Designer edits since last deploy will be lost:"
            )
            for a in previously_deployed:
                lines.append(f"  • {a.get('name', a.get('entity_type', 'entity'))} — last deployed {a['last_deployed']}")

        instance_config = _build_instance_config(client)
        workspace_path = str(ws.get_workspace_path(scope_prefix))

        # Build
        try:
            run_sdk_command(["build"], cwd=workspace_path, instance_config=instance_config,
                            error_on_conflict=True)
        except SdkRunnerError as e:
            return f"Build failed — no changes deployed.\n\nCompiler output:\n{e}"

        # Deploy
        try:
            run_sdk_command(["deploy"], cwd=workspace_path, instance_config=instance_config)
        except SdkRunnerError as e:
            return f"Deploy failed.\n\n{e}"

        # Update last_deployed for all entities
        now = datetime.datetime.utcnow().isoformat() + "Z"
        for action_meta in actions.values():
            action_meta["last_deployed"] = now
        try:
            ws.write_manifest(scope_prefix, manifest)
            ws.git_commit(scope_prefix, f"chore: record deploy at {now}")
        except ws.WorkspaceError as e:
            lines.append("")
            lines.append(
                f"⚠ Deploy succeeded but failed to update manifest: {e}\n"
                "Your entities are live on the instance. Run list_scope_entities — "
                "timestamps may not reflect this deploy."
            )

        # Post-deploy verification — SDK 4.7.2 known behaviors
        verification_notes = []

        # 1. Publish any CustomAction types that landed in Draft state
        qb_actions = QueryBuilder()
        qb_actions.add_equals("sys_scope.scope", scope_prefix)
        qb_actions.add_custom("action_status!=published")
        draft_resp = client.query_table(
            "sys_hub_action_type_definition",
            query=qb_actions.build(),
            fields=["sys_id", "name"],
            limit=50,
        )
        if draft_resp.get("success") and draft_resp.get("result"):
            published_names = []
            for action in draft_resp["result"]:
                pub_resp = client.glide_write(
                    "sys_hub_action_type_definition", "update",
                    {"action_status": "published"},
                    sys_id=action["sys_id"],
                )
                if pub_resp.get("success"):
                    published_names.append(action.get("name", action["sys_id"]))
            if published_names:
                verification_notes.append(
                    f"✓ Published {len(published_names)} Draft action type(s): "
                    + ", ".join(published_names)
                )

        # 2. Warn on inactive flows (SDK resets active=false on every install)
        qb_flows = QueryBuilder()
        qb_flows.add_equals("sys_scope.scope", scope_prefix)
        qb_flows.add_equals("active", "false")
        flow_resp = client.query_table(
            "sys_hub_flow",
            query=qb_flows.build(),
            fields=["sys_id", "name"],
            limit=50,
        )
        if flow_resp.get("success") and flow_resp.get("result"):
            flow_names = [f.get("name", f["sys_id"]) for f in flow_resp["result"]]
            verification_notes.append(
                f"⚠ {len(flow_names)} flow(s) reset to inactive by SDK install "
                f"(known behavior, SDK 4.7.2+): {', '.join(flow_names)}\n"
                "  Required: open each flow in Flow Designer → Edit → Save → Activate.\n"
                "  Do NOT use plain Activate — it reuses a stale snapshot and will "
                "crash Service Portal catalog items."
            )

        deployed_names = ", ".join(
            e.get("entity_type", "entity") + ":" + fname
            for fname, e in actions.items()
        )
        lines.append("")
        lines.append(f"✓ {len(actions)} entity/entities deployed: {deployed_names}")

        if verification_notes:
            lines.append("")
            lines.append("Post-deploy verification:")
            lines.extend(f"  {note}" for note in verification_notes)

        return "\n".join(lines)

    @mcp.tool()
    def sync_scope_workspace(
        scope: str,
        github_repo: str,
        workspace_path: str = None,
        instance: str = None,
    ) -> str:
        """Clone a scope's SDK workspace to this machine for cross-machine portability.

        Use this on a new machine to recover a workspace that was initialized
        elsewhere. Clones the GitHub repo and the workspace is ready for
        write_workspace_entity and deploy_scope_entities.

        The github_repo URL is in snmcp.json on the original machine, or find
        it on GitHub. On subsequent calls for the same scope, re-running this
        tool will report that the workspace already exists.

        Note: Run `npm install` in the workspace directory after cloning to
        restore node_modules before running deploy_scope_entities.

        Args:
            scope: Fluent scope prefix (e.g. "x_snc_myapp_sdk") or sys_id.
            github_repo: HTTPS clone URL of the workspace repo
                         (e.g. "https://github.com/myorg/snmcp-x-snc-myapp-sdk.git").
            workspace_path: Local path to clone into. Defaults to
                            ~/.snmcp/sdk-projects/<scope>/.
            instance: ServiceNow instance alias for credential lookup. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "clone an SDK workspace")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        scope_prefix = _resolve_scope_prefix(client, scope)

        if ws.workspace_exists(scope_prefix):
            return (
                f"Workspace already exists at {ws.get_workspace_path(scope_prefix)}. "
                "Delete it first if you want to re-clone."
            )

        try:
            username, token = ws.get_github_credentials(client)
        except ws.WorkspaceError as e:
            return str(e)

        from pathlib import Path
        target = Path(workspace_path) if workspace_path else ws.get_workspace_path(scope_prefix)

        try:
            ws.clone_workspace(github_repo, target, username, token)
        except ws.WorkspaceError as e:
            return f"Clone failed: {e}"

        try:
            ws.write_env_workspace_dir(target.parent)
        except Exception:
            pass  # non-fatal — user can set env var manually

        return "\n".join([
            f"Workspace synced for scope '{scope_prefix}'.",
            f"  Cloned to: {target}",
            f"  SNMCP_SDK_WORKSPACE_DIR written to .env",
            "",
            "Next: run `npm install` in the workspace to restore dependencies, "
            "then use deploy_scope_entities to push to the instance.",
        ])
