"""SDK-backed Flow Action tools — authors Flow Designer Custom Actions via the ServiceNow Fluent SDK.

Registration is gated by SNMCP_ENABLE_SDK_TOOLS=true in .env.
Tool implementations are in the follow-on plan: docs/superpowers/plans/2026-06-15-sdk-flow-action-tool.md
"""
from mcp import FastMCP


def register_tools(mcp: FastMCP) -> None:
    """Register SDK-backed flow action tools. Called by server.py when flag is set."""
    pass
