"""SDK-backed Flow Action tools — authors Flow Designer Custom Actions via the ServiceNow Fluent SDK.

Registration is gated by SNMCP_ENABLE_SDK_TOOLS=true in .env.

All tools require:
  - Node.js 22+ (NOW_NODE_BIN in .env, set by installer)
  - @servicenow/sdk (NOW_SDK_BIN in .env, installed by installer)
  - Foundry Script Runner (for GitHub credential retrieval)
  - A Fluent scope initialized via init_scope_workspace

Phase 2 (next PR): this workspace will be extended to author AiAgent and AiTool
definitions alongside CustomAction — the SDK supports all three entity types in one
project (confirmed empirically on zyew2, 2026-06-16).
"""
import datetime
from mcp.server.fastmcp import FastMCP
from ...core.client import get_client, require_instance_confirmation
from ...core.query_builder import QueryBuilder
from ...core import sdk_workspace as ws
from ...core.sdk_runner import run_sdk_command, SdkRunnerError
from ...core.formatters import format_error


def _resolve_scope_prefix(client, scope: str) -> str:
    """Resolve scope prefix or sys_id to a scope prefix string."""
    if len(scope) == 32 and all(c in "0123456789abcdef" for c in scope):
        qb = QueryBuilder()
        qb.add_equals("sys_id", scope)
    else:
        qb = QueryBuilder()
        qb.add_equals("scope", scope)
    resp = client.query_table("sys_scope", query=qb.build(), fields=["scope", "sys_id"], limit=1)
    if resp["success"] and resp.get("result"):
        return resp["result"][0]["scope"]
    return scope  # fall back to as-given


def _build_instance_config(client) -> dict:
    """Build instance_config dict for sdk_runner from client.config."""
    cfg = client.config
    # Determine auth type — check for OAuth attributes first
    has_oauth = bool(getattr(cfg, "client_id", None) and getattr(cfg, "client_secret", None))
    auth_type = "oauth" if has_oauth else "basic"
    config = {"url": cfg.instance, "auth_type": auth_type}
    if auth_type == "oauth":
        config["client_id"] = cfg.client_id
        config["client_secret"] = cfg.client_secret
    else:
        config["username"] = getattr(cfg, "username", "")
        config["password"] = getattr(cfg, "password", "")
    return config


def register_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    def init_scope_workspace(
        scope: str,
        github_org: str = None,
        repo_name: str = None,
        instance: str = None,
    ) -> str:
        """Initialize a git-backed SDK project workspace for a Fluent scope.

        Creates a local workspace at ~/.snmcp/sdk-projects/<scope>/ (or
        SNMCP_SDK_WORKSPACE_DIR), initializes a git repo, creates a GitHub
        remote using the GitHub credential stored in discovery_credentials,
        and pushes the initial commit.

        Safe to call for both MCP-created and UI-created scopes. Idempotent —
        returns a message if workspace already exists.

        Requires the Foundry Script Runner (setup_script_runner) to retrieve
        the GitHub token from discovery_credentials.

        Args:
            scope: Fluent scope prefix (e.g. "x_snc_myapp_sdk") or sys_id.
            github_org: GitHub org or username to create the repo under.
                        Auto-discovered from your GitHub token if omitted.
                        Required when you have multiple GitHub orgs.
            repo_name: GitHub repo name. Defaults to "snmcp-<scope-prefix>".
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(
            instance, "create a GitHub repository and initialize an SDK workspace"
        )
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        scope_prefix = _resolve_scope_prefix(client, scope)

        if ws.workspace_exists(scope_prefix):
            try:
                existing_manifest = ws.read_manifest(scope_prefix)
            except ws.WorkspaceError:
                existing_manifest = {}
            if existing_manifest.get("github_repo"):
                return (
                    f"Workspace already exists at {ws.get_workspace_path(scope_prefix)}.\n"
                    "Use create_flow_action to add actions."
                )
            # Workspace exists but GitHub remote is not configured — resume setup

        try:
            username, token = ws.get_github_credentials(client)
        except ws.WorkspaceError as e:
            return str(e)

        owners = ws.get_github_owner_options(token)
        if not owners:
            return (
                "Could not retrieve GitHub account information. "
                "Ensure the GitHub credential token has 'repo' and 'read:org' scopes."
            )

        selected_owner = github_org
        if not selected_owner:
            if len(owners) == 1:
                selected_owner = owners[0]["login"]
            else:
                owner_list = "\n".join(
                    f"  {i+1}. {o['login']} ({o['type']})" for i, o in enumerate(owners)
                )
                return (
                    "Multiple GitHub accounts found. Call init_scope_workspace again "
                    f"with github_org set to one of:\n{owner_list}"
                )

        if not repo_name:
            repo_name = f"snmcp-{scope_prefix.replace('_', '-')}"

        if not ws.workspace_exists(scope_prefix):
            try:
                ws.init_workspace(scope_prefix, instance or "default")
            except ws.WorkspaceError as e:
                return f"Failed to initialize workspace: {e}"

        try:
            clone_url = ws.create_github_repo(token, selected_owner, repo_name)
        except ws.WorkspaceError as e:
            return f"Failed to create GitHub repo: {e}"

        try:
            ws.git_set_remote_and_push(scope_prefix, username, token, clone_url)
        except ws.WorkspaceError as e:
            return f"Failed to push to remote: {e}"

        manifest = ws.read_manifest(scope_prefix)
        manifest["github_repo"] = clone_url
        ws.write_manifest(scope_prefix, manifest)
        ws.git_commit(scope_prefix, "chore: add github_repo to manifest")

        workspace_path = str(ws.get_workspace_path(scope_prefix))
        return "\n".join([
            f"SDK workspace initialized for scope '{scope_prefix}'.",
            f"  Workspace: {workspace_path}",
            f"  GitHub:    {clone_url}",
            "",
            "Next: use create_flow_action to author actions, then deploy_scope_actions to build and deploy.",
        ])

    @mcp.tool()
    def list_scope_actions(scope: str) -> str:
        """List all Custom Actions in a scope's local SDK workspace with pending/deployed status.

        Reads the local manifest — does not query the ServiceNow instance.
        Use this to see what has been authored and what is pending deployment.

        Args:
            scope: Fluent scope prefix only (e.g. "x_snc_myapp_sdk"). Sys_id not
                   supported — this tool reads the local workspace only and has no
                   instance to resolve sys_ids against.
        """
        if not ws.workspace_exists(scope):
            return (
                f"No workspace found for scope '{scope}'. "
                "Run init_scope_workspace first."
            )

        try:
            manifest = ws.read_manifest(scope)
        except ws.WorkspaceError as e:
            return str(e)

        actions = manifest.get("actions", {})
        if not actions:
            return f"No actions in workspace for scope '{scope}'. Use create_flow_action to add one."

        lines = [f"Scope: {manifest['scope']} | Instance: {manifest.get('instance', 'unknown')}"]
        lines.append(f"GitHub: {manifest.get('github_repo') or 'not configured'}")
        lines.append("")

        for internal_name, meta in actions.items():
            last_deployed = meta.get("last_deployed")
            if last_deployed:
                status = f"deployed {last_deployed}"
                last_modified = meta.get("last_modified", "")
                if last_modified and last_modified > last_deployed:
                    status = f"PENDING (modified since last deploy at {last_deployed})"
            else:
                status = "PENDING (never deployed)"

            lines.append(f"• {meta.get('name', internal_name)} ({internal_name})")
            lines.append(f"  Status: {status}")
            if meta.get("description"):
                lines.append(f"  {meta['description']}")

        return "\n".join(lines)

    @mcp.tool()
    def create_flow_action(
        name: str,
        internal_name: str,
        description: str,
        scope: str,
        inputs: list,
        outputs: list,
        script: str,
        instance: str = None,
    ) -> str:
        """Author a new Flow Designer Custom Action in the scope's SDK workspace.

        Generates TypeScript source, writes it to the workspace, updates the
        manifest, and auto-commits. Does NOT build or deploy — run
        deploy_scope_actions when ready to push to the instance.

        Args:
            name: Display name (e.g. "Get Alert Context")
            internal_name: snake_case programmatic name (e.g. "get_alert_context").
                           Must be unique within the scope.
            description: Action description shown in Flow Designer.
            scope: Fluent scope prefix or sys_id.
            inputs: List of input definitions. Each: {"name": str, "type": str,
                    "label": str, "mandatory": bool (optional), "table": str (reference only)}.
                    Types: "string", "boolean", "integer", "reference".
            outputs: List of output definitions. Each: {"name": str, "type": str, "label": str}.
            script: GlideScript body executed by the action. Runs server-side in the
                    scope's context — use GlideRecord, gs.*, etc.
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        client = get_client(instance)
        scope_prefix = _resolve_scope_prefix(client, scope)

        if not ws.workspace_exists(scope_prefix):
            return (
                f"No workspace found for scope '{scope_prefix}'. "
                "Run init_scope_workspace first."
            )

        # Guard against accidental overwrite of an existing action
        try:
            existing_manifest = ws.read_manifest(scope_prefix)
            if internal_name in existing_manifest.get("actions", {}):
                return (
                    f"Action '{internal_name}' already exists in scope '{scope_prefix}'. "
                    "Use update_flow_action to modify it."
                )
        except ws.WorkspaceError:
            pass  # manifest doesn't exist yet — first action in scope

        action_def = {
            "name": name,
            "internal_name": internal_name,
            "description": description,
            "inputs": inputs or [],
            "outputs": outputs or [],
            "script": script or "",
        }

        ts_content = ws.generate_action_ts(action_def)
        ws.write_action_file(scope_prefix, internal_name, ts_content)

        now = datetime.datetime.utcnow().isoformat() + "Z"
        ws.update_manifest_action(scope_prefix, internal_name, {
            **action_def,
            "last_modified": now,
            "last_deployed": None,
        })

        ws.git_commit(scope_prefix, f"feat: add flow action '{internal_name}'")

        return (
            f"Written: {internal_name} ({name})\n"
            f"  Workspace: {ws.get_workspace_path(scope_prefix)}/src/actions/{internal_name}.ts\n"
            "\nRun deploy_scope_actions when ready to build and push to the instance."
        )

    @mcp.tool()
    def update_flow_action(
        internal_name: str,
        scope: str,
        name: str = None,
        description: str = None,
        inputs: list = None,
        outputs: list = None,
        script: str = None,
        instance: str = None,
    ) -> str:
        """Update an existing Custom Action in the scope's SDK workspace.

        Merges the provided fields with the existing action definition, regenerates
        the TypeScript file, updates the manifest, and auto-commits. Omitted
        parameters retain their existing values.

        Does NOT build or deploy — run deploy_scope_actions when ready.

        Args:
            internal_name: snake_case name of the action to update.
            scope: Fluent scope prefix or sys_id.
            name: Updated display name (optional).
            description: Updated description (optional).
            inputs: Replacement input list (optional — replaces all inputs if provided).
            outputs: Replacement output list (optional — replaces all outputs if provided).
            script: Replacement script body (optional).
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        client = get_client(instance)
        scope_prefix = _resolve_scope_prefix(client, scope)

        if not ws.workspace_exists(scope_prefix):
            return (
                f"No workspace found for scope '{scope_prefix}'. "
                "Run init_scope_workspace first."
            )

        try:
            manifest = ws.read_manifest(scope_prefix)
        except ws.WorkspaceError as e:
            return str(e)

        if internal_name not in manifest.get("actions", {}):
            return (
                f"Action '{internal_name}' not found in workspace. "
                "Use create_flow_action to create it."
            )

        existing_meta = manifest["actions"][internal_name]

        action_def = {
            "name": name if name is not None else existing_meta.get("name", internal_name),
            "internal_name": internal_name,
            "description": description if description is not None else existing_meta.get("description", ""),
            "inputs": inputs if inputs is not None else existing_meta.get("inputs", []),
            "outputs": outputs if outputs is not None else existing_meta.get("outputs", []),
            "script": script if script is not None else existing_meta.get("script", ""),
        }

        ts_content = ws.generate_action_ts(action_def)
        ws.write_action_file(scope_prefix, internal_name, ts_content)

        now = datetime.datetime.utcnow().isoformat() + "Z"
        ws.update_manifest_action(scope_prefix, internal_name, {
            **action_def,
            "last_modified": now,
            "last_deployed": existing_meta.get("last_deployed"),
        })

        ws.git_commit(scope_prefix, f"feat: update flow action '{internal_name}'")

        return (
            f"Updated: {internal_name}\n"
            "\nRun deploy_scope_actions when ready to build and push to the instance."
        )

    @mcp.tool()
    def deploy_scope_actions(
        scope: str,
        instance: str = None,
    ) -> str:
        """Build and deploy all Custom Actions in a scope's workspace to ServiceNow.

        Runs `sdk build` then `sdk deploy` for the scope's local workspace.
        Reports pending actions (never deployed or modified since last deploy)
        and warns before overwriting any previously deployed actions.

        Build failures return the TypeScript compiler output — fix the source
        via update_flow_action then retry. No changes are deployed if build fails.

        Expected duration: ~60 seconds for build + deploy.

        ⚠ Re-deploying will overwrite any edits made in Flow Designer since the
        last deployment. The workspace is the source of truth — UI edits are lost.

        Args:
            scope: Fluent scope prefix (e.g. "x_snc_myapp_sdk") or sys_id.
            instance: ServiceNow instance alias. Uses default if omitted.
        """
        client = get_client(instance)
        scope_prefix = _resolve_scope_prefix(client, scope)

        if not ws.workspace_exists(scope_prefix):
            return (
                f"No workspace found for scope '{scope_prefix}'. "
                "Run init_scope_workspace first."
            )

        try:
            manifest = ws.read_manifest(scope_prefix)
        except ws.WorkspaceError as e:
            return str(e)

        actions = manifest.get("actions", {})
        if not actions:
            return f"No actions in workspace for scope '{scope_prefix}'. Use create_flow_action first."

        previously_deployed = [
            a for a in actions.values() if a.get("last_deployed")
        ]

        lines = [f"Deploying {len(actions)} action(s) to '{manifest.get('instance', 'instance')}'..."]

        if previously_deployed:
            lines.append("")
            lines.append(
                "⚠ Previously deployed actions will be overwritten. "
                "Any Flow Designer edits since last deploy will be lost:"
            )
            for a in previously_deployed:
                lines.append(f"  • {a['name']} — last deployed {a['last_deployed']}")

        instance_config = _build_instance_config(client)
        workspace_path = str(ws.get_workspace_path(scope_prefix))

        # Build
        try:
            run_sdk_command(["build"], cwd=workspace_path, instance_config=instance_config)
        except SdkRunnerError as e:
            return f"Build failed — no changes deployed.\n\nCompiler output:\n{e}"

        # Deploy
        try:
            run_sdk_command(["deploy"], cwd=workspace_path, instance_config=instance_config)
        except SdkRunnerError as e:
            return f"Deploy failed.\n\n{e}"

        # Update last_deployed for all actions
        now = datetime.datetime.utcnow().isoformat() + "Z"
        for action_meta in actions.values():
            action_meta["last_deployed"] = now
        try:
            ws.write_manifest(scope_prefix, manifest)
            ws.git_commit(scope_prefix, f"chore: record deploy at {now}")
        except ws.WorkspaceError as e:
            lines.append("")
            lines.append(
                f"⚠ Deploy succeeded but failed to update manifest: {e}\n"
                "Your actions are live on the instance. Run list_scope_actions — "
                "timestamps may not reflect this deploy."
            )

        deployed_names = ", ".join(a["name"] for a in actions.values())
        lines.append("")
        lines.append(f"✓ {len(actions)} action(s) deployed: {deployed_names}")
        return "\n".join(lines)

    @mcp.tool()
    def sync_scope_workspace(
        scope: str,
        github_repo: str,
        workspace_path: str = None,
        instance: str = None,
    ) -> str:
        """Clone a scope's SDK workspace to this machine for cross-machine portability.

        Use this on a new machine to recover a workspace that was initialized
        elsewhere. Clones the GitHub repo, sets SNMCP_SDK_WORKSPACE_DIR in .env,
        and the workspace is ready for deploy_scope_actions.

        The github_repo URL is in snmcp.json on the original machine, or find
        it on GitHub. On subsequent calls for the same scope, re-running this
        tool will report that the workspace already exists.

        Note: Run `npm install` in the workspace directory after cloning to
        restore node_modules before running deploy_scope_actions.

        Args:
            scope: Fluent scope prefix (e.g. "x_snc_myapp_sdk") or sys_id.
            github_repo: HTTPS clone URL of the workspace repo
                         (e.g. "https://github.com/myorg/snmcp-x-snc-myapp-sdk.git").
            workspace_path: Local path to clone into. Defaults to
                            ~/.snmcp/sdk-projects/<scope>/.
            instance: ServiceNow instance alias for credential lookup. Uses default if omitted.
        """
        confirmation_error = require_instance_confirmation(instance, "clone an SDK workspace")
        if confirmation_error:
            return confirmation_error

        client = get_client(instance)
        scope_prefix = _resolve_scope_prefix(client, scope)

        if ws.workspace_exists(scope_prefix):
            return (
                f"Workspace already exists at {ws.get_workspace_path(scope_prefix)}. "
                "Delete it first if you want to re-clone."
            )

        try:
            username, token = ws.get_github_credentials(client)
        except ws.WorkspaceError as e:
            return str(e)

        from pathlib import Path
        target = Path(workspace_path) if workspace_path else ws.get_workspace_path(scope_prefix)

        try:
            ws.clone_workspace(github_repo, target, username, token)
        except ws.WorkspaceError as e:
            return f"Clone failed: {e}"

        try:
            ws.write_env_workspace_dir(target.parent)
        except Exception:
            pass  # non-fatal — user can set env var manually

        return "\n".join([
            f"Workspace synced for scope '{scope_prefix}'.",
            f"  Cloned to: {target}",
            f"  SNMCP_SDK_WORKSPACE_DIR written to .env",
            "",
            "Next: run `npm install` in the workspace to restore dependencies, "
            "then use deploy_scope_actions to push to the instance.",
        ])
