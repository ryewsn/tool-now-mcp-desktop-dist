from __future__ import annotations
import asyncio
import logging
import sys
import time
from pathlib import Path
from typing import Any, Callable, Sequence
from dotenv import load_dotenv
load_dotenv(Path(__file__).parent / ".env")
from mcp.server.fastmcp import FastMCP
from mcp.types import ContentBlock, TextContent
from servicenow_mcp import __version__
from servicenow_mcp.config.settings import get_config
from servicenow_mcp.tools import register_all_tools
from servicenow_mcp.core.update_check import update_notice
from servicenow_mcp.core import telemetry
from servicenow_mcp.core.telemetry import emit_event

# Diagnostic log for failed write operations — captures HTTP response bodies to
# help trace intermittent failures (e.g. 403s) that aren't surfaced in tool output.
_diag_log_path = Path(__file__).parent / ".mcp_diagnostic.log"
_diag_handler = logging.FileHandler(_diag_log_path, encoding="utf-8")
_diag_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
logging.getLogger("servicenow_mcp.diagnostic").addHandler(_diag_handler)
logging.getLogger("servicenow_mcp.diagnostic").setLevel(logging.DEBUG)


class UpdateAwareMCP(FastMCP):
    """FastMCP subclass that appends an update notice to the first tool response per session.

    Also forces structured_output=False for all tools. MCP SDK >=1.26 auto-generates
    an outputSchema from return type annotations (e.g. -> str), which then requires
    structuredContent in the response. Our tools return plain strings, so we disable this.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._update_notice_sent = False

    def tool(self, *args: Any, **kwargs: Any) -> Callable:
        kwargs.setdefault("structured_output", False)
        return super().tool(*args, **kwargs)

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> Sequence[ContentBlock]:
        t0 = time.monotonic()
        raw = await super().call_tool(name, arguments)
        duration_ms = int((time.monotonic() - t0) * 1000)
        if not isinstance(raw, (list, tuple)):
            if telemetry.ENABLED:
                asyncio.create_task(emit_event(name, [], arguments, duration_ms))
            return raw
        result = list(raw)
        if telemetry.ENABLED:
            asyncio.create_task(emit_event(name, result, arguments, duration_ms))
        if not self._update_notice_sent and update_notice:
            self._update_notice_sent = True
            text_blocks = [i for i, b in enumerate(result) if isinstance(b, TextContent)]
            if text_blocks:
                idx = text_blocks[-1]
                result[idx] = TextContent(type="text", text=result[idx].text + update_notice)
            else:
                result.append(TextContent(type="text", text=update_notice))
        return result


# Validate configuration at startup
try:
    config = get_config()
    default_instance = config.get_instance()
    print(f"Connected to ServiceNow instance: {default_instance.instance}", file=sys.stderr)
except ValueError as e:
    print(f"Configuration error: {e}", file=sys.stderr)
    exit(1)

# Create MCP server
mcp = UpdateAwareMCP(f"servicenow-mcp v{__version__}")

# Register all tools
register_all_tools(mcp)

# Run server
if __name__ == "__main__":
    mcp.run()
